---
title: "Connector API - Swagger"
weight: 2
type: swagger
toc_hide: true
hide_summary: true
---

## Instructions for use

1. Select a server on the left hand side below, server will be 





 {{< swaggerui src="/swagger/connectorAPI.yaml" >}}
