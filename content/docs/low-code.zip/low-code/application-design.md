---
title: "Application design principles"
weight: 1
typora-root-url: ..\..\..\static
---

{{% pageinfo color="primary" %}}
Page under construction
{{% /pageinfo %}}
