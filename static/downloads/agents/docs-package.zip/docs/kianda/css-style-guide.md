# Kianda CSS and interface styling guide

**Document version:** 1.0.0  
**Prepared:** 2026-10-27  
**Intended location:** `docs/kianda/css-style-guide.md`  
**Audience:** AI agents and developers creating or changing Kianda processes, pages and custom components.  
**Companion contracts:** Process package 1.1.0 and page authoring package 1.0.0.  
**Verification boundary:** Documentation and source inspection. No application was executed, visually tested or certified for accessibility during preparation of this guide.

## 1. Purpose and working rules

Design Kianda applications with a professional, authoritative and clean enterprise interface. Make purpose, grouping, choices, actions and feedback easy to understand. Apply Material Design principles through the supported Kianda controls, Bootstrap 3 layout conventions and styles actually available in the target workspace. A design principle does not imply that a Material component library, font, icon set or token system is installed. [PROC §2, §14; PAGE §2, §6]

Use this guide with [general.md](./general.md), the relevant [process knowledge](./process-knowledge.md) or [page knowledge](./page-knowledge.md), and [custom addon knowledge](./custom-addon-knowledge.md) when component code is involved. The schemas remain [process-schema.json](./process-schema.json) and [page-schema.json](./page-schema.json).

Before changing presentation:

1. Identify the affected process fields, page widgets or custom component. Inspect their settings, class strings, content and dependencies.
2. Read the workspace stylesheet and identify inherited styles and later overrides. Verify that the proposed utility exists in the effective styling environment.
3. Use the correct persisted property for the level being edited. Keep layout classes, extra styling classes and native component settings distinct.
4. Prefer an established component and utility combination. Add scoped CSS when the existing vocabulary does not meet the requirement.
5. Preserve logical names, identifiers, bindings, rules, values, permissions and unrelated settings during a styling change.
6. Review the changed interface with realistic content and states when a runtime is available. Report which checks were actually performed.
7. Document substantive changes in the workspace's root `CHANGELOG.md`, including affected shared styles, dependencies and outstanding runtime checks.

Sections describing exact keys or selectors are source-based contracts or observations. Sections labelled as authoring recommendations describe design practice; they do not add required JSON properties or platform guarantees.

## 2. Styling sources and availability

### 2.1 Documented defaults and workspace overrides

The internal styling guide describes ten utilities shipped with the default global CSS. It explicitly allows workspace changes and overrides. Seven utilities target process fields and three target page widgets. Treat them as documented defaults with a known intended use, while checking the actual target workspace before relying on their appearance. [STYLE pp. 1–3]

The supplied `app.css` starts with an external `@import` of an public `app-style.css`, followed by a comment identifying workspace-specific CSS. Its local declarations implement several application-specific treatments. The imported stylesheet was retrieved and inspected completely: it contains selectors for all ten documented utilities. Section 4.4 records implementation details and differences from the prose guide. This is evidence for that inherited snapshot, not proof that every customer loads the same source. [CSS; SHARED]

The import is a dependency of that particular workspace. Preserve its intended role when editing that workspace; do not copy its tenant-specific URL into a generic Kianda application or replace a target's import as part of an unrelated styling task. The inherited source itself imports Animate.css 4.1.1. That is an observed dependency of this snapshot, not a required Kianda dependency or evidence that the animation stylesheet has loaded in every runtime. [SHARED]

An effective style can depend on the inherited stylesheet, local overrides, selector specificity, loaded framework styles and the rendered DOM. A utility's documented name is not proof that its source has loaded or that an overriding declaration has not changed it.

### 2.2 Source authority

Use the following distinctions throughout this guide:

| Evidence | What it establishes | What remains to be checked |
| --- | --- | --- |
| Internal styling guide | Intended utilities, component context and UI configuration labels | Current declarations, active overrides and computed appearance |
| Process/page knowledge and schemas | Persisted property names, supported shapes and documented behaviour | Rendered usability and component-specific behaviour outside those contracts |
| Inspected stylesheet | Exact declarations and selectors in that source snapshot | Whether the target loads it, whether selectors match and how the cascade resolves |
| Existing application JSON | How a particular saved application is configured | Whether its configuration is current, supported for a new application or appropriate for another tenant |
| Runtime inspection | Appearance and behaviour observed in the tested environment | Untested devices, data sets, permissions and other environments |

The source register at the end identifies the evidence used. Do not promote a tenant class or a visually plausible result into a universal platform feature.

## 3. Put styling in the correct property

| Object or location | Property or mechanism | Instruction |
| --- | --- | --- |
| Process field | `field.class` | Current persisted layout class string. Use for grid classes such as `col-sm-12`. Preserve the exact key. |
| Process field | `field.customCssClass` | Additional visual or behaviour-associated class tokens, such as `panel-card`. |
| Process field | `field.settings.mobileClass` | Existing nested mobile layout setting. Keep it nested and preserve its value unless deliberately changing the layout. Its precedence against other layout settings requires runtime inspection. |
| Process static text | `field.text` and `field.settings.controlBgScheme` | Content and documented background treatment for `fields/field-text`. These are distinct from its logical `name` and design `title`. |
| Page widget | `widget.class` | Responsive widget layout string. Use the existing Bootstrap 3 vocabulary. |
| Page widget | `widget.customCssClass` | Additional utility classes, such as `widget-section-title` or `widget-filter-compact`. |
| Page widget | Outer `widget.colorScheme` | Widget frame treatment; `panel-default` is documented. This does not establish the same property on a process panel. |
| Page container | `page.settings.containers[]` entries with `name`, `desktopClass`, `mobileClass` | Container layout declarations. A widget selects one through `widget.settings.container`. |
| Native page Link item | Item-level `cssClass` | A separate, real property in that item's contract. Do not globally replace every `cssClass` in a page. |
| Custom component template | Classes on HTML elements the component owns | Use stable, scoped classes and follow the component's actual rendering contract. Inspect the outer field/widget wrapper separately. |
| Workspace global stylesheet | `styles/app.css` in the proposed workspace layout | Shared styling with potential impact across applications. The extension's server filename mapping is a separate concern. |

Both field and widget layout use `class`, not `cssClass`. The process schema accepts an existing field `cssClass` for compatibility, but its documentation explicitly says that the proposed rename was not implemented. Schema acceptance does not establish how an extension or server will retain that property. Preserve unfamiliar existing data; generate the current `class` property. [PROC §6, §14.1; PS `$defs/Field`; PAGE §4–6; PG `$defs/Widget`, `$defs/LinkItem`]

Class values are tokens without a leading dot. Multiple tokens are separated by spaces. For example, `customCssClass: "section-title expandable-section"` contains two classes. Retain unrelated tokens when adding or removing a treatment. A token such as `expandable-section` does not by itself establish that an expand/collapse interaction exists. [PROC §14.1, §14.5]

Do not turn native settings into CSS merely to simplify serialization. Buttons have their own documented presentation settings, and list settings control whether an input is a radio list or a checkbox list. Styling does not change selection semantics or save behaviour.

## 4. Documented utility catalogue

The following class names are clean tokens transcribed from the internal guide. Invisible U+200B characters found after some class names in the DOCX have been removed in this reference. Do not copy those invisible characters into application JSON or selectors. [STYLE]

### 4.1 Process field utilities

| Class | Intended field and configuration | Documented effect | Important limit |
| --- | --- | --- | --- |
| `panel-card` | `fields/field-panel`; guide UI choice: Colour scheme = `panel-default` | White rounded panel grouping related content | The process panel's serialized key for that UI colour choice is unresolved; preserve saved settings or obtain a confirmed example. |
| `radio-list-card` | `fields/field-list`; Radio list; Vertical position | Full-width white choice cards with rounded corners | Retain single-selection behaviour and the actual option values. The guide recommends using its own surface outside another card where suitable. |
| `checkbox-list-card` | `fields/field-list`; Checkbox list; Vertical position | Corresponding card presentation for multiple selections | A checkbox list remains multi-select. Do not swap its mode for a different appearance. |
| `radio-list-button` | `fields/field-list`; Radio list; Vertical position in the guide's recipe | Rounded button treatment for choices; the guide describes possible Yes/No colours | The inspected implementation targets different exact values; see §4.4. Existing horizontal configurations are observed and should not be automatically rewritten. |
| `section-title` | `fields/field-text`; background choice `bg-primary`, `bg-warning`, `bg-info` or `bg-success` | Larger static section text with a background treatment and soft corners | Styling `field.text` does not prove semantic heading markup or an accessible name. |
| `table-no-style` | `fields/field-table` | Removes usual table borders/shading for compositions such as repeating cards | Preserve repeating row structure, operations and data. This is a field-table utility, separate from the page `Content` treatment. |
| `image-thumbnails` | `fields/field-image`; File field source; inline images enabled | Consistent thumbnail presentation; the guide describes `object-fit: cover` | Cropping can hide evidence details. Preserve a supported way to inspect the original image. |

Sources: [STYLE pp. 1–2; PROC §14.2–14.4]. These recipes are not mandatory schema properties. Do not apply every class to every type of field.

### 4.2 Exact process settings and unresolved mapping

| Desired configuration | Source-supported representation |
| --- | --- |
| Radio list | `settings.displayformat: "radiolist"` |
| Checkbox list | `settings.displayformat: "checkboxlist"` |
| Vertical list | `settings.radiodisplayposition: "vertical"` |
| Static section background | `settings.controlBgScheme: "bg-primary"` is observed with `section-title`; the styling guide also documents the other background choices above |
| Images from a file field | `settings.imagesource: "file"`, `settings.inlineImages: "yes"`, and an actual field descriptor in `settings.fileSource` |
| Process panel UI colour choice `panel-default` | Serialized key/value mapping remains unresolved in the supplied process contract |

For a process panel, neither the open `settings` object nor a similarly named widget property justifies inventing `settings.colorScheme`. `settings.cardPanel` is also distinct from `customCssClass: "panel-card"`; the package records empty-string `cardPanel` values and does not define a conversion between the two. [PROC §14.1–14.3; PS `$defs/PanelSettings`]

The following is a property excerpt for an existing field, not a complete field definition or a destructive replacement of its `settings`:

```json
{
  "type": "fields/field-list",
  "class": "col-sm-12",
  "customCssClass": "radio-list-button",
  "settings": {
    "displayformat": "radiolist",
    "radiodisplayposition": "vertical"
  }
}
```

Retain identities, choices, source bindings, rules and any other settings. Obtain actual stored values from the target application. The process guide distinguishes `radio-button-list`, observed in some existing data, from the documented `radio-list-button`; they must not be silently treated as interchangeable. [PROC §14.2–14.4]

### 4.3 Page widget utilities

| Class | Intended widget and configuration | Documented effect |
| --- | --- | --- |
| `widget-filter-tabs` | `widgets/widget-filter` with `settings.filterType: "radiolist"` | Presents radio options as a tab-like strip above the connected results region |
| `widget-section-title` | `widgets/widget-html` using `colorScheme: "panel-default"` | Guide describes a cleared frame background and faint lower separator; the inspected rule clears the frame but does not add that separator |
| `widget-filter-compact` | `widgets/widget-filter` | Reduces padding around the frame |

Apply these through `widget.customCssClass`. Process-field utilities do not automatically apply to page widgets with different markup. [STYLE pp. 2–3; PAGE §6.2]

A tab-like appearance does not create filter connections, routes or page security. Configure the real filter and its target connections using the page contract. Preserve default values, runtime state handling and query semantics. Do not add tab roles or keyboard assumptions unless the rendered widget implements the corresponding interaction.

An HTML heading widget should avoid repeating the same title in both its frame and inner content. The following is a partial presentation excerpt; retain the widget's identity, owning page and other settings:

```json
{
  "type": "widgets/widget-html",
  "class": "col-md-12 col-sm-12",
  "showHeader": false,
  "colorScheme": "panel-default",
  "customCssClass": "widget-section-title",
  "settings": {
    "container": "",
    "content": "<h2>Project overview</h2>"
  }
}
```

Choose the heading level for the surrounding document structure. The example's text is illustrative, and `showHeader: false` is a deliberate choice for this composition, not a required value for every widget. [PAGE §15.3]

### 4.4 Details verified in the inherited stylesheet

These are exact source observations from the retrieved snapshot, not mandatory branding tokens or computed runtime results. Other declarations can change the outcome. [SHARED]

| Utility | Verified selector or treatment | Practical implication |
| --- | --- | --- |
| `panel-card` | `.panel-card.form-group`: white background, 12px radius and `#e7eaee` border | Requires the expected wrapper classes. The separate `.card-panel` selector has a 10px radius; these names are not interchangeable. |
| `radio-list-card` | `.radio-list-card.form-group>div>span>label`: white cards, shadow, 4px radius, padding and negative left margin | Depends on native list markup. Inspect narrow layouts and overflow. |
| `checkbox-list-card` | `.checkbox-list-card.form-group>div>div`: white cards, shadow, 4px radius and padded content | Uses a different descendant structure from radio cards. |
| `radio-list-button` | Flex wrapping and label/overlay styling; exact value selectors for `OK`, `NOK` and `N/A` | Those selectors provide green, red and grey treatments respectively. The local Yes/No rules apply only to `?inlineButtons`, not this class. |
| `section-title` | `.section-title.form-group` removes shadow, uses 4px corners and bottom margin; nested `.field-richtext-content` is `1.4em` | The rule does not supply a background colour. Preserve the native background setting. |
| `table-no-style` | Removes panel/table treatments, hides `thead`, allows visible horizontal overflow and changes footer/link spacing | More than a cosmetic border change. Review headings, row controls and wide content. |
| `image-thumbnails` | Flex layout; nested `img` uses 110px width/height, 5px corners and `object-fit: cover` | These dimensions belong to this snapshot. Thumbnail cropping is confirmed in source. |
| `widget-filter-tabs` | Horizontally scrollable inline-flex form; selected `.radio-filter.is-checked` gets transparent background; `.radio-filter span.fa` is hidden | Check selection and focus remain perceivable without the hidden icon. |
| `widget-section-title` | `.page-widget.widget-section-title>.panel` removes background, border, shadow, margin, radius and padding | No lower separator is declared here. Verify any expected separator through the remaining styles or deliberately add a scoped treatment. |
| `widget-filter-compact` | Heading padding is 5px with 15px on the left; body padding is 5px | Compactness is a source-specific frame treatment. Check labels, focus and controls remain usable. |

For `radio-list-button`, a later generic checked-state rule has `background: none !important`. The value-specific rules also use `!important` and have higher specificity, so source order alone is not enough to explain a colour difference. Inspect the actual stored value, matching selectors and complete cascade. Preserve values used by rules and integrations; change presentation deliberately instead of renaming values to obtain a colour.

## 5. Composition rules that preserve application behaviour

### 5.1 Sections and cards

Use a static text field with `section-title` to establish a meaningful process section, followed by a `panel-card` containing related inputs where grouping helps the task. Keep the section's content separate from field naming and identity. Choose an existing palette treatment instead of assigning different colours to every section. Maintain consistent spacing between headings, cards and primary actions. [PROC §14.4–14.5]

Avoid unnecessary layers of nested cards. The card-style radio and checkbox lists already have their own surface treatment. Select the treatment that communicates the grouping without making every input appear equally prominent.

### 5.2 Repeating cards inside a process table

The process package documents `table-no-style` on a table with a `fields/table-row` child. Inside that row, the first child is a `fields/field-panel` using `panel-card`; the panel contains the repeated business fields. [PROC §14.4]

Preserve the full table/row/descendant structure, field scope, row operations and bindings. Repeated content still has a table lifecycle. Do not flatten it into unrelated panels or duplicate fixed panels to imitate repetition. The observed recipe does not require every table to contain exactly one panel or a particular number of stored rows.

### 5.3 Page lists in a container named Content

The page package records owner-confirmed default CSS for the exact container name `Content`. It hides the list table header and every body cell except the first. The relevant selector is:

```css
div[data-container="Content"]>div.widget-list .table-bordered>tbody>tr>td:not(:first-child) {
  display: none;
}
```

This excerpt explains an existing documented treatment; it is not an instruction to inject it into every page. The inherited stylesheet also contains this hiding selector and the header-hiding rule. Its nearby selector intended to set `table-layout: fixed` is preceded by a stray `*/`; do not assume that malformed rule applies or copy it into new CSS. The target's complete effective styling still requires runtime verification. [PAGE §6.3; SHARED]

For a card list, place the rendered card column first. Keep hidden projections required by its Handlebars template: hidden cells can still supply necessary row data. Review every list in the named container because the selector is not limited to one widget. Use a different container or a deliberately verified scoped treatment for an ordinary multi-column table.

Preserve container names unless a rename is part of the requested change. A rename can alter selectors as well as `settings.container` references. Container declaration order and widget order are both meaningful inputs; the exact rendering algorithm across containers is not established by the supplied material. [PAGE §6.1, §6.3]

### 5.4 Uploads and thumbnails

Use the existing file field for upload and bind a separate image field through a verified descriptor when that composition is appropriate. `image-thumbnails` changes presentation; it does not establish upload, image deletion, annotation, public access or click-to-enlarge behaviour. Check those capabilities in the actual controls. Give users a supported way to inspect evidence at sufficient detail, since a cropped preview can hide relevant content. [PROC §14.3–14.4]

### 5.5 Selection, visibility and security

Retain choice labels and stored values while styling. Yes/No colours can be contextually misleading: for one question “Yes” may be desirable, while for another it may identify a hazard. Use text and selection indicators, and preserve keyboard focus and disabled states.

CSS hiding, transparent text and visual omission do not establish authorization. Keep page and process permissions in their actual security model. Hiding a column also does not remove its data from a query result. [PAGE §13; PROC §14.5–14.6]

## 6. What the supplied workspace stylesheet actually contains

The following observations describe the local declarations in the supplied `app.css`, applied in addition to the inherited source. They are useful examples of dependency and regression concerns, not a portable Kianda utility catalogue. [CSS]

| Selector or family | Source behaviour | Consequence for an agent |
| --- | --- | --- |
| `div[data-name$="?inlineButtons"] .c-radio input[type=radio][value="Yes"]:checked+span` and the `No` variant | Sets a green/red border and translucent background on an adjacent `span`; the background uses `!important` | Requires that exact runtime markup, value spelling and `data-name` suffix. This source does not establish an association with `radio-list-button`. |
| `.expiry-badge-green`, `.expiry-badge-expiring`, `.expiry-badge-expired` | Shared pill-like layout with separate green, orange and red backgrounds, white text and a hover opacity change | Application-specific expiry presentation. Pair with readable status text and inspect actual contrast and states. |
| `#checklist-cards` | Column flex layout, fixed maximum height, shadow and both axes set to hidden overflow | The comment claims vertical scrolling, but `overflow-y: hidden` clips overflow. Assess long-content access before copying or changing the pattern. |
| `div[title="Checklist"] ...` | Styles nested panels, tables and links, removes some decoration and hides `.panel-footer` | Tied to an exact title attribute and broad descendants. Check title changes, localization, footer controls and all matching widgets. |
| `.checklist-item` with `.priority-box` and `.description-box` | Flex links with a 30%/70% split and fixed padding | A tenant card pattern. Check wrapping, long text and narrow-screen reading order. |
| `.checklist-link` | Link spacing, size and pointer cursor | Visual declarations alone do not establish a keyboard-operable action. Inspect the actual element and action wiring. |
| `.clearFiltersButton` | Button-like presentation with padding, background, text colour, border removal and `float: right` | Preserve the actual filter-clear action. Inspect focus, disabled state and layout in the rendered context. |
| `.slide-title-wrapper` and descendants | Flex layout and positioning for a title and image, with the image prevented from shrinking | Application-specific title/image placement. Inspect long titles, image size and constrained widths. |

Do not copy these exact names into unrelated applications simply because they are available in this example. Inspect whether a new component already has an established local pattern. Existing broad or title-dependent selectors should be reviewed when the affected application is changed; their presence is not a request to refactor all shared styling.

The inherited source also contains application-shell changes, named-field selectors, repeated `.dashlist-*` declarations and broad rules. For example, `.common-table td, th` includes an unscoped `th` selector. Review the complete cascade rather than assuming every rule is restricted to its nearby comment or prefix. [SHARED]

## 7. Design recommendations

These recommendations implement the owner's interface objectives. They are not new serialization requirements or a claim that a particular appearance has been tested.

### 7.1 Hierarchy and information density

Show the task's purpose and current context before detailed input or reporting content. Group related fields and give each group a clear heading where needed. Distinguish the main action from supporting actions through wording, position and established button styling. Keep essential instructions close to the decision they support.

Match density to the task. A short mobile inspection can use larger choices and generous separation; a manager's reporting page may use denser tables. Preserve readability and a clear route to the next action in both cases. Use live bound widgets for live metrics rather than hard-coded numbers chosen for a visual mockup. [PROC §14.5; PAGE §6.4]

### 7.2 Typography and spacing

Use the existing workspace font and hierarchy. Keep labels, values, help, section headings and actions consistent across related screens. Avoid shrinking text merely to force content into a fixed-height card. Preserve long labels and meaningful instructions through wrapping and layout adjustment.

Repeat alignment and spacing patterns. Leave more separation between unrelated groups than within a related group. Use restrained surface elevation and corner treatments. The supplied material does not define a mandatory numeric spacing scale, radius, font family or type scale; derive these from the target workspace or an approved design brief. [PROC §14.5, §14.7]

### 7.3 Responsive layout

Use the verified Bootstrap 3 grid vocabulary and component layout properties. Examples such as `col-sm-12` and `col-sm-6` appear in the process package; widget examples include `col-md-12 col-sm-12`. Allow dense groups to stack as needed, retain useful widths for long text and uploads, and check the actual mobile layout behaviour. Do not require all siblings to total twelve columns or assume that the framework's standard breakpoint behaviour overrides Kianda's renderer or tenant CSS. [PROC §6, §14.5; PAGE §5–6]

Modern utility names such as Bootstrap 5 spacing classes are not established by the supplied baseline. Use classes supported in the workspace. Add grid wrappers inside custom HTML/HBS only where that template owns the markup; do not invent an equivalent JSON wrapper property.

### 7.4 Colour and feedback

Use colour to reinforce meaning that is also available through text, icons or another usable cue. Preserve neutral treatments for ordinary grouping and reserve stronger emphasis for actions, selected states and significant feedback. Evaluate the actual foreground/background combination, including hover, focus, selection, error and disabled states.

The process guide identifies WCAG 2.2 contrast criteria as review targets: at least 4.5:1 for ordinary text and 3:1 for qualifying large text, subject to the criterion's definitions and exceptions. These are review criteria, not evidence of compliance. Inspect rendered colours and text sizes before reporting a pass. [PROC §14.6]

### 7.5 Semantics and input access

Keep visible focus, readable labels, useful error messages and keyboard-operable actions. A coloured section band does not automatically provide a semantic heading. A styled `div` or cursor change does not automatically provide button semantics. Use the actual supported controls and appropriate semantic HTML in component-owned templates.

Check focus and reading order after rearranging content. Review zoom, small viewports, long translated labels and repeated rows. Preserve access to full evidence behind thumbnails and to clipped or scrollable content. Avoid animations that distract from task completion, and respect an established reduced-motion treatment when one is available. [PROC §14.6; PAGE §6.4]

## 8. Introducing additional CSS

First identify the specific presentation requirement that existing utilities cannot meet. Find the owning process, page or component, and check current declarations before adding another rule. The global stylesheet is shared: broad selectors can affect other applications and reusable components. [STYLE p. 3]

For component-owned markup, a scoped class gives a clear boundary. This is an illustrative new pattern, not an installed Kianda utility:

```html
<div class="inspection-summary">
  <h3 class="inspection-summary__title">Inspection summary</h3>
  <p class="inspection-summary__details">Details rendered by the component.</p>
</div>
```

```css
.inspection-summary .inspection-summary__title {
  margin-top: 0;
  overflow-wrap: break-word;
}

.inspection-summary .inspection-summary__details {
  margin-bottom: 0;
  overflow-wrap: break-word;
}
```

Choose an appropriate unique prefix for the actual component, and keep semantic, escaped content binding consistent with its template contract. The example demonstrates scoping only; its spacing values are illustrative. Use the established target styling for colours, type sizes, borders and spacing.

Prefer a class you intentionally own to a selector tied to a translated title, generated Ember element ID, temporary DOM order or unrelated descendant. A class attached through `customCssClass` may be on an outer wrapper; inspect its placement before writing descendant selectors. If a more specific override or `!important` is necessary, explain which declaration it addresses and keep its scope narrow.

Preserve unrelated imports and shared rules. Do not add a new remote font, framework or stylesheet merely to reproduce a visual style without establishing that dependency as part of the requested work. Document any intentional import or asset change because it affects availability and deployment.

## 9. Verification and completion

### 9.1 Static checks

- Confirm valid JSON and run the relevant process/page schema validation for changed definitions.
- Check property placement: outer `class` and `customCssClass`, actual component settings, and page container declarations.
- Check class token spelling, casing and invisible characters. Preserve unrelated tokens.
- Identify source declarations, imports and relevant overrides for every newly used utility.
- Inspect affected selectors and their scope. Search dependencies before renaming containers, classes, titles or component markup.
- Preserve process row structures, field descriptors, page projections, queries and connections.
- Review any rules that hide content, footers or controls, constrain height, remove focus decoration or alter table display.

### 9.2 Runtime checks when an environment is available

- Open the affected process/page and verify that the intended styles load and match the expected elements.
- Test large and small viewports, zoom, long labels, empty and populated content, and multiple repeated rows.
- Check hover, focus, selected, unselected, validation, disabled and read-only states that apply.
- Check native operations: selecting values, clearing filters, adding/removing rows, opening links and inspecting uploaded evidence.
- Review other consumers of changed shared styles or reusable components.
- Inspect visible focus, accessible names, heading structure, meaningful feedback and actual contrast.

### 9.3 Report evidence accurately

Record what changed, why, which artifacts are affected, the checks performed, and any remaining deployment or visual review steps in `CHANGELOG.md`. Distinguish schema acceptance, CSS source inspection and runtime verification. JSON Schema does not establish computed styles, content visibility, usable wrapping, accessibility or correct interactions. If the target cannot be opened, report the static checks and the remaining runtime review explicitly. [PROC §14.6; PAGE §6.4]

## 10. Known limits and source register

The following items require target-specific evidence before making a new claim:

- The process panel setting corresponding to the UI's `panel-default` colour choice.
- Which inherited and local styles are loaded in a particular customer workspace, and whether they are overridden.
- An approved cross-workspace palette, font/type scale, numeric spacing/radius system or customised breakpoint policy.
- The actual accessibility and interaction behaviour of a styled native control or custom component.
- Whether a tenant class or helper should be promoted to a shared platform contract.

| Key | Source | Use in this guide |
| --- | --- | --- |
| STYLE | `Kianda Process Apps Styling Guide(1).docx`, supplied 27 October 2026; all three rendered pages inspected | Ten utility names, intended components, UI configuration labels, default-global-CSS statement and override guidance |
| CSS | `app.css`, supplied 27 October 2026; complete file inspected | External inherited stylesheet dependency and exact local workspace selectors/declarations |
| SHARED | Public `app-style.css` referenced by the supplied `app.css`; retrieved 27 October 2026; 73,508 bytes; SHA-256 `da1c59a5e27837e23abf74eac5346c5ff8cd130552f292d38f7c10f5cff1969e` | Complete inherited source inspection: ten utility selectors, value-specific styling, Content behaviour, dependencies and cascade caveats |
| PROC | `process-knowledge.md` from `kianda-process-schema-v1.1.0(1).zip`; particularly §§2, 6 and 14 | Current field layout property, branding objective, utility recipes, observed settings and limitations |
| PS | `kianda-process-schema.json` from that process package | Shapes and comments for field presentation properties and native settings; installed companion filename is `process-schema.json` |
| PAGE | `page-knowledge.md` from `kianda-page-authoring-v1.0.0(1).zip`; particularly §§4–6, 12–13 and 15.3 | Widget/container properties, page utilities, Content container behaviour, visibility boundaries and heading example |
| PG | `kianda-page-schema.json` from that page package | Widget, container and Link-item property contracts; installed companion filename is `page-schema.json` |

