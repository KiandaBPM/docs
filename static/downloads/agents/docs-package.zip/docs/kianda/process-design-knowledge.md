# Kianda process design knowledge

**Version:** 0.1.0 - draft for owner review  
**Prepared:** 29 October 2026  
**Intended location:** `docs/kianda/process-design-knowledge.md`  
**Audience:** Developers and AI agents designing or improving Kianda process experiences.  
**Companions:** `general.md`, `process-knowledge.md`, `process-schema.json`, `css-style-guide.md`; consult `custom-addon-knowledge.md` and page/reporting references when relevant.  
**Scope:** Design judgement, adaptive user journeys and the designer-to-builder handoff. This document does not extend Kianda's JSON contract.  
**Verification boundary:** Based on the owner's requirements, the companion references and static inspection of the selected Incident export. No Kianda application or skill was executed in a target workspace while preparing this draft.

## Contents

1. [Purpose and evidence](#1-purpose-and-evidence)
2. [The process design model](#2-the-process-design-model)
3. [Establish the requirements](#3-establish-the-requirements)
4. [Choose forms, sections and related records](#4-choose-forms-sections-and-related-records)
5. [Specify state without confusing its meanings](#5-specify-state-without-confusing-its-meanings)
6. [Design classification and branching](#6-design-classification-and-branching)
7. [Design transitions and re-entry](#7-design-transitions-and-re-entry)
8. [Handle changes to earlier answers](#8-handle-changes-to-earlier-answers)
9. [Design validation, navigation and actions](#9-design-validation-navigation-and-actions)
10. [Compose the visual experience](#10-compose-the-visual-experience)
11. [Ownership, permissions and consequences](#11-ownership-permissions-and-consequences)
12. [Data, reporting and dependencies](#12-data-reporting-and-dependencies)
13. [Designer-to-builder blueprint](#13-designer-to-builder-blueprint)
14. [Acceptance scenarios and verification](#14-acceptance-scenarios-and-verification)
15. [Annotated Incident reference](#15-annotated-incident-reference)
16. [Common design mistakes](#16-common-design-mistakes)
17. [Readiness, maintenance and sources](#17-readiness-maintenance-and-sources)

## 1. Purpose and evidence

Design the experience before choosing its implementation details. Translate the business requirement into a journey that helps each participant understand what matters now, provide the right information and complete the appropriate action.

In Kianda, visual process design includes deciding how stages, forms, sections, decisions and actions fit together. It is not a cosmetic pass over an already generated field list. An early answer may change which forms belong in the journey, which sections appear inside a form, which information is required and what happens next.

Aim for the simplest experience that satisfies the real requirements, not the fewest fields or the largest number of automated rules. A structurally valid application can still be confusing, inaccessible or operationally incorrect.

Interpret statements in this guide using three categories:

- **Documented platform fact:** A capability or limit explicitly established in a companion technical reference. Follow that reference for exact configuration and version boundaries.
- **Observed example:** A representation in an inspected export. It demonstrates a pattern, not universal correctness or verified runtime behaviour.
- **Design recommendation:** The proposed authoring policy in this guide. It is not a new server rule or persisted setting.

Unless identified as a documented fact or an observed example, the guidance below is a design recommendation. Explicit task requirements take precedence over these recommendations, within the applicable workspace instructions and supported platform contract. Do not silently resolve conflicting requirements, source versions or technical contracts.

Keep the knowledge layers separate: use this document to decide **what experience to create**; use `process-knowledge.md` and the schema to determine **how it can be represented**; use `css-style-guide.md` to apply the available presentation vocabulary.

## 2. The process design model

Use these distinctions when discussing a design. They are conceptual categories, not additional JSON properties.

| Concept | Design responsibility | Important distinction |
| --- | --- | --- |
| Business stage | Describe a meaningful phase, outcome or handoff. | A stage does not automatically require a separate form. |
| Form | Provide a coherent navigable activity or area of the process. | A form can represent a stage, an information category or a utility surface. |
| Section | Group closely related information and decisions within a form. | A heading or panel does not create an independent lifecycle. |
| Branch | Determine which activities or information apply to this case. | A branch may reveal several forms, or only a few fields. |
| Action | Express an intentional operation such as saving, submitting or assigning. | Navigation, persistence and business completion are not interchangeable. |
| Participant | Identify who needs to contribute and what they may do. | Visibility alone does not grant or enforce permission. |
| Related record | Represent work with its own identity or lifecycle where needed. | A repeating row is not automatically an independently managed record. |
| Utility structure | Support calculations, shared actions or implementation mechanics. | Do not present it as a user stage merely because it is a form. |

Do not impose a one-to-one mapping between stages and forms. For example, one reporting stage may use Classification, Circumstances and several conditionally relevant detail forms. Conversely, a compact process may use one form whose sections adapt to the user's choices.

## 3. Establish the requirements

Identify the intended outcome, participants, starting information, decisions, required evidence, completion criteria, reporting needs and important constraints. Read the actual workspace requirements and existing process before inventing a new structure.

Separate three questions:

1. **Business policy:** What must happen, and under which conditions?
2. **Interaction design:** How should the user understand and perform that work?
3. **Technical implementation:** Which verified Kianda capabilities implement it?

An unknown business threshold is not a UX decision. Do not invent an incident severity threshold, notification obligation, retention period or approval authority because it makes a branching diagram easier to complete. Use symbolic policy references in the blueprint and identify the missing decision.

For existing applications, establish which behaviours and identities must remain stable, whether open records must continue to work, and whether the request is a redesign or a focused improvement. A supplied example can contain historical defects and tenant-specific dependencies.

Make reasonable, reversible presentation assumptions and record them. Treat uncertainty that could cause unauthorized access, data loss, incorrect completion or unintended external actions as a blocker for the affected implementation, not as permission to guess. Continue with independent, safe portions of the design.

Right-size the design artifact. A small layout or wording change needs a short design note and affected-state checks. A new adaptive process needs the blueprint in section 13. Do not require a full redesign for a narrowly scoped technical repair.

## 4. Choose forms, sections and related records

Choose structure by task coherence, timing, ownership, information volume, navigation needs and lifecycle. Explain the decision, not just the result.

| Situation | Preferred starting point | Check before committing |
| --- | --- | --- |
| The same person provides a small amount of additional information during the current task. | Conditional section within the current form. | Does revealing it preserve the reading order and a manageable screen? |
| A substantial information category deserves its own navigable area, even within the same stage. | Separate form. | Does the user benefit from returning directly to it? |
| A later participant performs a distinct activity with different completion criteria. | Separate form or stage, using verified ownership and access mechanisms. | Does this really require a handoff, and how is it enforced? |
| A short optional detail interrupts the main journey. | Inline disclosure, or a supported dialog for a genuinely secondary task. | Avoid hiding essential work in an unexpected modal. |
| Several similar entries share the parent record's lifecycle. | Native repeating table, potentially presented as repeating cards. | Can users add, review, edit and remove entries on the required devices? |
| Each entry needs independent ownership, status, access or reporting. | Consider related process instances. | Verify the relationship and reporting mechanism; do not invent automatic linking. |
| Several apps repeat a stable, shared section. | Consider a reusable process Component. | Confirm its version/loading behaviour and naming implications. |

Prefer logical grouping over arbitrary screen boundaries. Avoid both one enormous form and unnecessary fragmentation into many forms with only one or two unrelated controls.

A form may be justified by information architecture without a new business stage. A separate stage may be justified by responsibility without requiring a new process instance. Record both the business stage map and the form map when they differ.

## 5. Specify state without confusing its meanings

Describe the state of each conditional form or section across these independent dimensions:

| Dimension | Question to answer |
| --- | --- |
| Applicability | Does this information or activity belong to the current case? |
| Visibility | Should this participant see it at this point? |
| Editability or availability | Can this participant interact with it now? |
| Requiredness | Which information is required for which action or transition? |
| Completion | Has the applicable activity genuinely met its completion criteria? |
| Authorization | Is access permitted through the relevant security mechanism? |
| Data treatment | What happens to existing values when applicability changes? |

These labels are **blueprint vocabulary**, not a proposed Kianda state API. The builder must map each dimension to verified configuration or record the capability gap.

In particular:

- Hidden does not mean not applicable, complete, deleted or secure.
- A required future activity can be temporarily unavailable without becoming optional.
- An inactive branch should not block the current participant with unreachable validation errors, but an applicable later stage must still satisfy its own completion requirements.
- Read-only does not imply complete; completed does not necessarily imply permanently immutable.
- A saved export's `visible` or `enabled` flags do not prove the final runtime state after initialization and rule execution.

Define an intentional initial experience. Keep core orientation and the first meaningful decision accessible. Hide irrelevant detail where appropriate; show upcoming stages with an explanatory state where this helps users anticipate the journey. Do not hide everything by default as a universal pattern.

## 6. Design classification and branching

Place high-impact classification choices early enough to shape the journey, but do not ask users to classify information they cannot reasonably know yet. Allow uncertainty when the business policy allows it; do not silently interpret a blank answer as No.

For each decision, specify its source, allowed answers, blank/unknown handling, whether it is exclusive or multi-select, downstream effects, validation timing and change policy. Treat unsupported or retired stored answers as an explicit case for existing records.

### 6.1 Exclusive choices and overlapping branches

Use exclusive selection only when choices genuinely cannot coexist. Use multi-select or independent decisions for overlapping categories. Do not accidentally design a radio-only journey for a case that can involve both Assets and Environment.

Define effective branch applicability from all relevant upstream decisions. A preserved child selection must not activate a branch after its parent decision has made that selection irrelevant.

For example, the following is **conceptual pseudocode, not Kianda configuration or expression syntax**:

```text
costIsApplicable = damageDetailsAreApplicable
                   AND (Assets is selected OR Security is selected)
```

For this example, agree the truth table before implementation:

| Damage details apply | Assets selected | Security selected | Cost applies |
| --- | --- | --- | --- |
| No | Any retained value | Any retained value | No |
| Yes | No | No | No |
| Yes | Yes | No | Yes |
| Yes | No | Yes | Yes |
| Yes | Yes | Yes | Yes |
| Unknown | Any | Any | Unresolved; do not silently mark complete |

### 6.2 One logical decision per target state

Give each target state a single, understandable logical definition. This does not mandate a single physical rule: several rules may be required by the supported engine. Their combined effect must implement the same predicate without accidental order dependence.

For example, independent rules saying "show Cost for Assets, otherwise hide" and "show Cost for Security, otherwise hide" can conflict. The intended OR relationship needs to remain true when either category applies. Inspect all writers to the target, including initialization, resets, mapped values and custom actions.

Keep a dependency map from the initiating answer through derived decisions to affected forms, sections, validation and actions. Prefer an acyclic design. Where a deliberate feedback loop exists, describe its convergence and safeguards rather than assuming the engine prevents loops.

## 7. Design transitions and re-entry

A branching design must work when the user first opens the process, edits a controlling answer, returns to an earlier form, reopens a draft and resumes an existing record. Consider programmatic changes and mapped values as well as direct user input.

For every meaningful transition, specify the prior state, initiating event, resulting state, newly applicable work, newly inapplicable work, data treatment and next reachable action.

Require the same relevant inputs, participant/permission context and lifecycle state to produce the same intended UI state regardless of the order in which the user selected and deselected options. Re-evaluating presentation should not duplicate records, send another notification or reset completed work without an explicit transition policy.

Keep presentation recalculation separate from consequential actions. Reopening a saved record is not, by itself, authorization to reassign work, re-send an email or repeat an external request. Do not assume a field-change rule also runs on initial load; the builder must establish the supported initialization path.

When data loading, uploads or a required service request are asynchronous, design loading, success, failure and retry states. Identify what subsequent work depends on a successful result. Do not infer transactional rollback or failure-stopping behaviour from visual ordering.

## 8. Handle changes to earlier answers

Specify an explicit policy for each branch that can become irrelevant after values have been entered. Do not let the choice emerge accidentally from whichever hide rule is easiest to copy.

| Policy | Appropriate use | Required design detail |
| --- | --- | --- |
| Preserve while inactive | Reversible choices where preserving entered information is useful and allowed. | Prevent stale data from affecting active calculations, validation, reporting and side effects; define reactivation behaviour. |
| Clear invalid dependent data | A changed parent selection makes a stored reference or value invalid. | Identify every affected value and derived value, the reason for clearing, and any required warning. |
| Clear after confirmation | Discarding substantial entered content is intended. | Provide an understandable consequence and recovery/cancellation path where supported. |
| Restrict or review the change | The process has progressed beyond a point where reclassification is routine. | Specify who may change it, which work is reopened or invalidated, and what history is required. |

Use preservation as a starting preference only where it fits the business, privacy and retention requirements. It is not an indefinite retention policy. Do not invent an inactive-data store or an audit mechanism that the platform has not established.

Distinguish hiding, clearing a field value, removing a table row, deleting a related record and deleting a file. They have different consequences. A documented clearing operation does not establish that linked external resources are also deleted.

For existing processes, preserve the current policy unless changing it is in scope. Flag a risky existing pattern for review rather than silently replacing it.

## 9. Design validation, navigation and actions

### 9.1 Validation belongs to an action and a state

Specify what is checked on input, moving forward, saving a draft, submitting a stage and completing the process. Do not assume all actions should run the same checks.

Connect requiredness to effective applicability and the relevant completion boundary. Identify how users reach and correct an error, including errors in another applicable form. Do not trap users with a required control that they cannot reach or edit.

State whether errors preserve entered data and keep the user in context. Decide whether an action is blocked, or whether a draft can still be saved. These policies require a supported implementation; field flags alone do not prove the behaviour.

The application-model guide documents that a custom rule's rejected Promise or thrown error does not automatically stop subsequent rules. Require explicit success gating where later saving, submission, notification or navigation depends on success. Do not generalize this into unverified behaviour for every native validation action. See `general.md`, "Rule execution is not an implicit transaction".

### 9.2 Navigation follows the applicable journey

Specify the next and previous meaningful destinations, treatment of hidden or unavailable forms, direct access, return-to-edit and what happens when the current form becomes irrelevant. Avoid exposing implementation-only utility forms in progress indicators.

Do not assume next means the next serialized array element. Resolve native and tenant-specific navigation mechanisms from their actual contracts. Where the future journey is undecided, avoid a misleading fixed total such as "Step 2 of 10" unless its meaning remains accurate.

### 9.3 Actions communicate their real effect

Use labels that distinguish Save draft, Continue, Submit, Assign, Complete and Close where those operations differ. Identify one clear primary action for the current task and keep secondary or destructive actions understandable.

Describe the intended order and success conditions for validation, model updates, persistence, external effects and navigation. If a side effect can succeed while saving later fails, define recovery and duplicate-prevention expectations without inventing transactional guarantees.

## 10. Compose the visual experience

Treat branding, hierarchy and responsive behaviour as design requirements from the start. Follow the owner's clean, professional enterprise style through verified Kianda controls and the existing workspace CSS. Material Design is a source of principles, not permission to install a new component framework.

Provide a composition description for each important form: purpose and guidance, initial decisions, section order, repeating information, evidence controls, feedback and actions. Include the main conditional states, not only the empty happy path.

Use headings to describe meaningful information groups. Put supporting help beside the decision it explains. Use cards for coherent groups rather than wrapping every control in its own elevated surface. Give long text, evidence uploads and complex repeating content enough width. Use multiple columns only when they improve scanning and can stack sensibly.

Keep visual order, reading order and keyboard order aligned. When a selection reveals content, make its relationship clear without unexpected navigation or loss of focus. When focused content is hidden, define a sensible focus destination through supported behaviour. Do not remove labels, focus indicators or usable error messages to make a screen appear cleaner.

Use `css-style-guide.md` for exact utilities, component settings and property placement. The current process contract uses `field.class` for layout and `field.customCssClass` for additional styling; do not rename the layout property to `cssClass`. Validate the effective workspace styles rather than assuming a utility's presence guarantees its appearance.

For example, a prominent single-choice decision may use the verified radio-card pattern; related inputs may use a section heading and card; repeated entries may use native table rows presented as cards. Choose the pattern for the task and preserve the underlying control semantics.

Do not implement business visibility through CSS alone. Do not introduce global CSS changes, JavaScript or custom components when existing native patterns satisfy the requirement. When additional code is justified, specify the gap, scope, reuse and regression implications.

Review long labels, empty and populated data, validation, read-only states, selected and unselected options, repeated entries, small screens and keyboard use. Never claim visual quality or accessibility conformance solely because class names or JSON Schema validation look correct.

## 11. Ownership, permissions and consequences

Describe participant roles conceptually before mapping them to actual workspace principals. For each activity, identify who may see it, edit it, submit it, reassign it and reopen it.

Do not equate separate forms, hidden fields, disabled controls or hidden navigation with an access boundary. Preserve existing security during unrelated edits. Resolve principal assignments through authorized target-workspace information; do not copy another tenant's identities or fabricate principals.

When the necessary permission mapping or authoring capability is unavailable, document the required administrator configuration and keep the affected release readiness explicit. Do not import the page-authoring policy for new principals into processes as though it were a confirmed universal process rule.

Treat notifications, external requests, anonymous access, assignment, deletion and publication as consequential operations. Record their triggers and failure handling. Testing a configuration must not accidentally send production notifications or alter live records.

For regulatory or safety-sensitive workflows, use approved business policies and identified sources. This design guide does not establish reporting duties, deadlines or legal compliance.

## 12. Data, reporting and dependencies

Design for how the collected information will be used, not only how it is entered. Identify the reporting dimensions, source-of-truth values, derived fields and relationships needed by the application.

The current application-model guide documents that the Summaries API does not independently query table contents, and arbitrary nested custom-field properties are not independently indexed. Account for those limits before choosing a table or a structured custom field for information that requires cross-record reporting. See `general.md`, "Tables and separate related records" and "Summary data is a projection".

Where summary values or reporting projections are needed, specify how supported rules maintain them and how branch changes affect them. Do not invent an automatically synchronized projection, or assume inactive preserved data should continue to contribute to totals.

Identify reusable Components, installed custom fields and rules, data sources, helper functions, global CSS/JavaScript and related processes. Treat a tenant-specific implementation as a dependency, not a portable built-in feature.

For changes affecting existing records, record expected compatibility and any migration or revalidation requirement. Adding a newly required branch must not silently strand previously valid drafts. Do not perform migration as a side effect of design authoring.

Include offline and reconnection behaviour only where required or already part of the application. A control being visible offline does not prove that its data or external services are available. Record the required scenarios and verification gaps.

## 13. Designer-to-builder blueprint

The blueprint is a Markdown design contract, not a process document or a new JSON schema. Keep it with the application's specifications, separate from the reusable platform guidance.

Use the existing workspace convention. In the absence of one, propose `specs/process-designs/<process-alias>.md` for a substantial design; create it only as part of authorized documentation work. Do not create a separate `spec/` folder. For a small change, use a compact design delta rather than duplicating the whole process specification.

Assign lightweight requirement, decision and test identifiers where they improve traceability. Do not insert them as undocumented properties into process JSON.

Use this template, omitting only sections genuinely irrelevant to a small task:

```markdown
# Process design: <title>

Status: draft | ready-with-assumptions | ready-for-implementation | blocked
Process alias or target: <actual alias, or proposed alias clearly marked>
Design revision/date: <revision>
Implementation mode: new | modify | review
Sources/baseline: <requirements, current files/revisions and reference versions>

## 1. Outcome, participants and scope
State the business outcome, users, success criteria, non-goals and constraints.
List existing behaviours and identities that must be preserved.

## 2. Requirements and assumptions
| ID | Requirement or assumption | Source/status | Acceptance evidence |
| --- | --- | --- | --- |

## 3. Business stages and form structure
| Stage | Form/section | Purpose | Participant | Why this boundary? |
| --- | --- | --- | --- | --- |
Explain where stages and forms deliberately differ.

## 4. Decisions and dependencies
| Decision | Source and allowed answers | Blank/unknown | Affected areas |
| --- | --- | --- | --- |
Include the effective predicates and truth tables for important combinations.
Use conceptual notation; do not claim it is runnable Kianda syntax.

## 5. State and transition contract
| Target | Initial state | Applicability | Visible/editable when | Required for | Completion condition |
| --- | --- | --- | --- | --- | --- |
Describe entry, changes, re-entry, reopening and programmatic updates.
Identify the logical owner of each target state and any conflicting writers.

## 6. Earlier-answer changes and data treatment
| Change | Values affected | Preserve/clear/review | Reactivation and downstream effects |
| --- | --- | --- | --- |
Include derived values, evidence, related records and completed work as relevant.

## 7. Navigation, validation and actions
Describe reachable paths, error correction and each action's actual effect.
Specify success gates, persistence boundaries, side effects and failure recovery.

## 8. Visual composition
Describe section order, grouping, controls, responsive layout and key states.
Reference supported CSS patterns; identify any justified custom dependency.

## 9. Ownership, security and reporting
Map conceptual roles to verified configuration or explicit administrator steps.
Identify reporting fields, relationships and migration/compatibility needs.

## 10. Implementation mapping and unresolved contracts
| Design item | Proposed native mechanism or verified dependency | Evidence | Gap/blocker |
| --- | --- | --- | --- |
Do not fabricate JSON keys, rule settings, principals or command names.

## 11. Acceptance scenarios
| Test ID | Starting state and participant | Action | Expected result | Verification method |
| --- | --- | --- | --- | --- |

## 12. Handoff
State readiness, material assumptions, blockers and files expected to change.
Separate recommended design from approved policy and observed runtime evidence.
```

The builder should consume this contract, not independently redesign it without explanation. Where implementation evidence requires a change, update the design and record the reason. Approval is required only when the user's workflow or a consequential unresolved decision requires it; a design phase is not an automatic stop in an end-to-end build request.

## 14. Acceptance scenarios and verification

Make the important branches executable as tests where tooling permits. The following coverage is a starting checklist, not an instruction to invent an uninstalled test framework.

| ID | Scenario | Required observation |
| --- | --- | --- |
| D01 | Open a new record with no classification. | The initial task is understandable; unknown decisions are not silently treated as completed or negative. |
| D02 | Select each supported primary classification. | The intended forms, sections and actions become applicable and reachable. |
| D03 | Select overlapping categories. | All relevant branches coexist; unrelated branches remain inactive. |
| D04 | Exercise each OR combination, including both and neither. | Shared targets such as Cost follow the agreed truth table. |
| D05 | Select then deselect an option; repeat in a different order. | The same final inputs produce the same intended state. |
| D06 | Change a parent decision while child values are populated. | Data treatment follows policy; stale values cannot drive inactive work. |
| D07 | Re-enable a previously populated branch. | Preserved values and completion status behave as designed. |
| D08 | Save and reopen each important branch state. | The UI reconstructs correctly without relying only on a fresh change event. |
| D09 | Move backward, access a form directly, or remove the current branch. | A valid, understandable navigation path remains. |
| D10 | Submit with missing applicable information and with inactive branch fields empty. | The correct action is blocked or allowed, with reachable errors. |
| D11 | Fail validation, saving, an upload or a required external action. | Later actions respect explicit success gates; data and retry behaviour are clear. |
| D12 | Reopen, retry or double-activate a consequential action. | No unintended repeated side effects or duplicate records. |
| D13 | Use the relevant participants and permissions. | Access enforcement and UI affordances match; hiding is not the security test. |
| D14 | Use an existing record with older answers or lifecycle state. | Compatibility or an explicit migration/review path is established. |
| D15 | Use narrow screens, keyboard navigation and long/populated content. | Reading order, focus, labels, wrapping and actions remain usable. |
| D16 | Disconnect and reconnect where offline use is required. | Supported work and recovery behave as specified; unavailable operations are clear. |

Use exhaustive combinations for small critical decision sets; prioritize overlapping predicates, dependency boundaries and high-consequence paths when the full combination set is too large. Record the coverage limits.

Report results separately as static review, simulated logic, schema/integrity checks, rendered review and runtime interaction tests. A truth-table simulation is not proof that the Kianda rules execute correctly. A screenshot is not proof of saving or access enforcement.

## 15. Annotated Incident reference

### 15.1 Evidence boundary

This case uses the Library export `incident(1).json`, with process alias `incident`, design version `136.0` and a serialized modified timestamp of `2026-01-13T14:35:23.117Z`. Its bytes were inspected on 29 October 2026. It is a historical snapshot, not a claim about the latest live Incident application.

Source SHA-256: `c4b25bf10d728028729f9077758ac42d40e08a739cda4a8ae9c2ef1e6f60ae41`.

The observations below come from the form inventory and selected classification/visibility rules. They are not a complete process audit or runtime test. JSON Pointers identify this exact snapshot. The transferable lessons are recommendations, not claims about the original designer's undocumented reasoning.

### 15.2 Observed form architecture

| Form title | Logical name | Serialized visibility |
| --- | --- | --- |
| Classification | `form1` | Visible |
| Circumstances | `form4` | Visible |
| People | `people` | Hidden |
| Authorities | `authorities` | Hidden |
| Assets | `assets` | Hidden |
| Cost | `cost` | Hidden |
| Quality | `quality` | Hidden |
| Environment | `environment` | Hidden |
| Security | `security` | Hidden |
| Investigation | `investigation` | Hidden |
| Summary | `FORM_OBS_Summary` | Visible |
| _Utility | `FORM_OBS_Utility` | Hidden |

Source: `/forms/0` through `/forms/11`. These are saved configuration flags. They do not prove runtime editability, ownership or ordering. The useful pattern is a stable reporting backbone with conditionally relevant information areas and a separate utility surface; it is not a requirement to create twelve forms for a new process.

### 15.3 Observed decisions and their reusable lessons

| Observed configuration | Source pointer | Design lesson |
| --- | --- | --- |
| Incident Type is a radio list with Near-miss, Incident and Accident. | `/forms/0/fields/2` | An early, exclusive classification can shape later work. Do not copy these categories into another domain without a requirement. |
| A Show Damage Type rule changes the visibility of a detail container and section title for Incident or Accident. | `/forms/0/fields/2/rules/1` | Branching can operate inside a form as well as across forms. |
| Damage type is a checkbox list with Assets, Quality, Environment, Reputation and Security. | `/forms/0/fields/4/fields/0` | Overlapping categories require a multi-branch design, not one exclusive route. |
| Category rules target Assets, Quality, Environment and Security forms. | `/forms/0/fields/4/fields/0/rules/1` through `/rules/4` | Whole information areas can be conditionally relevant. |
| Show Cost tests Assets OR Security and has explicit show/hide branches. | `/forms/0/fields/4/fields/0/rules/5` | Shared downstream forms need a combined predicate and combination tests. |
| Reportable to the authorities controls the Authorities form. | `/forms/0/fields/9/fields/1/fields/0/rules/0` | A separate policy decision can introduce another activity. The toggle is not itself proof of a legal reporting rule. |
| Investigation controls the Investigation form. | `/forms/0/fields/9/fields/3/fields/0/rules/0` | Another decision can activate a distinct information/activity area. Resolve lifecycle and ownership separately. |
| Project-related selection uses show in its true branch and hideAndClear in its alternate branch. | `/forms/0/fields/5/fields/0/fields/1/fields/0/rules/0` | Hiding and data clearing are deliberate, different consequences. Never copy the clearing policy indiscriminately. |

### 15.4 Review cautions before reusing the example

Several rules write to the same form state. For example, the Incident Type field initially hides several forms; the Assets rule also writes to Cost; and the later Show Cost rule uses the combined Assets/Security predicate. This is a reason to trace ordering, initialization and all state writers, not proof of a runtime defect.

The selected damage-type list does not expose People among its serialized choices, while one attached rule checks for People. The Incident Type field also has a rule affecting the People form for Accident. This discrepancy is a review prompt: check runtime choices, mapped/historical values and intended policy before retaining, removing or consolidating those conditions. Do not silently repair the source while borrowing the pattern.

The initial Next button uses `client-rule/go-to-next` at `/forms/0/fields/0/rules/0`. That is a tenant-specific dependency, not proof that an identically named native action exists or automatically skips every hidden form.

The source also contains retained alternate settings with `hasElse: false`. Do not treat inactive alternatives as active runtime behaviour. Follow the technical guide's confirmed false-default and same-action alternate-settings contract.

The lesson is to extract an explicit design contract from an existing application, then validate that contract. Do not treat a complex existing export as a universal golden template whose entire behaviour should be copied.

## 16. Common design mistakes

| Mistake | Better approach |
| --- | --- |
| Generate a field list and add styling at the end. | Design decisions, journey and visual composition together. |
| Create one form per business noun or one form for everything. | Choose boundaries using task, volume, timing, ownership and navigation. |
| Treat a hidden form as complete or secure. | Model applicability, completion and authorization independently. |
| Give every show rule an unrelated hide alternative. | Define the full target predicate and inspect all state writers. |
| Test only selecting an option once. | Test deselection, combinations, reversal and reopened records. |
| Preserve hidden values but still use them in calculations. | Define effective applicability and inactive-data treatment end to end. |
| Clear entered evidence whenever a branch disappears. | Apply an explicit, justified change policy. |
| Assume a failed rule stops later actions. | Establish the actual runner contract and success gates. |
| Use a table for data that requires unsupported cross-record queries. | Design reporting and storage together. |
| Fix every historical defect while making a small improvement. | Preserve scope and report unrelated findings separately. |
| Call a schema pass a successful application test. | Report structural, semantic, visual and runtime evidence separately. |

## 17. Readiness, maintenance and sources

A substantial design is ready for implementation when the builder can identify the intended forms and sections, explain the important predicates, handle answer changes, determine navigation and completion, identify the implementation mechanisms and run meaningful acceptance scenarios.

Unresolved high-consequence decisions remain blockers for their affected scope. Non-blocking assumptions must be visible. Do not label an unreviewed design approved, or a static design runtime-verified.

Maintain this guide as reusable design knowledge. Keep app-specific requirements in the app blueprint, implementation details in technical guides, styling recipes in the CSS guide and historical task outcomes in the workspace changelog. When a new case reveals a general lesson, add the lesson with its evidence and limits rather than copying a whole application into this file.

### Source register

| Source | Used for | Evidence limits |
| --- | --- | --- |
| Owner discussion, 29 October 2026 | Two complementary skills; visual process design; forms versus dynamic sections; Incident as a reference pattern. | Establishes the desired workflow, not every runtime setting. |
| `general.md`, version 1.0.0, 27 October 2026 | Installed documentation paths, application boundaries, rule error continuation, reporting limits, runtime and validation distinctions. | Source-based reference; target runtime not independently executed here. |
| `process-knowledge.md`, accepted 1.1.0, branding revision 1 | Process/form/field/rule model, identifiers, layout properties, Components, alternate settings and validation boundaries. | Follow its confirmed/observed/unresolved distinctions. |
| `css-style-guide.md`, version 1.0.0, 27 October 2026 | Presentation principles, supported utility vocabulary and target-style verification. | Effective target styles and interaction still require review. |
| `incident(1).json`, version 136.0, hash above | Selected concrete branching and form-layout observations. | Historical configuration snapshot; no runtime or complete behavioural audit. |

Review this draft against the real designer/player and representative user journeys before promoting it to an accepted standard. Do not change the technical schema merely to accommodate this guide's conceptual vocabulary.
