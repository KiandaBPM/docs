# Workspace product and architecture guide

This is the entry point for understanding and modifying the workspace. It consolidates the product-owner walkthrough and the workspace definitions. It describes the product configuration represented here.

## Read this documentation together

| Document | Purpose |
| --- | --- |
| [AGENTS.md](../../AGENTS.md) | Agent entry instructions and modification workflow. |
| [modules.md](./modules.md) | Module behavior, field/rule dependencies, shared components, and modification guidance. |
| [pages.md](./pages.md) | Navigation, operational/admin pages, reporting configuration, and page modification guidance. |
| [Application data model](./data-model.md) | Logical relationships between modules, supporting processes, components, pages, and reports. |


The source files remain necessary when implementing a change. This guide explains intent and dependencies; it is not a replacement for reading the exact current rule, field, widget, or security setting. Use the module and page guides as the canonical product knowledge.

## Product purpose


## Personas and responsibilities


### Identity distinctions that affect behavior


## Architecture at a glance

```mermaid
flowchart TD
    User[Users and workers] --> Pages[Page JSON: navigation and widgets]
    User --> Records[Process instances: operational and reference records]
    Pages --> Queries[Summary queries and filter connections]
    Queries --> Records
    Definitions[Process JSON: forms, fields, rules and security] --> Records
    Shared[Reusable process components] --> Definitions
    Extensions[Custom field, rule and widget JS/HBS] --> Pages
    Extensions --> Definitions
    Records --> Server[Scheduled server rules]
    Server --> Outputs[Reports, emails, linked records and updates]
    Hooks[Workspace app JS and CSS] --> Pages
    Hooks --> Definitions
    Library[Assets, hazards, materials, checklists and lookup records] --> Records
```

See the [application data model](./data-model.md) for the module-by-module process/page relationships. This is a logical model of low-code records and references, not a SQL schema or a guarantee of database foreign-key enforcement.

## Source organization

| Location | What it controls |
| --- | --- |
| [pages/](../../pages/) | Dashboard page definitions: identity, grouping/order, access, containers, widgets, filters, templates, and query connections. |
| [processes/](../../processes/) | Main operational processes | Shared components, reference libraries/designers, lookup records, configuration, data. |
| [components/fields/](../../components/fields/) | Custom form-field behavior and templates. |
| [components/rules/](../../components/rules/) | Custom rule implementations and designer settings templates. |
| [components/widgets/](../../components/widgets/) | Custom dashboard widgets and their settings/rendering templates. |
| [js/app.js](../../js/app.js) | Workspace startup hooks, modal links, offline synchronization, guided-tour links, and translation integration. |
| [styles/app.css](../../styles/app.css) | Workspace-specific presentation; also imports a remotely hosted base stylesheet. |
| [.kianda/workspace.json](../../.kianda/workspace.json) | Local workspace/tenant binding and mappings for pulled processes, pages, globals, and extensions. Preserve its binding; do not copy workspace keys or tenant values into documentation. |

This repository is a serialized Kianda workspace with custom extensions. It does not contain the entire Kianda runtime. Runtime platform services, hosted files, tenant configuration, and attachments can be dependencies that are not represented by local source files. The local workspace metadata is ignored by [the Git configuration](../../.gitignore).

## Terms and contracts used throughout the workspace


### JSON identities and references

Page definitions include `id`, `title`, `name`, `widgets`, `visibleTo`, `settings`, and grouping/public flags. Widget `type` selects a built-in or custom implementation; `settings.connections` explicitly connects filter values to target widget IDs and fields. Container/grid classes and widget templates control presentation.

Process definitions include `id`/`name`, `forms`, top-level `rules`, settings, publishing/version metadata, and security information. Forms contain nested fields and their own rules. Fields can contain more fields, settings, and rules; tables, panels, components, and hidden utility controls make shallow searches insufficient. Rules have identifiers, titles, action types, conditions, schedules, enabled flags, targets, and mappings.

Preserve stable internal field names, IDs, component references, and rule target names unless the requested change requires changing them. A display label is not the same contract as a stored option value. Expressions, report tags, queries, translations, linked-record mappings, and visibility rules can reference either. Search both the technical name and the displayed text when tracing a change.

## Shared domain building blocks

### Workspace hierarchy, assets, and responsibility

### Shared operational components


### Operational records and linked follow-up


## Access control


## Reporting and customer presentation


## Modification planning map


### Before implementing a change

1. Resolve the relevant process/page and current customer scope through these guides.
2. Read current JSON and recursively trace affected fields, nested rules, condition groups, target controls, mappings, components, and connected widgets.
3. Separate stored option values/internal identifiers from display text and translated labels.
4. Identify effects on existing records, exports, reports, emails, schedules, and offline data.
5. Make the smallest coherent change set. Preserve unrelated customer configuration and existing workspace changes.
6. Check JSON syntax and reference/link consistency. Use targeted runtime verification appropriate to the change; submission controls can create records, schedule jobs, or send real emails.
7. Update these guides when confirmed product behavior or architecture changes. State any behavior that remains unknown instead of inventing it.

## Recipes


## Coverage and planned features

