# Changelog

## Unreleased

### Kianda platform documentation integration — 2026-10-28

- **Requirement and result:** Make the supplied Kianda platform documentation discoverable to workspace agents. [AGENTS.md](./AGENTS.md#kianda-platform-knowledge-map) now links all seven references by task: application model, process guide/schema, page guide/schema, custom addons, and styling. [general.md](./docs/ehswise/general.md) now points to the available platform knowledge instead of a future integration placeholder.
- **Affected paths:** [docs/kianda/](./docs/kianda/), [AGENTS.md](./AGENTS.md), and [docs/ehswise/general.md](./docs/ehswise/general.md). Current companion-schema references in [process-knowledge.md](./docs/kianda/process-knowledge.md) and [page-knowledge.md](./docs/kianda/page-knowledge.md) use the installed filenames. Historical source filenames remain provenance.
- **Schema renames:** `docs/kianda/kianda-process-schema.json` → [process-schema.json](./docs/kianda/process-schema.json); `docs/kianda/kianda-page-schema.json` → [page-schema.json](./docs/kianda/page-schema.json). Schema bytes, versions, dialects, and URN identities are preserved; SHA-256 comparisons before and after each rename matched.
- **Validation:** Both renamed schemas parse as JSON and retain their expected URN identities; all 358 internal schema references resolve. All seven platform references in AGENTS and all 489 local links, including eight heading anchors across 11 Markdown files, resolved. Rename integrity was verified by matching SHA-256 checksums.
- **Checks not performed:** No Kianda runtime verification, application execution, schema conformance audit of operational exports, or publication was performed. This task changes documentation discovery and local filenames.
- **Configuration/migration/publishing:** External tooling that uses the old local schema filenames must adopt the new paths. No business-data migration or Kianda publication is required for these documentation changes.
