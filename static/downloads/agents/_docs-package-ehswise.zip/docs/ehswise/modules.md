# EHSwise modules: product behavior and modification guide

This guide describes the EHSwise process modules and the relationships an AI agent must preserve when modifying this workspace. It combines the product owner's walkthrough and corrections with the saved process definitions. Read [general.md](./general.md) for product context and architecture, [pages.md](./pages.md) for navigation and reporting, and the [application data model](./data-model.md) for relationships.

## 1. Scope, evidence, and terminology

- **Walkthrough confirmed** means the owner explained the operating behavior during the documentation exercise. These statements are authoritative product knowledge, including corrections to earlier explanations.
- **Source detail** means a behavior or implementation anchor found in the saved JSON. A saved export can differ from the live form or a customer's configured deployment. Inspect the relevant rule's `enabled`, conditions, target, mappings, and else branch before changing it.
- **Customer configuration** means an implementation choice rather than a universal product default. Common examples are hierarchy, access, required signatures, approval routing, and report formulas.
- **Roadmap** items are planned work, not capabilities an agent should assume are already available.
- Inspection, Action, Observation, Event, Checklist, Action Plan, Induction, Audit, Permit to Work, Incident, and Risk Assessment received detailed walkthroughs. Worked Hours, NCR, and Hazard have deliberately lighter coverage. Energy Registration and Green Initiative are cataloged from source without a detailed walkthrough.

In this workspace, a **process definition** is the JSON specification; a **process record/instance** is data created from it; a **form** is a stage inside that process; and a **dashboard page** is a page made from widgets. A field's human title and its technical `name` are different. Technical names, including punctuation and suffixes such as `?inlineButtons`, are referenced by rules, templates, and queries. Preserve their identity when changing labels.

This guide removes demo-specific names, dates, and selected values and resolves owner corrections into reusable product knowledge.

## 2. Entry points and module catalog

The [Create New page](<../../pages/Create New/create-new.json>) launches new records using `/forms/{processId}?isNew=1`. Home shortcuts use the equivalent `gotoForm(processName, isNew)` helper. Existing records use their own instance URL. A module being absent from Create New does not imply that its records or dependencies are absent.

| Module | Process ID and source | Dedicated reporting source | Coverage |
| --- | --- | --- | --- |
| Inspection | `inspection` — [inspection.json](<../../processes/QHSE - Modules/inspection.json>) | [inspections-report.json](../../pages/Analytics/inspections-report.json) | Detailed |
| Action | `action` — [action.json](<../../processes/QHSE - Modules/action.json>) | [action-report.json](../../pages/Analytics/action-report.json) | Detailed; also shared by other modules |
| Observation | `observation` — [observation.json](<../../processes/QHSE - Modules/observation.json>) | [observation-report.json](../../pages/Analytics/observation-report.json) | Detailed |
| Event | `event` — [event.json](<../../processes/QHSE - Modules/event.json>) | [event-report.json](../../pages/Analytics/event-report.json) | Detailed |
| Checklist | `checklist` — [checklist.json](<../../processes/QHSE - Modules/checklist.json>) | Generic record views; checklist library is separate | Detailed |
| Action Plan | `action-plan` — [action-plan.json](<../../processes/QHSE - Modules/action-plan.json>) | Generic record views | Detailed |
| Induction player | `induction` — [induction.json](../../processes/Training/induction.json) | Training/worker/certificate views | Detailed |
| Audit | `audit` — [audit.json](<../../processes/QHSE - Modules/audit.json>) | [audit-report.json](../../pages/Analytics/audit-report.json) | Detailed |
| Permit to Work | `permit-to-work` — [permit-to-work.json](<../../processes/QHSE - Modules/permit-to-work.json>) | [ptw-report.json](../../pages/Analytics/ptw-report.json) | Detailed |
| Incident pack | `incident` — [incident.json](<../../processes/QHSE - Modules/incident.json>) | [incident-report.json](../../pages/Analytics/incident-report.json), [accident-rate.json](../../pages/Analytics/accident-rate.json) | Detailed |
| Risk Assessment | `ra` — [ra.json](<../../processes/QHSE - Modules/ra.json>) | [ra-report.json](../../pages/Analytics/ra-report.json) | Task based and COSHH walkthroughs |
| Hazard | `hazard` — [hazard.json](<../../processes/QHSE - Modules/hazard.json>) | [hazard-library.json](../../pages/Analytics/hazard-library.json) | High level, with source anchors |
| Non Conformance Report | `ncr` — [ncr.json](<../../processes/QHSE - Modules/ncr.json>) | [ncr-report.json](../../pages/Analytics/ncr-report.json) | High level; Audit creation mapping examined |
| Worked Hours | `hours-worked` — [hours-worked.json](<../../processes/QHSE - Modules/hours-worked.json>) | Feeds Accident Rates | Matrix behavior confirmed |
| Energy Registration | `energy-registration` — [energy-registration.json](<../../processes/QHSE - Environment/energy-registration.json>) | [energy-registration.json](../../pages/Analytics/energy-registration.json) | Source catalog only |
| Green Initiative | `green-initiative` — [green-initiative.json](<../../processes/QHSE - Environment/green-initiative.json>) | Generic record views | Source catalog only |

All records can also be reached through views such as My Overview, Location, Assets, Subcontractor, and Admin Data according to the page's filters and record access. Refer to [pages and reports](./pages.md) before assuming a module has only one user entry point.

### Restricting a module

The default Create New links generally have empty `link.users` restrictions. Customers often restrict a module to a specific group or hide unused modules, particularly Action Plan or environmental modules. Change both the link visibility and the process security. Hiding a link alone does not prevent direct form navigation. Consider new-record permissions, existing-record/form assignments, lookup access, and report access separately.

## 3. Shared module contracts

### 3.1 Workspaces, hierarchy, and responsibility

The [EHS Asset process](../../processes/Data/asset.json) is the shared hierarchy and asset data model. Its active Type options are Project, Site, Location, Subcontractor, Office, and Asset. Common fields `type`, `title`, `code`, and `displayName` support dropdowns throughout the product. The default display name concatenates title and code. A former Plant type is unused legacy configuration.

The [Workspaces component](../../processes/Data/workspaces.json) embeds workspace selectors in many module forms. Typical technical fields are `processProject`, `processLocation`, `locationType`, `subcontractor` (sometimes titled Asset), and helper codes `processProjectCode`, `processLocationCode`, `processLocationCodeType`, `processAssetCode`, and `processSubcontractorCode`. Do not infer a field's business meaning from its legacy name: inspect its current title, lookup filter, and mapping.

Multiple associations are supported, for example an Observation can refer to a project, location, and asset simultaneously. Customer hierarchies can introduce Country or Region and require cascading selection; some form flows require the parent first. The walkthrough's Inspection followed a parent-to-child cascade. These are related behaviors: supporting multiple associations does not remove hierarchy constraints.

The [Configuration process](../../processes/Data/configuration.json) edits responsibility records in [Process Responsible](../../processes/Data/asset-responsible.json), keyed to the selected asset. Responsibility applies to that configured asset by default; inheritance requires onboarding configuration. Submitting a blank responsibility row clears that assignment. Module `lookupAssignees` and assignment rules consume these records to populate reviewers, administrators, and notification recipients. A new hierarchy level may need changes in all of these consumers, not just another dropdown.

### 3.2 Shared attachments

The [Attachments component](../../processes/Data/attachments-component.json) provides optional multiple pictures/camera capture, previews, and additional file uploads. It is reused by most modules, commonly in a collapsible Summary panel. Some hosts already have their own picture fields and hide the component's picture input. Check host initialization rules before exposing a duplicate control.

### 3.3 Shared actions and parent links

The [Actions component](../../processes/Data/actions-component.json) collects an immediate-action explanation and repeatable follow-up actions. Its dialog supplies topic, action description, priority, due date, responsibility, and optional evidence/originator-closure settings. Hosts commonly collect rows first; server rules then create one separate [Action record](<../../processes/QHSE - Modules/action.json>) per row on submission. A checklist question also has a question-associated action dialog and may create actions through configured question rules.

Frequently reused anchors include `INS_BTN_EditCLActionRules` (`_ACTION RULES`), `INS_TXTSIN_EditCLActionUrlID`, `actionProcessURLID`, and `Start Action Process`. Preserve the parent/source ID, source process/name, custom ID, question ID where applicable, workspace codes, responsible party, due date, and returned Action ID. Otherwise the Action can exist but lose its link to its source or its status feedback.

The host's confirmation/report email and an Action assignment email are separate events. Action emails are sent by the Action module during assignment, including anonymous external assignment. RA's own action interface is restricted to internal users even though the generic Action module supports external parties.

### 3.4 Shared checklist data and runtime

The chain is:

1. [Checklist Type](../../processes/Data/audit-type.json) (`audit-type`) holds checklist metadata, category, scales, template, and question ordering.
2. [Question](../../processes/Data/question.json) (`question`) holds the question definition, answer options, scores, mandatory/visibility rules, help, and related-question behavior.
3. [Checklist Component](../../processes/Data/checklist-component.json) (`checklist-component`) loads and renders questions within a host module.
4. The host module schedules question/action rules, sets its process status, generates its report, and sends its own notifications.

Inspection, Audit, standalone Checklist, Incident investigation, PTW Checks, and checklist slides in training reuse this capability. Incident's saved investigation component reference specifically selects the [without-actions variant](../../processes/Data/checklist-component-without-actions.json), while the owner described it as the shared checklist mechanism. Inspect the host's `componentId` rather than assuming every consumer embeds the same variant. A checklist is also part of an induction quiz; it is not restricted to inspections.

The designer offers convenience choices such as Yes/No/N/A or OK/Not OK/N/A, plus Custom, Dropdown List, Section Header, EHS Asset List, Worker List, text, date, date/time, signature, and file upload. Only Custom and Dropdown List question types contribute configured answer scores, as confirmed by the owner. Convenience answer presets can be represented through custom configurations. Do not assume a universal two-choice Yes/No schema or one response field for every question.

Key runtime names include `INS_TABLE_Checklist?nostyleTable`, `INS_TXTSIN_QuestionID`, `INS_TXTSIN_QuestionResponseType`, `INS_TXTSIN_ChecklistOutputResponse`, `answerValue`, `customAnswerConfiguration`, `customAnswerOptions`, `relatedQuestionsConfiguration`, `isMandatory`, `visibility`, `auditType`, `checklistTitle`, `checklistCategory`, `totalScore`, `highScore`, `lowScore`, and `scaleStatus`. `INS_BTN_ChecklistLoad` loads records from Question, filtered by checklist name/title, ordered by question `order`; this title-based relationship matters when renaming checklists.

**Scoring boundaries, corrected and confirmed by the owner:**

| Result | Comparison |
| --- | --- |
| Pass | Total score ≥ PassScore / high score |
| At Risk | Fail Score / low score < Total score < PassScore / high score |
| Failed | Total score ≤ Fail Score / low score |

N/A commonly has score 0. Unanswered scored questions do not earn points and can lower the final result below the pass threshold; do not assume that unanswered questions are excluded from the scoring basis. A source rule titled `Remove question if unanswered` is not evidence that an unanswered scored question is ignored by the owner's scoring policy. Read its conditions and distinguish cleanup/output processing from scoring semantics.

Labels are configurable. Audit's initially saved Great/OK/Failed labels are replaced at runtime by the selected checklist labels. Designer fields `highScore`, `lowScore`, `greatStatusLabel`, `okStatusLabel`, and `failedStatusLabel` and runtime fields `greatStatus`, `okStatus`, `failedStatus` must remain aligned.

### 3.5 Save, submit, server rules, and documents

Many processes contain hidden Utility forms and rule buttons. A displayed Next button may only change the visible form. Save Draft usually saves data and keeps it editable. Submit may schedule a sequence of server-side rules rather than performing every action in the browser. Inspect the host's exact rule chain before modifying scheduling or status logic.

Common hidden controls include `OBS_BTN_LocalRules`, `OBS_BTN_SaveRules`, `OBS_BTN_ServerRules`, custom-ID buttons, `lookupAssignees`, and `GI_BTN_AssignRules`. Similar names across processes do not imply identical behavior. Examine enabled rules and mappings inside each host. `processCustomID` is a business identifier; `processURLID` and the process instance ID serve navigation and linking. Do not substitute them blindly.

Reports commonly use the Generate Word Document/document-generation rule and Word templates containing rich-text content controls tagged `kf:<field-name>`, often saved as PDF to a report field. A template is not just a page widget. Modify field references, template tags, conditional template selection, generated file destination, and notification attachments together when the requested change requires them. Template binaries may be stored as process file references rather than readable files in this repository.

### 3.6 Changing a shared component

The host JSON contains embedded component content as well as its reference/configuration. Do not assume editing a component source automatically updates every saved host export. Inspect the component's settings and the host's embedded fields, use the project's established component update/publish workflow, and review the affected host definitions. Preserve host-specific differences, such as RA's internal-only actions or a host hiding duplicate attachment pictures.

## 4. Inspection

**Definition:** [inspection.json](<../../processes/QHSE - Modules/inspection.json>) · **New route:** `/forms/inspection?isNew=1` · **Report:** [inspections-report.json](../../pages/Analytics/inspections-report.json).

### Purpose and forms

Inspection records workplace checks using a configured checklist, workspace association, inspectors, scoring, and follow-up actions. The source forms are `FORM_INS_Type` (Inspection details), `FORM_INS_Checklist` (Checklist), `FORM_INS_General` (Inspectors), `FORM_INS_Confirm` (Confirm), `FORM_INS_Summary` (saved-record Summary), and `FORM_INS_Utility`.

1. **Inspection details:** required Title and When; Workspaces; required Category; and Checklist. Category is sourced from the Checklist Type `industry` field. Choosing a category exposes/filter-selects the checklist; choosing a checklist loads its ID, scoring, questions, and report settings. A `checklist` URL parameter can preselect a checklist for direct entry links.
2. **Checklist:** question types depend on the selected checklist. Rows may show guidance, comments, picture/media attachments, and New Action. New Action is linked to that question; related-question rules can also require/create an action.
3. **Inspectors:** repeatable rows with Internal/External Company choice, Name, Job Title, and an optional signature. Internal uses a user picker and populates name/job title. External uses a display-name text box. Multiple inspectors/signers are supported. **Signatures are not mandatory in the demonstrated default configuration**; customers decide their requirements.
4. **Confirm:** the user confirms the information and submits. Tabs are directly selectable in the demonstrated configuration. Next changes the form and does not submit.

### Completion

Save draft sets Draft, saves, and permits editing. Submit completes the inspection, generates its report, sends notification email, and sets the scored status to Pass, At Risk, or Failed according to the shared boundaries. A completed workflow and a scored display status are related but distinct concepts; inspect both submit and scoring rules.

Implementation anchors: `INS_BTN_ConfirmSubmit` performs validation and schedules `INS_BTN_SubmitRules`. The latter assigns a custom ID, schedules Checklist rules, refreshes related actions, loads a checklist-specific report template when configured, generates the report, sets status, sends `Inspection Notification`, applies assignments, and saves. Initialization preloads project/asset data, reads `checklist`, sets the process URL ID, and refreshes actions for existing records.

### Modification dependencies

- New checklist/category: change checklist records and category/filter metadata, not the Inspection question table manually.
- New response type or score behavior: inspect Checklist Type, Question, component runtime, report output, and all host processes.
- Required inspector signature: change the inspector row control plus validation/submission rules; account for internal and external names and multiple rows.
- New report: inspect the host's default template and the chosen checklist's Enable Report Template override.

## 5. Action

**Definition:** [action.json](<../../processes/QHSE - Modules/action.json>) · **New route:** `/forms/action?isNew=1` · **Report:** [action-report.json](../../pages/Analytics/action-report.json).

### Purpose and responsibility

Action is a central record type created standalone or from other modules. Its source forms are `FORM_ACT_Action` (Action), `FORM_OBS_Workspaces` (Workspaces), `FORM_ACT_FollowUp` (Follow-up), and Utility. Do not implement a separate action workflow in every parent module.

The entry form captures Action topic (`ACT_TXTSIN_Desc`), action description (`ACT_TXTMUL_Desc`), Date assigned, Priority (Low/Medium/High), and due date. Immediate action taken (`ACT_YN_ImmediateAction`) expands a text field describing what was done at the time.

Due-date choices are 1 day, 7 days, 14 days, or Custom. Relative choices count from today; Custom exposes a date input. `ACT_LSTSIN_DueDate?inlineButtons`, `ACT_DATE_DueDate`, and `_DATE RULES` are useful anchors.

`internalExternalResponsible` switches responsibility:

| Responsibility | Inputs and behavior |
| --- | --- |
| Internal | Responsible users (`ACT_USER_ResponsibleUsers`); assignment rules and email notify those users. |
| External | Company selects a Subcontractor record; Contact Email (`externalEmail`) is populated from it. Anonymous-link rules email access to that outside party. The person need not have an ordinary internal account. |

Next opens the workspace stage before standalone submission. The generic Action workspace form has older individual controls rather than assuming every host uses an identical Workspaces component layout.

### Follow-up and closure

The responsible party records Description of action taken, completion date, completed-by identity, optional Lessons learned, and evidence. The public/external flow substitutes text for an internal completed-by user picker.

- `requireActionCompleteEvidence` makes `actionCompletionEvidence` mandatory. Owner intent: require a picture evidencing completed work.
- Without Originator closes action, **COMPLETE** schedules `_Close Action` (`performCloseAction`), submits the record with Closed status, and sends closure notification.
- With Originator closes action, completion is sent to the initiator for approval. The initiator can **CLOSE ACTION** or **REQUEST CHANGES**. A completion notification is not itself closure approval.
- Request Changes appends history/comments, sets `processSubstatus` to `Requires Change`, and notifies the responsible internal users or external email.

`ACT_BTN_SubmitRules` creates the business ID, processes internal/external responsibility, notifies the initiator, schedules external notification and assignment rules, exposes Follow-up, enforces evidence when selected, and saves. `externalNotification` contains Anonymous form link and Notify External. `ACT_BTN_ApprovalAcceptRules` assigns Follow-up, sends the assignment email/alert, and sets `Pending follow-up`.

### Parent linkage and RA feedback

Source fields include `sourceProcess`, `ACT_TXTSIN_SourceID`, `ACT_TXTSIN_SourceProcessName`, and `ACT_TXTSIN_SourceCustomID`. Follow-up offers Go to Origin. For an RA additional-control action, `performCloseAction` includes `Update back to RA`, which matches the Action URL ID in the RA's action table and triggers `updateStatusesFromAction`. Preserve this completion callback when modifying shared actions.

The source contains the RA callback on the close chain; do not infer that every standalone Action has a meaningful RA target. Read lookup and linked-source values before changing this rule.

## 6. Observation

**Definition:** [observation.json](<../../processes/QHSE - Modules/observation.json>) · **New route:** `/forms/observation?isNew=1` · **Report:** [observation-report.json](../../pages/Analytics/observation-report.json).

### Classification and circumstances

Forms: `FORM_OBS_Classification`, `FORM_OBS_Circumstances`, `FORM_OBS_Summary`, and Utility. Classification offers Unsafe observation, Positive observation, and Improvement idea. Unsafe observation reveals **Stop Work Authority used?** SWA records a worker/contractor exercising the right and obligation to stop an unsafe task. Selecting Yes tags the process type accordingly.

Workspaces can associate the same observation with multiple types. Continue validates at least one selection. Circumstances captures required Title; optional Description and proposed action; optional picture; Reported on; and Reported by. Change reported by permits reporting for another employee or a manually named third party. **The submitter remains the creator and originator even when Reported by names someone else.** Related-subcontractor controls reveal a subcontractor selector and an Add Subcontractor dialog using EHS Asset type Subcontractor.

### Summary, actions, and notification

Summary displays record/workspace properties and expandable shared Attachments and Actions. Actions contains the immediate-action explanation and Add New Action. On submission, Server rules loops action rows and starts distinct linked Action records.

The optional confirmation checkbox sends email to the **submitter/originator**, not to the Reported by person. People to be notified adds interested parties in CC. The responsible rule is **Notify Originator & additional People** under `OBS_BTN_ServerRules`. Keep recipients and the confirmation condition together when changing email behavior.

Positive observations intentionally default to **Close observation right away**; they do not require action or investigation in the base product. Close-right-away exposes closure fields and a Close path. Ordinary observations provide Submit and an Open follow-up path. Public/anonymous Observation submission is supported; internal notification/confirmation controls are hidden for public use.

Implementation anchors include the Classification type rules, `OBS_BTN_LocalRules`, `OBS_BTN_SaveRules`, `OBS_BTN_ServerRules`, `OBS_BTN_Close`, and the action-row `_ACTION RULES`. The server chain generates the observation PDF, sets substatus, notifies, and saves. A change to the apparent reporter must not silently change the originator or notification recipient.

## 7. Event

**Definition:** [event.json](<../../processes/QHSE - Modules/event.json>) · **New route:** `/forms/event?isNew=1` · **Report:** [event-report.json](../../pages/Analytics/event-report.json).

Event complements training compliance by recording scheduled operational events and attendance. Forms are Classification (`form1`), Event Details (`form2`), Summary, and Utility. Workspaces is on Classification and at least one workspace is required.

| Event type | Details shown |
| --- | --- |
| Toolbox | Title and Event Details |
| Meeting | Title and Event Details |
| Training | Title, Event Details, training fields |
| Induction | Title and Event Details |
| Drill | Title, Event Details, drill fields |

Training includes course, Code, Generate training certificate?, Training Date, and optional Expiry Date. The course lookup reads [Training Course](../../processes/Data/training-course.json); **Get Course Code** populates the code from the selection. Drill adds drill type, scenario/planned activities, and optional evaluation.

### Participants and certificates

Every event type displays Participants for worker sign-off. Worker selection reads [Worker](../../processes/Training/worker.json) and populates name, role, company, ID, and subcontractor code. Other permits a free-text participant. Worker red-card information can be displayed. Multiple participants are supported.

Signatures are optional by default and can be required by customer configuration. Asking participants to sign a training record through email is a common customization; it is not the same as collecting signatures in person on the default Participants table.

For Training with Generate training certificate? enabled, **Generate training certs** loops participants. `generateCert` creates a PDF and starts [Certificate](../../processes/Training/certificate.json), carrying course, worker ID, certificate file, expiry, company/subcontractor and notes. The saved generation condition requires a Worker ID; free-text Other participants do not satisfy it. Preserve that distinction when extending attendance capture.

Summary resembles Observation: shared Attachments/Actions, People to be notified, and Submit. The owner confirmed the submission notification behavior and additional recipients. Action assignment emails still come from Action. `OBS_BTN_ServerRules` contains ID generation, action creation, report generation, certificate loop, notification and save.

## 8. Checklist runner

**Definition:** [checklist.json](<../../processes/QHSE - Modules/checklist.json>) · **New route:** `/forms/checklist?isNew=1`.

This versatile module runs a configured checklist and generates its report. It is a distinct product module from Inspection, although both use the same checklist component. The saved process has a Checklist form (`form1`) and Utility rather than Inspection's inspector and confirmation stages.

The required Checklist selector reads Checklist Type. Selection loads metadata/questions. A direct link can include a `checklist` parameter to preselect the desired checklist. The demonstration's selected checklist had been chosen manually; it is not a hard-coded default.

Question controls follow their definitions, with optional help, comments, picture and New Action. Workspaces must have at least one selection. Summary fields within the main form include required Title, When, Originator, and Checklist Status. Save draft sets Draft and saves. Submit validates workspace, completes the checklist, schedules submit rules, generates a PDF, stores its report, and sets scoring status when applicable. The business ID uses the `CHK_{YYYY}_` namespace.

The report notification is sent only to the **originator** by default. Each separately created Action notifies its own responsible party through Action assignment. The saved email rule retains the inherited title **Inspection Notification**; do not mistake that title for a process dependency on Inspection.

Anchors: `form1btnSubmit`, `INS_BTN_SubmitRules`, `INS_BTN_SaveChecklist`, and shared question/action buttons. Checklist-specific templates can override the host's default template.

## 9. Action Plan

**Definition:** [action-plan.json](<../../processes/QHSE - Modules/action-plan.json>) · **New route:** `/forms/action-plan?isNew=1`.

An Action Plan bundles separate Actions into a coordinated corrective or preventive plan. Customers focused purely on EHS often hide it because it also covers Quality responsibilities.

- **Corrective plan:** for example, coordinate multiple parties restoring a high-tension transformer after a major incident.
- **Preventive plan:** investigate and change the conditions that led to the occurrence to reduce recurrence.

Their technical workflows are similar but the business purposes are distinct. Do not merge these categories simply because the form implementation is shared.

Classification (`form1_ActionPlan`) includes Originator, Date and Time, Title, Description, Type of Plan and Workspaces. The separate optional When date is the **plan date**; individual Actions each have their own due date.

Actions (`FORM_OBS_Actions`) uses the shared component. It allows immediate-action notes and new internal/external action rows. The plan needs at least one Action for submission. Server rules creates separate Action records linked to the plan.

Summary (`FORM_ActPlan_Summary`) displays information, attachments and Follow up/Reported By. **Reporter is the key owner of the plan.** The **Notify** rule sends email to the **originator**, with the generated PDF report; ownership and notification recipient must not be conflated. Submission validates title, description, workspace and action count and completes the plan. Save Draft keeps it editable.

## 10. Induction player

**Definition:** [induction.json](../../processes/Training/induction.json) · **New route:** `/forms/induction?isNew=1` · **Designer:** [induction-type.json](../../processes/Data/induction-type.json) and [slide.json](../../processes/Data/slide.json).

The player executes a selected training/induction. Its forms are Start (`start`), Induction (`induction`), Summary, and Utility. Available inductions depend on the customer's security configuration.

### Learner identity and assignment

Start asks for the induction, Myself or Someone else, and Workspaces. With Someone else, a table selects workers from the Workers list. Submission creates an anonymous link for **each selected worker**. Those workers are the learners; the creator who assigns the induction is not substituted as the learner.

Multiple workspace types can be selected. Customer security/hierarchy can restrict choices and enforce cascading Country → Project/Site selection. These choices do not themselves filter induction definitions except through the configured security model.

### Slides and quiz

Slides can be Image, Video, or Checklist. Rich text can supplement any type. Only images/videos have a minimum waiting timer. Setting timer seconds to **0 disables the wait**. Its purpose is to discourage skipping content immediately.

The learner completes checklist questions inside the player, typically using custom multiple-choice answers. Quiz result can set the induction to Passed or Failed; a failed quiz sets Failed. Requiring a failed quiz to repeat the preceding slide is a common customer configuration. The owner explicitly described it as **not a public base-product setting in the current release**; exposing it as a configurable option is planned.

### Completion and certificate

Server rules generates the certificate and sends it by email to the **worker/learner**. The generated certificate is also stored as a separate Certificate record associated with the learner's Worker ID and email. The owner confirmed both operations; do not document certificate generation and worker email as alternatives.

Relevant source controls: `startIndution` creates worker-specific Induction records; `initializeInduction` generates anonymous access, sends assignment notification and loads content; `OBS_BTN_ServerRules` includes Generate certificate, Notify worker and certificate upload scheduling; `uploadCertificate` includes Create induction training certificate. Preserve worker identity, induction identity/title, expiry, file and URL mappings.

See [supporting training processes](#18-supporting-data-and-designer-processes) for designer cloning, expiry and worker reminders.

## 11. Audit

**Definition:** [audit.json](<../../processes/QHSE - Modules/audit.json>) · **New route:** `/forms/audit?isNew=1` · **Report:** [audit-report.json](../../pages/Analytics/audit-report.json).

Audit combines the shared checklist with explicit Findings that can become NCRs. Forms: Classification (`audit`), General (`form8`), Checklist (`FORM_INS_Checklist`), Findings (`FIN`), Summary and Utility.

### Audit type and general information

| Type | Meaning confirmed by owner |
| --- | --- |
| Internal | Internal audit |
| Subcontractor | Audit of a subcontractor; reveals its selector/add controls |
| External - Certification | A dry run ahead of an external certification audit to check everything is in place |
| External - External stakeholders | External stakeholders participate in the external audit |

Classification also selects workspace, Category and Checklist. General captures required Title; optional comments, Standard and Audit date. Standard is the applied standard, such as ISO 9001. **Audit date is the actual audit date**, not a target or next review date.

Checklist uses the shared renderer, question-level Actions and score thresholds. Initially saved Great/OK/Failed text is replaced by the selected checklist's configured result labels at runtime.

### Findings → NCR

Findings is repeatable. A row captures finding topic, classification (Major, Minor, OFI, OBS), auditor remarks, proposed correction, and Finding Owner. Those classifications change the business meaning/outcome, not the default workflow stages.

The row's `FindingRules` / **Create NCR** rule starts [NCR](<../../processes/QHSE - Modules/ncr.json>) when no Finding ID has already been stored. It triggers the target Submit button and maps:

| Audit finding data | NCR meaning |
| --- | --- |
| Finding topic | Title |
| Classification | Non conformance level (`Category`) |
| Remarks auditor | Remarks |
| Proposed correction | Recommendation by Originator |
| Finding Owner | Owner (`manager`) |
| Source Audit and date | Audit link and date |
| Workspace selections/codes | Same project/location/subcontractor context |
| Returned process ID | Stored back as Finding ID in the Audit row |

**Each finding's owner is assigned through the NCR process.** Keep row identity and the returned ID to avoid recreating duplicate NCRs on a later save/submission.

### Summary and server work

Summary includes audit properties, shared attachments, optional People to be notified and optional confirmation email. Server rules runs checklist actions, parent actions and findings, loads any checklist report template override, generates the report, notifies the originator when confirmation is selected and additional people when populated, and saves. Save Draft sets Draft. Owner confirmation of a finding's classification does not imply that the score determines NCR closure.

## 12. Permit to Work (PTW)

**Definition:** [permit-to-work.json](<../../processes/QHSE - Modules/permit-to-work.json>) · **New route:** `/forms/permit-to-work?isNew=1` · **Report:** [ptw-report.json](../../pages/Analytics/ptw-report.json).

PTW records authorization, precautions, parties, checks, equipment and workers for a high-risk job and validity period. It supports digital and paper operation.

### Classification and branching

Types: General, Confined spaces, Lifting operations, Hot works, Working at height, and Electrical and mechanical. Choose exactly one mode:

1. **Complete your PTW digitally** — digital permit workflow.
2. **Upload a completed (paper) PTW** — upload a permit already completed outside EHSwise.
3. **Start your PTW digitally and complete on paper** — create/print a report, complete it on paper, and upload it later.

Workspace selection is required. Electrical and mechanical exposes LOTO; Confined spaces exposes gas-measurement/watchman controls. The saved forms are Classification, Circumstances, Involved parties, Checks, Equipment, Participants, LOTO, Confined spaces, Summary and Utility, with names prefixed `FORM_PTW_` except the shared Checklist form.

### Permit details / Circumstances

Required Title, Description of works, and Applicable Risk Assessment. **Applicable Risk Assessment is free text in this version**; linking an existing RA record is a common customization. Optional Additional Documentation and request Date. Date is the request date; First issue valid from/till define permit validity. Extension uses its separate valid-from/till fields.

Internal/External changes Reported by between a user picker and an outside person's text name; Company is available. Related to another PTW? exposes a linked permit selector. Multiple permits may need to apply to the same work, for example General plus Confined spaces.

### Involved parties and phases

The repeatable table holds Phase, Role, Internal/External, Name, Company and signature. Roles include Permit holder, Approver, Verifier and Isolating authority. Phases include First issue, Extension and Closure. External names use text; internal names use user selection. Requested phases add rows to this same table. A hidden print table is assembled for report output.

This version is designed for in-person signatures. **Individual signatures are not required by default.** The customer defines which approvals must be enforced during implementation. Do not interpret the page's instructional text about signatures as field-level mandatory enforcement.

### Checks, Equipment, Participants

- **Checks** loads a checklist appropriate to the high-risk task via the shared component.
- **Equipment** is shown for all permit types. Choices come from EHS Admin → Other lists, backed by equipment definitions such as [ptw-equipment.json](../../processes/Data/ptw-equipment.json). Selection is optional. Other does not reveal a specialized field.
- **Participants** are the people actually doing the job. Teamlead identifies their team leader. Rows include phase, identity, company and signature. First issue and Extension can have different workers. A signature acknowledges the permit conditions/control measures; it is configurable and not mandatory by default. The process calculates total/internal/external participant counts.

### Confined spaces

Gas measurements is repeatable: Name of the person making the reading, Date and Time, oxygen, LEL, H₂S and CO. Multiple readings can be recorded. Watchman is repeatable with Name and IN/OUT times representing coverage periods; multiple watchmen are supported. Neither collection is required by default, but customers can configure requirements.

**No gas-reading limits are enforced by the base form.** Users interpret readings against the applicable site procedure and local requirements. The walkthrough included contextual operating reference values; those are not product validation constants and must not be converted into universal legal/safety thresholds by an AI agent.

### LOTO

Lock Out Tag Out records Equipment Isolated, Isolation Point, LOTO key no., Issued To, Locked out on and Lock released on. Key number is the company's actual key identifier. Issued To is the person who took the key to secure the equipment. The permit holder records release. Rows can be added/removed and are not required by default. The walkthrough did not establish any additional automatic interlock or validation of isolation correctness.

### Submission and lifecycle

Summary recaps permit, status timeline, properties, attachments/actions and optional confirmation. Originator receives the confirmation email. Submit validates PTW type, title, works description, applicable RA, workspace and permit holder. Customer-required signatures/checks may add validation.

- Normal submission enters **Open** with the demonstrated inline-approval arrangement.
- If the customer disables inline approval, the owner described submission entering **Reported**.
- While Open, the owner can **Extend**. This adds Extension signer rows and uses Extension valid from/till.
- **Close** sets Closed; **Suspend** sets Suspended.

Source anchors: `PTW_BTN_SubmitRules`, `PTW_BTN_ExtendRules`, `PTW_BTN_CloseRules`, `PTW_BTN_SuspendRules`, `PTW_BTN_ServerRules`, and `PTW_BTN_CreateReport`. The saved Extend chain sets status **Extended** with substatus **Extension**. There is a saved-source discrepancy for Suspend: the owner described **Suspended**, while the enabled saved rule sets global status **Closed** and `processSubstatus` **Suspended**. Preserve this distinction when diagnosing behavior; resolving it requires deciding the intended status contract and its report/assignment consumers. Report rules select templates by PTW type after sorting/copying involved-party rows to a print table.

When adding a PTW type, cover classification choice, applicable specialized forms/checklist, report-template condition, required-form validation, participants/signatures, phase transitions, and reporting filters. Do not copy only the card label.

## 13. Incident pack

**Definition:** [incident.json](<../../processes/QHSE - Modules/incident.json>) · **New route:** `/forms/incident?isNew=1` · **Reports:** [incident-report.json](../../pages/Analytics/incident-report.json), [accident-rate.json](../../pages/Analytics/accident-rate.json).

Incident is one process combining Near-miss, Incident and Accident with conditional damage forms, authority reporting records, investigation, actions, notification and document generation. It is not one independent process per incident type.

### Classification and conditional forms

| Driver | Source field | Effect |
| --- | --- | --- |
| Incident Type | `incidentType?radioCards` | Manual single-choice Near-miss / Incident / Accident. Accident activates People and Potential LTI. |
| Damage type | `incidentType?checkboxCards` | Multi-select Assets / Quality / Environment / Reputation / Security. Adds corresponding detail forms where defined. |
| Reportable to authorities | `reportable_authorities` | Displays Authorities to record an externally made report. |
| Investigation | `investigation` | Displays Investigation, with optional reusable investigation checklist. |
| Emergency | `EmergencyInfo` | Captures emergency flag; do not infer an external emergency dispatch integration. |

Workspaces offers project, location, asset and additional subcontractor association. Required Reporter (`Reporter`) and incident date/time (`processDate`) are on Classification. Reporter is not automatically interchangeable with the hidden originator field.

Initial visible forms are Classification (`form1`), Circumstances (`form4`) and Summary (`FORM_OBS_Summary`). Options reveal People (`people`), Authorities (`authorities`), Assets (`assets`), Cost (`cost`), Quality (`quality`), Environment (`environment`), Security (`security`), and Investigation (`investigation`). The toggle field and Investigation form share the same name in different contexts; references include a type, so preserve both.

**Owner correction:** People is activated by **Accident**, not by Incident or a current People damage choice. Source contains an old Damage → People rule but it is disabled; People is not in the current damage choices. Reputation has no separate form and is described in the incident details.

Source detail: Incident Type first hides dependent forms and clears Damage type, then applies type-specific rules. Near-miss hides Duty of Notification/Investigation controls. Damage rules show Assets, Quality, Environment and Security; the enabled `Show Cost` condition covers **Assets or Security**. The walkthrough specifically demonstrated the Assets → Cost path. Changing these rules requires inspecting both enabled branches and else behavior so stale forms do not remain visible after a type change.

### Circumstances

Incident Title (`processSubject`) is required. Description of what happened/circumstances (`processDescription`) records the event and ongoing activity; `processDamage` is a conditional damage description. Picture areas support different levels of context: aerial/location, incident scene, contributing information, and damage/injury. These specialized pictures coexist with the shared Summary attachments.

### People and injury metrics

People is for Accident. It captures injury description and repeatable injured people (`victimsTable?nostyleTable`) plus repeatable witnesses (`witnessTable`). Multiple injured people and multiple witnesses are supported.

An injured-person row includes body-map annotation, employee/contractor choice (`InjuredPersonPosition?inlineButtons`), name, job/company details, injury type, first aid provided, classification, additional notes and any applicable time periods. Employees use a user picker (`InjuredPerson`). Other/contractor identity can be typed (`nameOfTheInjuredPerson`) with contracting company and company contact information.

Injury Classification choices include Lost Time Incident, Restricted Work, Medical Treatment, First Aid, Illness and Fatality. Lost Time, Restricted Work, Medical Treatment and First Aid contribute to Accident Rates figures. Do not count only process records when the configured report is meant to count injured people or days.

The Utility form stores `firstAidCount`, `lostTimeIncidentCount`, `medicalTreatmentCount`, `totalRestrictedWorkDays`, `totalLTIDays`, and `injuredPeopleCount`. Row/table rules update counters and time-based fields. Restricted Work and LTI have their own start/end and calculated day fields. These feed dashboard calculations together with Worked Hours.

Witness identity options include Employee, Contractor, Member of public and Other. Other reveals free-text witness name and company. Witness signature controls are available; customer-required signatures must be explicitly configured.

### Investigation

Investigation captures required investigation summary, optional uploaded report and Yes/No for using an investigation checklist. No hides the checklist. Yes selects a checklist such as a five-whys investigation, using the shared checklist capability. The saved Incident embeds `componentId=checklist-component-without-actions`; its separate Summary Actions component remains available for follow-up actions.

Root Cause and optional Secondary Root Cause come from [Root Cause](../../processes/Data/root-cause.json), maintained at EHS Admin → Other Lists → Root Causes. Notes are available for each. Keep lookup data changes separate from changes to the inline environmental/material/quality choices below.

### Authorities

Repeatable Authority, Comments and Attachments capture reporting information. Authority is required in the saved row; Comments/Attachments are optional there. **The actual report to authorities occurs outside EHSwise.** Selecting Reportable records the reporting requirement and exposes this form; it does not submit a regulatory report automatically.

### Assets and Cost

Assets captures technical-incident type, priority, operational impact and repeatable damaged assets. Technical types: Machine faulty, Break-down, Electrical, Usability and Durability. Priority: Low, Medium, High, Critical. Impact asks if damage affects project/site operations; owner meaning includes decommissioning the asset and resulting project impact.

Damaged asset is text describing it (`damagedAsset`); Owner (`owner`) is the individual directly responsible. Do not assume this damage table is an EHS Asset record picker.

Cost records who pays (Internal/External), Value and Description per row. Totals `internalCost`, `externalCost`, `overallCost` aggregate the rows. No currency is indicated in this version. Cost row fields are optional by default. The source also permits Cost for Security damage as noted above.

### Quality

Simple required Category and optional Remarks; Other exposes Specify Other. Inline categories include Complaint; production loss/delay; production/specification deficiency with acceptance, repair/rework or rejection; unmet requirements/instructions/scope; documentation/reporting; incoming parts/goods/units; inspection/test criteria non-conformity; job execution; Other. Changing this classification does not automatically create an NCR; Audit Findings → NCR is a separate explicit integration.

### Environment

`environmentAspects` is an inline multiselect, not a lookup process. Values: Air emissions; Energy consumption; Fauna/flora; Soil emissions; Use of natural resources; Waste; Water emissions; Other. Other shows Specify Other.

The repeatable Materials table records Material, Medium, Amount and Unit. Amount is the material released; Unit is the measurement unit, for example kg or litres. Material row inputs are not enforced by default.

The inline Material options are Potential Acid Sulfate Soil; Analysing / testing (product for); Anti Corrosion / Erosion product; Cleaning / degreasing agent; Contaminated soil; Cooling systems (product for); Detection of water in oil (product for); Dredged material; Fuel; Glue / adhesive; Grinding (product for); Herbicide; Hydraulic oil; Insulation product; Lubricant; Paint; Rest control (product for); Radioactive product; Sludge/spent oil/waste/water/bilges; Soil remediation (additive for); Soldering (product for); Treatment of radiator (product for); Wastewater treatment (additive for); Water treatment (additive for); Welding / torch cutting (product for); Other. Preserve the saved wording unless changing the labels is part of the request.

Medium records where released: outside of containment; air; containment; ground/soil; groundwater; sewer system; water-lake; water-rainwater buffer; water-sea; water-waterway. These are inline Incident choices and are independent of the COSHH Material library.

### Security

Security Category is an inline multiselect: Armed Robbery, Burglary, Vandalism/Arson, Other and Bombing. Other expands a specification field. The repeatable Declaration table records Reference Number, Date Notified and an attached reference. The owner described these as information about the report. This declaration/report capture is separate from process access security and the Policies document-control workflow.

### Summary, submission, and server execution

Summary shows incident properties, generated PDF (`processReport`, titled Finalised report), shared Attachments/Actions and People to be notified (`OBS_USER_AddNotify`). Submit does not merely generate a local browser printout: it validates, runs local/save and assignment rules, and schedules Server rules on the server. Draft is excluded from the normal Server rules schedule. Scheduling is one-time, ordered and unique in the saved rule configuration.

Important hidden controls:

| Control name | Role |
| --- | --- |
| `INC_BTN_validateForms` | Type, title, workspace and relevant conditional-form validation |
| `OBS_BTN_LocalRules` | Open/submission UI and save chain |
| `OBS_BTN_SaveRules` | Draft subject/substatus, assignment schedule, server schedule and save |
| `generateCustomID` | Year/sequence-based custom incident ID |
| `lookupAssignees` | Responsibility lookups for reviewers/admins/project manager/Incident Notify |
| `GI_BTN_AssignRules` | Draft/Open/Closed/reviewer form assignments |
| `OBS_BTN_ServerRules` | Authoritative PDF/action/notification execution |

Enabled Server rules:

| Rule title | Effect / condition |
| --- | --- |
| Run Checklist Rules | Runs shared investigation checklist rules when selected and Open. |
| Run custom ID | Assigns the business ID if blank. |
| Run actions | Loops shared action rows, creating separate linked Action records. |
| Get Company Name | Populates email signature/company field. |
| Generate incident report | Non-Accident and no Investigation; uses `OBS_FILE_ObservationReportTemplate`. |
| Generate incident report - Accident | Accident and no Investigation; uses `reportTemplateAccident`. |
| Generate incident report - Investigation | Non-Accident with Investigation; uses `reportTemplateInvestigation`. |
| Generate incident report - Investigation and Accident | Accident with Investigation; uses `reportTemplateInvestigationAndAccident`. |
| Set substatus | Open and no assigned-to user → Pending assignment. |
| Show Close | Open → show Close comment/CLOSE; hide Submit. |
| Notify Originator | Emails `processOriginator`. |
| Notify Additional People | Emails the selected People to be notified when populated. |
| Notify incident Notify | Emails `incidentNotify`, populated by responsibility Configuration. |
| Save form | Persists generated data and rule results. |

All four document rules save PDF to Finalised report. The three email rules use incident type/business ID in the subject and include incident context and an access link. **The saved settings do not attach the PDF to these emails**; report generation and email attachment are distinct. Owner confirmed the three recipient groups and server-side execution.

Closing uses Close comments, Closed by/date and the Close control. Assignment rules vary by Draft, Open and Closed. A new conditional form must be covered in explicit assignment lists as well as in UI visibility.

### Modification recipe: add a new incident type

First decide whether the request means a new **top-level event type** or a new **damage category**. They are different fields and dependencies. For a top-level type such as a new peer of Near-miss/Incident/Accident:

1. **Classification options:** edit `incidentType?radioCards.settings.choices` and any card rendering/translations. Keep existing choice values compatible with saved records. For a damage category instead, edit `incidentType?checkboxCards`.
2. **Branch behavior:** inspect the field's Hide forms, Show Damage Type, Clear Damage Type, Show people, Show damage and Hide Investigation & Notification rules, including else branches and disabled legacy rules. Decide which forms and toggles apply. Do not enable the old Damage → People rule just to make a new type work.
3. **New fields/forms:** create stable names/IDs and correct parent references; add visibility and clear-on-change behavior deliberately. Add required-field validation to `INC_BTN_validateForms` only when that new branch applies.
4. **Summary and common fields:** update relevant summary/metadata/description templates, `processName`, custom subject/header expressions and any type-derived `processDamage`/`damageOptionsText` behavior. Inspect page card templates using these values.
5. **Documents:** decide whether the new type should follow the current non-Accident template branches or requires its own template. The current condition “not Accident” includes any new choice unless changed. Update both with/without Investigation branches and the generated report fields/Word content controls. Add a matching close/regeneration path where needed.
6. **Counters and rate semantics:** decide whether the type may have injured people and whether it should contribute to injury counts, LTI/restricted days and incident rates. Review People visibility, row/table counter rules, Utility fields, [Accident Rates page](../../pages/Analytics/accident-rate.json), [accident-rate widget](../../components/widgets/accident-rate.js) and its [template](../../components/widgets/accident-rate.hbs). Do not silently count a new type as an Accident or apply a universal rate formula.
7. **Responsibilities and notifications:** review `lookupAssignees`, `incidentNotify`, Process Responsible configuration, assignment rules, three notification rule conditions and message labels. A new type alone does not create a separate configured notify group.
8. **Access:** inspect process-level creation/security and every explicit form assignment list in `GI_BTN_AssignRules`. Update customer group restrictions only as requested. Consider anonymous/public behavior separately.
9. **Pages and reports:** inspect [Incident Report](../../pages/Analytics/incident-report.json), its type filters, chart series, list columns, counts, cards and export fields; review Location/Asset/Subcontractor record-type tabs when changing the process title or introducing a genuinely separate process. The process title/category matching used by page tabs is different from Incident Type.
10. **Language and compatibility:** add translations for new labels/options through the Languages configuration; preserve fallback English and existing choice values. Consider whether old records need any explicit migration. Record the change in this guide.

## 14. Risk Assessment (RA)

**Definition:** [ra.json](<../../processes/QHSE - Modules/ra.json>) · **New route:** `/forms/ra?isNew=1` · **Report:** [ra-report.json](../../pages/Analytics/ra-report.json).

Forms: Details (`form1`), Assessment (`risks`), Actions (`FORM_OBS_Actions`), Summary and Utility. `typeOfAssessment` selects Task based or COSHH.

- **Task based:** hazards of tasks/roles, for example lifting boxes onto a conveyor; assess existing risk and the controls needed to mitigate it.
- **COSHH:** risks inherent in chemical materials; determine PPE and precautions needed while using/handling/maintaining them.

### Details and COSHH material data

Task based requires Area, Description of Task/Role, Effective Date, Review Date and Operator. Operator and assessor signature controls are available but not required in the demonstrated base configuration. Assessor(s) permits multiple users. Origin contains assessment date, Reported by and optional subcontractor association. Shared Workspaces links the context and can use the customer's cascade/security model.

COSHH replaces task-specific details with Substance, Supplied By, SDS file, revision, description and hazard-property indicators. `substance` looks up [COSHH Material](../../processes/COSHH/material.json), prepopulating `suppliedBy`, `sDSFile`, `revision`, `substanceDescription` and properties such as Oxidising, Explosive, Flammable, Toxic, Corrosive, Human Health and Gas under pressure. **The assessor can edit these values in the RA.** The SDS file belongs to the Material and can be opened from the assessment. Editing assessment inputs does not imply a write-back to the Material library.

### Assessment and scales

Assessment displays Severity, Likelihood and score bands above the assessments table as a visual key. The walkthrough configuration uses:

| Score | Severity | Likelihood |
| --- | --- | --- |
| 1 | Negligible — unlikely to cause injury | Improbable — very unlikely |
| 2 | Minor — first aid / acute illness | Remote — unlikely |
| 3 | Moderate — serious injury/illness EMT | Possible — reasonably likely |
| 4 | Serious — major LTA / chronic illness | Probable — likely |
| 5 | Critical — fatality | Almost Certain — very likely |

Risk score = severity × likelihood. Visible bands: 1–3 LOW; 4–7 UNLIKELY; 8–11 MEDIUM; 12–19 HIGH; 20–25 VERY HIGH. These are saved/walkthrough configuration values, not asserted universal safety scales.

**Add Risk** opens a risk dialog. Title (`findingTopic`) is the actual Work Element, such as lifting boxes. Hazard (`findingClassification?inlineButtons`) comes from the shared [Hazard library](<../../processes/QHSE - Modules/hazard.json>). Selecting a hazard provides baseline description, existing controls, severity and likelihood. These are editable by the assessor by default; customers often make existing controls read-only.

Hazards may be global or scoped to project/site/location. If multiple versions appear, **the assessor chooses the applicable version**; there is no confirmed automatic precedence rule. In COSHH, configured chemical hazards are chosen **independently of the selected substance**; the dropdown is not filtered by that material.

### Residual risk and actions

Next - Residual Risk captures Additional Controls, Future Severity, Future Likelihood, Responsible Person and Target Completion Date. It calculates residual score using the same multiplication and bands. Add Risk & Close returns the risk to the table; Update Risk & Close edits an existing entry. Users can bundle as many risk rows as needed.

The table (`findings?nostyleTable`) presents Work Element, Hazard, Status, and visual Current/Future State cards side by side. Row fields include current and future score/control data, `assessmentRiskID`, `assessmentHazardID`, action IDs and flags. Preserve those links when changing the display.

The Actions tab lists actions associated with additional controls and allows additional actions. **RA-created actions are internal-user only.** On completion of an additional-control action, its additional controls are added to the existing controls of the associated shared Hazard record, so later assessments can use the improved controls. Preserve scope and library identity: this is a meaningful shared-data update, not just a local status badge.

Source anchors include `riskActionUrlID`, `riskActionProcessURLID`, `actionCreatedFlag`, `assessmentCreatedFlag`, `INS_TABLE_ChecklistActions?nostyleTable`, `actionRiskID`, `actionHazardID4`, `updateStatusesFromAction`, `setStatusToComplete`, `updateHazard1` and the Action module's Update back to RA rule. The source also has a Create Action from this Hazard? control and copied hidden finding/NCR rule structures. Trace active triggers and conditions before using them; their presence does not mean that ordinary RA risk rows are Audit Findings or always create NCRs.

The walkthrough did not trace every action-creation flag or button callback. Owner-confirmed behavior is that additional-control actions are listed, can be completed by internal responsible users, and completion updates the shared risk's existing controls. Treat the exact creation timing of any newly customized path as a source-tracing task rather than inventing a new business rule.

### Summary and server work

Summary is mainly informational. It recaps assessor, task/material context, dates, operator, properties and Finalised report; provides People to be notified and Submit. It does not introduce another assessment method.

`OBS_BTN_ServerRules` assigns ID, runs ordinary and risk actions, generates RA and people reports, merges generated PDFs, sends originator/additional notifications and saves. `updateStatus` updates action status/counts and regenerates the report. Review/close controls also exist in saved source beyond the walked creation flow; exact customer approval requirements were not established.

### Changing risk behavior

- Library field changes: review Hazard → Add Risk lookup mappings → assessments table → Actions feedback → visual/report templates → RA Report.
- New scale: change numeric mappings, labels, displayed keys/cards, score band conditions, report visuals and Hazard defaults together.
- Read-only existing controls: enforce the assessor input rules without blocking the intended action-completion update to the shared library.
- Substance-specific hazard filtering would be new behavior, not the documented default.

## 15. Worked Hours

**Definition:** [hours-worked.json](<../../processes/QHSE - Modules/hours-worked.json>) · **New route:** `/forms/hours-worked?isNew=1` · **Daily data:** [hours-worked-data.json](../../processes/Data/hours-worked-data.json).

Worked Hours supplies exposure hours used in incident/accident-rate calculations. It records aggregate project/category totals, **not individual worker timesheets**.

Form 1 selects the project in Workspaces (`FORM_MS_POVO`). Measure (`FORM_MS_Measure`) selects a month/date range and Employee, Subcontractor or Temporary category, then displays daily cells in a week/weekday matrix with a period total. Custom permits a **custom date range**. Users should complete all relevant categories together to avoid duplicate registration.

**Bulk Update** opens a dialog for a total number and divides it equally across the matrix cells. Source also exposes Daily/Total and options such as overwrite existing data/exclude weekends; the owner explained the total-spreading path. Do not infer unconfirmed rounding or holiday behavior. The UI warns that background processing/visualization takes time and asks users to wait approximately ten minutes before changes and refresh afterward.

Technical anchors include `MS_LSTSIN_MissingRanges?inlineButtons`, `MS_DATE_StartDate`, `MS_DATE_EndDate`, `MS_LSTSIN_EmployeeType?inlineButtons`, `MS_TBL_Measures?nostyleTable`, weekday-hour fields, `MS_NUM_TotalRangeHours`, `MS_BTN_BulkUpdate`, `MS_BTN_RawRules`, and submit rules. The raw rule chain creates/updates daily Hours Worked Data records.

Change the daily data mapping, date/category identity and aggregation/report consumers together when changing the matrix. Rate formulas are widget/customer-specific; do not hard-code one denominator multiplier into this module.

## 16. Non Conformance Report (NCR)

**Definition:** [ncr.json](<../../processes/QHSE - Modules/ncr.json>) · **New route:** `/forms/ncr?isNew=1` · **Report:** [ncr-report.json](../../pages/Analytics/ncr-report.json).

Owner-confirmed lifecycle: **Submission → Review → Closure**. NCR captures a non-conformance and its follow-up workflow. Audit findings can create linked NCRs and pass ownership; it can also be entered from Create New.

Source forms are Classification (`form1NCR`), Actions, Summary and Utility. Classification includes Originator (`raised by`), Date and Time (`Process Created Date`), required Owner (`manager`), Category (`ncrCategory`), Title, Remarks, non-conformance level (`Category`: Major/Minor/OFI/OBS), optional impact, images and Recommendation by Originator. Audit-linked fields include Audit, Auditor, Audit Date and Go to audit. Shared Actions supports separate linked action records. Summary provides attachments, notification selection and closure controls.

The saved Server rules generates a report, creates actions and sends Notify. This source inventory does not establish every customer review approver, escalation or closure-approval rule. The walkthrough stopped at high-level coverage, so retain that limit when designing changes. Audit classification meanings do not automatically constitute separate NCR workflows.

## 17. Hazard library

**Definition:** [hazard.json](<../../processes/QHSE - Modules/hazard.json>) · **New route:** `/forms/hazard?isNew=1` · **Library page:** [hazard-library.json](../../pages/Analytics/hazard-library.json).

EHS personnel configure reusable hazards/risks with baseline controls and severity/likelihood, globally or for projects/sites/locations. RA selects these records. Multiple available hazard versions are displayed; **the assessor chooses the applicable version**.

Source forms: Classification (`form1-1`), Risk (`acceptedRisk`), Summary and Utility. Classification contains Hazard Type (General, Engineering, Safety, Chemical, Biological, Ergonomic), Title, Hazard Context, pictures, Workspaces, Reporter/date and Accepted Risk. Risk includes category, risk context, required Control Measures, Risk Owner, Likelihood, Severity and computed rating. Library categories include common hazards such as manual handling, chemical substance, confined spaces, electricity and moving machinery.

RA additional-control Action completion can append controls to this shared record. Altering hazard identity, scope or baseline fields therefore affects lookup selection, assessment creation and later action feedback. Do not resolve duplicate/versioned hazards by inventing automatic scope priority. Full hazard authoring/approval workflow was not demonstrated.

## 18. Supporting data and designer processes

These are operationally significant records even when they do not appear as a main Create New module. Their managing pages are described in [pages.md](./pages.md).

### Checklist library, designer, import and reuse

| Definition | Purpose |
| --- | --- |
| [audit-type.json](../../processes/Data/audit-type.json) | Checklist Type metadata, category, questions, scoring scales, template selection/export |
| [question.json](../../processes/Data/question.json) | Individual question definitions, answer types/scores, visibility/mandatory/related-question rules |
| [checklist-import.json](../../processes/Data/checklist-import.json) | Excel import and public-library import flow |
| [checklist-component.json](../../processes/Data/checklist-component.json) | Reusable runtime renderer and response/action rules |
| [checklist-component-without-actions.json](../../processes/Data/checklist-component-without-actions.json) | Separate runtime variant; inspect consumers before choosing it |

Admins can preview a checklist before use. The public library contains Kianda-authored examples shared across customers. Download creates a **local customer copy** for publishing; it does not edit the shared original. File import uses a supplied Excel template and handles duplicates. The owner confirmed duplicate handling but did not specify every identity/overwrite rule; inspect import rules for the particular change.

Checklist designer allows question/header configuration and scale editing. Thresholds aggregate actual question scores. Enable Report Template permits a custom Word template. Word rich-text content controls use `kf:<field-name>` tags. The top-right Excel export allows reuse: export, edit template questions, reimport.

**Roadmap:** AI-generated checklist drafts with admin correction/publish mechanism, and generating a custom report template from an existing Word document. Do not present these as released behavior.

### Induction designer and slides

[Induction Type](../../processes/Data/induction-type.json) stores title/description, expiry configuration and ordered slide links. Expiry is useful for high-risk work requiring retraining. Clone copies the entire induction including its slides. [Slide](../../processes/Data/slide.json) stores image/video/checklist content, optional rich-text guidance and timer. Its `slideDuration(InSeconds)` is 0 to disable waiting. The player is a separate [Induction process](../../processes/Training/induction.json).

The custom player field is implemented by [induction-slides.js](../../components/fields/induction-slides.js) and [induction-slides.hbs](../../components/fields/induction-slides.hbs). Review these when changing slide navigation, timer or quiz interaction, in addition to process rules.

**Roadmap:** AI generation of a complete induction/training and public configuration for quiz-failure replay behavior.

### Worker, Certificate, course and role records

[Worker](../../processes/Training/worker.json) supports the Worker Training Card, identity/company/role, certificates and compliance. A red card indicates repeated safety offenses and typically mandatory training/induction with a formal record. Default create/import access is broad; onboarding usually applies security.

Certificates uploaded through the card are individual training records. The displayed date is expiry. Training/course choices are configured in EHS Admin lists; selected training populates Code, which the user can change. Reminder-day options are configurable and shared across training types.

[Certificate](../../processes/Training/certificate.json) stores worker link/ID/email, training, certificate file/URL, expiry, reminders and notes. It schedules due/expired notifications. [Training Certificate page](../../pages/Training/training-certificate.json) calculates its displayed status using expiry and ember-moment helpers. Do not conflate a rendered date-based badge with a separately persisted process status. By default the certificate page is visible to all users; customer security may narrow it.

Related lookups/import: [Training Course](../../processes/Data/training-course.json), [Worker Role](../../processes/Data/worker-role.json), [Worker Import](../../processes/Data/worker-import.json). Event Training and Induction can create Certificate records programmatically, so changes to required certificate inputs must cover both producers and manual upload.

### EHS Asset, responsibility and subcontractor onboarding

[EHS Asset](../../processes/Data/asset.json) supplies hierarchy and physical assets. Type-controlled panels show relevant fields; common identity values feed cross-module selectors. Assets can have inspection schedules/owners; scheduled notifications help EHS leaders track overdue inspections. The carousel pages can display the asset QR code and edit through a pencil control.

Subcontractor is an EHS Asset Type. Sending an anonymous link lets an outside subcontractor fill information and attach documents. **The owner confirmed the anonymous link does not expire in this version.** Do not invent a default expiry. Planned richer subcontractor management includes regular reviews and separate document maintenance similar to worker certificates.

[Configuration](../../processes/Data/configuration.json) selects asset type and asset, then edits rows stored in [asset-responsible.json](../../processes/Data/asset-responsible.json). Blank submissions clear responsibility; inheritance requires customer configuration.

Bulk asset import uses a preview/edit table and supplied Excel template. Known owner-confirmed issue: duplicate matching should use **Type + Code**, whereas existing matching is insufficient. Validation is limited. These are documented product issues, not changes performed by this exercise.

### COSHH Material

[Material](../../processes/COSHH/material.json) stores substance, supplier, latest SDS/revision, description, hazard properties and next SDS check date. The hazard indicators and other inputs are separate, not automatically inferred from an uploaded SDS. Material details are carried into COSHH RA and remain editable there. Editing the material library and conducting an assessment are distinct operations.

### Lookup lists and document control

EHS Admin → Other lists maintains small record-backed lookup processes, including [Root Cause](../../processes/Data/root-cause.json), [Training Course](../../processes/Data/training-course.json), [Worker Role](../../processes/Data/worker-role.json), equipment, [Energy Type](../../processes/Data/energy-type.json) and [Energy Unit](../../processes/Data/energy-unit.json). Changes affect **future selections**; they do not retroactively rewrite historical records.

Policies is a document-library/document-control view. Origin distinguishes group/company-wide from site-specific applicability. The documented approval route is serial: approval becomes Approved after all approvers approve. The displayed policy date is next review. Default policy administration is EHS Admins only. See [Policies page documentation](./pages.md) for its exact backing definitions and page configuration.

## 19. Environmental modules with limited coverage

### Energy Registration

**Definition:** [energy-registration.json](<../../processes/QHSE - Environment/energy-registration.json>) · **New route:** `/forms/energy-registration?isNew=1` · **Report:** [energy-registration.json](../../pages/Analytics/energy-registration.json).

No detailed owner walkthrough was performed. Source shows Workspaces, Consumption period, Asset type, Energy type, Equipment, Source and Summary forms. Inputs include a no-consumption period option, start/end, asset type/subtype, paying party, energy type/subtype, amount/unit, equipment and consumption evidence/source. Helper fields include emission/conversion-factor data. Associated lookups include Energy Type, Energy Unit and Equipment.

This inventory is sufficient to locate the feature, not to infer approved emissions factors, reporting scopes, calculation semantics or regulatory coverage. Trace lookup records, submit rules and report widget calculations for a requested change. Customer omission from Create New is supported.

### Green Initiative

**Definition:** [green-initiative.json](<../../processes/QHSE - Environment/green-initiative.json>) · **New route:** `/forms/green-initiative?isNew=1`.

No detailed owner walkthrough was performed. Source forms cover Environmental aspect, Workspaces, Green initiative, Actions, Attachments and Summary. It captures proposed initiative, environmental impact/estimated impact, whether materials are reused and Executed versus Idea/Suggestion. Source contains feedback/approve/reject controls and notification/assignment rule chains. These controls alone do not establish every approval scenario or current customer policy. Inspect conditions, security and template links before modifying the module.

## 20. Common change dependency checklist

Use these as implementation navigation, not as an approval gate:

| Requested change | Inspect together |
| --- | --- |
| Add module to Create New | Process ID/security; link target and `link.users`; relevant Home shortcut; record-type tabs, reports and translations |
| Add hierarchy level | EHS Asset Type/panels/parent field; Workspaces component and embedded hosts; selected-ID/code mappings; page URL filters/carousels; responsibility lookup and access; reports |
| Add checklist question type | Designer choices and Question schema; import/export representation; renderer; mandatory/visibility/related-question rules; score/output fields; host submit/report handling |
| Make signatures mandatory | Correct row/control; internal/external mode; validation on active branches; customer approval policy; generated report and public flow |
| Add Action field | Generic dialog and both create/edit copies; component hosts; Start Action mappings; standalone Action; follow-up/closure; parent linkage/report/email |
| Add Event type | Classification choice; type-specific panels/clear rules; required fields; Participants; certificate conditions; Summary/report; Event Report series/filters |
| Add Incident type | Follow the detailed Incident recipe; review injury counts and Accident Rates separately from label changes |
| Change risk controls or scales | Hazard library; RA lookup/dialog/table; visual keys/cards; Action completion callback; shared control update; reports |
| Change notifications | Exact originator/reporter/worker/responsible identity; conditions; CC/additional groups; attachments; asynchronous ordering |
| Rename lookup/process title | Title-based filters/tab matching/template references; stable IDs/names; existing records and stored links; translations |

## 21. Limits and source discrepancies to preserve

- The documentation exercise did not change process JSON, publish a workspace, send notifications, or execute module submissions to validate new changes.
- The live checklist renderer and saved definitions contain inherited controls/names. Use `enabled`, conditions and actual mappings; a copied title alone is not evidence of current behavior.
- Inspection signatures are optional in the demonstrated base setup. Earlier general comments about signatures being required were explicitly corrected.
- Score boundaries are the owner's final Pass ≥ high, At Risk strictly between low/high, Failed ≤ low. N/A/unanswered behavior must not be replaced with an exclusion assumption.
- Incident People is driven by Accident. The older Damage → People rule is disabled. Cost is source-enabled for Assets or Security; the owner demonstrated Assets.
- Incident notification PDFs are generated/stored separately; the inspected three notification settings do not attach them.
- PTW Suspend was described by the owner as setting Suspended. The saved enabled rules set global Closed and substatus Suspended; Extend sets global Extended and substatus Extension. This source discrepancy was documented, not changed.
- Anonymous subcontractor onboarding links are non-expiring in the documented version. Do not apply an assumed link lifetime to other workflows without inspecting their own rule.
- RA hazards are independent of substance and multiple hazard versions are chosen by the assessor. No automatic scope precedence was confirmed.
- Worked Hours is aggregate project/category exposure, supports custom date range, and Bulk Update total spreading. It is not a worker-level payroll module.
- Detailed NCR approval roles, complete Hazard lifecycle, every RA action-creation callback and the environmental modules were outside the agreed walkthrough scope. Trace source and ask targeted product questions if a future modification depends on those details.
- Customer reporting formulas may vary (for example LTIR/RIDDOR). The owner identified the saved Accident Rates multiplier/default and report-filter inconsistencies as bugs to fix later; see [pages/reporting documentation](./pages.md). They were not fixed as part of this documentation.
