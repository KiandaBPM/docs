# EHSwise pages and report configuration

This is the page reference for agents changing this EHSwise workspace. It combines the product owner's walkthrough with the page JSON inspected on 27 October 2026. Read [general.md](./general.md) for product concepts and architecture, [modules.md](./modules.md) for operational processes, and [the application data model](./data-model.md) for relationships.

The walkthrough describes the base product and common customer changes. A saved page definition describes this workspace's current configuration. Keep those two evidence sources distinct: customer security, branding, hierarchy, formulas, and workflow can vary. Roadmap features are explicitly identified below. Current source differences are recorded in this document.

## Navigation and page identity

Dashboard routes follow `/dashboard/{page.id}`. Process routes follow `/forms/{process.name}?isNew=1` for creation and `/forms/{record-id}` for existing records. A menu caption, page group, file name, page ID, process name, and process title can differ. Resolve the actual identifiers before editing links, filtering, or templates. In particular, Location is the `my-project` page and Risk Assessment records have the process title `RA` in cross-process views.

| Menu or page | Dashboard route | Definition | Primary data |
| --- | --- | --- | --- |
| Home | `/dashboard/index` | [index.json](../../pages/Dashboard/index.json) | Branding, shortcuts, walkthroughs |
| Create New | `/dashboard/create-new` | [create-new.json](<../../pages/Create New/create-new.json>) | Process links |
| My Overview | `/dashboard/my-overview` | [my-overview.json](<../../pages/My overview/my-overview.json>) | Current user's assignments and created records |
| Location | `/dashboard/my-project` | [my-project.json](<../../pages/My Project/my-project.json>) | EHS Asset + location-linked records |
| Assets | `/dashboard/my-asset` | [my-asset.json](<../../pages/My Asset/my-asset.json>) | EHS Asset + asset-linked records |
| Subcontractor | `/dashboard/subcontractor` | [subcontractor.json](../../pages/Subcontractor/subcontractor.json) | Subcontractor assets + their records/workers |
| Policies | `/dashboard/policies` | [policies.json](../../pages/Policies/policies.json) | Document |
| Training → Workers | `/dashboard/workers` | [workers.json](../../pages/Training/workers.json) | Worker |
| Training → Certificates | `/dashboard/training-certificate` | [training-certificate.json](../../pages/Training/training-certificate.json) | Certificate |
| Training → How-to Guides | `/dashboard/ehswise-guides` | [ehswise-guides.json](../../pages/Training/ehswise-guides.json) | HTML, video and PDF guidance |
| EHS Admin → Projects & Assets | `/dashboard/Assets` | [Assets.json](<../../pages/EHS Admin/Assets.json>) | Asset, Configuration, Process Responsible, imports |
| EHS Admin → Checklists | `/dashboard/checklist-data` | [checklist-data.json](<../../pages/EHS Admin/checklist-data.json>) | Checklist Type, questions, import |
| EHS Admin → Inductions | `/dashboard/induction-design` | [induction-design.json](<../../pages/EHS Admin/induction-design.json>) | Induction Type, Slide |
| EHS Admin → COSHH | `/dashboard/coshh-materials` | [coshh-materials.json](<../../pages/EHS Admin/coshh-materials.json>) | COSHH Material |
| EHS Admin → Other Lists | `/dashboard/other-data-lists` | [other-data-lists.json](<../../pages/EHS Admin/other-data-lists.json>) | Lookup process records |
| EHS Admin → Admin Data | `/dashboard/admin` | [admin.json](<../../pages/EHS Admin/admin.json>) | Configured cross-process summaries |
| EHS Admin → Languages | `/dashboard/languages` | [languages.json](<../../pages/EHS Admin/languages.json>) | Language configuration custom widget |
| Analytics | Individual report routes below | [Analytics folder](../../pages/Analytics/) | Operational module records and metric data |

EHS Admin pages and the 12 Analytics pages have the EHS Admins visibility group in this export: `624882d9-abec-4454-9e6e-779b35a2218b`. This identifier belongs to this workspace; map it to the intended customer group when porting configuration. Page visibility does not replace process-level security or record access rules. Default ordinary pages generally have empty page `visibleTo` lists; this does not establish unrestricted record access.

## How page widgets work together

Page JSON declares `widgets`, containers, grid classes, visibility, and widget `settings`. Common types are `widgets/widget-list`, `widgets/widget-filter`, `widgets/widget-link`, `widgets/widget-chart`, `widgets/widget-tile`, `widgets/widget-html`, and `widgets/widget-walkme`. `client-widget/...` points to workspace custom widget implementations.

Keep these contracts when changing a page:

- **Sources:** list/chart/tile `processName` and `processSource`, or filter/carousel `settings.list`, identify where records/options come from. A cross-process summaries list can omit a single `processName`.
- **Query:** `queryType` chooses matching records, current-user assignments, or created-by-current-user records. Its conditions are an additional boundary.
- **Filter targets:** `settings.connections` contains target `widgetId`, display title, source metadata, and target conditions. `connectTo` on charts/tiles is another relationship to inspect. Filtering is configured per widget; a filter's presence on the page does not imply every widget receives it.
- **URL state:** `enableQueryString`, `queryParameter`, and `updateURL` on filters keep selection in the URL. Carousel `parameter` reads the corresponding value.
- **Rendering:** custom fields have Handlebars `html`; their supporting data often appears as hidden list fields. Retain hidden fields needed by the template even when they are not normal columns.
- **New-record context:** links with `autoAppendQuery` retain page context such as project/asset selections. Follow the corresponding process rules that consume those parameters.

The owner clarified that the filter editor's **Associated process (for filtering only)** supplies field metadata. It is not a durable process-name filter for the cross-process Items list. For example, a filter edited using Observation metadata can still target the common project or custom-ID field of all record types. To restrict record type in the location views, use `__PROCESS_TITLE` as the Tabs filter does.

## Home

Definition: [index.json](../../pages/Dashboard/index.json); ID `index`; group `Dashboard`.

### Purpose, content, and customer variation

Home is the landing page for all users. Its base content is static and does not change with selected project or role. The main actions are three HTML shortcuts: **Record Event**, **Create observation**, and **Conduct an inspection**. They call `gotoForm('event', true)`, `gotoForm('observation', true)`, and `gotoForm('inspection', true)` respectively. The first parameter names the process; the second is the new-instance Boolean. These duplicate a convenient subset of the Create New catalogue. Customers sometimes add more main-action links.

The full-width custom carousel supplies banner imagery and welcome messaging. The owner said this is usually the first customer branding change; branding creates a sense that the system belongs to the customer. Edit images, text, and layout without changing process targets accidentally. The accompanying HTML About Section explains offline refresh.

EHSwise is a PWA. The service worker caches application runtime; the refresh gesture additionally caches process JSON definitions in IndexedDB to enable full offline use. Treat the runtime cache and cached process definitions as separate concepts when explaining offline preparation. The Home instructions advise refreshing before going offline and preserving the session/cache during offline use.

### Hidden onboarding walkthroughs

There are five `widgets/widget-walkme` widgets. They may be hidden in normal use by CSS classes while remaining visible in the page designer. Their step `type` is either `popup` or `click`; click steps navigate the interface using selectors. Walkthroughs are executable UI dependencies, not just descriptive copy.

| Walkthrough / CSS hook | What it teaches | Significant selectors and targets |
| --- | --- | --- |
| Welcome to EHSwise / `getting-started-guide` | Toolbar, offline refresh, notifications, profile; left menu; EHS Admins; Checklists; creating/configuring assets; Location banner/selector/tabs; Create New; energy/waste modules | `#right-nav-toolbar`, `.sidebar > .nav`, `li[data-group="EHS Admin"]`, `li[data-name="Assets"] > a`, `.slide-title`, `.widget-filter-tabs`, `li[data-name="create-new"] a` |
| `invite-team-guide` | Navigate to Team, open Manage Team Members, enter first/last/display names and email, then save invitations | `li[data-name="team-setup"]`, `.button-panel:first` |
| `create-projects-guide` | Open Projects & Assets, create an asset, select Type, complete type-specific fields, save | `li[data-name="Assets"] a`, `.button-panel:first` |
| `observation-guide` | Choose Location, favourite it, open Create New → Observation, select unsafe, fill details, review Summary and submit | `li[data-name="my-project"] a`, `.page-widget[title="Project"]`, `a[title="Add to favourites"]`, `.button-panel:contains(Observation)`, `.form-field[data-name="OBS_LSTSIN_TopicType?radioCards"]`, `button[data-name="OBS_BTN_ContinueClassification"]`, `.form-tab-list li[data-name="FORM_OBS_Summary"]`, `button[data-name="OBS_BTN_Submit"]` |
| `checklist-guide` | Open checklist library/designer, edit/reorder questions, scales/export; explain import and blank checklist creation | `li[data-name="checklist-data"] a`, `.widget-list`, `.widget-list a.btn:first`, `.button-panel:last` |

The welcome popup links to the four shorter guides with `data-guide` values. Its audit/inspection guide link is commented out. Existing selector strings include legacy caption assumptions: the current Location widget is titled Location while guide selectors mention Project; `energy-waste-modules` is saved without a CSS class prefix; Team setup is referenced although no matching page definition is in this export. These are source observations requiring UI review if altering guides. Do not assume they have all been demonstrated to work. Renaming widget titles, menu groups, field names, CSS classes, or button order can break guide navigation.

## Create New

Definition: [create-new.json](<../../pages/Create New/create-new.json>); ID/group `create-new` / `Create New`.

This is an ordinary dashboard page. CSS presents its menu entry as a primary button pinned at the top of the left menu. Its function is to make all available record creation actions easy to find.

The Links widget creates Inspection, Action, Observation, Event, Checklist, Action plan, Induction, Audit, Permit to work, Incident, Risk Assessment, Hazard, Non-conformance, and Hours Worked. A separate Energy Links widget creates Energy Registration and Green Initiative. Each is a process link that opens `/forms/{process-name}?isNew=1`; the saved links use `autoAppendQuery: true`.

Customers commonly hide unused modules, especially Action plan or energy/waste modules, and restrict others, such as Risk Assessment, to specific groups. `link.users` controls link visibility. Apply process security as well so a user cannot bypass the menu restriction by opening the form URL directly. The base JSON has empty `users` restrictions and `adminOnly: "no"`; these values are configuration, not a recommended permission policy for every customer. For each new or renamed module, update this page, any Home shortcut, relevant location/asset/subcontractor tabs, Analytics, and translation labels.

## My Overview

Definition: [my-overview.json](<../../pages/My overview/my-overview.json>); ID `my-overview`.

This page helps the current user find unfinished assigned work and records they previously started. It has two HTML section headings and two cross-process list widgets.

| List | Query behavior | Conditions in saved JSON |
| --- | --- | --- |
| Records Awaiting My Input | `processSource: own`, `queryType: assignedTo`; UI setting **Matching condition and assigned to current user** | `__STATUS != Closed` AND `processCustomID` is not blank |
| My Records / Records Submitted By Me | `processSource: own`, `queryType: createdBy` | `processSubject` is not blank AND `__PROCESS_NAME != certificate` |

The owner specifically explained that the Awaiting Input condition uses the **Custom Process ID (Calculate in the server)**. Do not replace the assignment query with a creator query: the same user can create a record while a different person must act on it. Custom cards depend on common properties including custom ID, subject, project/location, status, process title, and record identity. Existing-record links route to the instance. A new module that should appear here must populate the common summary properties and assignments expected by these lists.

## Location

Definition: [my-project.json](<../../pages/My Project/my-project.json>); caption **Location**; ID `my-project`.

This is the principal operational page. The default shows a Project-level hierarchy; customers often add Country, Region, Site, or other levels. The shared source is [EHS Asset](../../processes/Data/asset.json), while operational forms embed [Workspaces](../../processes/Data/workspaces.json) to associate records to that hierarchy.

### Selection and connections

1. The **Location** dropdown reads active Asset records with `type = Project`; displays `displayName`, stores `code`, and writes URL `project` (`enableQueryString`/`updateURL`). `PRJ1` is the saved demo default, not a cross-customer constant.
2. The **My Project** custom carousel reads the selected Asset through `parameter: project`. Its template presents description, location, Local EHS, dates, edit pencil, and QR code. The selector also explicitly connects `code = filterValue1` to the carousel.
3. The dropdown connects the Items list by `processProjectCode = filterValue1`.
4. The **Tabs** radio filter writes URL `tab` and connects `__PROCESS_TITLE = filterValue1` to Items. Default choices: Action, Inspection, Observation, Incident, Event, RA, Hazard, Induction, Action Plan, Audit, NCR, PTW. Titles must match actual process titles; adding a visible label alone is insufficient if its title differs.
5. Items is a cross-process list with a custom card field and common fields (`processCustomID`, `processSubject`, `__STATUS`, `__NAME`, creator, created, and substatus).
6. Three additional filters target Items: ID contains `processCustomID`; Creator contains `processOriginator`; Status equals `__STATUS` with Open, Closed, Follow-up, Draft options.
7. NEW RECORD navigates to Create New and appends the query string, preserving workspace context for processes that consume it.

Example: `/dashboard/my-project?project=PRJ1&tab=Action`. The banner's pencil opens the selected Asset record in a modal. The QR image encodes the project view using the Asset code. The template is part of carousel settings; supporting implementation is [carousel-widget.js](../../components/widgets/carousel-widget.js) and [carousel-widget.hbs](../../components/widgets/carousel-widget.hbs).

### Adding a hierarchy level

Coordinate Asset Type choices, relevant type-specific fields, parent references, Workspaces component, dropdown sources/conditions and cascade wiring, URL parameters, summaries properties, page filters, record access security, responsibility configuration, and affected reporting. A common onboarding change adds Country or Region to Asset Type, adds a matching parent field to Projects/Sites, then filters child choices by the selected parent. Country alone on the standard new-asset screen is an independent system country list; it does not automatically create a customer hierarchy relationship.

## Assets

Definition: [my-asset.json](<../../pages/My Asset/my-asset.json>); ID `my-asset`.

Assets gives a physical-asset view of records. It follows the Location page's carousel → dropdown → type tabs → Items pattern, using URL `asset` and `tab` instead of `project`.

- Asset dropdown reads active Asset records with `type = Asset`, displays `displayName`, and stores `code`. Saved demo default is `LD001`.
- Selector connects `processAssetCode = filterValue1` to Items and `code = filterValue1` to the My Asset Banner.
- Carousel `parameter: asset` displays description, location, owner, a pencil to edit the selected asset, and a QR code for `/dashboard/my-asset?asset={code}`. Its saved heading contains legacy text My Project; preserve the difference between a display-template caption and data source identity.
- Tabs are Inspection (default), Action, Audit, Observation, Event, Hazard, Incident; they match `__PROCESS_TITLE`. Customers sometimes change these according to which records can be linked to assets.
- ID, Creator, and Status filters use the same common summary properties as Location.
- The page's new-record links include ADD ASSET, opening the new Asset dialog. The owner emphasized this as an important route for creating assets. Existing assets are edited from the carousel pencil.

Example: `/dashboard/my-asset?asset=LD001&tab=Inspection`.

### New/edit Asset behavior relevant to this page

The Asset process is [asset.json](../../processes/Data/asset.json). Type controls panels and fields. `displayName` is calculated from title and code, for example **Ladder - 0001**. The asset owner is notified on the configured inspection schedule. This supports EHS leaders in identifying assets that have not been inspected regularly enough. When changing the schedule or display name, inspect the Asset rules and consuming dropdowns/templates, not just this page.

## Subcontractor

Definition: [subcontractor.json](../../pages/Subcontractor/subcontractor.json); ID `subcontractor`.

This is a focused view of subcontractor-specific records, including workers. Its dropdown reads active Asset records with `type = Subcontractor`, displays `displayName`, stores `code`, and updates URL `subcontractor`. The carousel uses `parameter: subcontractor`, displays description/country/active information, and provides an edit pencil. Saved demo default `JohnLTD` is just example data.

The selector connects Items through `processSubcontractorCode`; Tabs restrict `__PROCESS_TITLE`. Choices are Worker (default), Induction, Inspection, PTW, Action, NCR, Observation, Incident, Audit, Event. ID, Creator, and Status filters target Items. The custom card needs common process fields plus worker role/originator where relevant. The saved list also contains `processName: worker`; inspect the dynamic tab behavior and summaries query when changing it rather than inferring that a fixed Worker source is sufficient for all tabs.

Example: `/dashboard/subcontractor?subcontractor=JohnLTD&tab=Worker`. When customer site security is applied, users only see subcontractors permitted to them. Treat selector visibility and underlying record security as coordinated parts of that behavior.

The subcontractor self-service flow belongs to the Asset process and is described under Projects & Assets below.

## Training → Workers

Definition: [workers.json](../../pages/Training/workers.json); ID `workers`; data [worker.json](../../processes/Training/worker.json).

Purpose: manage worker training compliance. New Worker opens a modal; Import Workers opens [worker-import.json](../../processes/Data/worker-import.json); Go To Certificates opens `training-certificate`. The base lets anyone create/import workers. Customer onboarding usually adds security, so do not assume that open creation is the final customer policy.

The 20-row Workers list renders a card with picture/default avatar, display name and initials, role, subcontractor or Internal, training status, and red-card indicator. Cards open the worker profile in a modal. Supporting hidden fields include picture URL, worker ID/account, subcontractor code, display name, initials, role, expiring training information, and `issueRedCard`.

| Control | Source / target |
| --- | --- |
| Worker Name | Free text; `displayName contains filterValue1` |
| Company | Asset records restricted to Subcontractor; display name / code; target `processSubcontractorCode` |
| Role | Worker Role records; target worker `role` |
| Status | Ok, Due, Expired; target `trainingStatus` |
| All Workers tile | Count Worker; connected to Workers list |
| Red Card Workers tile | Count Worker with `issueRedCard = Yes`; connected to Workers list |

A red card means repeated safety offences. Typically the worker is sent to mandatory training/induction and a formal record is created. It is a safety/compliance concept, not simply another certificate expiry status.

### Worker profile and certificate upload

Individual training certificates are uploaded from the worker profile using [certificate.json](../../processes/Training/certificate.json). The date shown is the **expiry date**. Reminder days are configurable and shared across training types; users can change them. The training dropdown is maintained in EHS Admin → Other Lists (Training Courses). Selecting training populates its code. Certificates have automatic reminder behavior; preserve the worker/certificate relationship when altering forms or notifications.

## Training → Certificates

Definition: [training-certificate.json](../../pages/Training/training-certificate.json); ID `training-certificate`; default visible to everyone, subject to customer security.

This page lists the certificates themselves. Upload Certificate opens a new Certificate modal. The 20-row list's custom card shows training title, worker, company, status, and time relative to the expiry date; it opens the Certificate instance.

Filters are Course, Company, Status, Expiry Date Range, and Worker:

- Course uses Training Course `course` and filters Certificate `processSubject`.
- Company uses Subcontractor Asset `code` and filters `processSubcontractorCode`.
- Status offers Ok / Due / Expired and filters `trainingStatus`.
- Expiry range applies inclusive `gte`/`lte` to `expiringTrainingDate`.
- Worker displays Worker `displayName`, stores `processWorkerID`, and filters Certificate `workerID`.

The owner explained that statuses are expiry-based and use Ember Moment helpers for their presentation. The inspected card reads stored `trainingStatus` to choose green/check (Ok or empty), amber/hourglass (Due), or red/exclamation (Expired), then uses `moment-from-now` with `expiringTrainingDate`. Therefore changing expiry semantics requires following the Certificate/Worker calculation and reminder rules as well as this rendering template; the page alone does not prove all calculation behavior.

## Training → How-to Guides

Definition: [ehswise-guides.json](../../pages/Training/ehswise-guides.json); ID `ehswise-guides`.

This Training child page contains three HTML widgets: End User Guides, EHS User Video Guides, and PDF Guides. It is a help-content page rather than a workflow-data list. The page was identified in navigation but not walked through individually. Inspect its HTML links and media when changing guidance; keep Home selector-driven walkthroughs separate from this guide library.

## Policies

Definition: [policies.json](../../pages/Policies/policies.json); ID `policies`; data [document.json](../../processes/Policies/document.json).

Policies is the document library and document-control entry point. Opening a card opens the Policy/Document record, from which the actual file can be opened. The card includes originator, custom ID/title, creation date, status and document type. Approved status has a distinct icon.

The page includes document-type and Location filters. Document Type reads Document `businessUnit`; Location reads EHS Asset Site records using display name/code. **Review This Month** is based on `nextRevisionDate`, meaning next review/revision date, not the upload date. The list uses standard record identity plus custom fields; retain fields referenced by its template.

The owner described policy creation/document control as EHS Admins by default. The saved New Policy link and widget have empty user restrictions, so the page configuration alone does not prove enforcement; inspect process security and customer onboarding configuration before changing access.

### Document control approval screen

Origin follows the customer's hierarchy: Group means company-wide; Site means the document/policy applies to one site. Submitting starts a **serial approval** workflow. Each approver acts in turn; after everyone approves, the record becomes Approved. Do not implement a parallel or first-approval-wins model when customizing this workflow. Apply customer hierarchy and document scope consistently to selection, record access, and reporting.

## EHS Admin → Projects & Assets

Definition: [Assets.json](<../../pages/EHS Admin/Assets.json>); ID `Assets` (capital A); data [asset.json](../../processes/Data/asset.json).

This is the central maintenance page for hierarchy/workspace data used across modules and a frequent onboarding customization point. The Manage Assets widget opens New Asset, Configuration, and Bulk Import Assets in modals. Tabs filter Asset `type`; saved options are Project, Site, Location, Subcontractor, Office, Asset with Project default. All Assets is a custom-card list of Asset records with display name, type, active state, and record identity.

Type is defined by the Asset process. Its value controls which panels/fields are shown. Title, Code, Display Name, and Type are shared properties consumed widely by dropdowns and pages. A historical Plant asset type remains in parts of the process but is unused; the owner plans to remove it. Do not promote Plant to a supported default hierarchy level merely because its configuration remains.

### Responsibilities configuration

The special Configuration action opens `/forms/configuration?isNew=1` in a new-form modal using [configuration.json](../../processes/Data/configuration.json).

1. Select the Asset Type, then the specific Asset.
2. Continue to load the module-responsibility table, populated from Process Responsible records in [asset-responsible.json](../../processes/Data/asset-responsible.json).
3. Assign people to the responsibility rows and submit.
4. The process creates/updates responsibility configuration records for the selected Asset ID/code context.

Responsibilities apply only to the configured asset by default. Inheritance can be delivered through onboarding configuration; it is not inherent in the base selection flow. **Submitting a blank row clears that responsibility assignment.** Preserve this clearing behavior when changing table persistence. Module server rules consume these responsibility records, including incident notification recipients. Inspect topic codes and the selected asset mapping, not only visible topic labels, when adding a responsibility.

The saved Configuration process additionally contains an Overview form and a Groups entry point. That source presence is not an owner walkthrough of a separate groups-security flow; inspect it if that feature is in scope.

### Bulk Import Assets

Bulk Import Assets opens [asset-import.json](../../processes/Data/asset-import.json). It provides a sample Excel template and a table for bulk entry/import. Imported data is previewed and can be edited manually before submission. Validation is limited in the reviewed version.

**Owner-confirmed defect:** matching existing assets should use **Type AND Code**. The reviewed import behavior did not use the required composite match. Document and address it as a defect when import work is requested; do not copy the insufficient matching rule into a new implementation. Stronger validation is a future improvement discussed by the owner, not a shipped guarantee.

### Subcontractor self-service Asset screen

With Type Subcontractor, an administrator can send an email containing an anonymous link so the subcontractor can provide details and attach documents. The Anonymous form link rule generates a link that **never expires** in this version. Do not infer expiry from an unrelated field or a default assumption. The response updates the subcontractor information through the configured process flow.

The owner described a future subcontractor-management version with regular review and separate document maintenance similar to worker certificates. This is roadmap information, not current functionality.

## EHS Admin → Checklists

Definition: [checklist-data.json](<../../pages/EHS Admin/checklist-data.json>); ID `checklist-data`.

This shared library supplies inspections, audits, standalone checklists, incident-investigation checklists, induction quizzes and other consumers. A checklist definition is the **Checklist Type** process, technically [audit-type.json](../../processes/Data/audit-type.json); the filename does not mean only audits use it.

New Checklist opens a new Checklist Type modal. Import Checklist opens [checklist-import.json](../../processes/Data/checklist-import.json). The page has a category filter using `industry`, a searchable 15-row checklist list with custom cards, and a header HTML widget. Clicking a library item opens its designer; Preview lets an administrator view the checklist quickly before use.

### Import: public library and file

The public checklist library is shared across customer workspaces and contains examples created by Kianda. **Download creates a local customer-library copy** for publishing/customization; it is not a live reference that automatically keeps all customers' copies synchronized.

File import includes a sample Excel template so customers can model questions for import. The owner confirmed that duplicate handling is supported; the exact matching policy was not described in the walkthrough, so inspect the import rules before changing or promising replace/merge behavior. Maintain compatibility between file import and designer export.

### Checklist designer

The designer stores checklist name (`auditName`), category (`industry`), version, description, report-template choice/file, scoring setting, question configuration, and order. Adding a checklist starts with its name, then opens the designer.

Supported question choices in the saved designer are:

| Choice | Intent / related configuration |
| --- | --- |
| OK, Not OK, NA; Yes, No, NA | Preset answer families |
| Section Header | Organizes questions; does not request an answer |
| Custom | Administrator-defined possible answers and scores |
| Dropdown List | Configured dropdown answer options |
| EHS Asset List | Asset selector; includes Asset Type configuration |
| Worker List | Worker selector with selection-mode configuration |
| Single Line Textbox; Multi Line Textbox | Free text |
| Date; Date and Time | Temporal values |
| Signature | Signature answer |
| File Upload | Files/evidence |

Question configuration includes text, code, type, possible answers, score, sort order, and mandatory-question toggle. The table persists question IDs and ordering; reordering is more than a visual change. When adding a new answer type, update the designer, question persistence, reusable runtime [checklist-component.json](../../processes/Data/checklist-component.json), import/export mapping, and report rendering together.

### Scoring and labels

Checklist scales are editable in a dialog. They define thresholds against aggregated question scores and configurable display labels (`greatStatusLabel`, `okStatusLabel`, `failedStatusLabel`). These labels replace initial Pass/At Risk/Failed labels at runtime in consumers such as Audit. The owner stated that **Custom and Dropdown List questions contribute to scoring**. Unanswered questions are **not ignored**; the resulting score remains lower and may fail to reach the pass threshold. Do not silently rescale totals to only answered questions.

The confirmed boundary logic from the Inspection walkthrough is:

- Pass: total score **greater than or equal to** PassScore.
- At Risk: total score **greater than** FailScore and **less than** PassScore.
- Failed: total score **less than or equal to** FailScore.

NA answers are typically configured as zero. Customer choices and scoring configuration can differ; read the actual definition rather than assuming universal per-answer weights.

### Custom Word report and Excel reuse

Enable Report Template allows a custom Word template for generated inspection/checklist reports. Kianda's **Generate word document** rule parses rich-text content controls tagged `kf:<name-of-field>`. Preserve field names/tags and nested table mappings when changing a template or source fields. The planned next designer version can generate a custom report template from an existing Word document; that is roadmap work.

The top-right export/download action exports the checklist to an Excel template. Customers can modify questions and reimport for quick reuse. Export fields include category, checklist name, question, question code, answer type, order, help text, and custom answer configuration. Keep export schema aligned with the import template.

**Roadmap:** AI-generated checklists with draft → administrator review/correction → publish to library. Do not treat an AI draft as a published checklist in the current flow.

## EHS Admin → Inductions

Definition: [induction-design.json](<../../pages/EHS Admin/induction-design.json>); ID `induction-design`.

This is the training/induction content library. New Induction Design opens [induction-type.json](../../processes/Data/induction-type.json) as a form rather than a new modal in the saved page. The searchable 15-row list reads Induction Type and opens its designer. Supporting processes are [slide.json](../../processes/Data/slide.json) for content and [induction.json](../../processes/Training/induction.json) for the learner player.

### Induction Type designer

The initial form captures title/description. The Slides form manages ordered slides and enable-expiration / expires-after-completion settings. Expiration is particularly relevant to high-risk jobs. Clone creates a new induction including **all slides**. It does not merely copy a title pointing at the original slides. Slide ordering, callback/refresh behavior, linked checklist IDs, and media URLs are structural dependencies.

### Slide editor and runtime implications

Slide Type can be **Image**, **Video**, or **Checklist**. Rich-text content can add guidance alongside any of those types. Image/video slides have a timer in seconds intended to prevent users skipping training content too quickly; **0 disables the wait**. Checklist slides do not have that timer. The slide stores title, content, media/files, order, parent campaign/induction ID and checklist identity as applicable.

Learners complete the checklist inside the player. These are commonly custom multiple-choice answers. Customers often customize failed-checklist behavior to force revisiting the previous slide. The owner corrected this point: it is **not a public setting in the main product yet**; a configurable option is planned for the next release.

AI generation of complete inductions/training is underway. Keep this separate from the currently available manual designer. For learner identity, anonymous links, result status, certificate generation, and worker email behavior, read the Induction section of [modules.md](./modules.md).

## EHS Admin → COSHH material library

Definition: [coshh-materials.json](<../../pages/EHS Admin/coshh-materials.json>); ID `coshh-materials`; data [material.json](../../processes/COSHH/material.json).

This page maintains a library of hazardous/risky chemical substances. It includes a custom banner carousel, Supplied By filter, Add Chemical modal link, and a 10-row material card list. The list exposes substance, material code, supplier, status and revision. Its datasource is COSHH Material (`material`).

The New Material dialog captures the material metadata and hazardous properties used by COSHH Risk Assessment. The owner confirmed that the relevant hazard details are separate inputs rather than automatically inferred from one another. Details carry into [ra.json](<../../processes/QHSE - Modules/ra.json>): selecting a substance populates supplier, revision, SDS/file, description and hazard properties; the assessor can edit these in the assessment. The SDS belongs to the material record and can be opened from the assessment.

COSHH RA hazards are independently selected from the configured hazard library; they are **not filtered by the selected substance**. Material-library hazards/properties and the shared Hazard records used for risk scoring are related concepts but distinct data.

## EHS Admin → Other Lists

Definition: [other-data-lists.json](<../../pages/EHS Admin/other-data-lists.json>); ID `other-data-lists`.

Lookup data is stored as small process records, usually one-page forms with limited rules. The page groups inline lists and modal add/edit links.

| List | Definition | Important fields / consumers |
| --- | --- | --- |
| Worker Role | [worker-role.json](../../processes/Data/worker-role.json) | Role, Department; worker records and filters |
| Training Courses | [training-course.json](../../processes/Data/training-course.json) | Course, Code, Active; certificate training selection/code |
| Energy Type | [energy-type.json](../../processes/Data/energy-type.json) | Energy subtype, Unit, AssetType, Title; energy registration |
| Energy Unit | [energy-unit.json](../../processes/Data/energy-unit.json) | Title, Energy Type, Unit; energy registration |
| PTW Equipment | [ptw-equipment.json](../../processes/Data/ptw-equipment.json) | Title, Category, Applicable PTW; equipment options in permits |
| Root Cause | [root-cause.json](../../processes/Data/root-cause.json) | Root Cause; incident investigations |

**Owner-confirmed update semantics:** editing these choices changes future selections; it does not rewrite the captured values of historic records. Do not implement retroactive migrations merely to update a dropdown label. If a customer explicitly requests a migration, treat it as separate work with an impact assessment.

## EHS Admin → Admin Data

Definition: [admin.json](<../../pages/EHS Admin/admin.json>); ID `admin`.

This page exposes the broad record list with filtering, configured summary fields, selected-row bulk delete and export. It uses Kianda's schemaless summaries model to request fields across different process types. Common columns are record ID, status, process title, created-by/date, `processCustomID`, and code. Fields need not have identical form schemas in every module, but the requested property names must match saved data.

The owner's high-level description was all system records. The actual saved All Records list excludes several supporting/master-data processes, including question, team-member, ehswise-lite-members, Checklist Type, asset, induction-type, root-cause, ptw-equipment, worker, energy-unit, energy-type, training-course and worker-role. Consequently **all** means the configured operational scope, not literally every process record. Review the conditions before using this page as a complete backup or inventory.

The list enables search, column filtering, sorting, 20-row load-more paging, delete, bulk delete and export. Bulk delete applies **only to selected rows**. The owner confirmed OData export respects the filters and selected fields. The current page also saves `exportdataFormat: excel`; inspect the actual export control/platform behavior when extending it rather than assuming a single format from the caption. This is an administrative view; preserve its EHS Admin access boundary.

## EHS Admin → Languages

Definition: [languages.json](<../../pages/EHS Admin/languages.json>); ID `languages`; custom widget [lang.js](../../components/widgets/lang.js) / [lang.hbs](../../components/widgets/lang.hbs).

English is the default language. Add Language enables other languages. Automatic translation can populate values, and administrators can override translations manually. Process-field labels are translated here as well as the application interface.

When translation is enabled, a user's language selection is saved to their profile and used on the next visit. If the key for that language is missing, the interface falls back to the English label. Preserve keys and fallback behavior when changing labels, adding types, or moving fields. A missing translation is a missing language-specific key, not evidence that the underlying process field is absent.

## Analytics

### Architecture and generation contract

The following 12 reports were explicitly reviewed. They are customer configuration points where onboarding teams spend substantial time. Customers often alter filters, formulas, layout and definitions over time; LTIR, RIDDOR and other rate conventions can vary. Each widget instance can have a different formula intentionally.

Most reports use a wide Left container (`col-lg-9`) and narrower Right (`col-lg-3`); Accident Rates adds full-width Middle metrics. Standard charts are `widgets/widget-chart`, usually record counts grouped by `labelsField`. Standard tiles count or sum. Lists use selected fields, sorting, paging, export settings and custom status/ID templates. Queries are generally `processSource: own`, `queryType: all`; fixed conditions and connected filters further constrain results.

```mermaid
flowchart LR
    Source[Process records] --> List[List query and hidden fields]
    Source --> Charts[Chart grouping and aggregation]
    Source --> Tiles[Tile conditions or formula]
    Filters[Filters and URL state] --> Wiring[Explicit target widget IDs and conditions]
    Wiring --> List
    Wiring --> Charts
    Wiring --> Tiles
    Custom[Custom JS and Handlebars] --> Charts
    Custom --> Tiles
```

The project/configured-hierarchy filter usually applies throughout a report. However **each page can design its own filter coverage**. Inspect every `settings.connections` entry and `connectTo` reference. The inventory at the end of this file captures exact current field names, widget IDs and connection targets to support generation and tracing. It records configuration, including defects; it is not a clean template to clone blindly.

### Report route and process map

| Report | Route suffix | Page definition | Main process definition |
| --- | --- | --- | --- |
| Accident Rates | `accident-rate` | [accident-rate.json](../../pages/Analytics/accident-rate.json) | [incident.json](<../../processes/QHSE - Modules/incident.json>) + [hours-worked-data.json](../../processes/Data/hours-worked-data.json) |
| Actions | `action-report` | [action-report.json](../../pages/Analytics/action-report.json) | [action.json](<../../processes/QHSE - Modules/action.json>) |
| Audits | `audit-report` | [audit-report.json](../../pages/Analytics/audit-report.json) | [audit.json](<../../processes/QHSE - Modules/audit.json>) |
| Energy & Waste | `energy-registration` | [energy-registration.json](../../pages/Analytics/energy-registration.json) | [energy-registration.json](<../../processes/QHSE - Environment/energy-registration.json>) |
| Events | `event-report` | [event-report.json](../../pages/Analytics/event-report.json) | [event.json](<../../processes/QHSE - Modules/event.json>) |
| Hazard Library | `hazard-library` | [hazard-library.json](../../pages/Analytics/hazard-library.json) | [hazard.json](<../../processes/QHSE - Modules/hazard.json>) |
| Incidents | `incident-report` | [incident-report.json](../../pages/Analytics/incident-report.json) | [incident.json](<../../processes/QHSE - Modules/incident.json>) |
| Inspections | `inspections-report` | [inspections-report.json](../../pages/Analytics/inspections-report.json) | [inspection.json](<../../processes/QHSE - Modules/inspection.json>) |
| NCR | `ncr-report` | [ncr-report.json](../../pages/Analytics/ncr-report.json) | [ncr.json](<../../processes/QHSE - Modules/ncr.json>) |
| Observations | `observation-report` | [observation-report.json](../../pages/Analytics/observation-report.json) | [observation.json](<../../processes/QHSE - Modules/observation.json>) |
| PTW | `ptw-report` | [ptw-report.json](../../pages/Analytics/ptw-report.json) | [permit-to-work.json](<../../processes/QHSE - Modules/permit-to-work.json>) |
| Risk Assessments | `ra-report` | [ra-report.json](../../pages/Analytics/ra-report.json) | [ra.json](<../../processes/QHSE - Modules/ra.json>) |

### Accident Rates

Definition: [accident-rate.json](../../pages/Analytics/accident-rate.json); no main record list. Sources combine incident utility counts with hours-worked data.

- First Aid Cases sums `firstAidCount`; Medical Treatment and Lost Time Cases are both saved against `lostTimeIncidentCount` in the reviewed configuration. The Medical Treatment mapping is a source discrepancy to inspect rather than infer correctness from the caption.
- RIDDOR Cases counts `reportable_authorities contains Yes`.
- Hours Worked sums Employee hours (`DATAMS_NUM_EmployeeHours`) from `hours-worked-data`.
- Incidents this year / last year count incident `processDate` with `isThisYear` / `isPrevYear`.
- Custom AFR tile: numerator `incident.injuredPeopleCount`, denominator Employee hours; expression `(AccidentCount * 100000) / WorkerHours`.
- Custom LTIR tile: numerator `incident.lostTimeIncidentCount`, denominator Employee hours; expression `(LTICount * 200000) / HoursWorked`.
- Annual custom chart `client-widget/accident-rate` uses Year interval and six years, independently configured AFR expression. The saved page value was corrected to `(AccidentCount * 200000) / EmployeeHoursWorked`.

Project and Location selectors use Asset records and code values with URL `project` / `location`. Project restricts Type Project; Location restricts Type Site / Active Yes. Both have explicit links to the first-aid/medical/lost-time/RIDDOR/hour/year tiles. The Date Range targets incident `processDate`, but its saved target ID is absent from this page. It does not establish functional filtering of all rate widgets.

Implementations: [accident-rate.js](../../components/widgets/accident-rate.js), [accident-rate.hbs](../../components/widgets/accident-rate.hbs), [widget-tile.js](../../components/widgets/widget-tile.js), [widget-tile.hbs](../../components/widgets/widget-tile.hbs). Logo and `_CSS` are presentation widgets.

**Default defect remains in code:** although the page's chart setting is 200,000, the custom chart JavaScript fallback/initialization still uses `(AccidentCount * 20000) / EmployeeHoursWorked`. The owner confirmed 20,000 is an incorrect default requiring update. Distinguish a corrected instance setting from an unfixed implementation default. Formula differences between the AFR tile, LTIR tile and chart are otherwise intentionally supported, not automatically defects.

### Actions

Definition: [action-report.json](../../pages/Analytics/action-report.json); source `action`.

Status and Priority pie charts group `__STATUS` and `ACT_LSTSIN_Priority?inlineButtons`. A 10-row overdue list (widget titled Checklist) filters `ACT_DATE_DueDate isBeforeToday` AND `__STATUS = Follow-up`, sorting earliest due date first. High Priority counts Priority High; External Actions counts `internalExternalResponsible = External`; Overdue Actions uses the same overdue condition.

The 30-row Actions list sorts custom process ID descending and shows custom ID link, creator, internal/external responsibility, topic, responsible users, priority, due date, date assigned, project/location, status, action taken, completion date and person. Search, sorting, paging and OData export are enabled; add/delete/bulk delete are disabled. Add Action is a separate link to the Action process.

Responsible-user dropdown sources Action responsible users. It targets the list, Status/Priority charts, overdue/high/external tiles, and overdue list. One connection names a missing Completed on Time widget. Date Range applies `processDate` bounds to the main list, overdue list, High Priority and External Actions. Reported-this-week / previous-month / previous-year tiles use `processDate`. Preserve custom ID, priority and status templates and hidden backing fields.

### Audits

Definition: [audit-report.json](../../pages/Analytics/audit-report.json); source `audit`.

Charts: Status pie (`__STATUS`), Category pie (`category`), Projects bar (`processProject`). The 30-row list has audit/custom ID, audit type, category, checklist, title, project, `auditDate`, creator, standard, total score and status. It sorts custom ID descending, exports via OData, and disables add/delete/bulk delete.

Project options come from Audit `processProject` and target list, Status, Category, Projects, Internal, External, and Subcontractor widgets. Date range targets the list's `auditDate`. Audit type counters use `type-of-audit?radioCards`: Internal equals Internal; External contains External; Subcontractor equals Subcontractor. Total counts all matching audit records. This week and previous month use `auditDate`; **previous year currently lacks its date condition**, an owner-confirmed defect.

### Energy & Waste

Definition: [energy-registration.json](../../pages/Analytics/energy-registration.json); source `energy-registration`.

The 30-row list contains custom ID, project, start/end dates (`ER_DATE_StartDate`, `ER_DATE_EndDate`), asset type, energy type/subtype, units, amount, other asset types, modifier, created and status. It sorts custom ID descending, enables OData export, and disables add/delete/bulk delete. The current chart grouping uses `ERE_TXTSIN_EnergyType`, while displayed selection fields include `ERE_LISTSIN_EnergyType`; preserve that distinction until process mappings are reviewed.

Project options come from Energy Registration `processProject` and target list, Status pie and Energy Type bar chart. Manual Date uses `__CREATED` on the list rather than the consumption start/end range. The three time counters use creation date for this week, previous month and previous year. Total Number of Energy and Waste Records counts records; it is not the sum of usage amounts across incompatible units.

### Events

Definition: [event-report.json](../../pages/Analytics/event-report.json); source `event`.

Charts group Status, Event Type (`eventType?radioCards`), and Project. The 30-row list includes custom ID, event type, title, project, created date, initiator and status; OData enabled, mutations disabled, custom-ID descending.

Project options come from Event `processProject`. Explicit targets are Events list, Event Type chart, Status and Induction/Drill/Toolbox/Training counters. Date range targets list `__CREATED`. Counters by type match the corresponding value; there is also total count. Time tiles use this week and previous week. **Created this year uses `isPrevYear`**, an owner-confirmed label/condition defect. Do not automatically copy it as current-year logic.

### Hazard Library

Definition: [hazard-library.json](../../pages/Analytics/hazard-library.json); source `hazard`.

This report is also a maintenance entry point. Hazard Type radio filter uses `incidentType?radioCards`; Hazard Category dropdown uses `findingClassification?inlineButtons`; Country and Project use `processCountryCode` and `processProjectCode`. They source Hazard records. Country connects to Project and other filters; Country/Project also constrain the risk lists and band tiles, supporting cascading selection. Check the exact target table: Category currently targets only the two ranking lists, so its existence is not evidence every tile/main list is filtered.

Risk bands count `riskRating`: Very High ≥20, High 12–19, Medium 8–11, Unlikely 4–7, Low ≤3. A Total Number of Hazards tile is separate. Two 10-row lists restrict `__STATUS = Open` and sort `riskRating` descending (top) / ascending (bottom), rendering custom risk cards.

The 20-row main list includes custom ID, hazard type, project, date, category, controls, risk owner, likelihood, severity, and current rating. It enables add/delete but disables bulk delete/export, unlike most Analytics lists. Create a Hazard links to new Hazard and new RA. Multiple global/project/site/location variants of a hazard can be shown; the assessor chooses the applicable record rather than an automatic winning version being selected.

### Incidents

Definition: [incident-report.json](../../pages/Analytics/incident-report.json); source `incident`.

Charts group Status, Incident Type (`incidentType?radioCards`, bar), Damage Type (`incidentType?checkboxCards`, pie). The 30-row list includes incident/custom ID, type, damage types, emergency indicator, incident date/time (`processDate`), project, creator, Potential LTI, investigation flag and status. It sorts custom ID descending, exports through OData and permits delete; add/bulk delete are disabled.

Potential LTIs counts `potential_LTI = Yes`. Investigation counts `investigation = Yes` AND `__STATUS = Open`. RIDDOR/reportable counts `reportable_authorities = Yes`; total counts incidents. Time counters use `__CREATED` for this week/previous month/previous year. Date Range targets the list with `processDate`, meaning occurrence date rather than record-created date.

Project targets incident list/charts and potential-LTI/investigation/reportable tiles through `processProject`, but its option source is mistakenly **Observation**. This is an owner-confirmed bug; a new report should obtain the appropriate project choices rather than reproduce the wrong process source.

### Inspections

Definition: [inspections-report.json](../../pages/Analytics/inspections-report.json); source `inspection`.

Charts group Status and Project as pies and Checklist (`INS_LUPSIN_Checklist`) as bar. Pass / At Risk / Failed tiles count matching `__STATUS`; total counts inspection records. The 30-row list includes custom ID, title (`INS_TXTSIN_UploadTitle`), category, checklist, project, `processDate`, creator, status and substatus. It exports via OData and disables add/delete/bulk delete; custom ID descending.

Project options source Inspection `processProject`; target list, Status/Checklist charts, and outcome tiles. This Month / Last Month / Last Year use `processDate`. Date Range is still incorrectly configured against **Audit `auditDate` and a missing Audits list ID**. Last Month also retains an obsolete connection. Older evidence recorded the Failed tile's Project field as Laundry; the inspected JSON now uses `processProject` there. Keep the original defect history without asserting it is still present in that exact field.

### Non Conformance Reports

Definition: [ncr-report.json](../../pages/Analytics/ncr-report.json); source `ncr`.

Charts group Status, Classification (`Category`), and Project. The 30-row NCR list includes custom ID, Date and Time (`Process Created Date`), title, classification, originator (`raised by`), project, owner (`manager`), modifier and status. It sorts custom ID descending, exports via OData, and disables add/delete/bulk delete.

Project options source NCR `processProject`; target list, Status/Classification charts and classification tiles. Date Range targets list `Process Created Date`; time counters use that same field with this-week/previous-month/previous-year operators. Major and Minor count `Category` values; total counts NCR records. **OBS and OFI combines `Category = OBS` OR `Category = OFI` in the current source**, matching the intended union semantics. The earlier AND-condition defect is not present in this inspected configuration.

### Observations

Definition: [observation-report.json](../../pages/Analytics/observation-report.json); source `observation`.

Charts group Status, Observation Type (`OBS_LSTSIN_TopicType?radioCards`), and Project. The 30-row list includes custom ID, type, project, location, asset, title, reported date (`processDate`), reporter, SWA and reported-on-behalf-of employee/third-party fields. Its saved Asset column uses field `subcontractor`; do not rename that mapping merely from its caption without following the process data. Custom ID descending, OData enabled, add/delete/bulk delete disabled.

Tiles count all observations, `OBS_YN_SWAUsed = Yes`, subcontractor-related records, and Positive observation. Project options source Observation `processProject` and explicitly target list, Status/Observation Type charts, SWA and subcontractor tiles. Date range targets list `processDate`; period counters use this-week/previous-month/previous-year. Positive observations are intentionally auto-closed in the base product; reporting should preserve this interpretation of status.

### Permit to Work

Definition: [ptw-report.json](../../pages/Analytics/ptw-report.json); source `permit-to-work`.

Charts are Status, Project and PTW Type pies (`PTW_LSTSIN_TypePTW?radioCards`). The 30-row list includes custom ID, project, `processDate`, reporter, title, work description, type, PPE, rescue equipment, participant count and status. Custom ID descending, OData enabled, add/delete/bulk delete disabled.

Project options source PTW `processProject`; target list, Status/Project/PTW Type and Open/Extended/Closed tiles. The saved list connection metadata names `ncr`, despite the actual target list using PTW. One other target condition uses `selectAChecklist` as though it were the project field, and Extended points at an obsolete widget ID. These are configuration mismatches to resolve against intended filter coverage. Date Range targets the list's `Process Created Date`; period tiles use the same field. Active counts Open, Extended counts Extended, Closed counts Closed, plus total. The owner described extension as adding a phase while Open; do not infer a different workflow solely from a report tile called Extended.

### Risk Assessments

Definition: [ra-report.json](../../pages/Analytics/ra-report.json); main source `ra`.

Charts group Status, Assessors (`assessors`) and Project. The 30-row list includes custom ID, creation date, initiator, area, effective date, review date (`recommendedReviewDate`) and relative display, operator, project, assessors, assessment date (`processDate`), close comment, version and status. Custom ID descending, OData enabled, add/delete/bulk delete disabled.

Type tiles count `typeOfAssessment = Task based` or COSHH. Overdue Review Date uses `recommendedReviewDate isBeforeToday`; total counts RA. **Project dropdown is incorrectly sourced from Event**, and most of its target metadata also says Event. The period tiles query Event rather than RA, Created this year uses `isPrevYear`, and Date range targets a stale Events widget. These are owner-confirmed bugs; the main report's RA source does not make those other widgets correct automatically.

## Known defects and source discrepancies

The owner confirmed the reporting mismatches as bugs to document and fix later. Documentation work does not authorize silently changing report or process behavior. Record the following when choosing a generation example:

| Area | State in inspected source | Consequence for an agent |
| --- | --- | --- |
| Accident chart scale | Page instance 200,000; JS fallback/init 20,000 | Default remains a defect; preserve legitimate per-widget formula flexibility |
| Accident Date Range | Missing Incidents target ID | Reconnect to intended existing widgets |
| Action responsible-user filter | Missing Completed on Time target | Resolve target/removal using intended report design |
| Audit previous-year count | No date condition | Add intended previous-year condition when fixing |
| Events current-year tile | `isPrevYear` | Correct label/condition contract |
| Incident Project selector | Observation source | Use the intended Incident/hierarchy source |
| Inspection date range / Last Month | Audit field/list and stale connection | Use inspection field/real list target; older Laundry mapping is now `processProject` |
| NCR OBS/OFI | Current conditions use OR between OBS and OFI | Historical AND-condition defect is not present in the inspected source |
| PTW connections | Stale Extended ID, checklist used for project, NCR metadata | Review actual target and field mapping |
| RA filters/date widgets | Event sources/metadata, stale Events target, wrong-year condition | Rewire to RA as intended |
| Asset import | Owner says matching must use Type + Code | Do not use Code-only identity |
| Accident Medical Treatment | Saved sum duplicates lost-time field | Source observation requiring field mapping review; not independently confirmed by owner as a separate defect |

Do not convert every differing caption/metadata label into a runtime defect: a connection label can be stale while its ID and field are correct. Conversely a page can render successfully with missing filter targets. Compare IDs, actual field names, conditions and source process together.

## Additional exported pages not individually walked through

These definitions exist and should be considered when searching dependencies, but their business rules were not confirmed by the product owner in this exercise.

| Page | Observed implementation |
| --- | --- |
| [my-site.json](<../../pages/My Site/my-site.json>) / `my-site` | Site-focused variant of carousel + asset selector + type tabs + Items. Both carousel and selector use URL `locationCode`; tabs include Action, Inspection, Observation, Hazard, RA, Incident, PTW, Audit, Event, NCR, Action plan. |
| [my-office.json](<../../pages/My Office/my-office.json>) / `my-office` | Office-focused variant using `locationCode`, Items, common filters and process-title tabs. |
| [lessons-learned.json](<../../pages/Lessons Learned/lessons-learned.json>) / `lessons-learned` | Person/action-bar, welcome-banner, HTML tiles and custom `level-1-search` widget. |
| [lessons-learned2.json](<../../pages/Lessons Learned/lessons-learned2.json>) / `lessons-learned2` | Lessons Learned Items source `lessons-learned`; search/category/discipline filters with URL state; category data references `sub-category`, discipline references `knowledge-vault`. |
| [lessons-webinar.json](<../../pages/Knowledge Vault/lessons-webinar.json>) / `lessons-webinar` | Video Player and Vault Cast Gallery lists read `lessons-learned`; video selector uses URL `video`; search/category/banner/CSS widgets. |

## Change recipes for AI agents

### Add a record type to Location or Assets

1. Resolve the exact process title, not just its creation-route name.
2. Confirm that the module saves the relevant shared workspace code (`processProjectCode`, `processAssetCode` or `processSubcontractorCode`) and common card fields.
3. Add the matching title to the Tabs options and preserve `__PROCESS_TITLE` target conditions.
4. Keep URL `tab` and the intended default selection aligned with available values.
5. Retain hidden data required by the custom Items card and ensure its record link opens the right instance.
6. Add/adjust creation access in Create New and process security when relevant.

### Create or adapt an Analytics report

1. Choose a source module and enumerate its **actual internal field names and types**; do not derive them from a chart label.
2. Set page ID/title/group/containers and map EHS Admins visibility to the intended workspace group.
3. Configure the primary list: source, conditions, visible/hidden fields, sorting, page size, search, export, and mutation controls.
4. Add charts with grouping fields, count/sum aggregation and chart type. Add tiles with explicit conditions and aggregation.
5. Define each filter's option source, value/display fields, datasource conditions, URL behavior, and every target widget/condition.
6. For rates, state numerator, denominator, unit, scale factor, date scope, user/customer definition and zero-denominator behavior. The walkthrough did not establish a universal zero-hours behavior; inspect implementation before promising one.
7. Preserve custom-widget dependencies and instance settings; decide deliberately whether to change one instance or shared JS defaults.
8. Check all IDs and source/field references against the page and processes. Exclude known defects above from a new configuration.
9. Follow the user's requested validation scope. This reference describes what to inspect; documentation creation did not execute report queries or modify runtime configuration.

### Change a label, selector, or navigation entry

Check page ID versus display title, links, query parameters, template field references, translation keys, walkthrough selectors, reporting group fields and process security. A process title used in `__PROCESS_TITLE` tabs is an integration contract; changing the title alone may make records disappear from views.

## Exact Analytics configuration inventory

The following inventory is derived from the inspected page definitions. Field names, operators, query choices and connection IDs intentionally retain their current spelling, including legacy names and known defects. `{filterValue1}` / `{filterValue2}` denote the saved right-hand filter reference; `[saved: ...]` records accompanying saved display text rather than a universal fixed filter. Empty date-operator operands are normal for operators such as `isThisYear`. The narratives above explain meaning and correction status. Use the linked JSON as the source when making changes.


### Source inventory: Accident Rates

Definition: [accident-rate.json](../../pages/Analytics/accident-rate.json); page ID `accident-rate`.

| Widget title / ID | Type and source query | Grouping / aggregation / fixed conditions | Connected list |
| --- | --- | --- | --- |
| First Aid Cases<br>`d90c47c0-2c89-4df4-8fa2-27b4fb7cc8a4` | widgets/widget-tile; incident; own / all | sum `firstAidCount` | b91838ae-2965-40aa-8170-96729363a564 — missing in page |
| Medical Treatment<br>`9248024f-a5f4-4b15-946b-a4c5ec2c7d82` | widgets/widget-tile; incident; own / all | sum `lostTimeIncidentCount` | b91838ae-2965-40aa-8170-96729363a564 — missing in page |
| Lost Time Cases<br>`fb254ef0-59f2-44a2-b33e-7a7918edaa03` | widgets/widget-tile; incident; own / all | sum `lostTimeIncidentCount` | b91838ae-2965-40aa-8170-96729363a564 — missing in page |
| RIDDOR Cases<br>`1e228678-944e-46e7-bc8c-b763b79a23ec` | widgets/widget-tile; incident; own / all | tile count; where (reportable_authorities contains Yes) | b91838ae-2965-40aa-8170-96729363a564 |
| AFR<br>`95444bdf-07be-49c8-9f51-dec62c259084` | client-widget/widget-tile; expressions over incident + hours-worked-data | `(AccidentCount * 100000) / WorkerHours`; sums `injuredPeopleCount` and `DATAMS_NUM_EmployeeHours` | No explicit connected-list setting |
| LTIR<br>`2931037e-1847-44f0-b30b-7c0e39d53e01` | client-widget/widget-tile; expressions over incident + hours-worked-data | `(LTICount * 200000) / HoursWorked`; sums `lostTimeIncidentCount` and `DATAMS_NUM_EmployeeHours` | No explicit connected-list setting |
| Hours Worked<br>`f48dfaac-be25-4344-b03f-0f59883623e8` | widgets/widget-tile; hours-worked-data; own / all | sum `DATAMS_NUM_EmployeeHours` | b91838ae-2965-40aa-8170-96729363a564 — missing in page |
| incidents this year<br>`ba792bfc-310e-4b8b-b7ff-933fefffd454` | widgets/widget-tile; incident; own / all | tile count; where (processDate isThisYear ) | b91838ae-2965-40aa-8170-96729363a564 |
| Incidents last year<br>`4b936433-e191-4f96-9906-2c3a2532dd12` | widgets/widget-tile; incident; own / all | tile count; where (processDate isPrevYear ) | b91838ae-2965-40aa-8170-96729363a564 |
| AFR - Accident Frequency Rate<br>`8e0bfc11-9336-4dc0-b878-b68e05763ab8` | client-widget/accident-rate; implementation owns queries | `timeFrame: Year`, `monthsCount: 6`, `afrFormula: (AccidentCount * 200000) / EmployeeHoursWorked` | No explicit connected-list setting |

**Filter: Project** (`360ef62a-b81c-4514-8a70-bd88280d3629`), dropdownlist; options source `asset`; display `displayName`; value `code`; URL parameter `project`.

Option constraints: `(type eq Project)`.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| RIDDOR Cases | `1e228678-944e-46e7-bc8c-b763b79a23ec` | `incident` | (processProjectCode eq {filterValue1} [saved: PRJ1]) |
| First Aid Cases | `d90c47c0-2c89-4df4-8fa2-27b4fb7cc8a4` | `incident` | (processProjectCode eq {filterValue1} [saved: PRJ1]) |
| Medical Treatment | `9248024f-a5f4-4b15-946b-a4c5ec2c7d82` | `incident` | (processProjectCode eq {filterValue1} [saved: PRJ1]) |
| Lost Time Cases | `fb254ef0-59f2-44a2-b33e-7a7918edaa03` | `incident` | (processProjectCode eq {filterValue1} [saved: PRJ1]) |
| Hours Worked | `f48dfaac-be25-4344-b03f-0f59883623e8` | `incident` | (processProjectCode eq {filterValue1} [saved: PRJ1]) |
| Total incidents | `ba792bfc-310e-4b8b-b7ff-933fefffd454` | `incident` | (processProjectCode eq {filterValue1} [saved: PRJ1]) |
| Previous year | `4b936433-e191-4f96-9906-2c3a2532dd12` | `incident` | (processProjectCode eq {filterValue1} [saved: PRJ1]) |

**Filter: Location** (`1fc6e8e2-8dfe-4bbf-97ba-61e7a154cedb`), dropdownlist; options source `asset`; display `displayName`; value `code`; URL parameter `location`.

Option constraints: `(type eq Site)`.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| First Aid Cases | `d90c47c0-2c89-4df4-8fa2-27b4fb7cc8a4` | `incident` | (processLocationCode eq {filterValue1} [saved: ST001]) |
| Medical Treatment | `9248024f-a5f4-4b15-946b-a4c5ec2c7d82` | `incident` | (processLocationCode eq {filterValue1} [saved: ST001]) |
| Lost Time Cases | `fb254ef0-59f2-44a2-b33e-7a7918edaa03` | `incident` | (processLocationCode eq {filterValue1} [saved: ST001]) |
| RIDDOR Cases | `1e228678-944e-46e7-bc8c-b763b79a23ec` | `incident` | (processLocationCode eq {filterValue1} [saved: ST001]) |
| Hours Worked | `f48dfaac-be25-4344-b03f-0f59883623e8` | `incident` | (processLocationCode eq {filterValue1} [saved: ST001]) |
| Total incidents | `ba792bfc-310e-4b8b-b7ff-933fefffd454` | `incident` | (processLocationCode eq {filterValue1} [saved: ST001]) |
| Previous year | `4b936433-e191-4f96-9906-2c3a2532dd12` | `incident` | (processLocationCode eq {filterValue1} [saved: ST001]) |

**Filter: Date Range** (`8194614d-1024-4101-bbdb-76a7cad61945`), daterange; options source `manual`; display ``; value ``; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Incidents **missing in page** | `b91838ae-2965-40aa-8170-96729363a564` | `incident` | (processDate gte {filterValue1} AND processDate lte {filterValue2}) |

### Source inventory: Actions

Definition: [action-report.json](../../pages/Analytics/action-report.json); page ID `action-report`.

| Widget title / ID | Type and source query | Grouping / aggregation / fixed conditions | Connected list |
| --- | --- | --- | --- |
| Status<br>`93ec3954-2b40-447b-ae0d-3550023294b8` | widgets/widget-chart; action; own / all | group __STATUS; chart pie | b84cb3d7-7638-481e-98ac-a35b52ddc2da |
| Priority<br>`6ea8b601-fa9e-4acd-a6be-0117049cf949` | widgets/widget-chart; action; own / all | group ACT_LSTSIN_Priority?inlineButtons; chart pie | b84cb3d7-7638-481e-98ac-a35b52ddc2da |
| Checklist<br>`dc898dfc-2dd1-43d8-baff-0a8a3cc1a4aa` | widgets/widget-list; action; own / all | where (ACT_DATE_DueDate isBeforeToday {ACT_DATE_ActionCompleted} [saved: Date action completed] AND __STATUS eq Follow-up) |  |
| High Priority<br>`cbaae906-23cd-42df-b6f0-5cf29e2d99b0` | widgets/widget-tile; action; own / all | tile count; where (ACT_LSTSIN_Priority?inlineButtons eq High) | b84cb3d7-7638-481e-98ac-a35b52ddc2da |
| Actions<br>`b84cb3d7-7638-481e-98ac-a35b52ddc2da` | widgets/widget-list; action; own / all |  |  |
| Reported this week<br>`df6af641-117a-4e78-9253-781e45d6c336` | widgets/widget-tile; action; own / all | tile count; where (processDate isThisWeek ) | b84cb3d7-7638-481e-98ac-a35b52ddc2da |
| Reported previous month<br>`3da10166-fad9-4fdc-9236-e838777798d1` | widgets/widget-tile; action; own / all | tile count; where (processDate isPrevMonth ) | b84cb3d7-7638-481e-98ac-a35b52ddc2da |
| Reported previous year<br>`371fdb0a-6b88-43d7-8aca-3a18b0a17abe` | widgets/widget-tile; action; own / all | tile count; where (processDate isPrevYear ) | b84cb3d7-7638-481e-98ac-a35b52ddc2da |
| External Actions<br>`d803370a-9c89-4947-a92e-bab1c963a0fb` | widgets/widget-tile; action; own / all | tile count; where (internalExternalResponsible eq External) | b84cb3d7-7638-481e-98ac-a35b52ddc2da |
| Add Action<br>`ac9e8212-83e2-4e29-a101-c162ca5b0e21` | widgets/widget-link; ;  /  |  |  |
| Overdue Actions<br>`199f5760-e598-40af-b66c-e4c2c02ccb2a` | widgets/widget-tile; action; own / all | tile count; where (ACT_DATE_DueDate isBeforeToday  AND __STATUS eq Follow-up) | b84cb3d7-7638-481e-98ac-a35b52ddc2da |

**List: Checklist** — page size 10; add no; delete no; bulk delete no; export no.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| ID | `__NAME` | hidden |
| Process Name | `__PROCESS_NAME` | hidden |
| Modified | `__MODIFIED` | hidden |
| Action topic | `ACT_TXTSIN_Desc` | hidden |
| Priority | `ACT_LSTSIN_Priority?inlineButtons` | hidden |
| Due date | `ACT_LSTSIN_DueDate?inlineButtons` | hidden |
| Overdue Actions | `___CUSTOM_FIELD6` | Handlebars template |
| Status | `__STATUS` | hidden |
| Due date | `ACT_DATE_DueDate` | hidden |

**List: Actions** — page size 30; add no; delete no; bulk delete no; export yes.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| ID | `__NAME` | hidden |
| Custom ID | `processCustomID` | hidden |
| Action ID | `___CUSTOM_FIELD13` | Handlebars template |
| Created by | `__CREATED_BY` |  |
| Internal or external? | `internalExternalResponsible` |  |
| Created | `__CREATED` | hidden |
| Action topic | `ACT_TXTSIN_Desc` |  |
| Responsible users | `ACT_USER_ResponsibleUsers` |  |
| Priority | `ACT_LSTSIN_Priority?inlineButtons` | hidden |
| Priority | `___CUSTOM_FIELD18` | Handlebars template |
| Due date | `ACT_DATE_DueDate` |  |
| Date assigned | `processDate` |  |
| Project | `processProject` | hidden |
| Specific Location | `processLocation` | hidden |
| Action Status | `___CUSTOM_FIELD11` | Handlebars template |
| Status | `__STATUS` | hidden |
| Description of action taken | `ACT_TXTMUL_ActionsTaken` |  |
| Date action completed | `ACT_DATE_ActionCompleted` |  |
| Action completed by | `ACT_USER_ActionCompletedBy` |  |

**Filter: Filter By Responsibles** (`2c850f6b-ef3b-409c-88d3-a229a4147ba1`), dropdownlist; options source `action`; display `ACT_USER_ResponsibleUsers`; value `ACT_USER_ResponsibleUsers`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Actions | `b84cb3d7-7638-481e-98ac-a35b52ddc2da` | `action` | (ACT_USER_ResponsibleUsers contains {filterValue1}) |
| Status | `93ec3954-2b40-447b-ae0d-3550023294b8` | `action` | (ACT_USER_ResponsibleUsers contains {filterValue1}) |
| Overdue Actions | `199f5760-e598-40af-b66c-e4c2c02ccb2a` | `action` | (ACT_USER_ResponsibleUsers eq {filterValue1}) |
| High Priority | `cbaae906-23cd-42df-b6f0-5cf29e2d99b0` | `action` | (ACT_USER_ResponsibleUsers contains {filterValue1}) |
| External Actions | `d803370a-9c89-4947-a92e-bab1c963a0fb` | `action` | (ACT_USER_ResponsibleUsers contains {filterValue1}) |
| Priority | `6ea8b601-fa9e-4acd-a6be-0117049cf949` | `action` | (ACT_USER_ResponsibleUsers contains {filterValue1}) |
| Checklist | `dc898dfc-2dd1-43d8-baff-0a8a3cc1a4aa` | `action` | (ACT_USER_ResponsibleUsers contains {filterValue1}) |
| Completed on Time **missing in page** | `24aa5edd-7559-48ff-92d8-a98ba4f6fdbc` | `action` | (ACT_USER_ResponsibleUsers contains {filterValue1}) |

**Filter: Date Range** (`1385f920-78ee-47e6-b930-c9d702adf5a5`), daterange; options source `manual`; display ``; value ``; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Actions | `b84cb3d7-7638-481e-98ac-a35b52ddc2da` | `action` | (processDate gte {filterValue1} AND processDate lte {filterValue2}) |
| Checklist | `dc898dfc-2dd1-43d8-baff-0a8a3cc1a4aa` | `action` | (processDate gte {filterValue1} AND processDate lte {filterValue2}) |
| High Priority | `cbaae906-23cd-42df-b6f0-5cf29e2d99b0` | `action` | (processDate gte {filterValue1} AND processDate lte {filterValue2}) |
| External Actions | `d803370a-9c89-4947-a92e-bab1c963a0fb` | `action` | (processDate gte {filterValue1} AND processDate lte {filterValue2}) |

### Source inventory: Audits

Definition: [audit-report.json](../../pages/Analytics/audit-report.json); page ID `audit-report`.

| Widget title / ID | Type and source query | Grouping / aggregation / fixed conditions | Connected list |
| --- | --- | --- | --- |
| Status<br>`0c5866ba-3932-4389-81ab-ba214e326a84` | widgets/widget-chart; audit; own / all | group __STATUS; chart pie | 1bea60b6-e323-4382-8993-7ac9bcf22fc4 |
| Category<br>`db13625f-d71b-45e0-8229-2e09268e47dc` | widgets/widget-chart; audit; own / all | group category; chart pie | 1bea60b6-e323-4382-8993-7ac9bcf22fc4 |
| Projects<br>`501a91fd-40f8-47ac-bcb8-3716ea9faede` | widgets/widget-chart; audit; own / all | group processProject; chart bar | 1bea60b6-e323-4382-8993-7ac9bcf22fc4 |
| Audits<br>`1bea60b6-e323-4382-8993-7ac9bcf22fc4` | widgets/widget-list; audit; own / all |  |  |
| Audits this week<br>`6e43f4a2-2e60-4f5f-beba-3d6623031353` | widgets/widget-tile; audit; own / all | tile count; where (auditDate isThisWeek ) | 1bea60b6-e323-4382-8993-7ac9bcf22fc4 |
| Audits previous month<br>`a3acee4c-3098-41d5-8d95-e9522531d18b` | widgets/widget-tile; audit; own / all | tile count; where (auditDate isPrevMonth ) | 1bea60b6-e323-4382-8993-7ac9bcf22fc4 |
| Audits previous year<br>`3c247a40-5c3a-43d0-8150-7fe6c05bc201` | widgets/widget-tile; audit; own / all | tile count | 1bea60b6-e323-4382-8993-7ac9bcf22fc4 |
| Internal<br>`35a98175-5b85-4953-8b2b-5b28a6c9bda3` | widgets/widget-tile; audit; own / all | tile count; where (type-of-audit?radioCards eq Internal) | 1bea60b6-e323-4382-8993-7ac9bcf22fc4 |
| External<br>`d5ea4422-aaf6-41f7-bf0f-2764b916395f` | widgets/widget-tile; audit; own / all | tile count; where (type-of-audit?radioCards contains External) | 1bea60b6-e323-4382-8993-7ac9bcf22fc4 |
| Subcontractor<br>`cf8455e3-146e-404a-8d49-a069a284911c` | widgets/widget-tile; audit; own / all | tile count; where (type-of-audit?radioCards eq Subcontractor) | 1bea60b6-e323-4382-8993-7ac9bcf22fc4 |
| Total Number of Audits<br>`71e714de-07e7-48c8-8b25-1d914f0fa8c9` | widgets/widget-tile; audit; own / all | tile count | 1bea60b6-e323-4382-8993-7ac9bcf22fc4 |

**List: Audits** — page size 30; add no; delete no; bulk delete no; export yes.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| ID | `__NAME` | hidden |
| Audit ID | `___CUSTOM_FIELD13` | Handlebars template |
| Custom ID | `processCustomID` | hidden |
| Audit type | `type-of-audit?radioCards` |  |
| Category | `category` |  |
| Checklist | `INS_LUPSIN_Checklist` |  |
| Title | `processSubject` |  |
| Project | `processProject` |  |
| Audit date | `auditDate` |  |
| Created by | `__CREATED_BY` |  |
| Status | `__STATUS` | hidden |
| Standard | `standard` |  |
| Score | `totalScore` |  |
| Audit Status | `___CUSTOM_FIELD10` | Handlebars template |

**Filter: Filter By Project** (`0df05b80-b406-47f3-86f8-a60840c916e3`), dropdownlist; options source `audit`; display `processProject`; value `processProject`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Audits | `1bea60b6-e323-4382-8993-7ac9bcf22fc4` | `audit` | (processProject eq {filterValue1}) |
| Status | `0c5866ba-3932-4389-81ab-ba214e326a84` | `audit` | (processProject eq {filterValue1}) |
| Category | `db13625f-d71b-45e0-8229-2e09268e47dc` | `audit` | (processProject eq {filterValue1}) |
| Chart 13 | `501a91fd-40f8-47ac-bcb8-3716ea9faede` | `audit` | (processProject eq {filterValue1}) |
| Internal | `35a98175-5b85-4953-8b2b-5b28a6c9bda3` | `audit` | (processProject eq {filterValue1}) |
| External | `d5ea4422-aaf6-41f7-bf0f-2764b916395f` | `audit` | (processProject eq {filterValue1}) |
| Subcontractor | `cf8455e3-146e-404a-8d49-a069a284911c` | `audit` | (processProject eq {filterValue1}) |

**Filter: Date range** (`0830246b-eeaa-41d2-a069-585ca03166be`), daterange; options source `manual`; display ``; value ``; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Audits | `1bea60b6-e323-4382-8993-7ac9bcf22fc4` | `audit` | (auditDate gte {filterValue1} AND auditDate lte {filterValue2}) |

### Source inventory: Energy & Waste

Definition: [energy-registration.json](../../pages/Analytics/energy-registration.json); page ID `energy-registration`.

| Widget title / ID | Type and source query | Grouping / aggregation / fixed conditions | Connected list |
| --- | --- | --- | --- |
| Energy Registrations<br>`da2a79c4-cd2c-4886-9fa3-33f814829b41` | widgets/widget-list; energy-registration; own / all |  |  |
| Created this week<br>`eed8002d-ed94-46dd-ae73-e7f83951e3c3` | widgets/widget-tile; energy-registration; own / all | tile count; where (__CREATED isThisWeek ) | da2a79c4-cd2c-4886-9fa3-33f814829b41 |
| Created previous month<br>`ead4da6b-6438-4b6c-ba6b-7709b76f70b5` | widgets/widget-tile; energy-registration; own / all | tile count; where (__CREATED isPrevMonth ) | da2a79c4-cd2c-4886-9fa3-33f814829b41 |
| Created previous year<br>`8cfd0495-e1fe-4975-ae46-a6ad3a4dcc69` | widgets/widget-tile; energy-registration; own / all | tile count; where (__CREATED isPrevYear ) | da2a79c4-cd2c-4886-9fa3-33f814829b41 |
| Status<br>`eef82b2f-c675-4c41-81a6-daf2af9af43c` | widgets/widget-chart; energy-registration; own / all | group __STATUS; chart pie | da2a79c4-cd2c-4886-9fa3-33f814829b41 |
| Energy Type<br>`78ff2ad4-1b70-4a28-92a5-75378fb76ce1` | widgets/widget-chart; energy-registration; own / all | group ERE_TXTSIN_EnergyType; chart bar | da2a79c4-cd2c-4886-9fa3-33f814829b41 |
| Total Number of Energy and Waste Records<br>`7381c8f1-7240-4da3-9be0-f5e5080e0001` | widgets/widget-tile; energy-registration; own / all | tile count | da2a79c4-cd2c-4886-9fa3-33f814829b41 |

**List: Energy Registrations** — page size 30; add no; delete no; bulk delete no; export yes.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| ID | `__NAME` | hidden |
| Energy Reg ID | `___CUSTOM_FIELD14` | Handlebars template |
| Custom ID | `processCustomID` | hidden |
| Project | `processProject` |  |
| Start date | `ER_DATE_StartDate` |  |
| End Date | `ER_DATE_EndDate` |  |
| Asset type | `ERE_LSTSIN_AggregatedAsset?inlineButtons` |  |
| Energy type  | `ERE_LISTSIN_EnergyType` |  |
| Energy subtype | `ERE_LISTSIN_EnergySubtype` |  |
| Unit | `ERE_LISTSIN_Units` |  |
| Amount | `ERE_NUM_SingularAmount` |  |
| Other asset types | `ERE_LSTSIN_AggregatedAsset` |  |
| Modified by | `__MODIFIED_BY` |  |
| Created | `__CREATED` |  |
| Status | `__STATUS` | hidden |
| Energy Registration Status | `___CUSTOM_FIELD13` | Handlebars template |

**Filter: Project** (`708adc8d-b447-40b6-be3a-a71c5e38f30b`), dropdownlist; options source `energy-registration`; display `processProject`; value `processProject`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Energy Registrations | `da2a79c4-cd2c-4886-9fa3-33f814829b41` | `energy-registration` | (processProject eq {filterValue1}) |
| Status | `eef82b2f-c675-4c41-81a6-daf2af9af43c` | `energy-registration` | (processProject eq {filterValue1}) |
| Energy Type | `78ff2ad4-1b70-4a28-92a5-75378fb76ce1` | `energy-registration` | (processProject eq {filterValue1}) |

**Filter: Date** (`9ddb765b-c51e-4087-82d2-926d384ac62b`), daterange; options source `manual`; display ``; value ``; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Energy Registrations | `da2a79c4-cd2c-4886-9fa3-33f814829b41` | `energy-registration` | (__CREATED gte {filterValue1} AND __CREATED lte {filterValue2}) |

### Source inventory: Events

Definition: [event-report.json](../../pages/Analytics/event-report.json); page ID `event-report`.

| Widget title / ID | Type and source query | Grouping / aggregation / fixed conditions | Connected list |
| --- | --- | --- | --- |
| Status<br>`489cba4f-8ef9-4ce2-a83a-3b8a0d287312` | widgets/widget-chart; event; own / all | group __STATUS; chart pie | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Project<br>`5916db6d-0f89-47de-949c-0dc7e2f6a58c` | widgets/widget-chart; event; own / all | group processProject; chart bar | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Event Type<br>`3b0879f0-dc17-4f60-b182-a0262ea7b4a1` | widgets/widget-chart; event; own / all | group eventType?radioCards; chart pie | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Induction<br>`90be57c4-bc52-4b39-bd78-c2d8b71eef1e` | widgets/widget-tile; event; own / all | tile count; where (eventType?radioCards eq Induction) | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Events<br>`6acb37ed-392c-477f-aa46-71e86e1da409` | widgets/widget-list; event; own / all |  |  |
| Drill<br>`517418cf-30e6-41ee-a5f5-260c35878342` | widgets/widget-tile; event; own / all | tile count; where (eventType?radioCards eq Drill) | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Created this week<br>`76d494f1-87bd-4557-9033-68bbbd65b64f` | widgets/widget-tile; event; own / all | tile count; where (__CREATED isThisWeek ) | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Created previous week<br>`211e354a-1110-42a7-a777-5f27c5f40ee0` | widgets/widget-tile; event; own / all | tile count; where (__CREATED isPrevWeek ) | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Created this year<br>`e6d8226c-7548-40de-b4a3-f2d941eec35f` | widgets/widget-tile; event; own / all | tile count; where (__CREATED isPrevYear ) | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Toolbox<br>`ea5d00d3-4ab2-4199-9317-8e1a2f996a43` | widgets/widget-tile; event; own / all | tile count; where (eventType?radioCards eq Toolbox) | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Training<br>`6ed10c67-bc4b-4b27-955d-1dd8ba3f2fa8` | widgets/widget-tile; event; own / all | tile count; where (eventType?radioCards eq Training) | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Total Number of Events<br>`e8a6174c-4cf3-4036-95f3-a1cb6088c6bb` | widgets/widget-tile; event; own / all | tile count | 6acb37ed-392c-477f-aa46-71e86e1da409 |

**List: Events** — page size 30; add no; delete no; bulk delete no; export yes.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| ID | `__NAME` | hidden |
| Event ID | `___CUSTOM_FIELD9` | Handlebars template |
| Custom ID | `processCustomID` | hidden |
| Event Type | `eventType?radioCards` |  |
| Title | `processSubject` |  |
| Project | `processProject` |  |
| Created | `__CREATED` |  |
| Initiated by | `__CREATED_BY` |  |
| Status | `__STATUS` | hidden |
| Event Status | `___CUSTOM_FIELD8` | Handlebars template |

**Filter: Filter By Project** (`6a6cde2a-98c4-4889-9d6d-14f6ab37d045`), dropdownlist; options source `event`; display `processProject`; value `processProject`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Events | `6acb37ed-392c-477f-aa46-71e86e1da409` | `event` | (processProject eq {filterValue1}) |
| Event Type | `3b0879f0-dc17-4f60-b182-a0262ea7b4a1` | `event` | (processProject eq {filterValue1}) |
| Induction | `90be57c4-bc52-4b39-bd78-c2d8b71eef1e` | `event` | (processProject eq {filterValue1}) |
| Drill | `517418cf-30e6-41ee-a5f5-260c35878342` | `event` | (processProject eq {filterValue1}) |
| Status | `489cba4f-8ef9-4ce2-a83a-3b8a0d287312` | `event` | (processProject eq {filterValue1}) |
| Toolbox | `ea5d00d3-4ab2-4199-9317-8e1a2f996a43` | `event` | (processProject eq {filterValue1}) |
| Training | `6ed10c67-bc4b-4b27-955d-1dd8ba3f2fa8` | `event` | (processProject eq {filterValue1}) |

**Filter: Date range** (`496cf03f-e349-4f8e-b74e-6fa4d5864f39`), daterange; options source `manual`; display ``; value ``; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Events | `6acb37ed-392c-477f-aa46-71e86e1da409` | `event` | (__CREATED gte {filterValue1} AND __CREATED lte {filterValue2}) |

### Source inventory: Hazard Library

Definition: [hazard-library.json](../../pages/Analytics/hazard-library.json); page ID `hazard-library`.

| Widget title / ID | Type and source query | Grouping / aggregation / fixed conditions | Connected list |
| --- | --- | --- | --- |
| Total Number of Hazards<br>`22160dcd-ea62-454c-8e3e-c68ffb36925d` | widgets/widget-tile; hazard; own / all | tile count | a7a9cfce-2f7b-4dfc-a661-90e5c66f31ed |
| Very High Risks<br>`080e2bd4-c7ab-40b4-a477-f786fca47b4b` | widgets/widget-tile; hazard; own / all | tile count; where (riskRating gte 20) | a7a9cfce-2f7b-4dfc-a661-90e5c66f31ed |
| High Risks<br>`c306545a-aa67-41c5-9551-8b02c301a6d0` | widgets/widget-tile; hazard; own / all | tile count; where (riskRating gte 12 AND riskRating lte 19) | a7a9cfce-2f7b-4dfc-a661-90e5c66f31ed |
| Medium Risks<br>`839cfdc8-890f-4fd6-b489-282a024964a2` | widgets/widget-tile; hazard; own / all | tile count; where (riskRating gte 8 AND riskRating lte 11) | a7a9cfce-2f7b-4dfc-a661-90e5c66f31ed |
| Unlikely<br>`f6bd7d78-1666-4b70-83ea-e118c4877638` | widgets/widget-tile; hazard; own / all | tile count; where (riskRating gte 4 AND riskRating lte 7) | a7a9cfce-2f7b-4dfc-a661-90e5c66f31ed |
| Checklist<br>`8b4974d7-b52a-43f5-8682-58832a53be22` | widgets/widget-list; hazard; own / all | where (__STATUS eq Open) |  |
| Checklist<br>`e39c3d07-0db6-45cb-b03f-afec45958eaf` | widgets/widget-list; hazard; own / all | where (__STATUS eq Open) |  |
| Low Risks<br>`d582ba26-8a5b-4e06-9759-9dda95a0f6e2` | widgets/widget-tile; hazard; own / all | tile count; where (riskRating lte 3) | a7a9cfce-2f7b-4dfc-a661-90e5c66f31ed |
| Hazards<br>`a7a9cfce-2f7b-4dfc-a661-90e5c66f31ed` | widgets/widget-list; hazard; own / all |  |  |
| Create a Hazard<br>`bff57c0b-dff1-4f8a-b526-0bda846d700f` | widgets/widget-link; ;  /  |  |  |

**List: Checklist** — page size 10; add no; delete no; bulk delete no; export no.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| Top 10 Open Risks | `___CUSTOM_FIELD3` | Handlebars template |
| ID | `__NAME` | hidden |
| Modified | `__MODIFIED` | hidden |
| Title | `processTitle` | hidden |
| Status | `__STATUS` | hidden |
| Process Name | `__PROCESS_NAME` | hidden |
| Current Risk Rating | `riskRating` | hidden |

**List: Checklist** — page size 10; add no; delete no; bulk delete no; export no.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| ID | `__NAME` | hidden |
| Process Name | `__PROCESS_NAME` | hidden |
| Modified | `__MODIFIED` | hidden |
| Title | `processTitle` | hidden |
| Bottom 10 Open Risks | `___CUSTOM_FIELD5` | Handlebars template |
| Status | `__STATUS` | hidden |
| Current Risk Rating | `riskRating` | hidden |

**List: Hazards** — page size 20; add yes; delete yes; bulk delete no; export no.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| ID | `__NAME` | hidden |
| Process Name | `__PROCESS_NAME` | hidden |
| Modified | `__MODIFIED` | hidden |
| _Custom process ID | `processCustomID` |  |
| Hazard Type | `incidentType?radioCards` |  |
| Project | `processProject` |  |
| Report date and time | `processDate` |  |
| Category | `findingClassification?inlineButtons` |  |
| Control Measures | `controlMeasures` |  |
| Risk Owner | `riskOwner` |  |
| Likelihood | `currentStatelikelihood` |  |
| Severity | `currentStateseverity` |  |
| Current Risk Rating | `riskRating` | hidden |
| Risk Rating | `___CUSTOM_FIELD15` | Handlebars template |

**Filter: Filter by Hazard Type** (`60a36860-1ed8-4860-b4f9-17dae2fa9bf3`), radiolist; options source `hazard`; display `incidentType?radioCards`; value `incidentType?radioCards`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Checklist | `8b4974d7-b52a-43f5-8682-58832a53be22` | `hazard` | (incidentType?radioCards eq {filterValue1}) |
| Checklist | `e39c3d07-0db6-45cb-b03f-afec45958eaf` | `hazard` | (incidentType?radioCards eq {filterValue1}) |
| Hazards | `a7a9cfce-2f7b-4dfc-a661-90e5c66f31ed` | `hazard` | (incidentType?radioCards eq {filterValue1}) |

**Filter: Filter by Hazard Category** (`d94e839f-f945-4b5b-af4b-45846796419e`), dropdownlist; options source `hazard`; display `findingClassification?inlineButtons`; value `findingClassification?inlineButtons`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Checklist | `8b4974d7-b52a-43f5-8682-58832a53be22` | `hazard` | (findingClassification?inlineButtons eq {filterValue1}) |
| Checklist | `e39c3d07-0db6-45cb-b03f-afec45958eaf` | `hazard` | (findingClassification?inlineButtons eq {filterValue1}) |

**Filter: Filter by Country** (`b455bced-e9b6-4722-9047-3263f974560d`), dropdownlist; options source `hazard`; display `country`; value `processCountryCode`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Hazards | `a7a9cfce-2f7b-4dfc-a661-90e5c66f31ed` | `hazard` | (processCountryCode eq {filterValue1}) |
| Checklist | `8b4974d7-b52a-43f5-8682-58832a53be22` | `hazard` | (processCountryCode eq {filterValue1}) |
| Checklist | `e39c3d07-0db6-45cb-b03f-afec45958eaf` | `hazard` | (processCountryCode eq {filterValue1}) |
| Filter by Hazard Category | `d94e839f-f945-4b5b-af4b-45846796419e` | `` | (processCountryCode eq {filterValue1}) |
| Filter by Hazard Type | `60a36860-1ed8-4860-b4f9-17dae2fa9bf3` | `` | (processCountryCode eq {filterValue1}) |
| Very High Risks | `080e2bd4-c7ab-40b4-a477-f786fca47b4b` | `hazard` | (processCountryCode eq {filterValue1}) |
| High Risks | `c306545a-aa67-41c5-9551-8b02c301a6d0` | `hazard` | (processCountryCode eq {filterValue1}) |
| Medium Risks | `839cfdc8-890f-4fd6-b489-282a024964a2` | `hazard` | (processCountryCode eq {filterValue1}) |
| Unlikely | `f6bd7d78-1666-4b70-83ea-e118c4877638` | `hazard` | (processCountryCode eq {filterValue1}) |
| Low Risks | `d582ba26-8a5b-4e06-9759-9dda95a0f6e2` | `hazard` | (processCountryCode eq {filterValue1}) |
| Filter by Project | `f59b5277-260a-42b8-8743-241d64140b5e` | `` | (processCountryCode eq {filterValue1}) |

**Filter: Filter by Project** (`f59b5277-260a-42b8-8743-241d64140b5e`), dropdownlist; options source `hazard`; display `processProject`; value `processProjectCode`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Hazards | `a7a9cfce-2f7b-4dfc-a661-90e5c66f31ed` | `hazard` | (processProjectCode eq {filterValue1}) |
| Checklist | `8b4974d7-b52a-43f5-8682-58832a53be22` | `hazard` | (processProjectCode eq {filterValue1}) |
| Checklist | `e39c3d07-0db6-45cb-b03f-afec45958eaf` | `hazard` | (processProjectCode eq {filterValue1}) |
| Filter by Hazard Category | `d94e839f-f945-4b5b-af4b-45846796419e` | `` | (processProjectCode eq {filterValue1}) |
| Filter by Hazard Type | `60a36860-1ed8-4860-b4f9-17dae2fa9bf3` | `` | (processProjectCode eq {filterValue1}) |
| Very High Risks | `080e2bd4-c7ab-40b4-a477-f786fca47b4b` | `hazard` | (processProjectCode eq {filterValue1}) |
| High Risks | `c306545a-aa67-41c5-9551-8b02c301a6d0` | `hazard` | (processProjectCode eq {filterValue1}) |
| Medium Risks | `839cfdc8-890f-4fd6-b489-282a024964a2` | `hazard` | (processProjectCode eq {filterValue1}) |
| Unlikely | `f6bd7d78-1666-4b70-83ea-e118c4877638` | `hazard` | (processProjectCode eq {filterValue1}) |
| Low Risks | `d582ba26-8a5b-4e06-9759-9dda95a0f6e2` | `hazard` | (processProjectCode eq {filterValue1}) |

### Source inventory: Incidents

Definition: [incident-report.json](../../pages/Analytics/incident-report.json); page ID `incident-report`.

| Widget title / ID | Type and source query | Grouping / aggregation / fixed conditions | Connected list |
| --- | --- | --- | --- |
| Status<br>`a4f2fb6b-cbac-4725-a7db-7363b191c973` | widgets/widget-chart; incident; own / all | group __STATUS; chart pie | b91838ae-2965-40aa-8170-96729363a564 |
| Incident Type<br>`9c178fbb-e30b-4b59-a4c2-2ad50c58b9f7` | widgets/widget-chart; incident; own / all | group incidentType?radioCards; chart bar | b91838ae-2965-40aa-8170-96729363a564 |
| Damage Type<br>`083a04df-a4b7-49c2-9945-fe436ccb2a4b` | widgets/widget-chart; incident; own / all | group incidentType?checkboxCards; chart pie | b91838ae-2965-40aa-8170-96729363a564 |
| Potential LTIs<br>`1cba681b-e2a1-42b8-98e9-b9d3529d6bd2` | widgets/widget-tile; incident; own / all | tile count; where (potential_LTI eq Yes) | b91838ae-2965-40aa-8170-96729363a564 |
| Created this week<br>`8f41bd17-c008-4dea-b13b-0ebcb761e2cc` | widgets/widget-tile; incident; own / all | tile count; where (__CREATED isThisWeek ) | b91838ae-2965-40aa-8170-96729363a564 |
| Investigation<br>`cd447919-e317-45fa-a7c3-307dbb67a144` | widgets/widget-tile; incident; own / all | tile count; where (investigation eq Yes AND __STATUS eq Open) | b91838ae-2965-40aa-8170-96729363a564 |
| Incidents<br>`b91838ae-2965-40aa-8170-96729363a564` | widgets/widget-list; incident; own / all |  |  |
| Created previous month<br>`8ef92740-199b-4a5f-bcee-bed78230cd4b` | widgets/widget-tile; incident; own / all | tile count; where (__CREATED isPrevMonth ) | b91838ae-2965-40aa-8170-96729363a564 |
| Created previous year<br>`a2af3b7f-07ca-4ff0-8896-214ebe9dd98c` | widgets/widget-tile; incident; own / all | tile count; where (__CREATED isPrevYear ) | b91838ae-2965-40aa-8170-96729363a564 |
| Reportable to Authorities / RIDDOR<br>`89d00355-229d-4a7e-9f73-3442e6a04a9e` | widgets/widget-tile; incident; own / all | tile count; where (reportable_authorities eq Yes) |  |
| Total Number of Incidents<br>`880f72af-b6ef-419c-96aa-300b02575a14` | widgets/widget-tile; incident; own / all | tile count | b91838ae-2965-40aa-8170-96729363a564 |

**List: Incidents** — page size 30; add no; delete yes; bulk delete no; export yes.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| Incident ID | `___CUSTOM_FIELD9` | Handlebars template |
| Custom ID | `processCustomID` | hidden |
| ID | `__NAME` | hidden |
| Incident Type | `incidentType?radioCards` |  |
| Damage Type | `incidentType?checkboxCards` |  |
| Emergency? | `EmergencyInfo` |  |
| Incident date and time | `processDate` |  |
| Project | `processProject` |  |
| Created by | `__CREATED_BY` |  |
| Status | `__STATUS` | hidden |
| Potential LTI (>24h) | `potential_LTI` |  |
| Investigation | `investigation` |  |
| Incident Status | `___CUSTOM_FIELD8` | Handlebars template |

**Filter: Filter By Project** (`0cd45195-cfb0-4a84-a5a6-b5b5ebdf6c8d`), dropdownlist; options source `observation`; display `processProject`; value `processProject`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Incidents | `b91838ae-2965-40aa-8170-96729363a564` | `incident` | (processProject eq {filterValue1}) |
| Status | `a4f2fb6b-cbac-4725-a7db-7363b191c973` | `incident` | (processProject eq {filterValue1}) |
| Incident Type | `9c178fbb-e30b-4b59-a4c2-2ad50c58b9f7` | `incident` | (processProject eq {filterValue1}) |
| Damage Type | `083a04df-a4b7-49c2-9945-fe436ccb2a4b` | `incident` | (processProject eq {filterValue1}) |
| Potential LTIs | `1cba681b-e2a1-42b8-98e9-b9d3529d6bd2` | `incident` | (processProject eq {filterValue1}) |
| Investigation | `cd447919-e317-45fa-a7c3-307dbb67a144` | `incident` | (processProject eq {filterValue1}) |
| Reportable to the Authorities / RIDDOR | `89d00355-229d-4a7e-9f73-3442e6a04a9e` | `incident` | (processProject eq {filterValue1}) |

**Filter: Date Range** (`270a2d84-63eb-4321-9001-373ae1ed2124`), daterange; options source `manual`; display ``; value ``; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Incidents | `b91838ae-2965-40aa-8170-96729363a564` | `incident` | (processDate gte {filterValue1} AND processDate lte {filterValue2}) |

### Source inventory: Inspections

Definition: [inspections-report.json](../../pages/Analytics/inspections-report.json); page ID `inspections-report`.

| Widget title / ID | Type and source query | Grouping / aggregation / fixed conditions | Connected list |
| --- | --- | --- | --- |
| Status<br>`70a02f05-a458-4d67-a9c9-d0e629ba7a6a` | widgets/widget-chart; inspection; own / all | group __STATUS; chart pie | 41081568-83a6-47a3-9340-2e019d5eb19c |
| Project<br>`037d3c7e-7c66-471a-85af-6e44f6ab409f` | widgets/widget-chart; inspection; own / all | group processProject; chart pie | 41081568-83a6-47a3-9340-2e019d5eb19c |
| Checklist<br>`950bdbfd-20d6-464e-a5b9-0ba1863411a8` | widgets/widget-chart; inspection; own / all | group INS_LUPSIN_Checklist; chart bar | 41081568-83a6-47a3-9340-2e019d5eb19c |
| Pass<br>`343e184f-5f6d-46c3-b716-5e4897c7f349` | widgets/widget-tile; inspection; own / all | tile count; where (__STATUS eq Pass) | 41081568-83a6-47a3-9340-2e019d5eb19c |
| At Risk<br>`7090d8e2-5a68-49d9-9e35-0b8587ade025` | widgets/widget-tile; inspection; own / all | tile count; where (__STATUS eq At Risk) | 41081568-83a6-47a3-9340-2e019d5eb19c |
| Failed<br>`c713315b-4471-4c05-9988-9a083677587b` | widgets/widget-tile; inspection; own / all | tile count; where (__STATUS eq Failed) | 41081568-83a6-47a3-9340-2e019d5eb19c |
| Inspections<br>`41081568-83a6-47a3-9340-2e019d5eb19c` | widgets/widget-list; inspection; own / all |  |  |
| This Month<br>`c299d940-93c0-4e80-bfdf-9f0f6fa49dfc` | widgets/widget-tile; inspection; own / all | tile count; where (processDate isThisMonth ) | 41081568-83a6-47a3-9340-2e019d5eb19c |
| Last Month<br>`e5882b86-fab4-47ae-a44d-93aa479df227` | widgets/widget-tile; inspection; own / all | tile count; where (processDate isPrevMonth ) | 1bea60b6-e323-4382-8993-7ac9bcf22fc4 |
| Last Year<br>`00ad738c-62c3-4948-b8f7-47c35f50bc94` | widgets/widget-tile; inspection; own / all | tile count; where (processDate isPrevYear ) | 41081568-83a6-47a3-9340-2e019d5eb19c |
| Total Number of Inspections<br>`22990e12-4960-482a-a6c3-a31319d361d0` | widgets/widget-tile; inspection; own / all | tile count | 41081568-83a6-47a3-9340-2e019d5eb19c |

**List: Inspections** — page size 30; add no; delete no; bulk delete no; export yes.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| Inspection ID | `___CUSTOM_FIELD11` | Handlebars template |
| ID | `__NAME` | hidden |
| Custom ID | `processCustomID` | hidden |
| Audit type | `type-of-audit?radioCards` | hidden |
| Title | `INS_TXTSIN_UploadTitle` |  |
| Category | `category` |  |
| Checklist | `INS_LUPSIN_Checklist` |  |
| Project | `processProject` |  |
| When | `processDate` |  |
| Created by | `__CREATED_BY` |  |
| Status | `__STATUS` | hidden |
| Passed? | `___CUSTOM_FIELD12` | hidden, Handlebars template |
| Inspection Status | `___CUSTOM_FIELD13` | Handlebars template |
| _processSubstatus | `processSubstatus` | hidden |

**Filter: Filter By Project** (`b87f123c-1b00-4fff-a60e-822d272aee50`), dropdownlist; options source `inspection`; display `processProject`; value `processProject`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Audits | `41081568-83a6-47a3-9340-2e019d5eb19c` | `inspection` | (processProject eq {filterValue1}) |
| Status | `70a02f05-a458-4d67-a9c9-d0e629ba7a6a` | `inspection` | (processProject eq {filterValue1}) |
| Checklist | `950bdbfd-20d6-464e-a5b9-0ba1863411a8` | `inspection` | (processProject eq {filterValue1}) |
| Pass | `343e184f-5f6d-46c3-b716-5e4897c7f349` | `inspection` | (processProject eq {filterValue1}) |
| Inspections | `41081568-83a6-47a3-9340-2e019d5eb19c` | `inspection` | (processProject eq {filterValue1}) |
| At Risk | `7090d8e2-5a68-49d9-9e35-0b8587ade025` | `inspection` | (processProject eq {filterValue1}) |
| Failed | `c713315b-4471-4c05-9988-9a083677587b` | `inspection` | (processProject eq {filterValue1}) |

**Filter: Date range** (`0f7c4efd-0d7a-49d6-91b6-8dd389331ab3`), daterange; options source `manual`; display ``; value ``; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Audits **missing in page** | `1bea60b6-e323-4382-8993-7ac9bcf22fc4` | `audit` | (auditDate gte {filterValue1} AND auditDate lte {filterValue2}) |

### Source inventory: NCR

Definition: [ncr-report.json](../../pages/Analytics/ncr-report.json); page ID `ncr-report`.

| Widget title / ID | Type and source query | Grouping / aggregation / fixed conditions | Connected list |
| --- | --- | --- | --- |
| Status<br>`bd519a71-d358-48ef-8cf5-7211fca8a20e` | widgets/widget-chart; ncr; own / all | group __STATUS; chart pie | 4e0d4095-8895-4997-95fe-27a60ae50c4f |
| Classification<br>`98526ed6-10c2-4e4f-a646-b596e30d85c7` | widgets/widget-chart; ncr; own / all | group Category; chart pie | 4e0d4095-8895-4997-95fe-27a60ae50c4f |
| Project<br>`cbd2a259-e853-4e83-8773-e362cd3fdd65` | widgets/widget-chart; ncr; own / all | group processProject; chart pie | 4e0d4095-8895-4997-95fe-27a60ae50c4f |
| NCR Records<br>`4e0d4095-8895-4997-95fe-27a60ae50c4f` | widgets/widget-list; ncr; own / all |  |  |
| Created this week<br>`acf36dcc-bd4c-419a-9d40-8693e92fb764` | widgets/widget-tile; ncr; own / all | tile count; where (Process Created Date isThisWeek ) | 4e0d4095-8895-4997-95fe-27a60ae50c4f |
| Created previous month<br>`8a2256e9-aa8a-4254-8e94-9c9ea63f395c` | widgets/widget-tile; ncr; own / all | tile count; where (Process Created Date isPrevMonth ) | 4e0d4095-8895-4997-95fe-27a60ae50c4f |
| Created previous year<br>`d4df8a50-c363-414b-9620-2f731055dc6c` | widgets/widget-tile; ncr; own / all | tile count; where (Process Created Date isPrevYear ) | 4e0d4095-8895-4997-95fe-27a60ae50c4f |
| Major<br>`95e4ffbe-c7f0-4971-a53a-8dfc35cdfd02` | widgets/widget-tile; ncr; own / all | tile count; where (Category eq Major) | 4e0d4095-8895-4997-95fe-27a60ae50c4f |
| Minor<br>`785c717b-7300-411c-91d2-6278d2c326a0` | widgets/widget-tile; ncr; own / all | tile count; where (Category eq Minor) | 4e0d4095-8895-4997-95fe-27a60ae50c4f |
| OBS and OFI<br>`d8d4dd67-7098-406a-b442-d726aec2ad48` | widgets/widget-tile; ncr; own / all | tile count; where (Category eq OBS OR Category eq OFI) | 4e0d4095-8895-4997-95fe-27a60ae50c4f |
| Total Number of NCRs<br>`45f5ff6b-4c42-457a-afd2-7a299572335a` | widgets/widget-tile; ncr; own / all | tile count | 4e0d4095-8895-4997-95fe-27a60ae50c4f |

**List: NCR Records** — page size 30; add no; delete no; bulk delete no; export yes.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| ID | `__NAME` | hidden |
| NCR ID | `___CUSTOM_FIELD11` | Handlebars template |
| Custom ID | `processCustomID` | hidden |
| Date and Time | `Process Created Date` |  |
| Title | `processSubject` |  |
| Classification | `Category` |  |
| Originator | `raised by` |  |
| Project | `processProject` |  |
| Owner | `manager` |  |
| Modified by | `__MODIFIED_BY` |  |
| Status | `__STATUS` | hidden |
| NCR Status | `___CUSTOM_FIELD10` | Handlebars template |

**Filter: Filter By Project** (`c3061c46-8e8c-4f38-bbb9-71be858ae0b3`), dropdownlist; options source `ncr`; display `processProject`; value `processProject`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| NCR Records | `4e0d4095-8895-4997-95fe-27a60ae50c4f` | `ncr` | (processProject eq {filterValue1}) |
| Status | `bd519a71-d358-48ef-8cf5-7211fca8a20e` | `ncr` | (processProject eq {filterValue1}) |
| Classification | `98526ed6-10c2-4e4f-a646-b596e30d85c7` | `ncr` | (processProject eq {filterValue1}) |
| Major | `95e4ffbe-c7f0-4971-a53a-8dfc35cdfd02` | `ncr` | (processProject eq {filterValue1}) |
| Minor | `785c717b-7300-411c-91d2-6278d2c326a0` | `ncr` | (processProject eq {filterValue1}) |
| OBS and OFI | `d8d4dd67-7098-406a-b442-d726aec2ad48` | `ncr` | (processProject eq {filterValue1}) |

**Filter: Date Range** (`bbe977ea-fad5-487e-aab6-d96dcb63993e`), daterange; options source `manual`; display ``; value ``; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| NCR Records | `4e0d4095-8895-4997-95fe-27a60ae50c4f` | `ncr` | (Process Created Date gte {filterValue1} AND Process Created Date lte {filterValue2}) |

### Source inventory: Observations

Definition: [observation-report.json](../../pages/Analytics/observation-report.json); page ID `observation-report`.

| Widget title / ID | Type and source query | Grouping / aggregation / fixed conditions | Connected list |
| --- | --- | --- | --- |
| Status<br>`083f1822-35fc-49bd-aa18-515dbd6314b4` | widgets/widget-chart; observation; own / all | group __STATUS; chart pie | fadac495-db3e-4938-811e-de3badc44283 |
| Project<br>`3d1e106e-59cd-4712-91f1-e78135552783` | widgets/widget-chart; observation; own / all | group processProject; chart bar | fadac495-db3e-4938-811e-de3badc44283 |
| Observation Type<br>`c4e6c595-12a9-4641-908f-8418e15dbe2e` | widgets/widget-chart; observation; own / all | group OBS_LSTSIN_TopicType?radioCards; chart pie | fadac495-db3e-4938-811e-de3badc44283 |
| Total Number Observations<br>`11edbc5c-7308-43dd-af02-3bf74a3e1ad5` | widgets/widget-tile; observation; own / all | tile count | fadac495-db3e-4938-811e-de3badc44283 |
| Observations<br>`fadac495-db3e-4938-811e-de3badc44283` | widgets/widget-list; observation; own / all |  |  |
| Stop Work Authority?<br>`7178157c-9e81-4e86-a5a8-4880e5b46e47` | widgets/widget-tile; observation; own / all | tile count; where (OBS_YN_SWAUsed eq Yes) | fadac495-db3e-4938-811e-de3badc44283 |
| Reported this week<br>`c153d7c9-4b1b-4490-a75e-b7e6e8898f25` | widgets/widget-tile; observation; own / all | tile count; where (processDate isThisWeek ) | fadac495-db3e-4938-811e-de3badc44283 |
| Reported previous month<br>`9ca6118b-e994-4ade-9e72-1cab317b88c9` | widgets/widget-tile; observation; own / all | tile count; where (processDate isPrevMonth ) | fadac495-db3e-4938-811e-de3badc44283 |
| Reported previous year<br>`cfe36837-75bd-4980-a034-4435b9bd1df8` | widgets/widget-tile; observation; own / all | tile count; where (processDate isPrevYear ) | fadac495-db3e-4938-811e-de3badc44283 |
| Related to Subcontractor<br>`d357f10d-9620-47b9-ad6e-3ae5289678f2` | widgets/widget-tile; observation; own / all | tile count; where (isThisObservationRelatedToASubcontractor eq Yes) | fadac495-db3e-4938-811e-de3badc44283 |
| Positive Observations<br>`0e089c1d-34fc-4a40-b815-d655d8e860b3` | widgets/widget-tile; observation; own / all | tile count; where (OBS_LSTSIN_TopicType?radioCards eq Positive observation) | fadac495-db3e-4938-811e-de3badc44283 |

**List: Observations** — page size 30; add no; delete no; bulk delete no; export yes.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| ID | `__NAME` | hidden |
| Custom ID | `processCustomID` | hidden |
| Observation ID | `___CUSTOM_FIELD13` | Handlebars template |
| Observation type | `OBS_LSTSIN_TopicType?radioCards` |  |
| Project | `processProject` |  |
| Specific Location | `processLocation` |  |
| Asset | `subcontractor` |  |
| Title | `processSubject` |  |
| Reported on | `processDate` |  |
| Reported by | `OBS_USER_ReportedBy` |  |
| Stop Work Authority used? | `OBS_YN_SWAUsed` |  |
| Reported on behalf of employee | `OBS_USER_ReportedBehalfOf` |  |
| Reported on behalf of third party | `OBS_TXTSIN_ReportedBehalfOf` |  |
| Observation Status | `___CUSTOM_FIELD11` | Handlebars template |
| Status | `__STATUS` | hidden |

**Filter: Filter By Project** (`84697318-9100-47c1-b35e-bd046374b1de`), dropdownlist; options source `observation`; display `processProject`; value `processProject`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Observations | `fadac495-db3e-4938-811e-de3badc44283` | `observation` | (processProject eq {filterValue1}) |
| Status | `083f1822-35fc-49bd-aa18-515dbd6314b4` | `observation` | (processProject eq {filterValue1}) |
| Observation Type | `c4e6c595-12a9-4641-908f-8418e15dbe2e` | `observation` | (processProject eq {filterValue1}) |
| Observations | `fadac495-db3e-4938-811e-de3badc44283` | `observation` | (processProject eq {filterValue1}) |
| Stop Work Authority Used | `7178157c-9e81-4e86-a5a8-4880e5b46e47` | `observation` | (processProject eq {filterValue1}) |
| Related to Subcontractor | `d357f10d-9620-47b9-ad6e-3ae5289678f2` | `observation` | (processProject eq {filterValue1}) |

**Filter: Date Range** (`a33a8f21-88e0-4370-ba05-aeabb8a87163`), daterange; options source `manual`; display ``; value ``; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Observations | `fadac495-db3e-4938-811e-de3badc44283` | `observation` | (processDate gte {filterValue1} AND processDate lte {filterValue2}) |

### Source inventory: PTW

Definition: [ptw-report.json](../../pages/Analytics/ptw-report.json); page ID `ptw-report`.

| Widget title / ID | Type and source query | Grouping / aggregation / fixed conditions | Connected list |
| --- | --- | --- | --- |
| Status<br>`cf1642db-9915-4bb5-a054-0f954a99748e` | widgets/widget-chart; permit-to-work; own / all | group __STATUS; chart pie | 2e1c0474-9e5a-4f22-9fc9-eadd13d0cce0 |
| Project<br>`13c78a83-5d5c-43fd-a018-8ecd4d614565` | widgets/widget-chart; permit-to-work; own / all | group processProject; chart pie | 2e1c0474-9e5a-4f22-9fc9-eadd13d0cce0 |
| PTW Type<br>`50462785-4a76-403c-9426-94f5acf96eca` | widgets/widget-chart; permit-to-work; own / all | group PTW_LSTSIN_TypePTW?radioCards; chart pie | 2e1c0474-9e5a-4f22-9fc9-eadd13d0cce0 |
| PTW Records<br>`2e1c0474-9e5a-4f22-9fc9-eadd13d0cce0` | widgets/widget-list; permit-to-work; own / all |  |  |
| Created this week<br>`b2e4aed1-9c90-492d-853e-4dc66ff52476` | widgets/widget-tile; permit-to-work; own / all | tile count; where (Process Created Date isThisWeek ) | 2e1c0474-9e5a-4f22-9fc9-eadd13d0cce0 |
| Created previous month<br>`aea1aa7a-d294-4866-a87c-94d857d6e949` | widgets/widget-tile; permit-to-work; own / all | tile count; where (Process Created Date isPrevMonth ) | 2e1c0474-9e5a-4f22-9fc9-eadd13d0cce0 |
| Created previous year<br>`645992ca-b1ea-4d93-9d51-5a2ec367335f` | widgets/widget-tile; permit-to-work; own / all | tile count; where (Process Created Date isPrevYear ) | 2e1c0474-9e5a-4f22-9fc9-eadd13d0cce0 |
| Active<br>`a5338f93-4363-4643-9ade-d2ad84f65d02` | widgets/widget-tile; permit-to-work; own / all | tile count; where (__STATUS eq Open) | 2e1c0474-9e5a-4f22-9fc9-eadd13d0cce0 |
| Extended<br>`952e1c63-28b4-4458-b542-d49efdfc40e9` | widgets/widget-tile; permit-to-work; own / all | tile count; where (__STATUS eq Extended) | 4e0d4095-8895-4997-95fe-27a60ae50c4f |
| Closed<br>`5e597111-db57-4750-b138-68f6f6367ace` | widgets/widget-tile; permit-to-work; own / all | tile count; where (__STATUS eq Closed) | 2e1c0474-9e5a-4f22-9fc9-eadd13d0cce0 |
| Total Number of PTWs<br>`7b5bdd0b-581b-4706-b795-b95c44865bbe` | widgets/widget-tile; permit-to-work; own / all | tile count | 2e1c0474-9e5a-4f22-9fc9-eadd13d0cce0 |

**List: PTW Records** — page size 30; add no; delete no; bulk delete no; export yes.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| ID | `__NAME` | hidden |
| PTW ID | `___CUSTOM_FIELD11` | Handlebars template |
| Custom ID | `processCustomID` | hidden |
| Project | `processProject` |  |
| Date | `processDate` |  |
| Reported by | `PTW_USER_ReportedByCompany` |  |
| Title | `processSubject` |  |
| Status | `__STATUS` | hidden |
| Description of the works | `processDescription` |  |
| PTW type | `PTW_LSTSIN_TypePTW?radioCards` |  |
| PPE | `PTW_LUPMUL_PPE?checkboxCards` |  |
| Rescue equipment | `PTW_LUPMUL_RescueEquipment?checkboxCards` |  |
| Total number of participants | `PTW_NUM_Total` |  |
| PTW Status | `___CUSTOM_FIELD10` | Handlebars template |

**Filter: Filter By Project** (`b8708d67-e094-4dc0-8ed5-b34d868c934f`), dropdownlist; options source `permit-to-work`; display `processProject`; value `processProject`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| PTW Records | `2e1c0474-9e5a-4f22-9fc9-eadd13d0cce0` | `ncr` | (processProject eq {filterValue1}) |
| Status | `cf1642db-9915-4bb5-a054-0f954a99748e` | `permit-to-work` | (processProject eq {filterValue1}) |
| Project | `13c78a83-5d5c-43fd-a018-8ecd4d614565` | `permit-to-work` | (processProject eq {filterValue1}) |
| Active | `a5338f93-4363-4643-9ade-d2ad84f65d02` | `permit-to-work` | (processProject eq {filterValue1}) |
| Extended | `952e1c63-28b4-4458-b542-d49efdfc40e9` | `permit-to-work` | (processProject eq {filterValue1}) |
| Closed | `5e597111-db57-4750-b138-68f6f6367ace` | `permit-to-work` | (processProject eq {filterValue1}) |
| Project | `50462785-4a76-403c-9426-94f5acf96eca` | `permit-to-work` | (selectAChecklist eq {filterValue1}) |

**Filter: Date Range** (`0260f265-7348-433c-a93a-b3c538a0c38a`), daterange; options source `manual`; display ``; value ``; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| PTW Records | `2e1c0474-9e5a-4f22-9fc9-eadd13d0cce0` | `permit-to-work` | (Process Created Date gte {filterValue1} AND Process Created Date lte {filterValue2}) |

### Source inventory: Risk Assessments

Definition: [ra-report.json](../../pages/Analytics/ra-report.json); page ID `ra-report`.

| Widget title / ID | Type and source query | Grouping / aggregation / fixed conditions | Connected list |
| --- | --- | --- | --- |
| Status<br>`f0d79560-d5fa-48d4-8a04-56b70db1f316` | widgets/widget-chart; ra; own / all | group __STATUS; chart pie | cc9a083e-be95-4794-ab19-514c68fca93f |
| Project<br>`40f1d454-e71a-46fa-b64a-fdf57c077a1f` | widgets/widget-chart; ra; own / all | group processProject; chart bar | cc9a083e-be95-4794-ab19-514c68fca93f |
| Assessors<br>`7e344138-f972-477f-8a69-55036650ccbf` | widgets/widget-chart; ra; own / all | group assessors; chart pie | cc9a083e-be95-4794-ab19-514c68fca93f |
| Task Based<br>`d73edeb6-0ba0-4edf-a51c-22fbb1dcc2ef` | widgets/widget-tile; ra; own / all | tile count; where (typeOfAssessment eq Task based) | cc9a083e-be95-4794-ab19-514c68fca93f |
| Risk Assessments<br>`cc9a083e-be95-4794-ab19-514c68fca93f` | widgets/widget-list; ra; own / all |  |  |
| COSHH<br>`e408a92d-c728-4d78-956f-5dc2d47d6db1` | widgets/widget-tile; ra; own / all | tile count; where (typeOfAssessment eq COSHH) | cc9a083e-be95-4794-ab19-514c68fca93f |
| Created this week<br>`6b0fa04f-c86a-4a0e-811b-f0afb072d6d6` | widgets/widget-tile; event; own / all | tile count; where (__CREATED isThisWeek ) | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Created previous week<br>`da1a7337-b800-4efa-8769-87c6132c2352` | widgets/widget-tile; event; own / all | tile count; where (__CREATED isPrevWeek ) | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Created this year<br>`a8327942-3330-47d3-8146-b056f667e907` | widgets/widget-tile; event; own / all | tile count; where (__CREATED isPrevYear ) | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Overdue Review Date<br>`f1eb1a43-0050-4ae8-981b-b11dd4809f23` | widgets/widget-tile; ra; own / all | tile count; where (recommendedReviewDate isBeforeToday Toolbox) | cc9a083e-be95-4794-ab19-514c68fca93f |
| Risk Assessments<br>`d888560a-8546-489e-a77b-82b12bea2d61` | widgets/widget-tile; ra; own / all | tile count | cc9a083e-be95-4794-ab19-514c68fca93f |

**List: Risk Assessments** — page size 30; add no; delete no; bulk delete no; export yes.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| ID | `__NAME` | hidden |
| Custom ID | `processCustomID` |  |
| Created | `__CREATED` |  |
| Initiated by | `__CREATED_BY` |  |
| Area | `area` |  |
| Effective Date | `effectiveDate` |  |
| Review Date | `recommendedReviewDate` |  |
| Review Date Timeframe | `___CUSTOM_FIELD15` | Handlebars template |
| Operator | `operator` |  |
| Project | `processProject` |  |
| Assessor(s) | `assessors` |  |
| Assessment date | `processDate` |  |
| Close comment | `OBS_TXTMUL_CloseComments` |  |
| Version Number | `versionNumber` |  |
| Status | `__STATUS` | hidden |
| Review Date | `___CUSTOM_FIELD15` | Handlebars template |
| Risk Assessment Status | `___CUSTOM_FIELD8` | Handlebars template |

**Filter: Filter by Project** (`58aefa13-0334-494f-b07d-7ae67da08fa3`), dropdownlist; options source `event`; display `processProject`; value `processProject`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Risk Assessments | `cc9a083e-be95-4794-ab19-514c68fca93f` | `event` | (processProject eq {filterValue1}) |
| Assessors | `7e344138-f972-477f-8a69-55036650ccbf` | `event` | (processProject eq {filterValue1}) |
| Task Based | `d73edeb6-0ba0-4edf-a51c-22fbb1dcc2ef` | `event` | (processProject eq {filterValue1}) |
| COSHH | `e408a92d-c728-4d78-956f-5dc2d47d6db1` | `event` | (processProject eq {filterValue1}) |
| Overdue Review Date | `f1eb1a43-0050-4ae8-981b-b11dd4809f23` | `event` | (processProject eq {filterValue1}) |
| Risk Assessments | `cc9a083e-be95-4794-ab19-514c68fca93f` | `event` | (processProject eq {filterValue1}) |
| Status | `f0d79560-d5fa-48d4-8a04-56b70db1f316` | `event` | (processProject eq {filterValue1}) |
| Project | `40f1d454-e71a-46fa-b64a-fdf57c077a1f` | `ra` | (processProject eq {filterValue1}) |

**Filter: Date range** (`83f4d52b-7d3e-4581-bd90-2fa148b858e5`), daterange; options source `manual`; display ``; value ``; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Events **missing in page** | `6acb37ed-392c-477f-aa46-71e86e1da409` | `event` | (__CREATED gte {filterValue1} AND __CREATED lte {filterValue2}) |
