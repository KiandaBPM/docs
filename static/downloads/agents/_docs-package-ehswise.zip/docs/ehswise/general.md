# EHSwise product and architecture guide

This is the entry point for understanding and modifying the EHSwise workspace. It consolidates the product-owner walkthrough and the workspace definitions inspected on **27 October 2026**. It describes the product configuration represented here; customer workspaces can change fields, roles, hierarchy, formulas, approvals, branding, and available modules.

## Read this documentation together

| Document | Purpose |
| --- | --- |
| [AGENTS.md](../../AGENTS.md) | Agent entry instructions and modification workflow. |
| [modules.md](./modules.md) | Module behavior, field/rule dependencies, shared components, and modification guidance. |
| [pages.md](./pages.md) | Navigation, operational/admin pages, reporting configuration, and page modification guidance. |
| [Application data model](./data-model.md) | Logical relationships between modules, supporting processes, components, pages, and reports. |

See [Recipes](#recipes) for the owner-reviewed Division → Project hierarchy and Cyber Security Incident customization examples.

The source files remain necessary when implementing a change. This guide explains intent and dependencies; it is not a replacement for reading the exact current rule, field, widget, or security setting. Use the module and page guides as the canonical product knowledge.

## Product purpose

EHSwise supports environment, health, safety, and quality operations on the Kianda Low-Code Platform. Users report observations and incidents, perform inspections and audits, assess risks, organize preventive/corrective work, manage permits for high-risk work, and maintain training compliance. Shared reference records and reusable form components connect these activities.

Operational records can be viewed by **location/project**, **physical asset**, **subcontractor**, or **current-user responsibility**. These are views over related records, rather than separate copies of the same operational information. Analytics pages aggregate process data into lists, charts, totals, and customer-specific rates.

The product is frequently configured during onboarding. A customer might use Country → Region → Site in place of the base Project model, hide quality-related modules, restrict who can create Risk Assessments, require different signatures or approval stages, or adopt a different accident-rate formula. A change request must be interpreted against that customer's actual configuration.

## Personas and responsibilities

These are product personas. They are not all separate built-in security roles.

| Persona | Typical work | Access/configuration considerations |
| --- | --- | --- |
| General authenticated user / originator | Create operational records, view own pending work, report on behalf of someone else, receive submission confirmations. | Home and the base operational navigation serve general users. Process and site security can restrict data or module access. |
| EHS professional, assessor, inspector, auditor | Perform inspections/audits, investigate incidents, choose applicable hazards, evaluate controls and residual risk, raise actions and findings. | Assignments and configured workspace access determine available records. Checklist labels and risk scales affect interpretation. |
| Responsible person / action owner | Receive and complete assigned follow-up work, provide evidence where required. | Actions support internal users and external subcontractor contacts; RA-created actions are internal only in the discussed configuration. |
| Permit owner / holder, team lead, participant | Issue and manage a permit, record approvals and acknowledgments, extend/suspend/close, participate in high-risk work. | The specific approval and signature requirements are implementation choices; an available signature control is not necessarily mandatory. |
| Worker / learner | Hold training certificates, participate in training events, complete induction slides and quizzes. | A Worker record is distinct from an authenticated user account. Anonymous induction links can be created for individual workers. |
| Subcontractor contact | Supply company details/documents or complete an externally assigned action. | Anonymous links are used for specific flows. Do not assume the recipient has an internal account. |
| EHS administrator | Maintain assets/hierarchy, responsibility configuration, checklists, inductions, substances, lookup lists, translations, and administrative data. | The EHS Admin folder is restricted to the **EHS Admins** group in the base product. |
| EHS leader / reporting consumer | Review compliance, overdue inspections/training, incidents, action performance, and rate calculations. | Analytics is restricted to EHS Admins in the base product. Reports and metric definitions are often customized. |
| Onboarding/configuration team | Adapt the workspace to the customer, configure security/hierarchy/approvals, import reference data, change reports and branding. | Must trace changes across processes, embedded components, pages, templates, rules, translations, and security. |

### Identity distinctions that affect behavior

- **Creator / submitter / originator** is not always the person shown in **Reported by**. For example, an Observation can be reported on behalf of someone else, while its confirmation email goes to the submitter.
- **User** is an account that can be selected in an internal user picker. **Worker** is a training/compliance record and can exist without an account. **Other/External** modes often use text fields instead of user pickers.
- An **Action owner**, **asset owner**, **assessor**, **reporter**, and **permit holder** have different responsibilities. Do not substitute one for another when mapping fields or recipients.
- **People to be notified** and configured module notification recipients are separate sources. Some modules email the originator automatically; others expose a confirmation toggle. Check the specific module's rules.

## Architecture at a glance

```mermaid
flowchart TD
    User[Users and workers] --> Pages[Page JSON: navigation and widgets]
    User --> Records[Process instances: operational and reference records]
    Pages --> Queries[Summary queries and filter connections]
    Queries --> Records
    Definitions[Process JSON: forms, fields, rules and security] --> Records
    Shared[Reusable process components] --> Definitions
    Extensions[Custom field, rule and widget JS/HBS] --> Pages
    Extensions --> Definitions
    Records --> Server[Scheduled server rules]
    Server --> Outputs[Reports, emails, linked records and updates]
    Hooks[Workspace app JS and CSS] --> Pages
    Hooks --> Definitions
    Library[Assets, hazards, materials, checklists and lookup records] --> Records
```

See the [application data model](./data-model.md) for the module-by-module process/page relationships. This is a logical model of low-code records and references, not a SQL schema or a guarantee of database foreign-key enforcement.

## Source organization

| Location | What it controls |
| --- | --- |
| [pages/](../../pages/) | Dashboard page definitions: identity, grouping/order, access, containers, widgets, filters, templates, and query connections. |
| [processes/QHSE - Modules/](<../../processes/QHSE - Modules/>) | Main operational processes such as Incident, Action, Inspection, Audit, RA, NCR, PTW, and Worked Hours. |
| [processes/Data/](../../processes/Data/) | Shared components, reference libraries/designers, lookup records, configuration, import utilities, and derived data. |
| [processes/Training/](../../processes/Training/) | Worker, Certificate, and Induction player processes. |
| [processes/COSHH/](../../processes/COSHH/) | COSHH Material records. |
| [processes/Policies/](../../processes/Policies/) | Controlled-document workflow. |
| [processes/QHSE - Environment/](<../../processes/QHSE - Environment/>) | Energy Registration and Green Initiative processes. |
| [components/fields/](../../components/fields/) | Custom form-field behavior and templates, including the induction player and language tooling. |
| [components/rules/](../../components/rules/) | Custom rule implementations and designer settings templates. |
| [components/widgets/](../../components/widgets/) | Custom dashboard widgets and their settings/rendering templates. |
| [js/app.js](../../js/app.js) | Workspace startup hooks, modal links, offline synchronization, guided-tour links, and translation integration. |
| [styles/app.css](../../styles/app.css) | Workspace-specific presentation; also imports a remotely hosted base stylesheet. |
| [.kianda/workspace.json](../../.kianda/workspace.json) | Local workspace/tenant binding and mappings for pulled processes, pages, globals, and extensions. Preserve its binding; do not copy workspace keys or tenant values into documentation. |

This repository is a serialized Kianda workspace with custom extensions. It does not contain the entire Kianda runtime. Runtime platform services, hosted files, tenant configuration, and attachments can be dependencies that are not represented by local source files. The local workspace metadata is ignored by [the Git configuration](../../.gitignore).

## Terms and contracts used throughout the workspace

| Term | Meaning for an agent |
| --- | --- |
| Process definition | The JSON template defining forms, fields, rules, security, and settings for a record type. |
| Process instance / record | A submitted or saved instance of that definition. A process definition file is not a dataset of all records. |
| Form | A step or screen within a process. A dashboard page and a process form are different objects. |
| Page | A dashboard definition, normally reached through `/dashboard/{pageId}`. It can display/query many process types. |
| Process component | A reusable process definition embedded into host processes through `fields/field-component`. Host JSON contains nested component fields and settings such as `componentId` and `componentLoaded`; inspect both host and shared definition. |
| Custom extension | Field, rule, or widget behavior implemented with paired JavaScript and Handlebars files. Do not treat these files as standalone Node modules. They run in the platform's runtime context. |
| Asset | An overloaded reference-record model: Project/Site hierarchy items, physical assets, and Subcontractors can all be represented by types of the EHS Asset process. It is not limited to equipment. |
| Summary query | A configurable projection/aggregation of process records. Lists can request common or module-specific fields across process types without one fixed cross-module schema. |
| Custom Process ID | Human-facing module identifier calculated by server rules, distinct from the platform record identifier and process definition name. |
| URL context | Parameters such as `project`, `asset`, `subcontractor`, `tab`, or `checklist` can initialize selection/filter state. They do not grant access to a record. |

### JSON identities and references

Page definitions include `id`, `title`, `name`, `widgets`, `visibleTo`, `settings`, and grouping/public flags. Widget `type` selects a built-in or custom implementation; `settings.connections` explicitly connects filter values to target widget IDs and fields. Container/grid classes and widget templates control presentation.

Process definitions include `id`/`name`, `forms`, top-level `rules`, settings, publishing/version metadata, and security information. Forms contain nested fields and their own rules. Fields can contain more fields, settings, and rules; tables, panels, components, and hidden utility controls make shallow searches insufficient. Rules have identifiers, titles, action types, conditions, schedules, enabled flags, targets, and mappings.

Preserve stable internal field names, IDs, component references, and rule target names unless the requested change requires changing them. A display label is not the same contract as a stored option value. Expressions, report tags, queries, translations, linked-record mappings, and visibility rules can reference either. Search both the technical name and the displayed text when tracing a change.

## Shared domain building blocks

### Workspace hierarchy, assets, and responsibility

The [EHS Asset process](../../processes/Data/asset.json) stores hierarchy/reference records. Common fields **Type**, **Title**, **Code**, and **Display Name** are consumed by dropdowns and pages. Asset type controls which panels and fields appear. The base hierarchy focuses on Projects, while implementations commonly add Country/Region/Site levels and parent-link fields for cascading selection.

The [Workspaces Component](../../processes/Data/workspaces.json) supplies reusable project/location/asset associations in modules. Hierarchy choices and selection rules depend on the deployment and host module. For example, an Observation can relate to multiple workspace types, while the Inspection walkthrough used a parent-to-child cascade. A hierarchy change must update the shared component, its host usage, lookup filters, security, pages, and reports that consume those fields.

The [Configuration process](../../processes/Data/configuration.json) selects an asset type and specific asset, then edits module responsibilities stored in [Process Responsible records](../../processes/Data/asset-responsible.json). Responsibilities apply to the configured asset by default. Inheritance requires onboarding configuration. Submitting a blank row clears its assignment.

### Shared operational components

| Shared source | Role and cross-module impact |
| --- | --- |
| [checklist-component.json](../../processes/Data/checklist-component.json) | Question rendering, scoring, question attachments/comments, and question actions; reused by Inspection, Audit, Checklist, PTW checks, and other checklist consumers. Incident investigation uses the related [checklist-component-without-actions.json](../../processes/Data/checklist-component-without-actions.json) variant. |
| [actions-component.json](../../processes/Data/actions-component.json) | Immediate-action text and a table/dialog for follow-up actions; submit/server rules create linked central Action records. |
| [action-dialog-component.json](../../processes/Data/action-dialog-component.json) | Shared action-entry fields and responsibility controls; inspect the host module for restrictions such as internal-only RA actions. |
| [attachments-component.json](../../processes/Data/attachments-component.json) | Shared pictures and file attachments, used in many module summaries. |
| [audit-type.json](../../processes/Data/audit-type.json) and [question.json](../../processes/Data/question.json) | Checklist library/designer metadata and configured questions used by checklist consumers. |

A shared-component edit can affect many modules, but host definitions also contain loaded component fields and module-specific rules. Inspect the component-loading/synchronization behavior in the actual workspace before assuming a shared file change automatically updates every host copy. Do not replace all embedded fields blindly.

### Operational records and linked follow-up

- **Action** is a central record type. It can be standalone or linked to a parent module/question. Assignment notifications are handled within its workflow, separately from the parent record's submission email.
- **Audit Findings** create separate **NCR** records and retain the returned NCR ID in the finding row. NCR uses Submission, Review, and Closure stages.
- **Hazard** holds reusable descriptions, controls, severity, and likelihood. An assessor chooses the applicable hazard version from the dropdown. Completing an RA additional-control action adds those controls to the associated shared hazard's existing controls.
- **COSHH Material** holds substance metadata/SDS. COSHH RA loads editable material details, but chemical hazards are selected independently and are not filtered by the substance.
- **Worked Hours** records aggregate hours by selected project/category/date. Server processing creates the data used for reporting; Accident Rates consumes [hours-worked-data.json](../../processes/Data/hours-worked-data.json), not merely the entry-form record.
- **Worker**, **Certificate**, **Training Event**, **Induction Type**, **Slide**, and **Induction** are distinct records/definitions. Training Events and induction completion can create Certificate records for workers.

## Workflow execution and outputs

**Next** commonly navigates to another form; it must not be assumed to submit. **Save draft** commonly saves with Draft status and allows further editing. **Submit**, **Close**, and specialized workflow controls have module-specific rule chains. Read the control's rules rather than inferring behavior from the label.

Hidden buttons and utility forms are active implementation elements. They can hold rule groups for generating custom IDs, creating linked records, producing reports, updating counts, assigning responsibility, sending emails, or saving. The Incident **Server rules** button is an important example: submission schedules its rules for server execution. Such processing is not necessarily complete when the client first returns.

Word-based report generation parses rich-text content controls tagged `kf:<field-name>`. Generated PDF/report files are then saved into configured file fields or attached to emails where the corresponding rule specifies them. A PDF stored on a record is not automatically an email attachment. Preserve template field-name contracts when changing a process.

## Access control

There are several independent access/presentation layers:

1. Page/folder visibility, such as EHS Admin and Analytics access through `visibleTo`.
2. Create New link visibility through `link.users`.
3. Process-level security governing direct form URLs and record access.
4. Customer-specific site/project hierarchy security affecting selectable and visible data.
5. Form, field, and action visibility/enabled/required conditions governing workflow presentation.

Hiding a link or tab does not secure its direct route. A requirement such as “only group X can create Risk Assessments” needs both the entry-link behavior and process security. Preserve the distinction between a UI filter and authorization. Anonymous subcontractor/induction/action flows require their own intended scope and recipient mappings; the subcontractor details link discussed in the walkthrough does not expire by default.

Security inspection starts with process `enableSecurity`, `securityMode` where present, `owners` and `administrators`, per-form `owners`/`security`, anonymous-access settings, and assignment-rule targets. These are source entry points, not a universal group-grant recipe. Confirm the platform security semantics and the destination workspace's group identities before applying a permission change; display visibility and form ownership are not interchangeable with process authorization.

## Offline operation and localization

EHSwise is a PWA. The service worker caches the runtime, while refresh/offline synchronization caches process definitions and configured lookup data in IndexedDB. [The app hook](../../js/app.js) compares process versions, synchronizes processes and custom widget types, and preloads lists/find-item queries that opt into `offlineCache`. Inspect [offline-data.json](../../processes/Data/offline-data.json) and [ensure-offline.js](../../components/rules/ensure-offline.js) when changing offline reference data. Do not assume a server-only report/email rule executes while disconnected.

English is the base language. The Languages page supports automatic translation and manual overrides, including process fields. Selected language is saved to the user's profile when translations are enabled. Missing translation keys fall back to the English label. [The app translation hooks](../../js/app.js) and [language-translation field](../../components/fields/language-translation.js) use page/widget/field/checklist identifiers, so renamed or added elements need translation coverage. Runtime language data is a hosted `lang.json` file; it is not present as a local source file here.

## Reporting and customer presentation

The [Analytics page guide](./pages.md#analytics) documents all 12 reviewed reports. Standard lists/charts/tiles use explicit summary queries, fields, condition groups, and filter connections. Project/hierarchy filters usually apply across a report, but every page can have its own filter design. Verify each intended target; do not infer global filtering from the page layout.

Rate formulas are per-widget configuration. The Accident Rates custom chart and calculated tiles can intentionally use different numerator definitions and scale factors. The saved chart setting was corrected to 200,000 during the walkthrough; [the chart implementation](../../components/widgets/accident-rate.js) still contains 20,000 fallback/initialization values. The page guide distinguishes current defects from historical corrections. No documentation task should silently repair unrelated source defects.

Home headers, messages, imagery, CSS, and links are frequently branded for customers. Create New is a normal page styled as a primary navigation button. Carousel descriptions, card/list field templates, and hidden guided tours can contain executable links and selectors. A menu/route/name change may require updating those selectors as well as the visible label.

## Modification planning map

| Request | Start with | Trace next |
| --- | --- | --- |
| Add an incident type | [Incident module guide](./modules.md) and [incident.json](<../../processes/QHSE - Modules/incident.json>) | Option values, classification visibility, dynamic forms, server report branches, utility counts, notifications, incident analytics, translations. |
| Add Country/Region to hierarchy | [asset.json](../../processes/Data/asset.json) and [workspaces.json](../../processes/Data/workspaces.json) | Parent-link fields, cascade conditions, process security, responsibility configuration, operational pages, module mappings, and all affected reports. |
| Restrict a module to a group | [create-new.json](<../../pages/Create New/create-new.json>) | `link.users`, process permissions/direct URLs, page/widget visibility where needed. |
| Add/change a checklist question or score | [audit-type.json](../../processes/Data/audit-type.json), [question.json](../../processes/Data/question.json) | Shared renderer, question rules, score thresholds/labels, report template, all consumers, import/export, translations. |
| Create/change a reporting page | [Page/report guide](./pages.md) | Exact process fields, widget IDs/types, connection conditions, aggregations, formulas, date fields, OData, access. |
| Change action creation/closure | [action.json](<../../processes/QHSE - Modules/action.json>) | Shared dialogs/components, parent linked-record mappings, internal/external recipients, evidence and originator approval. |
| Change worker training compliance | [worker.json](../../processes/Training/worker.json) and [certificate.json](../../processes/Training/certificate.json) | Training-course lookup, expiry/reminder schedules, training Events, Induction completion, worker/certificate pages. |
| Change customer branding | [Home page](../../pages/Dashboard/index.json), [app.css](../../styles/app.css), relevant carousel/widgets | Hosted imagery/styles, page HTML, menu presentation, tours/selectors, mobile layout. |

### Before implementing a change

1. Resolve the relevant process/page and current customer scope through these guides.
2. Read current JSON and recursively trace affected fields, nested rules, condition groups, target controls, mappings, components, and connected widgets.
3. Separate stored option values/internal identifiers from display text and translated labels.
4. Identify effects on existing records, exports, reports, emails, schedules, and offline data.
5. Make the smallest coherent change set. Preserve unrelated customer configuration and existing workspace changes.
6. Check JSON syntax and reference/link consistency. Use targeted runtime verification appropriate to the change; submission controls can create records, schedule jobs, or send real emails.
7. Update these guides when confirmed product behavior or architecture changes. State any behavior that remains unknown instead of inventing it.

## Recipes

These implementation examples were reviewed with the product owner after the documentation walkthrough. They describe proposed customer customizations. Division and Cyber Security are not being declared existing product features by their inclusion here. Example names for new fields and forms must be checked for collisions and applied consistently when implementing.

- [Recipe 1: Add Division above Project](#recipe-1-add-division-above-project)
- [Recipe 2: Cyber Security incident type and conditional form](#recipe-2-cyber-security-incident-type-and-conditional-form)

### Recipe 1: Add Division above Project

**Requirement:** introduce Division as a workspace hierarchy level, with Projects cascading from the selected Division.

**Target relationship:** Division → Project → associated operational records. Division is represented by records of the existing EHS Asset process with Type `Division`.

#### 1. Extend Asset types and parent relationships

In [asset.json](../../processes/Data/asset.json):

- Add **Division** to the Type choices and configure the type-specific field/panel visibility.
- Reuse the common Title, Code, Display Name, and Active properties.
- Add a **Division lookup to Project records**, filtered to active assets whose Type is Division.
- Store the selected Division's code as the Project's parent reference; `divisionCode` is a proposed field name, not an existing contract.
- Create Division records and assign existing Projects to their Division. Plan the backfill explicitly so existing Projects are not silently assigned to an arbitrary Division.

The standard Country input on an Asset is an independent system country list; adding a business hierarchy requires the explicit parent relationship described above.

#### 2. Extend the shared Workspaces component

In [workspaces.json](../../processes/Data/workspaces.json):

- Add a Division selector before Project. Follow the existing Project selector pattern: display `displayName` and use `code` as the selected value.
- Filter Division choices to Type Division and Active Yes.
- Extend the Project options filter from **Type = Project AND Active = Yes** to also require **Project's divisionCode = selected Division code**.
- Require the parent selection before allowing a Project to be chosen when the module uses a Project association.
- When Division changes, clear an incompatible selected Project and its helper code, refresh Project choices, and handle any dependent child selections. Do not leave a previously selected Project from another Division attached to the record.
- Keep modules that support other or multiple workspace associations working; the hierarchy requirement should apply to the appropriate association rather than making every record globally require a Project.

A picker such as `processDivision` and helper such as `processDivisionCode` are possible new names. Keep their meanings and mappings consistent with the existing `processProject` and `processProjectCode` contracts. Persist Division context where Division-level summary queries, reporting, or security need it.

#### 3. Propagate the component and context to consuming modules

Review the host processes that embed Workspaces and refresh their loaded component configuration using the workspace's established component update workflow. Host exports contain nested component fields, so changing only the shared definition does not establish that every host has updated.

Review module-specific workspace controls, preload rules, linked-record mappings, and derived data. Carry Division context into related Actions or other records where the intended queries/security require it. Check that opening an existing record initializes the correct Division and Project without resetting valid saved selections.

#### 4. Update administration and operational pages

In [Assets.json](<../../pages/EHS Admin/Assets.json>), add Division to the asset-type tabs so administrators can maintain those records. Ensure the Project editor exposes its new Division association.

In [my-project.json](<../../pages/My Project/my-project.json>):

- Add a Division filter and connect it to the Project selector's new parent field. This must constrain the Project choices, not just the final Items list.
- Retain the existing Project code mappings: Items uses `processProjectCode`, while the carousel resolves the selected Asset by `code` and the `project` URL parameter.
- Preserve Division and Project in URL state and new-record links where the consuming processes support that context. A proposed `division` parameter must have matching preload handling.
- Clear stale Project URL/filter state when Division changes.
- Connect Division to the intended record widgets using the persisted Division field or an explicitly designed Project-based query. A Division filter does not automatically filter every widget.

The Country → Project filter connections in [hazard-library.json](../../pages/Analytics/hazard-library.json) provide an existing filter-to-filter cascade example. They do not establish that stale child selections are automatically cleared by the runtime; verify that behavior.

#### 5. Align reporting, access, responsibilities, and imports

- Add Division filters to affected reports and explicitly connect each intended list, chart, and tile. Preserve consistent scope across rate numerators and denominators. Existing reports use both Project display fields and Project code fields; inspect each mapping.
- Apply the customer's Division-level record and lookup access rules. Filtering a dropdown is separate from authorization.
- If responsibilities are configured at Division level, extend [configuration.json](../../processes/Data/configuration.json) and the relevant consumers of [asset-responsible.json](../../processes/Data/asset-responsible.json). Responsibility inheritance to Projects requires explicit configuration; it is not created by the hierarchy link.
- If bulk onboarding uses [asset-import.json](../../processes/Data/asset-import.json), update the template, preview, and mappings for Division and Project parent codes. The documented matching defect requires Type + Code; do not copy a Code-only matching pattern.
- Add labels/translations and review offline-cached reference data. Decide whether historical operational records retain their original Division or follow future Project reassignment, then apply any backfill consistently.

#### Verification checklist

Verify creation/editing of Divisions and Projects; selecting Division then Project; switching Division; clearing invalid Projects/child selections; reopening existing records; URL initialization; new-record context; security; responsibility scope; reporting totals; and cached/offline selection behavior.

### Recipe 2: Cyber Security incident type and conditional form

**Requirement:** add **Cyber Security** as a top-level Incident Type with its own form, visible only when that type is selected.

Extend the existing [incident.json](<../../processes/QHSE - Modules/incident.json>) process. The existing Security damage category captures physical security events such as burglary and vandalism. The new top-level Cyber Security type has its own data-capture step while retaining the Incident process identity and existing entry points.

#### Suggested Cyber Security fields

Reuse common Incident Title, Description, Incident date/time, Reporter, Workspaces, Attachments, and Actions. Suggested new fields are:

| Field | Suggested control and purpose |
| --- | --- |
| Cyber incident category | Dropdown: Phishing, Malware/Ransomware, Account compromise, Unauthorized access, Data disclosure/loss, Service disruption, Other. |
| Discovered at | Date/time, separate from when the incident occurred. |
| Detection source | User report, monitoring alert, supplier notification, other. |
| Affected systems/services | Repeatable table: system/service name, asset reference where applicable, business owner, production/test environment. |
| Severity | Low, Medium, High, Critical. |
| Impact | Multi-select Confidentiality, Integrity, Availability, with an explanation of business impact. |
| Data exposure | Unknown, None identified, Suspected, Confirmed; optional data categories and approximate number of affected records. |
| Security response lead | Internal user picker for the person coordinating the response. |
| Containment details | What was done, when containment started, and when it was achieved. |
| Recovery details | Recovery work, service-restored date/time, and outstanding issues. |
| External reference | IT service-management ticket, supplier case, or external report reference. |

Keep initial reporting requirements small and allow investigation, containment, and recovery information to be completed during review. Required fields and stage-specific requirements are customer decisions, not established defaults for this proposed form.

#### 1. Add the Incident Type choice

Append **Cyber Security** to `incidentType?radioCards.settings.choices`. Keep existing values compatible with saved records. Keep the process identity/title as Incident, so existing Create New links and Incident record-type tabs continue to handle the records. This is a top-level type addition; the damage selector `incidentType?checkboxCards` has separate behavior.

#### 2. Create the new conditional form

- Title the form **Cyber Security Details**, with a unique technical name such as `cyberSecurity`, a new ID, and correctly linked parent references for its fields.
- Start with `visible: false` and activation consistent with the existing conditional forms, which use `activateWith: "form1"`.
- Configure Next/Save navigation between Circumstances, Cyber Security Details, and subsequent applicable forms.
- Use stable new field identities; `cyberCategory`, `cyberSeverity`, and `cyberDiscoveredAt` are proposed examples.

#### 3. Implement Cyber-only visibility

The Incident Type field already has an ordered **Hide forms** reset followed by type-specific rules. Add the new form to that hide/reset target list, then add a show rule for **Incident Type = Cyber Security** with an explicit hide path when the condition is false.

| Selected Incident Type | Cyber Security Details form |
| --- | --- |
| Cyber Security | Visible |
| Near-miss, Incident, Accident, or blank | Hidden |

Apply and verify the condition on type changes and when opening a saved record; change-only handling is insufficient. Visibility does not remove stored field values. Retaining or clearing previously entered Cyber details when the type changes must be an explicit decision.

#### 4. Add branch-specific validation

Extend `INC_BTN_validateForms` so Cyber-required fields are checked only when **Incident Type = Cyber Security**. Hidden Cyber fields must not block other types. Preserve Draft saving of incomplete records and configure any later review/closure requirements separately.

Decide which existing damage, investigation, and authority-reporting options apply to the Cyber branch. Adding the new type does not itself justify enabling Accident's People or Potential LTI fields. Review both enabled conditions and else behavior, including disabled legacy rules, rather than copying a visually similar branch blindly.

#### 5. Include the form in assignments and access

Add the new form to the applicable explicit target lists in the process's initial **Assign forms** rule and in `GI_BTN_AssignRules`, including its **Remove permissions** reset and the Draft, Open, Closed, and reviewer assignments.

If IT/Security ownership is required, configure that routing and access deliberately. A response-lead field or a new type choice does not automatically assign the form or notify that person. Review relevant responsibility lookups and preserve the distinction between the response lead, Reporter, and originator.

#### 6. Update generated reports, including closure

Add Cyber fields to the existing Word templates through appropriate conditional content, or introduce dedicated Cyber templates. Preserve the Generate Word Document contract using rich-text content controls tagged `kf:<field-name>`.

**Current source pitfall:** both existing non-Accident report branches also match Cyber Security: one for Investigation No and one for Investigation Yes. If dedicated Cyber report rules are added:

- Exclude Cyber Security from both existing non-Accident branches.
- Add mutually exclusive Cyber branches, with explicit investigation handling if different templates are required.
- Update the report-generation rule executed by **Close**, which currently regenerates the generic report.
- Keep the generated file destination and regeneration behavior consistent. The report rules write to `processReport`; overlapping branches or an unchanged Close rule can overwrite the intended Cyber PDF.

The new form alone does not make its fields appear in a generated report. Report template files can be hosted attachments rather than local source files.

#### 7. Update Summary and notifications

Include relevant Cyber details in the Summary and generated outputs. Review the existing notification rules for the originator, additional selected people, and configured `incidentNotify` recipients. Configure any separate response-lead notification explicitly.

Preserve the distinction between report storage and email attachments. The current Incident notification rules do not automatically attach the generated PDF merely because it is saved on the record.

#### 8. Review Analytics and record views

The Incident Type chart in [incident-report.json](../../pages/Analytics/incident-report.json) groups dynamically by `incidentType?radioCards`, so the new value should appear after matching records exist. Verify the actual query and any customer-specific restrictions.

- Add Cyber fields to list/export columns where required, and add Cyber filters or tiles if requested.
- Review [accident-rate.json](../../pages/Analytics/accident-rate.json) and its source counters so Cyber cases are not inadvertently treated as injury/LTI cases. Type changes must not leave stale data affecting safety metrics.
- Review whether generic authority-reporting flags should contribute to tiles labelled RIDDOR; the new type does not establish that reporting interpretation.
- Consult current reporting defects in [pages.md](./pages.md#known-defects-and-source-discrepancies). The Incident Project-filter source mismatch must be considered during verification rather than copied into new filtering.
- Existing operational Incident tabs continue to use the Incident process title. Adding a top-level type does not require changing that cross-process title contract.

#### 9. Translate, document, and verify

Add translations for the choice, form, fields, and options. When implementation changes confirmed product behavior, update [modules.md](./modules.md), the relevant page guide, and the [application data model](./data-model.md).

Verify selecting/switching types; Draft save and reopen; conditional visibility and required fields; navigation; reviewer access and assignments; submission and closure PDFs; intended recipients; asynchronous server processing; and Analytics grouping/counts. Include regression checks for Near-miss, Incident, and Accident.

## Coverage and planned features

Detailed walkthrough coverage includes operational navigation, administration and libraries, 12 Analytics pages, and the main modules through Task based and COSHH RA. Worked Hours, NCR, and Hazard were concluded at a higher level, supplemented by inspected source. Energy Registration and Green Initiative appear in the Create New catalog but did not receive the same detailed module walkthrough. Other source features, such as Lessons Learned, were not part of this documentation exercise.

Planned/in-progress capabilities described by the product owner include AI-generated checklist drafts with review/publishing, AI-generated inductions/training, improved checklist report-template generation, configurable induction failure/retake behavior, and broader subcontractor document/review management. Treat them as roadmap items until the actual implementation is confirmed. A legacy Plant asset type remains unused and is intended for later removal.

Generic Kianda platform references are available in [kianda/](../kianda/), starting with the platform [general.md](../kianda/general.md). Use the [Kianda platform knowledge map in AGENTS.md](../../AGENTS.md#kianda-platform-knowledge-map) to select the process/page guides and schemas, custom addon contracts, and styling guidance for a task. This product guide records EHSwise-specific architecture; the platform references cover generic authoring contracts and runtime boundaries.
