# EHSwise application data model and dependency map

This is a logical model for agents modifying this workspace. It combines the product walkthrough with the saved process and page definitions. It is not a relational database schema: EHSwise stores process records, nested form/table values, and linked record identifiers; pages query those values through Kianda lists and summaries. A field shared by several processes is not automatically a database foreign key.

Read this alongside the [product architecture](./general.md), [module guide](./modules.md), and [page guide](./pages.md). Source links below point to the editable JSON or widget code. The diagrams describe the documented base product; customer hierarchy, security, approvals, report formulas, and visible modules can differ.

## Reading the diagrams

| Relationship label | Meaning for a modifying agent |
| --- | --- |
| **creates / updates** | A rule starts or updates a separate process record. Inspect its conditions, input/output mappings, lookup keys, trigger target, and server scheduling. |
| **looks up / selects** | A form loads values from another process. Loaded values can be copied into the receiving record; do not assume live synchronization. |
| **embeds** | A process reuses a component definition. The component contributes fields, tables, and rules inside its parent; this alone does not create a separate business record. |
| **lists / filters / aggregates** | A page queries records. Widget connections, URL parameters, and filter conditions determine its scope. |
| **contains rows** | Repeatable data belongs to the containing record unless a separate create rule is documented. |

Arrows are directional dependencies with explicit labels. They do not imply automatic cascade updates, inherited permissions, mandatory relationships, or deletion behavior. Cardinalities are stated only where the walkthrough or rules establish them.

## 1. Overall application map

```mermaid
flowchart TB
    Home["Home / index"] -->|shortcuts| New["Create New"]
    New -->|new record| Inspection["Inspection"]
    New -->|new record| Action["Action"]
    New -->|new record| Observation["Observation"]
    New -->|new record| Event["Event"]
    New -->|new record| Checklist["Checklist"]
    New -->|new record| Plan["Action Plan"]
    New -->|new record| Induction["Induction player"]
    New -->|new record| Audit["Audit"]
    New -->|new record| PTW["Permit to Work"]
    New -->|new record| Incident["Incident / Accident / Near-miss"]
    New -->|new record| RA["Risk Assessment: Task based / COSHH"]
    New -->|new record| Hazard["Hazard library record"]
    New -->|new record| NCR["Non Conformance Report"]
    New -->|new record| Hours["Hours Worked"]
    New -->|new record| Energy["Energy Registration"]
    New -->|new record| Green["Green Initiative"]

    Asset["EHS Asset: hierarchy / asset / subcontractor"] -->|workspace lookups and associations| Operational["Operational records above"]
    Config["Configuration"] -->|creates / updates by asset ID| Responsible["Process Responsible records"]
    Asset -->|selected asset| Config
    Responsible -->|module routing / notification configuration| Operational
    Libraries["Checklist types + questions / materials / training / lookup lists"] -->|lookup and content| Operational
    Operational -->|assigned and created records| Overview["My Overview"]
    Operational -->|workspace-filtered summaries| Views["Location / Assets / Subcontractor pages"]
    Operational -->|all-record list| Admin["Admin Data"]
    Operational -->|aggregations and lists| Analytics["12 Analytics pages"]
    Audit -->|finding creates| NCR
    Hazard -->|baseline risks and controls| RA
    Operational -->|follow-up actions where configured| Action
    Event -->|training participants| Certificate["Certificate records"]
    Induction -->|successful learner completion| Certificate
    Worker["Worker records"] -->|worker lookup| Event
    Worker -->|learner lookup| Induction
    Certificate -->|worker ID| Worker
    Document["Document / policy records"] -->|library and approval workflow| Policies["Policies page"]
```

The **Operational records above** node is a diagram grouping, not an extra process. Not every operational process uses every shared component or every responsibility setting. See the exact reuse and relationship tables below.

## 2. Workspaces, access, and responsibility configuration

```mermaid
flowchart LR
    AssetsPage["Projects & Assets page"] -->|lists / edits / creates| Asset["asset: EHS Asset"]
    Import["asset-import: Excel preview/import"] -->|creates / updates| Asset
    Asset -->|Type + hierarchy fields| Workspace["workspaces: embedded selectors"]
    Workspace -->|copies selected workspace values| Module["Parent module record"]
    Asset -->|project URL parameter| Location["Location page + carousel"]
    Asset -->|asset URL parameter| AssetPage["Assets page + carousel / QR"]
    Asset -->|subcontractor URL parameter| SubPage["Subcontractor page"]
    Module -->|summary filters by workspace| Location
    Module -->|summary filters by asset| AssetPage
    Module -->|summary filters by subcontractor| SubPage
    AssetsPage -->|opens new modal| Config["configuration"]
    Asset -->|select Type, then asset| Config
    Config -->|loads / creates / clears assignments| Responsible["asset-responsible"]
    Responsible -->|asset-specific responsible / notify people| Module
    Security["Customer process and record security"] -->|restricts data and direct form access| Module
    Security -->|restricts available hierarchy records| Workspace
    Visibility["Page visibleTo / link.users"] -->|navigation visibility| Menus["Pages and Create New links"]
```

### Workspace and security relationship index

| Entity or dependency | Source and role |
| --- | --- |
| EHS Asset (`asset`) | [asset.json](<../../processes/Data/asset.json>) is the flexible common data record. Type-specific panels represent Projects, Sites/locations, Assets, and Subcontractors. Shared Title, Code, Type, and Display Name fields support selectors. A legacy Plant type remains but was confirmed unused. |
| Hierarchy configuration | Adding Country, Region, or another level requires configuring asset types, parent/cascade fields, the [Workspaces component](../../processes/Data/workspaces.json), and consuming pages, filters, and security. Country on an asset can also be the independent standard country list; do not treat every country field as an EHS Asset hierarchy link. |
| Projects & Assets administration | [Assets.json](<../../pages/EHS Admin/Assets.json>) centrally manages the hierarchy. This page's name differs from the end-user Assets page at [my-asset.json](<../../pages/My Asset/my-asset.json>). |
| Bulk Asset Import | [asset-import.json](../../processes/Data/asset-import.json) provides an Excel template and editable preview. The walkthrough identified matching by Code alone as a bug: intended matching is **Type + Code**. This is not evidence of a database uniqueness constraint. |
| Responsibility setup | [configuration.json](../../processes/Data/configuration.json) selects asset Type and the actual asset, loads existing [asset-responsible.json](../../processes/Data/asset-responsible.json) records into a table, then creates/updates assignments by asset ID. Blank submitted responsibility rows clear assignments. Default scope is the configured asset; inheritance requires customer configuration. |
| Workspace associations | [workspaces.json](../../processes/Data/workspaces.json) is embedded into many module definitions. Common persisted fields include project, location, asset, and their codes. Check the receiving process's actual names and mappings before changing a shared field. A single record can carry more than one workspace association; customer cascades and security affect selection. |
| Location view | [my-project.json](<../../pages/My Project/my-project.json>) uses `project` in the URL to connect the asset selector, carousel, record-type tabs, and summaries list. The process Title must match the record-type tab option. A filter's associated process is only its filter configuration, not necessarily the list's sole record source. |
| Asset view | [my-asset.json](<../../pages/My Asset/my-asset.json>) filters records around one selected asset, displays its QR code, opens edit through the carousel pencil, and opens the new Asset dialog. |
| Subcontractor view | [subcontractor.json](../../pages/Subcontractor/subcontractor.json) filters related records and workers. Site security can restrict which subcontractors appear. Subcontractors are EHS Asset records, not an unrelated dedicated subcontractor process. |
| Access boundary | Navigation visibility and data security are separate configuration layers. Hiding a Create New link with `link.users` must be paired with process security when direct URL access is to be prohibited. EHS Admin and Analytics pages are restricted to EHS Admins in the documented base configuration. |

## 3. Checklist design, checklist execution, Audit, NCR, and Actions

```mermaid
flowchart TB
    Designer["Checklists administration page"] -->|maintains library| Type["audit-type: Checklist Type"]
    Type -->|question identities and settings| Question["question records"]
    Import["checklist-import"] -->|creates / updates checklist metadata| Type
    Import -->|creates / updates questions| Question
    Public["Kianda public checklist library"] -->|download a customer-local copy| Import
    Designer -->|opens preview| Preview["check-list-tester"]
    Type -->|selected checklist| Preview
    Type -->|loads question data and scales| Component["checklist-component family"]
    Question -->|response types and scoring data| Component
    Component -->|embeds| Inspection["inspection"]
    Component -->|embeds| Checklist["checklist"]
    Component -->|embeds| Audit["audit"]
    Component -->|embeds| PTW["permit-to-work"]
    Component -->|investigation variant| Incident["incident"]
    Component -->|quiz / checklist slide| Induction["induction"]
    Component -->|question follow-up creation where enabled| Action["action record"]
    Audit -->|contains repeated finding rows| Finding["Topic / class / owner / returned NCR ID"]
    Finding -->|Create NCR on Submit| NCR["ncr record"]
    NCR -->|Submission / Review / Closure| NCRFlow["NCR workflow"]
    Plan["action-plan"] -->|one or more submitted actions| Action
    Other["Observation / Event / PTW / Hazard / NCR / Incident"] -->|embeds| Actions["actions-component"]
    Actions -->|opens data-entry dialogs| Dialog["action-dialog-component / edit variant"]
    Actions -->|creates separate records on parent submission| Action
    Action -->|stores source link| Parent["Originating record and optional question"]
```

### Checklist and action relationship index

| Dependency | Sources and contract |
| --- | --- |
| Checklist library | [checklist-data.json](<../../pages/EHS Admin/checklist-data.json>) lists [audit-type.json](../../processes/Data/audit-type.json), whose product title is **Checklist Type**. It is used by several modules, not only Audit. The designer maintains questions through [question.json](../../processes/Data/question.json). |
| Import/export and preview | [checklist-import.json](../../processes/Data/checklist-import.json) imports Excel questions or copies a checklist from Kianda's public library into the customer's library. The designer exports a reusable Excel template. [check-list-tester.json](../../processes/Data/check-list-tester.json) previews a checklist using the execution component. Import duplicate handling was confirmed supported; inspect its exact matching rules before changing it. |
| Common execution component | [checklist-component.json](../../processes/Data/checklist-component.json) is embedded by [inspection.json](<../../processes/QHSE - Modules/inspection.json>), [checklist.json](<../../processes/QHSE - Modules/checklist.json>), [audit.json](<../../processes/QHSE - Modules/audit.json>), [permit-to-work.json](<../../processes/QHSE - Modules/permit-to-work.json>), and [induction.json](../../processes/Training/induction.json). Component reuse does not create an independent Checklist runner record in those parent modules. |
| Incident investigation variant | The saved [incident.json](<../../processes/QHSE - Modules/incident.json>) embeds [checklist-component-without-actions.json](../../processes/Data/checklist-component-without-actions.json). The user described it as the same reusable checklist behavior; use the actual variant when locating implementation changes. Incident also has a separate shared Actions panel. |
| Scoring | Checklist Type provides configured answer scores and thresholds. Custom and dropdown answer types contribute scores. Unanswered questions lower the achieved total; they are not omitted from the pass requirement. For the walkthrough: Pass is `total >= PassScore`, At Risk is `FailScore < total < PassScore`, Failed is `total <= FailScore`. N/A is typically zero. Labels can be supplied by the selected checklist at runtime. |
| Reports | Checklist Type can specify a custom Word template. Kianda's Generate Word Document rule maps rich-text content controls tagged `kf:<field-name>`. Parent processes generate their own execution reports; the template is configuration rather than another incident/audit record. |
| Audit findings to NCR | [audit.json](<../../processes/QHSE - Modules/audit.json>) has repeated finding rows. Each uncreated row can start a separate [ncr.json](<../../processes/QHSE - Modules/ncr.json>) record on Submit, passing topic, classification, owner, date, workspace, and Audit source identity. The returned NCR ID is retained on the finding row. Major/Minor/OFI/OBS classifications affect business meaning, not separate default workflows. |
| Reused Actions panel | [actions-component.json](../../processes/Data/actions-component.json) contains immediate-action notes and action rows. It opens [action-dialog-component.json](../../processes/Data/action-dialog-component.json) and [edit-action-dialog-component.json](../../processes/Data/edit-action-dialog-component.json). Follow-up rows become separate [action.json](<../../processes/QHSE - Modules/action.json>) records through parent submission/server rules. Source identity and optional question identity link the action back. |
| Action Plan | [action-plan.json](<../../processes/QHSE - Modules/action-plan.json>) uses the shared Actions component and requires at least one action on submission. Corrective and preventive plans use the same technical mechanism but have distinct business meanings. Each created action keeps its own due date and responsible persons. |
| Action responsibility | Actions can normally be internal or external; external responsibility selects a Subcontractor asset and uses its email for anonymous completion. RA-created actions were confirmed internal only. Action assignment emails are sent by the Action module; a parent record's originator email is a separate notification. |
| Attachments | [attachments-component.json](../../processes/Data/attachments-component.json) embeds pictures and file uploads into parent records. This is shared form data, not a dedicated attachment business process per uploaded file. |

## 4. Workers, training events, certificates, and inductions

```mermaid
flowchart LR
    WorkersPage["Workers page"] -->|lists / creates / opens| Worker["worker"]
    WorkerImport["worker-import"] -->|imports| Worker
    Role["worker-role lookup"] -->|role choices| Worker
    Subcontractor["asset: Subcontractor"] -->|company association| Worker
    Course["training-course lookup"] -->|course and code| Certificate["certificate"]
    Worker -->|upload individual training| Certificate
    Event["event: Training"] -->|participant selects worker| Worker
    Course -->|training course and code| Event
    Event -->|PDF and certificate record for eligible participants| Certificate
    Designer["Inductions page"] -->|opens designer| InductionType["induction-type"]
    InductionType -->|defines ordered content| Slide["slide: image / video / checklist"]
    Slide -->|checklist content| ChecklistType["audit-type"]
    InductionType -->|lookup content and settings| Player["induction"]
    Worker -->|learner identity| Player
    Player -->|Someone Else: individual anonymous invitations| Individual["Learner induction records"]
    Individual -->|successful completion: PDF and email| Certificate
    Player -->|successful completion: PDF and email| Certificate
    Certificate -->|worker ID / course / expiry / file| CertificatesPage["Training Certificates page"]
    Certificate -->|worker-specific certificates| WorkersPage
```

### Training relationship index

| Entity or dependency | Source and role |
| --- | --- |
| Worker | [worker.json](../../processes/Training/worker.json) is listed on [workers.json](../../pages/Training/workers.json). Workers are business records; they need not be signed-in platform user accounts. A red card represents repeated safety offenses and can lead to mandatory training/induction. |
| Imports and role choices | [worker-import.json](../../processes/Data/worker-import.json) supports bulk worker entry. [worker-role.json](../../processes/Data/worker-role.json) supplies roles. Customer onboarding commonly restricts worker creation/import, although the base configuration permits broad access. |
| Training Course | [training-course.json](../../processes/Data/training-course.json) is maintained under Other Lists. Its selected training supplies a default code for certificate upload; users can change that code. Course choices and reminder settings are configurable. |
| Individual certificate upload | The worker profile creates [certificate.json](../../processes/Training/certificate.json) records for uploaded individual training. One worker can have multiple certificates. Each carries the worker link, training, file, expiry date, and reminder configuration. |
| Event-generated certificates | [event.json](<../../processes/QHSE - Modules/event.json>) contains a participant table for every event type. When type is Training and certificate generation is enabled, server rules generate PDFs and start Certificate records per eligible worker row. The saved rule requires a Worker ID; a free-text Other participant is not automatically equivalent to a linked Worker. |
| Induction content | [induction-design.json](<../../pages/EHS Admin/induction-design.json>) manages [induction-type.json](../../processes/Data/induction-type.json), which uses [slide.json](../../processes/Data/slide.json). Slides support image, video, or Checklist Type content with additional rich-text guidance. Timers apply to images/videos; zero disables waiting. Cloning an induction also clones its slides. |
| Induction execution | [induction.json](../../processes/Training/induction.json) executes a selected Induction Type for the learner. Someone Else selects multiple Worker rows and creates an individual anonymous link for each learner. The creator remains distinct from those learners. Successful completion generates a PDF, creates a Certificate record, and emails the worker; quiz failure sets Failed. |
| Certificate views | [training-certificate.json](../../pages/Training/training-certificate.json) displays certificate records. The owner confirmed that certificate status is derived from expiry. The saved card template consumes `trainingStatus` values such as Ok, Due, and Expired, and uses `ember-moment` helpers such as `moment-from-now` to display expiry dates. Worker cards show the same worker-linked training records. Preserve both the status field contract and date-helper presentation when changing the view. |
| Guides | [ehswise-guides.json](../../pages/Training/ehswise-guides.json) is an end-user help page. It is distinct from the induction designer, induction learner records, and certificate records. |

## 5. Hazards, COSHH materials, Risk Assessment, and control updates

```mermaid
flowchart TB
    HazardLibrary["Hazard Library Analytics page"] -->|lists / creates| Hazard["hazard: shared baseline risk"]
    Scope["Global or project/location scope"] -->|scopes available records| Hazard
    MaterialPage["COSHH Materials administration"] -->|maintains library| Material["material: chemical details / SDS"]
    RA["ra: Task based or COSHH"] -->|selects configured hazard independently| Hazard
    RA -->|COSHH substance lookup and editable copied details| Material
    RA -->|contains multiple risk items| RiskRows["Work element / hazard ID / inherent and residual scores"]
    Hazard -->|description / existing controls / severity / likelihood| RiskRows
    RiskRows -->|additional controls / owner / target date| Action["action: internal responsibility"]
    Action -->|completion triggers status update| RA
    RA -->|completed additional controls added to existing controls| Hazard
    RA -->|list and aggregate| RAReport["Risk Assessment Analytics"]
    Hazard -->|list and risk bands| HazardLibrary
```

### Risk relationship index

| Dependency | Sources and contract |
| --- | --- |
| Shared Hazard library | [hazard.json](<../../processes/QHSE - Modules/hazard.json>) supplies the baseline description, existing controls, severity, and likelihood used in [ra.json](<../../processes/QHSE - Modules/ra.json>). Hazards can be global or scoped to a project/location. When multiple versions are available, the assessor chooses the applicable record from the dropdown; the system does not automatically pick a winning version. |
| COSHH Material | [material.json](../../processes/COSHH/material.json) is maintained through [coshh-materials.json](<../../pages/EHS Admin/coshh-materials.json>). It stores substance metadata, supplier, description, hazard properties, SDS and revision. Selecting it in a COSHH RA prepopulates those details and allows the assessor to edit them. The SDS attachment can be opened from the assessment. The library material and assessment remain separate records. |
| COSHH hazard selection | Hazards in the Assessment tab are selected independently; the chosen substance does **not** filter the hazard dropdown. Assessment, risk scales, residual controls, Actions, and Summary otherwise follow the same mechanism as Task based RA. |
| Assessment rows | One RA can bundle multiple configured hazards/work elements. Each row retains current and future Severity × Likelihood scores and visual risk bands. Defaults are editable by the assessor; read-only existing controls are a common customer customization. |
| Control completion feedback | User-confirmed behavior: completing an additional-control action adds those controls to the associated shared Hazard's existing controls. The saved [Action process](<../../processes/QHSE - Modules/action.json>) targets RA's `Update statuses from action` using the source ID; [RA](<../../processes/QHSE - Modules/ra.json>) contains Hazard update rules. Preserve that chain and its identifiers when changing completion behavior. |
| Source-only legacy dependency | [ra.json](<../../processes/QHSE - Modules/ra.json>) also contains hidden `FindingRules` and a rule targeting `ncr` with Audit-labelled mappings. This was not established as part of the Task based/COSHH walkthrough. Inspect its conditions and trigger reachability before treating it as a standard RA-to-NCR relationship or copying it into new functionality. |

## 6. Incident, PTW, Worked Hours, environment, and reporting lineage

```mermaid
flowchart TB
    Incident["incident: Near-miss / Incident / Accident"] -->|Accident contains repeated injured people| People["Injury classification rows"]
    People -->|calculated counters in Utility| Counters["LTI / restricted work / medical / first aid"]
    Root["root-cause lookup"] -->|investigation choices| Incident
    Incident -->|optional investigation checklist| Checks["checklist component variant"]
    Incident -->|damage selections show forms| Detail["Assets + Costs / Environment / Security / Quality"]
    Incident -->|reportable selection| Authority["Authority report metadata; reporting outside app"]
    Hours["hours-worked: project + category matrix"] -->|creates / updates daily values| HoursData["hours-worked-data"]
    Counters -->|numerator measures| Rates["Accident Rates Analytics"]
    HoursData -->|denominator measures| Rates
    PTW["permit-to-work"] -->|related permits| PTW
    PTW -->|selected checks| Checklist["audit-type / checklist component"]
    Equipment["ptw-equipment lookup"] -->|PPE / rescue equipment choices| PTW
    PTW -->|Electrical / Mechanical| LOTO["LOTO table in same permit"]
    PTW -->|Confined spaces| Gas["Gas readings in same permit"]
    PTW -->|contains phase rows| Signers["Involved parties + participants"]
    PTW -->|Applicable Risk Assessment| FreeText["Free text in base version"]
    EnergyType["energy-type + energy-unit"] -->|lookup choices| Energy["energy-registration"]
    Energy -->|list and aggregate| EnergyReport["Energy and Waste Analytics"]
    Green["green-initiative"] -->|follow-up records| Action["action"]
    Operational["Operational process records"] -->|schemaless field summaries| Reports["Analytics / Admin Data / operational views"]
```

### Lineage and boundary notes

- **Incident is one process.** Its type and damage selections dynamically reveal forms. People is activated by Accident, not Incident. Reputation remains in the incident details rather than adding a dedicated form. Injured persons, witnesses, cost rows, environmental details, and authority/security report metadata are data within the Incident; they are not separate processes in this model.
- **Accident-rate metrics derive from stored counters.** The walkthrough confirmed lost time, restricted work, medical treatment, and first aid classifications feed Utility form counts. The [Accident Rates page](../../pages/Analytics/accident-rate.json) and [accident-rate widget](../../components/widgets/accident-rate.js) combine incident measures with [hours-worked-data.json](../../processes/Data/hours-worked-data.json). Each metric instance can have its own customer-defined formula.
- **Worked Hours separates entry from daily data.** [hours-worked.json](<../../processes/QHSE - Modules/hours-worked.json>) selects the project in its first form's Workspace component and captures aggregate project/category hours in a date matrix. Daily cells do not represent individual workers. Bulk Update evenly divides a total among cells; Custom selects a date range. Rule mappings create/update [hours-worked-data.json](../../processes/Data/hours-worked-data.json), which is the analytics source. Preserve both the parent association and daily record IDs when changing date ranges or update behavior.
- **PTW phases belong to one permit.** [permit-to-work.json](<../../processes/QHSE - Modules/permit-to-work.json>) retains first-issue, extension, and closure signature/participant rows in its tables. Related PTW links connect separate permit records. Its base Applicable Risk Assessment field is free text; a true RA lookup/link is a common customer request, not an existing default relational link.
- **PTW equipment is the PTW-specific lookup.** The saved PPE/rescue selectors use [ptw-equipment.json](../../processes/Data/ptw-equipment.json). A separate [equipment.json](../../processes/Data/equipment.json) also exists; do not swap them based on their similar titles. Equipment selection and individual signatures are optional by default. LOTO and gas readings do not enforce the safety limits discussed in the walkthrough.
- **Energy/Green scope is limited.** [energy-registration.json](<../../processes/QHSE - Environment/energy-registration.json>) and [green-initiative.json](<../../processes/QHSE - Environment/green-initiative.json>) are Create New targets. Energy has a dedicated reporting page and [energy-type.json](../../processes/Data/energy-type.json)/[energy-unit.json](../../processes/Data/energy-unit.json) lookup dependencies. Their end-to-end operational walkthrough was not completed; avoid inferring additional workflows from these diagrams. [waste-management.json](../../processes/waste-management.json) is another existing source definition, distinct from the Energy and Waste reporting page.

## 7. All 12 Analytics pages and their primary data sources

```mermaid
flowchart LR
    Incident["incident"] --> AccidentRates["Accident Rates"]
    HoursData["hours-worked-data"] --> AccidentRates
    Action["action"] --> Actions["Action report"]
    Audit["audit"] --> Audits["Audit report"]
    Energy["energy-registration"] --> EnergyPage["Energy and Waste report"]
    Event["event"] --> Events["Event report"]
    Hazard["hazard"] --> HazardPage["Hazard Library"]
    Incident --> Incidents["Incident report"]
    Inspection["inspection"] --> Inspections["Inspection report"]
    NCR["ncr"] --> NCRPage["NCR report"]
    Observation["observation"] --> Observations["Observation report"]
    PTW["permit-to-work"] --> PTWPage["PTW report"]
    RA["ra"] --> RAPage["RA report"]
```

| Analytics page source | Primary source process | Special dependency or interpretation |
| --- | --- | --- |
| [accident-rate.json](../../pages/Analytics/accident-rate.json) | [incident](<../../processes/QHSE - Modules/incident.json>) + [hours-worked-data](../../processes/Data/hours-worked-data.json) | Rate numerators, denominators, periods, and multipliers are per-widget configuration. Custom implementation: [accident-rate.js](../../components/widgets/accident-rate.js), [accident-rate.hbs](../../components/widgets/accident-rate.hbs), [widget-tile.js](../../components/widgets/widget-tile.js), [widget-tile.hbs](../../components/widgets/widget-tile.hbs). |
| [action-report.json](../../pages/Analytics/action-report.json) | [action](<../../processes/QHSE - Modules/action.json>) | Status, priority, responsible person, overdue and period summaries; source-linked actions remain independent records. |
| [audit-report.json](../../pages/Analytics/audit-report.json) | [audit](<../../processes/QHSE - Modules/audit.json>) | Audit list and outcome/category/type counts; Findings are linked NCR records, not extra Audit records. |
| [energy-registration.json](../../pages/Analytics/energy-registration.json) | [energy-registration](<../../processes/QHSE - Environment/energy-registration.json>) | Energy and Waste is the page label; it is not evidence that the list queries the separate Waste Management process. |
| [event-report.json](../../pages/Analytics/event-report.json) | [event](<../../processes/QHSE - Modules/event.json>) | Event-type summaries count Event records, distinct from participant rows and generated certificates. |
| [hazard-library.json](../../pages/Analytics/hazard-library.json) | [hazard](<../../processes/QHSE - Modules/hazard.json>) | Baseline risk bands and ranked hazards; Country/Project filtering can cascade. |
| [incident-report.json](../../pages/Analytics/incident-report.json) | [incident](<../../processes/QHSE - Modules/incident.json>) | Lists incidents, damage, reportable/investigation indicators; primary source differs from the stale saved Project dropdown source. |
| [inspections-report.json](../../pages/Analytics/inspections-report.json) | [inspection](<../../processes/QHSE - Modules/inspection.json>) | Outcome and checklist summaries, with documented filter/wiring bugs to resolve before reuse. |
| [ncr-report.json](../../pages/Analytics/ncr-report.json) | [ncr](<../../processes/QHSE - Modules/ncr.json>) | Classification/status/owner list, including NCRs originated by Audit findings. |
| [observation-report.json](../../pages/Analytics/observation-report.json) | [observation](<../../processes/QHSE - Modules/observation.json>) | Observation type, SWA, subcontractor and period counts. |
| [ptw-report.json](../../pages/Analytics/ptw-report.json) | [permit-to-work](<../../processes/QHSE - Modules/permit-to-work.json>) | Counts permits and statuses, rather than counting each phase/table row as another permit. |
| [ra-report.json](../../pages/Analytics/ra-report.json) | [ra](<../../processes/QHSE - Modules/ra.json>) | Counts assessment records and review dates. Saved Event-based filter/tile references are known bugs, not an RA-to-Event business relationship. |

Filters are configured per page and connected explicitly per widget. Project/configured hierarchy normally affects the intended widgets, but a common visual layout does not imply identical wiring. OData exports respect the selected fields and configured filters. Preserve source fields, custom templates, widget IDs, target connection conditions, and process/field names when changing reporting.

**Known source/default split:** the saved Accident Rates page uses a 200,000 chart multiplier, while the custom widget's fallback/default code still contains 20,000. The owner identified the old 20,000 default as requiring correction. This does not mean every rate tile must use 200,000; independent formulas are intentional. Other stale process/field/widget references are documented in the [page guide](./pages.md).

## 8. Other documented pages and cross-cutting data

| Page or facility | Relationship to records and configuration |
| --- | --- |
| [Home / index](../../pages/Dashboard/index.json) | Static customer-brandable navigation and process shortcuts. Hidden walkthrough widgets guide navigation through selectors. Home does not define a separate business record type. |
| [Create New](<../../pages/Create New/create-new.json>) | Launches the 16 module IDs in the overall map through `/forms/{processId}?isNew=1`. CSS presents a normal page as a pinned primary menu button. |
| [My Overview](<../../pages/My overview/my-overview.json>) | Queries incomplete records assigned to the current user and earlier records the user started. Awaiting Input combines **Matching condition and assigned to current user** with status not Closed and a nonblank server-calculated Custom Process ID. |
| [Policies](../../pages/Policies/policies.json) | Lists [document.json](../../processes/Policies/document.json). Open the record, then its attached document. Origin represents customer hierarchy, e.g. company-wide Group versus Site. New document approval is serial; approval requires all approvers to approve. The displayed date is next review. EHS Admins create/manage by default. |
| [Other Lists](<../../pages/EHS Admin/other-data-lists.json>) | Maintains simple process-record lookups including [training-course](../../processes/Data/training-course.json), [worker-role](../../processes/Data/worker-role.json), [energy-type](../../processes/Data/energy-type.json), [energy-unit](../../processes/Data/energy-unit.json), [root-cause](../../processes/Data/root-cause.json), and [ptw-equipment](../../processes/Data/ptw-equipment.json). Changes affect future selections; they do not rewrite prior captured values. |
| [Admin Data](<../../pages/EHS Admin/admin.json>) | Cross-process summaries list exposes common fields and Custom Process ID. Its selected fields are configurable even across different process definitions. Bulk Delete applies only to selected rows; OData uses selected fields and filters. |
| [Languages](<../../pages/EHS Admin/languages.json>) | Configures UI labels and process-field translations. English is default/fallback; auto-translation can be manually overridden. User profile language selection persists across sessions. This presentation configuration is separate from worker/incident business data. |
| Offline runtime and process cache | The PWA service worker caches runtime. The refresh gesture caches process JSON definitions in IndexedDB for offline operation. Do not treat cached definitions as a new process-record type or assume changing local JSON immediately updates an already cached device. [offline-data.json](../../processes/Data/offline-data.json) exists as supporting configuration; end-to-end synchronization internals were not reviewed. |
| Workspace binding and custom code | [.kianda/workspace.json](../../.kianda/workspace.json) maps exported definitions and custom components to the Kianda workspace. Custom widget JavaScript/Handlebars and page/process JSON jointly implement the UI. Workspace connection values are not part of the product data model. |

## 9. Change impact checklist for agents

1. Identify whether the requested change belongs to a **library record**, **execution record**, **nested row**, **embedded component**, **server rule**, **page query**, or **widget implementation**.
2. Follow the labelled dependencies above. For example, a new Incident type can affect form visibility, validation, Utility counters, report generation, notification conditions, reporting choices, and translations, even though it remains one Incident process.
3. Trace actual saved IDs, field names, linked record keys, conditions, and trigger buttons. Page titles and visible labels can differ from process IDs and saved field names.
4. Preserve author/learner/reporter/owner distinctions. The person entered in a field is not automatically the record creator or notification recipient.
5. Check both visibility and security when exposing a new module, hierarchy level, or external link.
6. Check whether an apparent copy is intentionally editable receiving-record data. Changing a Material or lookup record must not silently rewrite historical assessments or submissions.
7. Keep known bugs and source-only legacy relationships explicit. They are not supported patterns to reproduce in generated pages or workflows.

The walkthrough did not cover every process in the repository. Additional Lessons Learned, membership, My Office/My Site, and other source definitions exist. Their presence alone does not establish a completed workflow specification; inspect and document them separately when work requires them.
