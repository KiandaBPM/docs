# Kianda custom addon knowledge

Version: 1.0.0  
Prepared: 2026-10-27  
Intended location: `docs/kianda/custom-addon-knowledge.md`  
Audience: AI agents creating, reviewing or maintaining Kianda custom field, rule and page widgets.  
Baseline: the supplied Ember 2.18 developer guides, process authoring package v1.1.0 and page authoring package v1.0.0. The supplied documents establish the contracts described below; this guide does not claim that its examples were executed in a live workspace.

## 1. Scope and how to use this guide

A custom addon in this guide is a reusable Ember component registered as a Kianda field, rule or page widget. Its JavaScript implements behaviour, its Handlebars template renders the applicable interface, and each configured use stores its options in a `settings` object. A custom widget is distinct from a reusable **Component process** loaded by the native `fields/field-component` control; consult the process guide for that mechanism.

Read [general.md](./general.md) for the application model. Read [process-knowledge.md](./process-knowledge.md) and [process-schema.json](./process-schema.json) when placing a custom field or rule in a process. Read [page-knowledge.md](./page-knowledge.md) and [page-schema.json](./page-schema.json) when placing a page widget or editing its filters. Use [css-style-guide.md](./css-style-guide.md) for presentation.

Before changing an installed addon:

1. Locate its exact registered identifier, JavaScript, all applicable templates, and representative saved settings in the target workspace.
2. Identify consumers of its settings, returned values, field references, events, helpers and CSS. Search for the exact runtime identifier and affected setting names.
3. Establish which requirements native controls and rules already meet. Add a custom component when the requested behaviour needs that extension.
4. Preserve existing identities and settings contracts. Specify a migration before changing a stored value shape or meaning.
5. Separate static validation from target-workspace compilation, runtime verification and publication. Record the checks actually completed.

The source codes in square brackets refer to the supplied source register in section 15. They distinguish documented contracts from examples, recommendations and unresolved behaviour.

## 2. The three addon contracts

| Concern | Custom field | Custom rule | Custom page widget |
| --- | --- | --- | --- |
| Runtime identifier | `client-field/<component-id>` | `client-rule/<component-id>` | `client-widget/<component-id>` |
| Enclosing definition | Process field `type` | Process rule `action` | Placed page widget `type` |
| Primary responsibility | Render and edit field data | Perform a business action | Present information, query data or provide navigation |
| Configuration owner | `field.settings` | `rule.settings` | `widget.settings` |
| Model data | `field.text`, `field.value`, or deliberate child fields | Supplied process/form/field models | Query results normally remain component-local |
| Template | `design`, `edit`, `display`, `settings` views | Designer settings UI; not rendered for runtime execution | `settings` branch; otherwise page content |
| Runtime entry | Rendering, actions and lifecycle | `execute()` | Lifecycle and actions such as `refresh` |
| Host awaits asynchronous completion? | Field mode hooks are not awaited | Returned Promise from `execute()` is awaited | `actions.refresh` is not awaited |
| Persistence owner | Process save/commit workflow | Normally a process Save rule | Page designer saves configuration; instance mutations require their own workflow |

For a custom placed page widget, use `isCustom: true` as required by the supplied page schema. Do not copy that property onto other entity kinds without their own schema contract.

These prefixes identify the implementation to resolve; they do not prove that it is installed. An open settings schema does not create a component or establish its capabilities. The reusable component ID is also different from the GUID of an individual field, rule or placed widget. Multiple placed widgets can use the same component with independent settings and identities. [F; R; W; P §§6,12; Q §§7,17]

## 3. Shared implementation rules

### 3.1 Use the supported Ember environment

The supplied guides use classic Ember component modules:

```javascript
import Ember from "ember";

export default Ember.Component.extend({
  // Component methods, computed properties, actions and lifecycle hooks.
});
```

Use `this.get(...)`, `this.set(...)`, `setProperties`, Ember-aware collection operations, classic computed properties and service injection as demonstrated by the current implementation. Do not introduce Octane tracked properties or newer template syntax based solely on contemporary Ember examples. Call `this._super(...arguments)` when overriding inherited lifecycle hooks. Use ordinary method syntax for component methods so `this` remains the component; arrow callbacks inside those methods can retain it. [F §§4,11; R §9; W §§2,8]

Allocate mutable component-local arrays and objects per instance in `init()`. Store serializable configuration on the appropriate model; keep loading flags, errors, request counters, timers, DOM nodes, browser `File` objects and external SDK instances on the component. For field and rule widgets, `settings()` is a Designer initialization hook. Page widgets use ordinary lifecycle hooks; the supplied page contract does not establish a `settings()` convenience hook. The properties `field.settings`, `rule.settings` and `widget.settings` contain configuration data.

The documented environment includes `ember-moment` 8.0.1, `ember-truth-helpers` 2.0.0 and `ember-collection` 1.0.0. Page-widget documentation also lists bundled Chart.js, Bootstrap/BootstrapDialog, Kendo, Moment, jQuery/jQuery UI, Summernote and Babel. Verify the installed library version before using version-specific APIs. FullCalendar is an external dependency in the supplied examples, not a bundled Kianda guarantee. [F §11; R §7; W §13]

### 3.2 Preserve configuration and data types

The field, rule and widget models initialize a separate settings object. Initialize individual missing options, preserving intentional `false`, `0` and empty strings:

```javascript
// Fragment inside the appropriate settings or initialization method.
if (this.get("field.settings.placeholder") === undefined) {
  this.set("field.settings.placeholder", "Enter a reference");
}
```

Do not replace the entire settings hash to introduce defaults. It may contain existing custom configuration, engine diagnostics or page-filter state. Use the settings owner for the addon type: a rule's triggering `field` is not its configuration owner.

Inspect each contract's exact values and casing. Outer field flags are booleans; many native settings use strings. A custom widget may deliberately choose its own values. Do not globally coerce `"yes"`, `"no"`, `"Yes"`, booleans and empty defaults into one representation. Preserve unknown settings during unrelated edits. Report incomplete contract coverage separately from a known invalid setting. The warning-only treatment is confirmed for opaque page-widget settings; extending the same severity policy to custom fields/rules is a recommended policy here, not an established engine behaviour. [P §§6–7,12; Q §§16–17]

### 3.3 Own resources and asynchronous state

Mount DOM-dependent integrations after insertion into the relevant view. Use the component's own element, `this.$(...)`, or an instance-specific ID such as `elementId`. A shared component name is not a unique DOM identifier.

When a callback resolves, check that the component remains active, refers to the same model and still permits the operation. Re-enter Ember's run loop with `Ember.run` or `Ember.run.join` when publishing bound state from external callbacks, following the supplied examples. Unsubscribe listeners and dispose of timers, location watches, chart/calendar instances and SDK elements on teardown. Clean up mode-specific resources when editability changes as well as on destruction.

An `async` keyword alone does not make the host wait for callback work. Likewise, `this.send(...)` dispatches an action; do not use it as a general awaitable completion contract. Keep essential work in methods whose returned Promises are explicitly awaited by their caller. [F §§4,8–10; R §6; W §8]

### 3.4 Keep operations and permission checks in their proper context

Use escaped Handlebars output for ordinary record text, filenames and error messages. Rich HTML needs an established trusted-source and sanitization policy. Do not interpolate record values into executable JavaScript or depend on hidden UI to protect accessible data.

Use the current platform session, adapter or supported connector for authenticated operations. Do not embed tokens or secret credentials in component code, saved settings or public assets. An API operation can complete remotely before a later process save; neither an ignored late callback nor a failed process save reverses that external effect. Design retries and partial-completion handling for the particular integration. [F §§9–11; R §§6,10; W §§11–13]

## 4. Custom field widgets

### 4.1 Render all four modes

| Exact `displayMode` | Required interpretation |
| --- | --- |
| `design` | Designer-canvas preview; show an informative, non-operating preview |
| `edit` | Editable runtime UI; user actions may update the field |
| `display` | Read-only representation of stored data, including a disabled field |
| `settings` | Configuration UI bound to `field.settings` |

The literal is `design`, not `designer`. Kianda supplies insertion convenience methods `edit()`, `display()` and `settings()` when the corresponding mode is active. There is **no `design()` convenience hook**, and field mode hooks are **not awaited**. They are not guaranteed to run again whenever `displayMode` changes. Use explicit context-change handling for long-lived resources. [F §4]

Guard active integrations with the actual editable state. Uploading, geolocation acquisition or payment initialization must not begin merely because the control appears on the Designer canvas. Respect `field.enabled` and `field.visible`, including when delayed work completes.

### 4.2 Maintain text, value and rule notification

`field.value` is polymorphic: it may be a scalar, object or array according to the field's contract. `field.text` is its readable representation. Neither property should contain transient loading/error messages masquerading as business input.

| Update pattern | Rule-notification consequence |
| --- | --- |
| `field.set("value", nextValue)` changes the top-level value | Triggers the field's attached rules |
| Only `field.text` changes | Explicit value notification is needed when this logical edit should trigger rules |
| An existing value object's properties change | Use Ember-aware setters, finish the logical update, then notify `value` |
| An existing value array changes | Use Ember-aware collection operations, finish the update, then notify `value` |

For a text field with matching text and value, set readable text first:

```javascript
// Fragment in an editable action after context/input validation.
const field = this.get("field");
field.set("text", nextText);
field.set("value", nextText);
```

Rules observing the changed value can then see matching text. Do not add a second `notifyPropertyChange("value")` after the same top-level replacement. When intentionally keeping the same structured value or using text-only data, notify once after all relevant changes:

```javascript
// Existing structured object; this widget's value contract must allow it.
Ember.set(field.get("value"), "description", nextDescription);
field.set("text", nextDescription);
field.notifyPropertyChange("value");
```

A rule triggered by this notification can hide or remove the control. Finish component-local presentation changes before publishing the final value when the remaining code assumes the component is still rendered. Review direct and indirect update cycles. Updating several fields is not an atomic transaction. [F §§2–3,6,8]

### 4.3 Persistence and runtime validation

A field widget updates the current model; it does not call `process.save()` to persist its own data. Use the process's Save rule or surrounding commit workflow. Saving reusable widget code, saving the process definition and saving a running instance are different operations.

Required-input validation examines meaningful `field.text`/`field.value` content. A component-local `isBusy` or `errorMessage` does not automatically block submission. An object containing a pending external-operation reference may be nonempty without satisfying the business requirement. Model and validate the completion requirement explicitly in the process.

When clearing data, clear corresponding readable text. When replacing data asynchronously, decide whether a previous valid result remains acceptable until replacement succeeds. A native browser file input is empty after reopening even when a valid uploaded reference is stored; do not force a replacement by blindly binding that input's `required` attribute to `field.required`. [F §§3,5,9]

### 4.4 Process and child field access

Use `await this.get("field.process")` inside an asynchronous method when the relationship may still be resolving. Check for absence and recheck the current model after waiting. The field model resolves the wrapping process; copying legacy `.content` unwrapping everywhere is unnecessary.

Use the actual `fields` relationship for child field models and `parentField` for their inverse. Object properties inside `field.value` are not independent field models. A table-row helper's `subFields` has a different context; do not invent `field.subFields` as a generic relationship.

Create missing child models deliberately and once, using the supported store/relationship pattern; preserve existing children, identities and names. Normal display/rendering must not continually recreate them. Persist them through the surrounding design or instance workflow. Selecting existing utility fields through `field-picker` is another supported composition pattern. [F §§6–7; P §§4,6]

## 5. Field references and platform field APIs

A `field-picker` normally stores a descriptor, not a live model. Its `text` is the selection label, not the field's current contents. A literal input can instead be `{ "type": "text", "text": "Site" }`.

| API | Contract used by the supplied guides |
| --- | --- |
| `process.findFieldByName(name)` | Resolve a process field by name; check the result |
| `process.findFieldByRef(reference)` | Resolve a field reference; may return `undefined` |
| `process.getFieldRefText(reference)` | Read current field text or literal text; may return `undefined` |
| `field.get("value")` / `field.get("text")` | Read the resolved model's actual data |
| `process.setField(field, value, text)` | Update a field, optionally supplying separate display text; triggers that field's rules and may return a Promise |

Await `setField` when subsequent work depends on the update. Lists backed by data sources and user pickers can need asynchronous resolution. A field component awaiting it sequences that component's action; it does not make the process wait for all of the field's asynchronous activity.

Use `allowText=false` for a destination. Validate existence, compatible value shape and contextual identity before writing. Resolve references from the current process at runtime rather than retaining Designer models. Preserve row context for table operations.

A descriptor's `type: "field"` identifies its reference kind, while `fieldType` identifies the referenced field's outer control type. For newly authored page selectors, the page contract requires the matching `fieldType`; do not invent IDs or flatten all descriptors into one universal shape. Preserve exact stored names, including suffixes containing `?`. [F §7; R §§3–4; Q §8]

## 6. Custom rule widgets

### 6.1 Execute from the supplied context

`execute()` is the only runtime entry point. The runtime instantiates the component without rendering its settings template. Runtime logic must therefore work without `this.element`, `didInsertElement`, settings-editor actions or a prior call to `settings()`.

| Supplied property | Meaning |
| --- | --- |
| `process` | Current process instance |
| `rule` | Current rule and its saved settings |
| `field` | Attached/triggering field where applicable; can be null |
| `form` | Associated form where applicable; can be null |
| `node` | Attachment point: process, form or field |
| `ruleEngine` | Current orchestrator; supplied rather than inferred from a rendered view |

The attached field can be a button while the destination is another field selected in `rule.settings`. Read the configured destination instead of assuming `this.field` is the target. The engine owns conditions, enabled state and alternate-setting orchestration; a custom executor should not reimplement those mechanisms. [R §§1,3]

### 6.2 Return completion and handle failure correctly

The engine awaits the Promise returned by `execute()`. Use `async execute()` and await all work that defines completion, including field updates. For a callback API, adapt its documented completion to a Promise. Use sequential `for` loops for ordered mutations; `forEach(async ...)` does not make the outer operation await each callback.

**Return values are ignored. Errors do not stop the subsequent rule sequence.** `return false` is not a cancellation mechanism. When a rule throws or rejects, Kianda records/reports the failure and continues. Dependent actions require explicit conditions on a verified result or outcome field. Reset a reused outcome before attempting work; set success only after the required operations finish.

The engine writes `rule.settings.lastExecuted` after success and `rule.settings.lastError` on failure. Preserve those keys and do not use them as custom options or set them yourself. A previous diagnostic alone is not proof of the current attempt's result. Throwing does not roll back earlier field writes, an external request or a counter allocation. [R §§3,6]

### 6.3 A small rule implementation pattern

This example copies displayed field-or-literal text into an independently selected text destination. The saved `source` and `destination` descriptors are this example's settings contract. It requires compatible text fields and the matching settings template; it is not a complete process definition.

```handlebars
<div class="form-group">
  <label>Source text</label>
  {{field-picker process=process required=true allowText=true
    selectForms=false selectFields=true value=rule.settings.source}}
</div>
<div class="form-group">
  <label>Destination text field</label>
  {{field-picker process=process required=true allowText=false
    includes='["fields/field-textbox"]'
    selectForms=false selectFields=true value=rule.settings.destination}}
</div>
```

```javascript
import Ember from "ember";

export default Ember.Component.extend({
  async execute() {
    const process = this.get("process");
    const rule = this.get("rule");
    const source = rule.get("settings.source");
    const target = rule.get("settings.destination");

    if (!process || !source ||
        (source.type !== "field" && source.type !== "text")) {
      throw new Error("Copy text: select a source field or enter text.");
    }
    if (!target || target.type !== "field") {
      throw new Error("Copy text: select a destination text field.");
    }
    const destination = process.findFieldByRef(target);
    if (!destination) {
      throw new Error("Copy text: the destination field no longer exists.");
    }
    if (destination.get("type") !== "fields/field-textbox") {
      throw new Error("Copy text: the destination must be a text box field.");
    }
    if (source.type === "field") {
      const sourceField = process.findFieldByRef(source);
      if (!sourceField) {
        throw new Error("Copy text: the source field no longer exists.");
      }
      if (sourceField === destination) {
        throw new Error("Copy text: source and destination must differ.");
      }
    }
    const text = process.getFieldRefText(source);
    if (text === undefined || text === null) {
      throw new Error("Copy text: the source text could not be read.");
    }
    await process.setField(destination, String(text));
  }
});
```

This example limits the destination to `fields/field-textbox` in both the picker and executor. It compares resolved field models, because names alone do not distinguish fields in different table rows. Before reuse, verify the chosen textbox configuration and row context, and test the rule chain for indirect cycles. This example preserves an empty string as meaningful input; requiredness and business validation belong to the intended workflow. Add the normal Save rule if that workflow should persist the resulting instance. The documented Format text implementation provides a fuller configurable transformation. [R §§2,4–6; F §8]

### 6.4 Tables and background execution

For table-processing rules, validate source/destination tables, mappings and key columns before mutations. A table model exposes `rows`, `createRow()` and row `subFields` in the documented pattern. Table-row field names can repeat between rows, so field resolution and equality must respect row context and value type.

Process row-dependent operations sequentially. Capture and restore `rowContext`, `isInRowContext` and `secondaryRowContext` in `finally`, including after failure. Do not replace a previously existing secondary context with a guessed null default. Ensure callback-based condition evaluation is included in completion. Require valid keys for merge/unique modes and specify how complex values are compared; object identity is not semantic equality.

Custom rules can also run in scheduled tasks. Obtain business input from the supplied models and saved configuration. Avoid dialogs or waiting for user interaction, and verify that required services and remote access work in the scheduled environment. Headless suitability is a runtime check, not a consequence of omitting a template. [R §§8,10; P §4]

## 7. Configuration interfaces and validation

Common supported controls include `input`, `textarea`, `field-picker`, `radio-button`, `person-picker` and `rich-text`. Page configuration also uses `process-picker`, `rules/rule-conditions` and other controls documented for that context. Use the actual binding: a picker reference uses `value`, radio selection uses `group`, and rich-text content uses `contents`. Scope radio-group names with `elementId` when multiple instances can render together.

Useful documented fragments include:

```handlebars
{{radio-button name=(concat this.elementId "-mode")
  label="Keep case" value="preserve" group=this.rule.settings.caseMode}}
{{radio-button name=(concat this.elementId "-mode")
  label="Uppercase" value="upper" group=this.rule.settings.caseMode}}

{{rich-text contents=this.rule.settings.message height=220
  sanitize=true showCodeview=false showImageDialog=true showFontName=false}}
```

These control options describe UI behaviour; the custom implementation must use the stored settings. Picker output shape is context-specific. A person-picker result is not guaranteed to be one username string. Do not infer a helper or option's existence from its name. [F §11; R §7; W §5]

### 7.1 Field and rule configuration saves

Use required controls for mandatory settings. For additional synchronous checks, field and rule models expose a `saving` event:

- Set `args.isError = true` when rejecting the configuration.
- Append a clear message to `args.errors`.
- Preserve existing errors and failure state from other validators.
- Use a stable callback reference; detach a prior registration before adding it again and remove it on destruction from the same model.

This validates Designer configuration, not an instance Save rule. Do not assume asynchronous validators are awaited. Load required remote information beforehand and validate its resulting state synchronously. Runtime checks remain necessary because references can be deleted and older configurations can be imported. [F §5; R §5]

### 7.2 Page configuration differs

The supplied page-widget contract has **no equivalent `saving` validation event**. Use the global settings dialog's required-control validation and validate the saved settings again before the component performs a query or operation.

The settings dialog and runtime view share the same `widget` model but have separate component-local state and DOM. Do not call `widget.save()` from a picker or callback. Let the page designer own persistence; do not assume cancelling the dialog provides a transaction boundary for arbitrary mutations. [W §§2,5]

## 8. Custom page widgets

### 8.1 Understand the host and views

Use exactly `displayMode === "settings"` for the configuration branch; otherwise render page content. `isDesign` is separate design-presentation metadata. It is not another field-style mode. The `widget-base` host supplies the frame, title, header controls and bridge to the child component.

The custom component receives `widget`, host `data`, `id`, `isDesign` and action bridges. `widget.page` is the containing-page relationship; a standalone `page` argument is not established by the shown host invocation. Host `data` has no universal result shape. `process-picker` can supply process **definition** metadata for settings controls, not an editable current process instance.

Use ordinary lifecycle hooks. Guard data loading and chart/calendar mounting against settings mode. A field-style `edit()` or rule-style `execute()` does not define a page widget's runtime lifecycle. Do not fetch unconditionally from `didRender`, because the resulting state update can render again. [W §§2,4,8]

### 8.2 Filtering and refresh

A filter-aware custom reporting widget implements `actions.refresh`. Kianda fires this action with **no arguments** and **does not await it**. The widget must own loading state, errors, request ordering and completion.

The host resolves filter connections and merges temporary groups into the target's live `widget.settings.conditions`. Those groups carry `filterId`. Build a request from a fresh clone of the entire effective array, retaining those temporary groups. Kianda removes the originating groups when a filter is cleared and strips temporary groups before saving the page. Do not cache a stale base array or independently remove runtime groups before querying.

```javascript
// Fragment inside the widget's error-handled loading method.
const conditions = JSON.parse(JSON.stringify(
  this.get("widget.settings.conditions") || []
));
this.get("ruleEngine").parseDateConditions(conditions);
```

JSON cloning here is for serialized condition data, not Ember models or arbitrary objects. The date helper mutates the copy; use that array afterward rather than expecting a returned array or Promise.

Connections target the **placed widget ID**, not `client-widget/<component-id>`. The filter's authoritative design configuration is `settings.connections`; a filter appearing beside a custom widget does not prove that the connection exists or the component supports it. [W §6; Q §10]

### 8.3 Coordinate asynchronous refreshes

Use a deliberate request policy. The supplied metric example coalesces refreshes, serializes requests for one stable aggregate identity and checks a revision/model before publishing. Capture conditions once for a logical refresh, then clone independently for separate datasets.

A stale-result guard prevents obsolete UI publication; it does not cancel HTTP work or isolate collisions in the shared Ember store. Give separate logical datasets distinct `info.id` values and coordinate overlapping requests using the same identity. Separate runtime component lifetimes may also need distinct identities when an earlier component's request is unfinished.

Mount external resources after insertion and destroy the component's instance on teardown. Keep temporary chart data, request counters and timers off `widget.settings`. Define whether loading clears a previous result or displays it as stale. A failed request is different from an empty result. [W §§3,7–9]

## 9. Reporting through Summaries

### 9.1 Choose the right data contract

The Summaries endpoint is `POST /api/summaries` and returns a JSON array. Inside a Kianda page widget, the recommended simple client path is `store.query("summary", query)` with `preferOnline: true`; await its single Promise in an internally handled asynchronous method.

| `action` | Result interpretation |
| --- | --- |
| `list` | Summary records with projected `properties` |
| `tile` | Aggregate at `firstObject.properties.value` in the Ember result |
| `chart` | Grouped `properties.labels`, `values1` and any configured additional series |

`preferOnline` is a client-store option, not a server `Query` member. Direct REST consumers read the returned array and, for list totals, the `total-items` response header. `data.meta` is client metadata; the sources do not establish a universal `data.meta.totalItems` property. A datasource service's `select` action and `result.items` are a separate integration contract. [S §§2–5,8,10–13; W §§7,11]

For a count restricted to one configured process, the core request is below. Blank or omitted `info.process` can search across processes accessible to the user, so this example rejects a missing process selection. [S §3]

```javascript
// Fragment: the caller must validate settings, prepare conditions, handle
// failures and stale responses, and coordinate the stable dataset identity.
const processName = this.get("widget.settings.processName");
if (typeof processName !== "string" || !processName.trim()) {
  throw new Error("Count: select a process before loading data.");
}
const data = await this.get("store").query("summary", {
  action: "tile",
  info: {
    process: processName,
    queryType: "all",
    tile: "count",
    id: this.get("widget.id") + "-count"
  },
  fields: ["__PROCESS_NAME"],
  conditions: conditions,
  rowLimit: 1,
  preferOnline: true
});
const raw = data.get("firstObject.properties.value");
```

Here `rowLimit: 1` follows the aggregate request pattern; it does not mean only one matching instance is counted. Keep a returned numeric zero distinct from missing data. For a sum or average, use a verified numeric field and exact `sum` or `avg` setting. A missing denominator or nonpositive hours value should not become a plausible rate. [S §10; W §§3,9]

### 9.2 Scope, projection and identity

Use `info.process` to restrict one process and exact stored field names in projections. The supported relationship filters are `all`, `assignedTo`, `createdBy` and `modifiedBy`. `all` still applies instance permissions. Omit deprecated `processSource` and `isPartner` from newly constructed Summaries requests; preserve legacy page serialization according to its own authoring contract rather than indiscriminately rewriting it.

Fields outside tables, including panels/dialogs, are indexed. Custom fields expose their `field.text`; arbitrary nested properties in structured custom values are not independently searchable. Table-cell content and client-calculated `___CUSTOM_FIELD*` columns are outside the server projection contract. Maintain a useful text representation or explicitly designed reporting fields when a custom value must be searched.

Use `summary.name` for opening or addressing an instance. With `isListWidget: true`, `summary.id` can include a widget suffix; do not split it to guess the original name. For new list widgets, explicitly request the needed fields through a nonempty `fields` array, use zero-based `info.page`, and choose bounded page sizes and suitable deterministic sorting. These page-size and sorting choices are authoring recommendations, not a claim that the server enforces a particular upper limit or order. Use the documented date/number `sortFieldType` where appropriate. Typed companions such as `_utc` and `_number` can be absent for empty values. [S §§1,3–5,8; W §7]

### 9.3 Conditions, dates and access

A query has one level of groups containing individual conditions, not an arbitrary recursive Boolean tree. Preserve connectors and operator spelling. When persisting page-widget conditions, follow the page guide's GUID requirements for both groups and individual conditions. Process direct-rule groups and known settings-level query-filter groups also require GUIDs, but individual-condition ID requiredness remains unconfirmed in those process contexts. Follow the relevant process contract. Descriptive IDs in REST tutorial snippets are not templates for Designer-ready saved pages. Do not import the entire query operator catalogue into direct process-rule conditions. [Q §§1,9–10; P §§4–5,10]

Author relative-date configuration without hard-coded resolved boundaries; call `parseDateConditions` on the request copy at refresh time. Generated explicit reporting periods need an intentional calendar/timezone policy. The tutorial use of UTC monthly buckets is not a universal workspace timezone rule. Appending a range to `(A) OR (B)` requires preserving its Boolean meaning; the supplied examples' top-level `and` restriction is an example limitation, not an API restriction.

Indexing after an instance save is asynchronous. A refresh can briefly show prior values; do not claim that a successful save synchronously updates every dashboard. Permissions govern contributing instances for lists and aggregates. Hiding a field or widget is presentation, not field-level API security. Cached public-file scripts also do not guarantee offline reporting data, especially with the recommended online query path. [S §§1,6–8; W §§7,9,13; Q §§9–10]

The page package excludes new native Chart v2 authoring in V1. That policy does not prohibit the Summaries `chart` action or a verified custom Chart.js implementation. Preserve existing Chart v2 definitions under the page guide's compatibility rules. [Q §§7,16]

## 10. Navigation and other template contexts

The supplied page developer guide documents these global functions:

```javascript
window.showModalForm(nameOrUrl, isNew, params, isUrlPredefined, callBack, isStatic);
window.gotoForm(name, isNew, partnerId, queryParams, reload);
window.gotoDashboard(name, queryParams);
```

These lines are signatures, not calls with defined arguments. Use an instance `name` for an existing record and a process alias for a new process. Encode query parameter values. Do not assume a modal callback proves a save succeeded or returns an awaitable Promise. Verify optional partner, predefined-URL, reload and modal semantics before depending on them. [W §12]

Custom HBS **list columns** have another host context: `row`, projected properties and documented actions. They are not automatically standalone custom page widgets. An action available there, such as `showModal`, does not establish that every custom component inherits it. The custom-column action `showModal` and global `window.showModalForm` have different signatures; preserve their contexts. Similarly, the host invocation's action names do not define global-function argument signatures.

Keep hidden list projections that supply HBS values. Use the verified helpers/actions in [page-knowledge.md](./page-knowledge.md), declare actions referenced by a standalone component's own template, and avoid assuming an addon-specific token such as `[description]` is a global interpolation mechanism. The recorded `mmoment-diff` spelling is unresolved; do not introduce a dependency on it or silently rename it. [Q §11; W §§2,11–12]

## 11. Review of the supplied public upload field

The supplied `upload-public-file(1).js` and `.hbs` implement a **custom field widget**, not a rule. They demonstrate adapter/session use, a browser upload and field-picker mappings. They are an integration example with local assumptions; the corrected field-widget developer guide provides stronger recommended patterns. [U; F §9]

| Observed source behaviour | Required treatment when adapting it |
| --- | --- |
| Upload UI appears in both `edit` and `design` | Use a passive Designer preview; permit upload through an editable user action |
| Uses `window.event.target` | Pass the native event explicitly to the action |
| Resolves `field.process` with legacy `.content` unwrapping | Use the documented process relationship and handle asynchronous resolution/context changes |
| Hard-codes folder `induction-training` | Treat it as this application's choice; make a general destination explicit |
| Computes `isPublic` but sends `isPublic=true` unconditionally | The shown upload is public; do not claim it supports private uploads |
| Calls `ensureFolder` before checking that a file exists and ignores its success result | Validate prerequisites first and check folder-operation outcomes |
| Inserts folder parameters into URLs without consistent encoding | Encode configured path/name parameters using the actual endpoint contract |
| Assumes synchronous `session.authorize` callback | Verify that contract; await authorization if the target integration is asynchronous |
| Validates HTTP success but then accesses `result.files[0]` without full shape checks | Validate application success and the returned file reference |
| Writes utility fields without awaiting `process.setField` | Validate targets and await dependent writes |
| Leaves the uploader's own `field.text` and `field.value` unset | Deliberately define whether the control owns a value or is an action-only uploader; the display/required contract must agree |
| Has no component busy/error/lifetime strategy | Handle retries, pending state and late responses explicitly |

The template's `process=this.process` also requires verification because the documented field context is `field.process`, and the provided JavaScript does not establish a separate `process` property. Its target-filename setting is labelled “Target field Id”; clarify the label without renaming the stored setting during an unrelated edit.

The observed endpoints `/kianda-files/folder` and `/kianda-files/file`, their authentication pattern, and their response shape are integration dependencies. They are not a complete public files SDK contract for every deployment. The actual file upload can persist remotely even when the enclosing process is never saved. Do not retrofit rollback, private-file semantics or automatic orphan cleanup without the corresponding service contract.

## 12. Installation, updates and compatibility

Updating reusable widget code in Developer compiles it with Babel and produces source maps in the documented workflow. That differs from saving the configured use, publishing a process/page definition and saving an instance. Follow the workspace extension's actual publishing contract; local file save behaviour, asset propagation and cache invalidation are not established by these guides.

Changing shared component code can affect many existing uses. Retain saved settings and value shapes, initialize only missing defaults, and identify affected templates, processes and pages. If a migration is necessary, document its scope and verify representative retained configurations. Validate the enclosing process/page against its schema as well as reviewing the addon contract.

Do not infer automatic component installation, version pinning or settings migration from the existence of a source file. Resolve the installed registration and required assets. Preserve unknown outer metadata, while recognizing that permissive schema acceptance does not guarantee serializer retention. [F §12; R §11; W §§1,14; P §12]

## 13. Verification and completion

Select checks that address the changed behaviour:

| Area | Verification |
| --- | --- |
| Configuration | Required input, saved defaults, reopened settings, invalid/removed references, no duplicate listeners |
| Field | All four views; text/value agreement; clearing; required validation; rule notification; disable/hide/navigation during pending work |
| Rule | Correct attachment context; fully awaited work; failure followed by dependent rules; partial updates; scheduled operation where required |
| Page | Settings/runtime separation; initial load; zero/empty/error; change and clear filters; rapid refreshes; leave during a pending query |
| Shared component | Two simultaneous instances; independent DOM IDs, state and aggregate identities |
| Reporting | Exact field types/projections, paging, permissions, relative dates and indexing delay |
| Persistence | Save through the intended workflow, reopen, and verify retained values/configuration |
| Presentation | Responsive layout, keyboard operation, labels and useful loading/error/read-only states |

Use generated source maps and browser/Ember tooling for runtime diagnosis. Breakpoint a rule in `execute`, not an insertion hook. Investigate summary failures through the documented `support/logs` category `Instance | Summary find(Query)`. Do not convert failures into a successful empty list or zero tile.

For a substantive change, update [CHANGELOG.md](../../CHANGELOG.md) and current addon documentation with behaviour, affected identifiers/files, settings/value compatibility, checks performed, limitations and any publishing or migration steps. Keep “syntax checked”, “compiled”, “runtime tested” and “published” distinct. This guide itself was assembled from supplied material and static source review; runtime integration checks remain deployment-specific.

## 14. Future addon contracts and remaining limits

The process/page packages propose trusted, version-matched addon settings schemas as a future capability. They do not implement an addon registry or side-loading protocol. A future contract could identify an exact runtime type and its settings schema, stored value shape, supported references, filter participation, dependencies and migration rules. Validate the common envelope first and then a trusted matching addon contract.

An unknown addon must remain distinguishable from a known addon with invalid settings. Preserve opaque settings and report incomplete coverage; use the confirmed page-widget warning policy and the explicit host policy for fields/rules. Do not bypass known checks via an opaque fallback or add proposed registry metadata to saved process/page JSON. [P §12; Q §17]

Remaining boundaries include the exact installed service/helper/library inventory, full custom connector contracts, authentication timing for the uploader, private-upload semantics, widget update propagation, extension v2 publish behaviour, and current runtime verification of each example. Resolve those from the target implementation when a task depends on them. Do not invent new hooks, commands, registry endpoints or automatic rollback behaviour.

## 15. Source register

| Code | Supplied source | Main evidence |
| --- | --- | --- |
| F | `field-widget.md`, “Field widget development” | Four modes, hooks, values, notifications, settings validation, child fields, async integrations and corrected upload patterns |
| R | `rule-widget.md`, “Rule widget development” | Runtime context, execute completion/error semantics, field APIs, settings validation, table processing and scheduling |
| W | `page-widget.md`, “Page (Dashboard) Widget Development” | Host/model, settings branch, refresh/filter behaviour, query identities, lifecycle, navigation and dependencies |
| S | `summaries(1).md`, “Summaries API” | Server/client query distinction, projections, indexing, permissions, conditions, pagination and aggregates |
| U | `upload-public-file(1).js` and `upload-public-file(1).hbs` | Existing application-specific field implementation; limitations reviewed in section 11 |
| P | `kianda-process-schema-v1.1.0(1).zip`: `process-knowledge.md`, `kianda-process-schema.json` | Process envelopes, type prefixes, references, table scope, current styling keys and extensibility limits |
| Q | `kianda-page-authoring-v1.0.0(1).zip`: `page-knowledge.md`, `kianda-page-schema.json` | Page envelopes, conditions, field types, filter contracts, custom-column contexts and V1 authoring policy |

The `(1)` suffixes identify the uploaded source filenames and have no runtime meaning. The intended installed schema names are `process-schema.json` and `page-schema.json`. Sibling links assume the complete knowledge set exists under `docs/kianda/`; the source developer guides and reference implementations need not be duplicated into that directory for these links to work.
