# Kianda application model for AI agents

**Document version:** 1.0.0  
**Prepared:** 27 October 2026  
**Intended location:** `docs/kianda/general.md`  
**Audience:** AI agents creating, editing, reviewing or explaining applications in a Kianda workspace.  
**Baseline references:** Process authoring package 1.1.0; page authoring package draft 1.0.0; the supplied field, rule and page widget developer guides and Summaries API reference.  
**Validation status:** Source-based documentation. This document does not certify a target workspace, run its applications or establish new platform capabilities.

Kianda applications combine process definitions, runtime instances, pages, reusable components and workspace resources. An agent must understand which of these it is changing before choosing a file, model or API. Editing a design, changing a field in an open instance, querying a summary and publishing a component are different operations with different effects.

The exported workspace contains Kianda process/page JSON, Ember component source and global JavaScript/CSS. It is not necessarily an independently buildable Ember CLI or npm application. Inspect the available tooling before running build commands; do not invent package scripts, replace the platform with another framework or add standalone application scaffolding to satisfy a Kianda configuration task.

This guide provides that shared application model and a practical authoring workflow. Use the specialised knowledge files and schemas for exact serialized contracts. Instructions labelled **Authoring practice** are recommendations for producing reliable applications; they do not add properties, defaults or capabilities to Kianda.

## 1. Start here

Before a substantive change:

1. Read the applicable workspace [AGENTS.md](../../AGENTS.md), the user's task and relevant product specifications.
2. Identify the application artifacts affected: process definitions, pages, custom addon source, global JavaScript or global CSS.
3. Read the relevant specialised guide from the table below. Inspect the actual workspace definitions and dependencies before resolving names, field types or components.
4. Distinguish the intended business behaviour from an existing example's incidental values, identities, captured selections and tenant-specific configuration.
5. Implement the change within the installed runtime and available component contracts. Preserve unrelated data and settings.
6. Validate structure, dependencies and runtime behaviour as separate activities. Record what was actually checked and what remains unverified.
7. Update the change record and current documentation required by the workspace. Report implementation and publication status separately.

| Work | Required reference |
| --- | --- |
| Processes, forms, fields, rules, mappings or reusable process Components | [Process knowledge](./process-knowledge.md) and [process schema](./process-schema.json) |
| Pages, widgets, queries, filters, navigation or custom list-column templates | [Page knowledge](./page-knowledge.md) and [page schema](./page-schema.json), plus the actual supplying processes |
| Custom field, rule or page widgets | [Custom addon knowledge](./custom-addon-knowledge.md), the installed component source and its settings contract |
| Layout, styling, visual hierarchy or responsive behaviour | [CSS style guide](./css-style-guide.md) and the target workspace's stylesheet |
| Business-specific requirements | The relevant workspace specifications and existing application documentation |

The installation filenames above are the extension v2 layout selected by the workspace owner. The source archives call their schemas `kianda-process-schema.json` and `kianda-page-schema.json`; their installed names are `process-schema.json` and `page-schema.json`. A filename change does not change the schema version, dialect or contract. Preserve each schema's contents and identity when installing it under the selected name.

The page package explicitly describes itself as **draft 1.0.0**. The process package identifies **1.1.0** as the owner-adopted baseline. This overview does not change those statuses. (PROC, PAGE, WORKSPACE)

## 2. Workspace, application and product

A **Kianda workspace** is the context containing the processes, pages, installed custom components, shared assets and configuration relevant to an application. The supplied developer guides use the workspace's domain and authenticated context for its APIs. Resolve dependencies inside the actual target workspace; another customer's IDs, URLs, principals or installed addons are not portable defaults.

An **application** can span several process definitions and pages. There is no one-process-to-one-page requirement. For example, one process can support a personal task page, a management overview and a detailed reporting page, each with different queries and actions. A page can also combine data from several processes. (PAGE §§2–3; SUMMARY §§2–3)

A **product**, such as EHSwise or an ESG application, adds business terminology, reusable processes, branding and operating conventions on top of Kianda. The existence of a field name, component or process in an EHSwise export does not make it compulsory in every Kianda application. Names such as `processSubject`, `processProjectCode` and `processCustomID` are application conventions in the supplied material. Likewise, product-specific asset hierarchies or a component called `workspaces` must be inspected as actual dependencies; they are not established here as universal platform primitives. (PAGE §3.2; PROC §5; WORKSPACE)

**Authoring practice:** reuse an existing product's conventions when working within that product, while keeping its business model distinct from the platform contract. For a new application, choose consistent terminology and relationships deliberately rather than copying a sample's entire domain.

### Workspace files

| Location | Role |
| --- | --- |
| `processes/**/*.json` | Complete process definitions, including reusable Component definitions where present |
| `pages/**/*.json` | Complete page definitions and their widget configuration |
| `components/` | Custom component source; the documented layout has `fields/`, `rules/` and `widgets/` subfolders with JavaScript and Handlebars files |
| `js/app.js` | Workspace global JavaScript and any locally defined helpers |
| `styles/app.css` | Workspace global styles, including local overrides and dependencies |
| `docs/kianda/` | Installed platform knowledge and schemas |
| `specs/` | Application requirements when this folder is present |
| `AGENTS.md` | Workspace operating instructions and reference routing |
| `CHANGELOG.md` | Change documentation under the workspace's chosen convention |

Search the application directories recursively. A grouping folder is not a process identity or page route. Resolve identities from JSON, not just filenames. Use the component layout actually exported by the extension; do not invent registration files or commands that are not present. (PAGE §3.1; WORKSPACE)

## 3. Core concepts and their responsibilities

| Concept | Meaning | Key distinction |
| --- | --- | --- |
| Process definition | The configured application design: forms, recursive fields, rules, settings and related configuration | Defines the application; it is not one submitted business record |
| Form | A process-owned collection of fields and associated workflow/presentation configuration | A process may contain several forms, including utility forms |
| Field | A model used for inputs, static content, buttons, panels, dialogs, tables, groups and other controls | A field can contain child fields and rules; it is not always a scalar input |
| Rule | A configured action attached to a process, form or field | Its action, conditions and position determine part of the workflow |
| Process instance | An individual runtime business document using a process design | Its data and lifecycle are separate from the design's identity and version |
| Page | A widget-based surface for finding records, viewing results and opening applications | Saving page configuration does not update the records displayed on it |
| Page widget | A placed component with its own ID, settings and presentation | Several placed widgets can use the same implementation |
| Summary | A selected projection or aggregate over indexed instance data | Editing a returned summary object does not save an instance |
| Reusable process Component | A process-shaped definition with `type: "Component"` and exactly one form | Reuses configured form content through a native component field |
| Custom addon | A JavaScript/Handlebars implementation for a field, rule or page widget | Extends implementation behaviour; it is different from a reusable process Component |
| Data source | A configured source used by supported controls, rules or widgets | Its identifiers and query branch must be resolved from the workspace |

These distinctions come from the process and page contracts and developer guides. Do not merge their schemas into a single universal model. For example, a page query is not a process rule, and a page field selector is not a newly defined form field. (PROC §§3, 6, 8–11; PAGE §§5, 8–10; FIELD “How a field widget works”; RULE “How a rule widget works”; WIDGET §1; SUMMARY §1)

### Process containment

The supported design tree is a root process with `forms[]` and optional root `rules[]`; each form has `fields[]` and may have `rules[]`; fields can recursively contain `fields[]` and attached `rules[]`.

A process must contain at least one form. A reusable Component definition must contain exactly one. The supplied bare-app example includes a textbox, a button and Save/Close rules, but its contents are an example rather than a new universal minimum field count. (PROC §§2–3)

Traverse actual entity collections. A property called `fields` inside `settings` can contain references or component data. In particular, a group field's `settings.fields[]` refers to existing fields; it does not define cloned child entities. A field picker or mapping can similarly store a descriptor rather than a complete field. (PROC §§3, 8, 10)

## 4. Design state, runtime data and persistence

The same conceptual field can appear in a design and in an active instance, but those contexts have different purposes. Component configuration belongs in the appropriate `settings` object. Captured data belongs in the runtime models and supported value representation. Do not copy example business values into a new design unless an intentional, supported default is being authored.

| Operation | Effect established by the supplied sources |
| --- | --- |
| Edit a local process/page JSON file | Changes that local definition; remote synchronisation depends on the active extension workflow |
| Update a custom component through Kianda's Developer interface | Compiles/updates its implementation through the documented Developer workflow |
| Edit a placed widget's settings and save the page | Persists page/widget configuration, independently of the reported instances |
| Change a runtime field's `value` or `text` | Changes the current instance model; normal persistence is handled by a Save rule or surrounding commit workflow |
| Execute a custom rule | Performs its configured action; model changes normally depend on the process save workflow, while external actions may take effect immediately |
| Query summaries | Reads indexed projections or aggregates; it does not mutate the underlying instances |

The supplied materials do not establish all **extension v2** save, rename, delete, conflict-resolution or publication behaviours. Read the current extension/workspace instructions before relying on such behaviour. Do not interpret writing a JSON file as proof that the remote application was saved, published or tested. (FIELD “How a field widget works”, §3; RULE “Execution and persistence”; WIDGET §1; SUMMARY §1; PAGE §§2, 14)

### Field updates and business rules

Field widgets keep the field model consistent with user input. The developer guide distinguishes readable `field.text` from potentially structured `field.value`; their meanings depend on the field type. Value changes can trigger attached rules. A widget author must use the documented update/notification behaviour and avoid unwanted rule loops. Full mechanics belong in [custom addon knowledge](./custom-addon-knowledge.md). (FIELD §§2–4)

### Rule execution is not an implicit transaction

The rule developer guide establishes that `execute()` is the custom rule's runtime entry point. The engine waits for its returned Promise, ignores its return value and **continues subsequent rules after a thrown error or rejected Promise**. A failing rule must therefore not be assumed to prevent a following Save, notification or navigation action. Design explicit conditions around outcomes when later actions depend on success. Preserve rule order and inspect the actual workflow. (RULE “Execution and persistence”, §6)

An upload or service request may have already changed an external system even if the process instance has not been saved. Treat those effects separately in design, testing and change reporting. The supplied public-file-upload field widget is one concrete integration example; its implementation and limitations are covered in the addon guide. (FIELD introduction; RULE “Execution and persistence”; UPLOAD)

## 5. Identities, names and references

| Identity | Required handling |
| --- | --- |
| Process alias | Readable process identifier; `id` and `name` are aliases. Preserve accepted historical omission of root `id`; when both exist, check equality. Never substitute a form/field GUID. |
| Page alias | For new complete pages, emit equal readable non-GUID `id` and `name`; verify workspace uniqueness. |
| Form, field and rule IDs | GUID entity identities. Preserve on edits; allocate for genuinely new entities. |
| Placed page widget ID | GUID identity independent of its component type and title. |
| Custom component identifier | Selects an implementation, for example `client-widget/<component-id>`; reuse the installed implementation's exact identifier. |
| Runtime instance identifier | Use the instance identity supplied by its runtime/API contract. For a summary result, use `Summary.name`; it is not necessarily a GUID. |
| Query/group/condition IDs | Follow the contract of the specific model and editor surface; do not assume all ID-bearing objects have one global rule. |

A title is a display label. Renaming a field title does not require changing its logical name or ID; renaming a page title does not require changing its route. Repeated page widget titles are permitted and do not identify connection targets. (PROC §4; PAGE §§4–5; SUMMARY §4)

### Field-name scope

The accepted process guide makes a precise distinction:

- A field inside a table row is checked against **all fields in that row**, including descendants of panels or other containers. Corresponding fields in different rows may share a name.
- A field outside any table row is checked against **all fields in the process**, including fields inside rows.
- A reusable Component does not create an independent name namespace merely because it is a Component.

Do not reduce those rules to immediate-sibling uniqueness or globally reject valid repetitions between rows. Resolve ambiguous references with their containing process, row and parent context rather than choosing the first matching name. Deeper nested-row resolution and some identity scopes remain subject to the detailed process guide's limits. (PROC §4)

### Descriptors refer to something

A descriptor's `type` identifies the kind of reference; `fieldType` may identify the referenced field's implementation. For page process-field bindings, copy the real field's outer `type` into `fieldType`, and preserve its exact `name`. Punctuation and casing can be meaningful: a name containing `?` is still a field name and must not be truncated as though it were a URL. (PAGE §§3, 8; SUMMARY §5)

Not every descriptor stores identity in the same key. The confirmed scheduled-rule target stores the target rule GUID in `name` when `type` is `rule`, with parent context. A field descriptor may identify a logical field name instead. Use the action-specific contract. (PROC §§9–11)

**Authoring practice:** build a dependency index before renaming or cloning. Include real entities, field selectors, mappings, expressions, tokens, process/page aliases, widget connections, container names, custom templates and relevant CSS/DOM selectors. New internal entities need new identities and rewritten internal references; references to external processes, principals, files or components need resolution rather than automatic GUID replacement.

## 6. Compose the business application deliberately

The following are **authoring practices**, grounded in the available Kianda models. They are design guidance rather than additional process types or server rules.

### Reference data and transactional records

Use a clear distinction between relatively stable reference records, such as suppliers or locations, and transactional records, such as requests or inspections. Both can use ordinary process definitions and instances. This distinction does not introduce a new root `type` value such as `Reference` or `Transaction`.

When a process stores a reference to another record, identify the supported selection and mapping mechanism and the intended stored value. Decide whether displayed text should reflect current reference data or a captured value at the time of the transaction. The actual control/rule contract determines what can be authored; do not infer automatic relationships, cascade updates or deletion behaviour.

### Tables and separate related records

| Requirement | Design consideration |
| --- | --- |
| Repeating details share one parent document's lifecycle | A native table may fit; retain row entities, scope and supported row operations. |
| Each child needs independent ownership, status, lifecycle or direct reporting | Consider a separate process/instance relationship using a verified pattern. |
| A dashboard must search or aggregate a table cell | The documented Summaries API cannot address table contents. Choose an explicit reporting design rather than inventing a table query. |
| A custom field stores a structured object | Its `field.text` is searchable; arbitrary nested value properties are not independently indexed. |

If separately stored summary totals or reporting fields are required, specify how supported rules maintain them and how correctness is checked. Do not assume that duplicating a value creates an automatically synchronised projection. (PROC §8; SUMMARY §1)

### Start with supported native behaviour

Prefer native fields, layout containers, rules, lists, filters, tiles, charts and navigation when they express the requirement. Use custom addons for a defined capability gap or an established reusable implementation. Inspect existing dependencies before creating a duplicate component.

This is a maintainability recommendation, not a prohibition on custom code. A new addon also creates a settings contract, lifecycle, compatibility requirements and testing obligations; its source and its usage must be documented together.

### Reusable process Components and custom addons

A reusable process Component has `type: "Component"` and exactly one form. A parent `fields/field-component` references that Component's process ID through `settings.componentId`. The platform loads the first form's content and stores the referenced Component's `MajorVersion` in the field's `settings.version`. Preserve the supported loading/upgrading model; do not simulate it by blindly copying expanded descendants. Details of descendant identity upgrades and local override preservation remain unresolved in the source. (PROC §8)

Custom field, rule and page widgets instead use implementation identifiers such as `client-field/<component-id>`, `client-rule/<component-id>` and `client-widget/<component-id>`. Their settings belong to the placed field, rule or widget. One implementation can support many independently configured uses. Resolve installed source and dependencies before introducing a new reference. (PROC §12; PAGE §§3, 7; WIDGET §1)

## 7. Pages and reporting follow the process model

Design a page around a user's task: find work, submit a record, inspect a result or analyse a trend. Establish the supplying processes and actual field types before authoring the page bindings. Cross-process views require compatible meanings and types; matching field names alone are insufficient. (PAGE §§2–3)

Native pages use an ordered widget array. Named containers are declared separately in `page.settings.containers[]`; a widget selects one through `settings.container`. Widget `class` controls the documented responsive layout, while `customCssClass` adds styling. A native list with a custom HBS column remains a native list widget. Its template is not a separately installed custom page widget. (PAGE §§5–6, 11)

### Summary data is a projection

The Summaries API returns selected indexed instance data for lists, tiles and charts. Text, numeric and date representations support corresponding search, sorting and aggregation. Fields outside tables, including fields inside panels and dialogs, are indexed. Table contents and arbitrary nested custom-field properties are outside the documented search coverage. (SUMMARY §1)

Indexing is asynchronous after an instance update. A successful save and a refreshed summary are separate events; a dashboard can briefly show earlier indexed values. Use an instance result or retrieval when immediate saved-document confirmation is required, and refresh the reporting view appropriately. Do not promise a fixed indexing latency. (SUMMARY §1)

For raw REST list responses, the body is an array and the count is in the `total-items` response header. Widget-store metadata and caching behaviour are a client integration layer, not a different server envelope. Use `Summary.name` for instance operations: `Summary.id` can contain a widget-specific suffix, and splitting it is unsafe. Full request construction belongs in the Summaries and addon references. (SUMMARY §§4–5, 8, 12)

### Filters and navigation have distinct responsibilities

Author a new filter's relationships in `settings.connections`. Selected values, `filterId` tags and incoming copies materialised on target widgets belong to runtime state. Preserve independent fixed predicates and unrelated existing state; do not generate captured selections as portable defaults. Defaults are applied before query-string values, which take precedence on render. (PAGE §10)

Filter connections and tile/chart drill-down connections are separate mechanisms. Connecting a tile to a list does not establish that the tile inherits every list filter. Specify the intended effect of each filter on each target. A custom reporting widget must implement the documented refresh/query behaviour to participate. (PAGE §§7, 10; WIDGET §6)

Native Link items use `type: "process"`, `"dashboard"` or `"external"`, with a `target`. Preserve URL parameter relationships and actual destination aliases. Do not confuse navigation hiding or client-side visibility with access control. (PAGE §§12–13)

## 8. Keep surface-specific contracts separate

These distinctions reconcile statements across the supplied guides without rewriting the specialised contracts.

| Topic | Correct boundary |
| --- | --- |
| Relative dates | Saved page configuration retains relative operators and omits newly invented `date1`/`date2` boundaries. A widget prepares a copied request at refresh time; an external REST client prepares appropriate UTC boundaries itself. |
| Query identities | Saved page query groups and individual page conditions require GUIDs. Readable IDs or omitted condition IDs in illustrative raw API requests do not relax that page authoring requirement. Process direct-rule groups and known settings-level query-filter groups require GUIDs, but individual-condition ID requiredness remains unconfirmed in both process contexts. Follow the process contract without extending the page requirement to it. |
| `processSource` and `isPartner` | Historical page/widget settings can be preserved during unrelated edits. The Summaries reference says to omit these deprecated properties from new Summaries requests. |
| Query scopes and aggregates | A generic API or custom widget can support options not documented for a particular native widget's configuration UI. Follow the exact component contract when authoring native settings. |
| Rule errors | The rule developer guide supplies the continuation/Promise behaviour that the process guide previously left unresolved. Apply it to custom rule execution; do not infer a general transactional rollback mechanism. |
| Layout keys | Process fields and placed page widgets use `class`, with separate `customCssClass`. These are field/widget properties, not process/page root properties. Other contexts can legitimately use `cssClass`; do not perform a global key rename. |
| Versions | A documentation version, JSON Schema version, process design version, Component `MajorVersion` and instance version are different values. Do not substitute one for another. |

Sources: PROC §§4–5, 9–10, 14; PAGE §§5, 9–10, 16; RULE “Execution and persistence”; SUMMARY §§3, 6–7, 12; WIDGET §§6–7.

## 9. Runtime compatibility and presentation

The supplied page developer guide targets Ember 2.18; the field and rule guides use classic `Ember.Component.extend` modules and Handlebars. Use the existing runtime and verified helpers. Do not introduce newer Ember component conventions, a new Bootstrap version or an assumed external package merely because it is common elsewhere. (FIELD introduction; RULE introduction; WIDGET §§1–2)

The three addon types have different runtime contracts:

| Addon | Primary responsibility |
| --- | --- |
| Field | Render the appropriate field view and maintain field data; manage its own asynchronous UI work. |
| Rule | Execute a business action through `execute()` using saved configuration and runtime context. |
| Page widget | Render content and load/query data; manage its own asynchronous refresh state and errors. |

A rule's settings template is not rendered during execution. The page/filter bridge does not await a custom widget's `actions.refresh`. Refer to the addon guide for lifecycle, cleanup, configuration validation and concurrency details. (RULE introduction; WIDGET §§2, 6, 8)

IndexedDB-backed cache behaviour is documented for summary records. Visibility settings such as `offlineVisible` control presentation, not offline data completeness. Verify each required offline scenario rather than inferring that a displayed widget, external request or custom upload will work without connectivity. (SUMMARY §§4, 12; PAGE §5.2)

Branding is part of the application design. Apply the owner's Material Design principles—clear hierarchy, intentional whitespace, responsive composition and consistent typography—through verified Kianda components and the installed Bootstrap 3 styling environment. This does not imply a Material component package is installed. Inspect local CSS and overrides, and use the [CSS guide](./css-style-guide.md) for class/configuration recipes and evidence limits. (PROC §§2, 14; PAGE §§2, 6)

## 10. Security and external dependencies

The Summaries endpoint applies instance permissions to list results and to records contributing to aggregates. `queryType: "all"` means all matching accessible records, not unrestricted access. A hidden field remains a presentation setting rather than field-level API security. (SUMMARY §§1, 3)

The page guide distinguishes page-load restrictions from presentation restrictions. Page `visibleTo` controls the documented page access restriction; widget `visibleTo`, Link `users`, hidden navigation and CSS cannot protect downloaded data or model content by themselves. Empty restriction arrays mean that additional restriction is unconfigured; they do not establish anonymous access. (PAGE §13)

The installed page-authoring **V1 policy leaves new principal assignments unconfigured** and requires an administrator handoff for role-sensitive applications. Preserve existing restrictions on unrelated edits. The VS Code extension's version number does not itself supersede this authoring policy; a newer verified principal-discovery/assignment contract is needed before changing that scope. Likewise, preserve existing Chart v2 definitions, but do not author new Chart v2 widgets under the current page package. (PAGE §§1, 7, 13, 16)

Resolve data sources, installed components, files, helper functions, URLs and principals from the target workspace. A schema accepting a reference does not prove that the dependency exists, is accessible or has the intended behaviour. Preserve unknown settings and identify coverage gaps. Page-widget unknown-settings warnings are explicitly established; apply the process guide's separate handling for unknown field/rule contracts. (PROC §§11–12; PAGE §§3, 7, 17)

## 11. Validation, change records and handoff

### Validate in separate layers

| Layer | Check | Claim allowed after success |
| --- | --- | --- |
| Parsing and schema | Strict JSON; appropriate Draft 2020-12 schema; required shape, exact wire types and known settings; configured format checks | The checked document conforms to those structural assertions |
| Semantic/integrity | Scoped identities and names, aliases, ownership, references, component availability, mappings, queries, templates and dependencies | The specific checked relationships are consistent with the available evidence |
| Runtime and visual | Actual compilation, data, rule outcomes, filtering, navigation, permissions, layout, keyboard use and required offline scenarios | The scenarios actually exercised behaved as recorded |

Both supplied schemas use Draft 2020-12. Do not rely on value coercion, insertion of defaults or removal of unknown properties during validation. An open settings object permits extension compatibility; it does not make an invented key operational. Some supplied legacy exports contain known problems, and a regression suite can correctly pass by rejecting an invalid fixture. Consult the package reports when interpreting recorded results. (PROC §§12–13; PAGE §16; package READMEs)

### Document completed work

For each substantive task, follow the root completion policy and update [CHANGELOG.md](../../CHANGELOG.md) or its designated change-record location. Record:

- The requirement or defect and the resulting behaviour.
- Important changed artifact paths and dependencies.
- Validation actually performed, with outcomes and relevant limitations.
- Required configuration, migration, runtime verification or publication steps.
- Any material unresolved contract or administrator security handoff.

Update current application/addon documentation when the behaviour or settings contract changes. A history entry explains a change; the maintained documentation should explain the current application directly. Keep diagnostics, task notes and transport metadata outside persisted process/page JSON.

Writing files, publishing them, saving instances, validating schemas and testing runtime behaviour are separate completion claims. State each only when supported by the work performed. (PAGE §§2, 14, 16; WORKSPACE)

## 12. Evidence and remaining limits

Use the following evidence categories when maintaining this guide:

- **Confirmed/documented:** an explicit owner clarification recorded in the supplied knowledge packages, or a stated contract in the supplied developer documentation.
- **Observed:** a representation or implementation in a supplied example. It does not establish universal defaults or correctness.
- **Authoring practice:** a recommendation in this guide, identified as such.
- **Unresolved:** a detail that needs current implementation or target-workspace evidence.

The most relevant remaining limits are extension v2 synchronisation/publication details; exact alias alphabets and reserved names; some nested-row/reference scopes; Component upgrade identity/local-override behaviour; complete installed addon/helper registries; detailed offline behaviour; and target-workspace rendering and effective permissions. Keep the more precise limits in the process, page, addon and CSS guides. Do not treat an uncertainty in one area as permission to reopen an unrelated confirmed contract.

When sources appear to conflict, first check whether they describe different surfaces, versions or phases. Preserve the specific authoring contract and identify the discrepancy with file/section references. A newer source describing an API request must not silently rewrite a saved page schema, and an old example must not broaden a confirmed setting enum.

### Source register

| Label | Supplied source | Role |
| --- | --- | --- |
| PROC | `kianda-process-schema-v1.1.0(1).zip`: `process-knowledge.md`, `kianda-process-schema.json` and README | Process entities, identities, settings, reusable Components, design requirements and validation boundaries |
| PAGE | `kianda-page-authoring-v1.0.0(1).zip`: `page-knowledge.md`, `kianda-page-schema.json` and README | Page model, bindings, filters, navigation, V1 scope, permissions and runtime limits |
| FIELD | `field-widget.md` | Field-widget responsibility, model updates and persistence boundaries |
| RULE | `rule-widget.md` | Custom rule execution, async completion, error continuation and persistence |
| WIDGET | `page-widget.md` | Page-widget implementation/configuration distinction, shared settings, filters and refresh behaviour |
| SUMMARY | `summaries(1).md` | Indexed data, table/custom-field limits, permissions, identities, date preparation, pagination and caching |
| UPLOAD | `upload-public-file(1).js` and `upload-public-file(1).hbs` | Supplied integration example; detailed treatment belongs to the addon guide |
| WORKSPACE | Owner's extension-v2 file layout and workspace instructions in this authoring request | Intended locations, shared documentation purpose and change-record requirement |

References to original source filenames are provenance labels, not a requirement to install those source archives beside this document. The sibling guides and schemas linked above are the working reference set. This guide intentionally avoids copying tenant principals, business records or private source-workspace URLs into reusable examples.
