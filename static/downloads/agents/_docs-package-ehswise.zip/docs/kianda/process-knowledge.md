# Kianda process-app authoring knowledge

**Version:** Accepted v1.1 (`1.1.0`) · **Updated:** 23 October 2026  
**Documentation revision:** Branding guidance 1; schema remains `1.1.0`.  
**Companion schema:** [process-schema.json](./process-schema.json), identifier `urn:kianda:process-schema:1.1.0`.  
**Audience:** An AI agent creating, updating, or improving complete Kianda process definitions in JSON.  
**Scope:** Process, forms, recursive fields, rules, conditions, descriptors, mappings, and their relevant settings.

This guide combines the owner's latest answers, `kianda-process-schema.md`, five EHSwise exports, the supplied bare-app example, the internal process-app styling guide, and its visual example. Branding is a core authoring requirement: use the directive in §2 and the practical guidance in §14 alongside the structural contracts. No process was executed in Kianda during this analysis.

The owner adopted `kianda-process-schema.json` as the first version; v1.1.0 incorporates the follow-up confirmations of 23 October. The earlier Json.NET-generated schema mentioned by the owner and the older schema inventory in the handoff remain historical context; no comparison against those actual schema files is claimed. The latest owner answers supersede conflicting earlier statements, including the missing-`hasElse` default, query-filter group identity, scheduled-rule references, and generated table-row names. Schema acceptance does not certify application behaviour.

## 1. Evidence and precedence

Use these labels when interpreting or extending this reference:

| Label | Meaning | How an authoring agent should use it |
| --- | --- | --- |
| **Confirmed** | Explicit platform-owner statement in the handoff or latest follow-up. | Apply the latest statement when earlier evidence conflicts. |
| **Documented** | Current internal guidance supplied by the owner, including the styling guide. | Follow its stated purpose and configuration; distinguish UI labels from JSON keys and account for workspace overrides. |
| **Observed** | Structure or value in the supplied exports, explicitly corrected bare-app fixture, or visual example. | Preserve existing serialization; a screenshot establishes appearance only. Do not assume every observation is universally correct or required. |
| **Historical** | An older schema declaration or older example described in the handoff. | Compare with current evidence; do not silently apply old assumptions. |
| **Proposed** | A recommended authoring or validation policy. | Identify it as a policy choice, not deployed platform behaviour. |
| **Unresolved** | Requires current model, serializer, component, or runtime evidence. | Preserve data and report the gap instead of inventing a contract. |

Portable source references used below are:

- **H:** `kianda-process-schema.md`, using its numbered sections. H records owner statements as U1–U5 and distinguishes them from the historical P0 schema and P1–P3 examples.
- **C2026:** Owner follow-up of 22 October 2026 accepting this work as v1 and clarifying table-row name scope, the number-setting bug, string settings/defaults, condition-group GUIDs, current `class` styling, runnable rule configuration, and Component loading/versioning. Those confirmations are recorded in the relevant sections below.
- **C2026-23:** Owner follow-up of 23 October 2026 confirming the server's boolean `hasElse` default of false, GUIDs for query-filter groups edited through `rules/rule-conditions`, a scheduled-rule target descriptor, and the code used to generate row names. These answers supersede the corresponding unresolved points in v1.0.0.
- **CB:** Owner branding request of 23 October 2026: professional, authoritative and clean process apps, applying Material Design principles, clear hierarchy, whitespace, responsive layouts and consistent typography.
- **B:** `Kianda Process Apps Styling Guide.docx`, supplied internal developer guidance. Its class table spans rendered pages 1–2; page 3 discusses global `app.css` and workspace overrides.
- **BV:** `branding example.png`, supplied screenshot. It is visual evidence, without the app JSON, stylesheet, computed styles or interaction states.
- **A:** `action.json`.
- **E:** `event.json`.
- **I:** `incident.json`.
- **IN:** `inspection.json`.
- **O:** `observation.json`.
- **S:** Original `simple-app.json`, supplied by the owner as a bare app. The uploaded bytes are not valid JSON: a comma is missing after the second button rule's `elseSettings: {}`.
- **SC:** `fixtures/simple-app.syntax-corrected.fixture.json`, the explicit derivative with that one missing comma added. The source S is unchanged. All bare-app JSON Pointers below refer to SC; the correction is syntax repair, not a runtime test or an application redesign.
- **ST:** `fixtures/schedule-rule-target.owner-example.json`, the exact target descriptor from C2026-23. The surrounding chat excerpt is an illustrative partial scheduling rule, not a newly supplied valid full app; it omits an outer rule ID and includes a trailing comma.

Pointers such as `A /forms/0/fields/1` identify objects in these exact snapshots. File versions matter: the current Incident and Observation exports differ from the older examples described by H. Use current-source pointers rather than reusing historical positions.

The new corpus contains:

| Source | Forms | Recursive fields | Rules | Rule condition groups | Rule conditions |
| --- | ---: | ---: | ---: | ---: | ---: |
| A | 4 | 122 | 110 | 53 | 58 |
| E | 4 | 169 | 117 | 62 | 77 |
| I | 12 | 385 | 264 | 144 | 174 |
| IN | 6 | 209 | 181 | 92 | 115 |
| O | 4 | 167 | 134 | 78 | 93 |
| **Total** | **30** | **1,052** | **806** | **429** | **517** |

These counts follow actual entity containment. Settings descriptors are excluded from field counts; settings-level query filters are excluded from rule-condition counts. The corpus has 1,034 direct rule-condition arguments, 35 process-attached rules, 771 field-attached rules, and no form-attached rules. Absence in this dataset does not remove supported model features.

## 2. Authoring responsibilities

Create a process definition, rather than a submitted business-record instance. Translate the requested workflow into forms, field trees, and ordered rules. Reuse verified component examples where appropriate, while checking their dependencies and preserving the distinction between configuration and captured values.

For an edit, change only the requested design and the references necessarily affected by that change. Preserve existing identities, logical names, array order, security configuration, arbitrary settings, and unrelated metadata. A display-title change does not require a name or ID change.

For a new process, allocate new GUIDs for newly created form, field, rule, and condition-group entities, including query-filter groups managed by `rules/rule-conditions`. Do not copy template principals, workspace URLs, audit users, timestamps, record values, or external dependency IDs as defaults. Use the confirmed Component loading model in §8; copying expanded trees without managing identities can corrupt references.

**Proposed workflow:** establish the design and dependencies, build an entity index, author the complete JSON, validate structure and known settings, then run specialized integrity and runtime checks. A schema pass is one stage of validation. Keep unresolved requirements explicit instead of filling gaps with plausible but undocumented properties.

### Core design directive for the authoring agent

The owner requires branding to be part of app design. Use this directive when creating or refining the interface; §14 translates it into documented Kianda classes, observed settings, composition recipes and review practices.

> You are an expert UI/UX designer and Kianda platform architect. Treat branding and usability as core requirements of every process application. Create professional, authoritative and clean interfaces that help people understand the workflow, make informed choices and complete tasks accurately.
>
> Apply Material Design principles through Kianda's native forms, fields, layout containers and reusable Components. Establish a clear visual hierarchy from the form's purpose to its sections, labels, guidance and actions. Use intentional whitespace, consistent typography, responsive layouts and restrained colour, surfaces and elevation. Make related apps feel like a coherent product while adapting their density to the task and screen size.
>
> Implement the design with verified Kianda settings and available workspace CSS classes. Preserve application behaviour, identities and valid serialization. Make actions, selection, validation and feedback easy to recognize and operate. Review the result on small and large screens and with keyboard interaction. Deliver interfaces that are cohesive, accessible, visually refined and effective in everyday enterprise work.

This directive translates the owner-confirmed design objective into proposed authoring instructions. Detailed composition and review recommendations in §14 are authoring policy; they do not add required properties to the JSON contract.

### The supplied bare-app example

C2026 identifies S as a bare app with one form, one textbox and one button. After the explicitly recorded syntax correction, SC contains one form, two fields and two button rules, ordered `rules/rule-save` then `rules/rule-close`. The textbox's settings are empty; the close rule omits `conditions`, and both rules omit `schedule` and `hasElse`. The textbox also omits a child `fields` array. These are useful omission/default fixtures; do not fill every missing historical model property simply to reproduce a verbose export.

The sample's empty settings do not prove that every native action or field can run without configuration. Its fixed identities, timestamps and values are source evidence, not defaults to copy into a new app. The malformed raw source must fail JSON parsing; only SC can proceed to schema validation. No claim is made that SC was executed in Kianda.

Sources: H §§1–4, 16–18; C2026; SC `/forms/0`, `/forms/0/fields/0/rules`, `/forms/0/fields/1`; new corpus containment and identity analysis.

## 3. Containment and model boundaries

The root process contains `forms[]` and may contain process-attached `rules[]`. **Confirmed in C2026:** a process must have at least one form; the server rejects a process with none. A definition with `type: "Component"` has exactly one form. Each form contains `fields[]` and may contain form-attached `rules[]`. A field can contain child `fields[]` recursively and attached `rules[]`. Inputs, buttons, panels, dialogs, tables, rows, static content, groups, and reusable wrappers all use the field model.

Recurse only through those **actual entity collections**. An arbitrary property named `fields` under `settings` may contain references or component data. For example, `fields/field-group.settings.fields[]` contains descriptors of existing fields, not newly defined child entities. Likewise, a settings object containing `field` is not necessarily a full field or an ownership relationship.

A field's outer model contains its identity, title, logical name, component type, flags, value/text, optional help/styling, relationships, descendants, rules, and settings. The selected component's options belong inside `settings`; a rule's settings belong to the rule, not its owning field.

**Observed:** actual entity objects, collections and settings hashes are non-null in all five exports; empty hashes occur. **Accepted v1 profile:** entity collections must be arrays and entity/settings nodes must be objects when present. Historical P0 allowed null construction states; those are outside this whole-document profile. Principal collections retain their separately defined compatibility rules. Missing, null, empty string, empty array and empty object remain distinct; validation does not fill omitted keys.

Sources: H §§3, 5, 8.1, 8.5, 10; C2026; A–O `/forms`, recursive outer `/fields`, and attached `/rules`; SC.

## 4. Identities, names, and edits

### Process identity

**Confirmed:** root `id` and `name` are aliases for the process identifier. They are normally a readable, dasherized name; they are not form/field/rule GUIDs. A title can suggest the identifier, but the user can override it. The exact allowed characters, case policy, reserved words, and normalization rules are not fully specified.

**Observed:** all five current exports contain equal root `id` and `name`. H's older three examples omitted root `id`. Preserve whichever accepted representation an existing document uses; do not insert a process GUID. When both aliases exist, an external integrity check must verify equality. Workspace alias availability also requires external context.

### Entity identity

**Confirmed:** forms, fields, and rules use GUID IDs unique within the process app. All 1,888 such entities in the current corpus have GUID-shaped IDs, and no app contains duplicate entity IDs. A descriptor repeating an entity's ID is a reference, not a duplicate entity.

Preserve IDs while editing. When cloning an entity subtree, assign new IDs to the new entities and rewrite references targeting those clones. Do not rewrite external-process IDs, principal IDs, datasource IDs, or reusable-template IDs simply because they resemble GUIDs. Keep rule `originalId` separate from current identity; its complete lifecycle semantics are unresolved.

**Confirmed in C2026:** direct-rule condition groups require GUID IDs because they are loaded as separate Ember Data models and need unique identities. **C2026-23 also confirms** that settings-level query-filter groups managed by the same `rules/rule-conditions` component need GUIDs for the UI to deserialize and edit them. This is a UI authorability requirement; the owner distinguished it from an intrinsic server requirement for those query filters. Supply GUIDs for new groups in these known models and preserve existing group IDs. V1.1.0 enforces their presence and GUID format in direct-rule groups and applicable known query-filter settings. Inactive alternate settings remain open (§9), so structural acceptance does not certify the UI readiness of every retained filter group.

Neither confirmation makes every individual condition ID mandatory. The exact uniqueness boundary for group IDs and cross-model collisions also remains unresolved. A conservative generation policy is to allocate fresh GUIDs for new groups and avoid reusing them within a document. Do not extend that policy into a claimed workspace-wide identity contract or apply group rules to arbitrary tenant settings objects.

### Logical names

Names are readable and typically camelCase; existing uppercase prefixes, underscores, hyphens, and `?` suffixes must be preserved. A title change must not automatically rename a field: expressions, mappings, tokens, and name-only references can depend on its name.

**Confirmed field-name scope in C2026:**

- A field inside a table row is checked against **all fields of that row**, including descendants of panels or other containers in the row. The test is not limited to immediate siblings. Corresponding fields in different repeated rows may share a name.
- A field outside any table row is checked against **all fields in the process**, including fields inside rows. Do not reduce that check to outside-row fields only.
- A reusable component does not acquire an independent name namespace merely because it is a component. Apply the table-row exception where it actually contains rows.

For example, A `/forms/3/fields/7/fields/12/fields/0/fields/0` and the corresponding second row field share a name in separate row scopes; that repetition is expected. Duplicates outside row scope require an integrity error rather than automatic renaming. The follow-up addresses **field** names: a form and field sharing a string is not thereby a proven violation. Keep form/field descriptor kinds separate when resolving references.

Resolve names together with IDs and context; never select the first match silently. C2026-23 confirms the internal row-name creation formula in §8. Parent tables can share a name in different outer rows, so their separate table instances can legitimately contain the same generated row name. Repetition alone is not an internal-row naming error; this resolves the earlier warning about I's repeated name in different table instances. This is separate from the four confirmed ordinary-field duplicate groups in E, I and O; deeper nested-name resolution still needs the correct containment context.

Sources: H §§4, 15, 16.2, superseded on field-name scope by C2026 and supplemented on row names by C2026-23; A–O `/id`, `/name`, and actual entity trees.

## 5. Process and form configuration

Keep display labels, logical identities, document versions, metadata, state, and security distinct. Root `version` is a process/design version; it is not the JSON Schema dialect or reusable-component version. Root `completed` is boolean. Form `completed` is a date-time string, with a separate `isComplete` boolean.

The current exports add root flags such as `deleted`, `rejected`, `publish`, `isDraft`, `allowNew`, and `isPartner`, plus integer `MajorVersion` and `MinorVersion`. Their presence is not permission to invent general defaults. C2026 establishes a specific version relationship for Components: a loaded component field's `settings.version` stores the referenced Component process's `MajorVersion`.

Root `type` distinguishes a normal process from a reusable definition with the exact value `"Component"`. Four EHSwise exports and SC explicitly use `"Process"`; I omits `type`. Preserve accepted omission in existing data. For a new Component definition, emit `type: "Component"` and exactly one form. Do not treat an arbitrary missing or unfamiliar type as proof of a Component.

Process settings include execution-order, navigation, comments, notifications, anonymous access, and other options. Representation varies by key: `keepRuleExecutionOrder` is a string in the examples, while `buttonDisplayFlag` is boolean. Preserve exact wire types. Anonymous access, deletion and notification options are consequential configuration and must be chosen deliberately for a new design.

Forms have GUID identity, logical name/title, fields, rules, process ownership, settings, workflow/presentation properties, and ownership/security state. Every current `/forms/N/process` matches the root process alias. Current forms omit historical properties such as `status`, `completedBy`, and `partnerHide`; the older handoff serialized them. Presence in one serializer generation is not universal requiredness.

`activateWith` references a **form name**, or can be empty/absent; older examples also demonstrate null. It is not automatically a GUID. `submitMode` values include `single` and `all`, but their complete semantics and exhaustive enum are not supplied. A populated `currentForm` contract is unresolved. Hidden utility forms remain part of the app and its reference indexes.

Form settings can include `allowEdit`, `allowReassign`, `enableActions`, `hideFooterButtons`, `allowOwnerEdit`, `enableRulesOnSave`, and custom-action configuration. User collections in settings can contain rich principal objects, unlike simpler ID arrays elsewhere. Field-reference options such as `customActionField` require semantic resolution. Empty form settings remain valid observed serialization.

Instance-ID templates, such as `customInstanceIDFormat`, can refer to field names. They are separate from the root process alias. Recurring EHSwise support fields are application conventions, not compulsory core properties. Preserve security fields and resolve principals through authorized workspace data; structural validation does not prove authorization.

Sources: H §§6–7; C2026; A–O roots, `/settings`, and `/forms`; SC; historical P0 descriptions in H §5.

## 6. Field catalogue and values

The catalogue is incomplete. Component availability and full settings contracts require the target workspace/runtime registry.

| Field identifier | Purpose and authoring distinction | Evidence |
| --- | --- | --- |
| `fields/field-textbox` | Single-line, multiline or rich-text input. | Confirmed; observed |
| `fields/field-number` | Numeric input/display. | Confirmed; observed |
| `fields/field-list` | Configured selection modes and data-bound choices. | Confirmed; observed |
| `fields/field-date` | Date/date-time input and defaults. | Confirmed; observed |
| `fields/field-toggle` | Toggle/checkbox-style control. | Confirmed; observed |
| `fields/field-userpicker` | User/group/principal selection. | Confirmed; observed |
| `fields/field-file` | File upload/access. | Confirmed; observed |
| `fields/field-image` | Image display; sources may be field descriptors. | Confirmed; observed |
| `fields/field-signature` | Signature capture. | Confirmed; observed |
| `fields/field-text` | Static/non-end-user-editable content, often HTML. | Confirmed; observed |
| `fields/field-button` | Action control with settings and/or ordered rules. | Confirmed; observed |
| `fields/field-panel` | Layout container with descendants. | Confirmed; observed |
| `fields/field-dialog` | Modal container with descendants. | Confirmed; observed |
| `fields/field-table` | Repeating structure containing row fields. | Confirmed; observed |
| `fields/table-row` | Internal row entity containing columns/containers. | Observed |
| `fields/field-group` | Mirrors existing fields through descriptors. | Confirmed; observed |
| `fields/field-component` | Loads the first form's contents from a referenced Component process. | Confirmed in C2026; expanded wrappers observed |
| `fields/field-subform` | Related-record management. | Owner-described; absent here |
| `fields/field-link` | Link field. | Owner-described; absent here |
| `client-field/<component-id>` | Tenant-defined implementation. | Confirmed; absent in current five exports |

`field.value` is polymorphic and often omitted. The current corpus has 158 values: 75 strings, 73 arrays and 10 integers. This is not an exhaustive allowed union. Tenant fields and other native modes can have different models. Do not force string values or add `value: null` everywhere.

Outer `showTitle`, `visible`, `enabled`, and `required` are booleans in the examples. A field's `required` controls application input; it does not mean every property on that field is required by JSON Schema. Many settings switches instead use `"yes"`/`"no"` strings. Never globally coerce these representations.

**Current owner correction in C2026:** `field.class` is the correct persisted layout property. Renaming it to `cssClass` was an aspiration, not the implemented behaviour; backward compatibility requires continued use of `class`. Generate layout classes in `field.class`, preserve existing values, and do not deprecate or silently rename this key. `customCssClass` remains separate additional styling. Existing `cssClass` data should not be deleted automatically, but it is not a confirmed replacement for `class`.

The observed 305 `class` values, zero `cssClass` values and 135 `customCssClass` values now align with that correction. Ten of the additional-class strings are empty. Bootstrap 3 responsive classes can be combined; do not require every sibling width to total twelve or move `settings.mobileClass` into an outer property. B documents seven process-field visual utilities normally used in `customCssClass`; see §14 for their component context, settings and evidence limits.

Sources: H §§8–9, superseded on `class` by C2026; A–O actual field trees and component/settings inventories.

## 7. Exact confirmed textbox and number settings

These contracts are supported by H §9 and C2026. Enforce known values **when present**. The configuration UI's availability rules do not establish serialized requiredness or prohibit retained inactive settings.

### Textbox

Discriminator: `field.type = "fields/field-textbox"`.

| Setting | Confirmed values or meaning | Serialization limit |
| --- | --- | --- |
| `textMode` | `single`, `multiple`, `richtext` | Some fields omit it or have empty settings. |
| `textStyle` | `""`, `field-text-capitalize`, `field-text-uppercase`, `field-text-lowercase` | Empty string is intentional. |
| `controlType` | `text`, `password` | Available in single mode; no proven presence/absence dependency. |
| `autofill` | `On`, `off`, `new-password`, `street-address`, `email`, `tel` | Preserve uppercase `On`; lowercase `on` is not a confirmed additional token. |
| `rows` | String captured by the settings textbox and passed to the textarea helper | Empty string selects defaults; exact bounds and accepted numeric syntax remain unproven. |
| `placeholder` | String | No requiredness or maximum length supplied. |
| `maxlength` | String captured by the settings textbox and passed to the input helper | `"100"` and `""` are supported examples; empty string selects defaults. |

Only 235 of 287 current textboxes serialize `textMode`. Current empty `rows` examples include A `/forms/3/fields/5/fields/9/settings/rows` and IN `/forms/4/fields/4/fields/1/fields/0/fields/0/fields/0/fields/2/settings/rows`. Do not lose these cases by translating “row count” directly into an integer-only assertion.

### Number

Discriminator: `field.type = "fields/field-number"`.

| Setting | Confirmed values or meaning | Dependency/limit |
| --- | --- | --- |
| `displayFormat` | `n` default; `#` integer; `c` currency; `p` percentage | Preserve compact tokens. |
| `currencyFormat` | `en-IE`, `en-US`, `en-AUS`, `ja-JP`, `en-GB`, `en-CA` | Available for currency; preserve literal `en-AUS` pending code confirmation. |
| `euroFormat` | `en-IE`, `pt-PT`, `fr-FR` | Available in the currency branch when currency format is `en-IE`. |
| `showArrows` | `yes`, `no` | Known conflicting historical/current values are not new enum members. |
| `nativeMobile` | `yes`, `no` | String representation. |
| `decimalPlaces` | String setting; explicit owner example `"0"` | Zero is supported; empty string selects defaults. Do not coerce to a JSON number. |
| `placeholder` | String | No requiredness supplied. |

**Confirmed wire/default behaviour in C2026:** `decimalPlaces`, `rows`, and `maxlength` naturally become strings because the settings editor captures them through textbox fields and forwards them to the relevant helpers. Empty strings mean defaults. Preserve strings and empty strings; do not coerce numeric-looking values. Exact numeric grammar, bounds and concrete default values have not been supplied, so the structural schema must not invent a digit-only or positive-only rule from the property names.

The current corpus has **11 `showArrows: "c"` conflicts**: three in I and eight in IN. Examples: I `/forms/9/fields/4/fields/6/settings/showArrows` and IN `/forms/1/fields/3/fields/6/settings/showArrows`. C2026 confirms a bug: `"c"` does not enter the exact `"no"` branch that sets `spinners=false`. That excerpt alone does not establish final spinner defaults. Generate only `"yes"`/`"no"`; report existing conflicts without expanding the enum or rewriting the apps.

Earlier assistant schemas requiring `rows`, `controlType`, `currencyFormat`, or `euroFormat` were proposals. Available UI controls can be defaulted, omitted, or retained after mode changes. Their runtime requiredness needs implementation evidence.

## 8. Other settings, tables, and reusable components

For manual lists, preserve exact keys such as `listsource`, `displayformat`, `radiodisplayposition`, `choices`, and `choicesValue`. Choices are newline-delimited strings in the confirmed example, not an invented array-of-objects format. `choicesValue` can remain present while `enableSeparateValues` is false. Data-bound lists add process/datasource descriptors, filters, mappings, sorting and limits; their references may belong to another process.

Tables contain `fields/table-row` entities whose children define columns and nested containers. Multiple row entities exist. A contains-two-rows example is A `/forms/3/fields/7/fields/12`. Do not flatten rows or enforce exactly one row. Table `pagesize` is lowercase and is currently an integer in 13 instances and a string in five. Preserve each wire representation; no universal coercion policy is established.

**Confirmed row-name creation rule in C2026-23:**

```javascript
var name = table.get('name') + '-row' + rowIndex;
```

For a new row, the logical name combines its containing table's name, the literal `-row`, and `rowIndex`. This does not derive a row's GUID. It also does not establish that indices start at zero or one, are contiguous, equal serialized array positions, or follow a universal numeric syntax. Obtain the correct index allocation when generating rows. Different table instances can produce identical row names when their table names repeat inside different outer-row scopes; retain that instance context.

**Observed limit:** all 19 current row entities are direct children of 18 actual table entities. Only one row name starts with its current table's name plus `-row`; 18 retain different prefixes. The cause of this difference is unproven. The creation formula therefore must not be treated as a proven invariant after table-name edits, and existing row names must not be automatically rewritten to match current parents. All current row names are unique within their respective table instances. Comparing parent names and row names is an external diagnostic with creation/edit context; the 18 prefix differences are informational observations, not newly proven naming errors.

Group fields mirror existing fields through `settings.fields[]` descriptors. They do not clone those entities and are not equivalent to panels. Validate their targets in the relevant local process scope.

### Creating and loading a reusable Component

**Confirmed in C2026:** create a normal process-shaped definition, set root `type` to the exact value `"Component"`, and give it exactly one form. That form's field contents are the reusable content. A parent app's component field loads the contents of the Component's first form during design or runtime into the component field. This remains the process/form/field model; no separate page or widget model is involved.

Set `field.settings.componentId` to the referenced **Component process ID**, not a wrapper GUID or the native identifier `fields/field-component`. The platform loads that Component and stores its `MajorVersion` in the field's `settings.version`. This is the referenced Component's major version, never the parent app's `MajorVersion` or a root `version` string. When the Component is updated, the server automatically upgrades it based on the version loaded.

For generation, create/resolve the Component dependency, ensure its one-form shape, and populate the parent field's correct `componentId`. Do not guess a version unrelated to the Component's `MajorVersion` or require hand-authored expanded children merely because exports contain them. Preserve an existing loaded subtree during unrelated edits. Ask the specialized tool to resolve/load/update dependencies through the supported mechanism rather than manually replacing loaded contents to simulate an upgrade.

Observed wrappers can also carry `componentName`, `componentLoaded`, and `hideShowComponent`; some panels carry similar metadata. These observations do not make every metadata key mandatory. Fine details of cloned descendant IDs, local customization preservation, and rule `originalId` during an upgrade still need implementation evidence; the confirmed automatic loading/version relationship should not be confused with those remaining details.

Other field settings remain incompletely specified. Date defaults such as relative `now` are configuration, not timestamps to replace during generation. Image/file sources can be descriptors. User-picker values can be principal collections. Button settings and ordered rule chains can both contribute behaviour. Preserve these structures and obtain component-specific evidence before imposing stricter rules.

Sources: H §§9.5–10, supplemented by C2026 on Component definitions/loading/versioning and C2026-23 on row-name generation; A–O field settings; current table and mapping inventories.

## 9. Rules: attachment, order, and settings

A rule's `action` selects its implementation. Its GUID is identity; `title` is descriptive. Do not invent a rule `name`. `originalId` is retained provenance-like data with incompletely specified lifecycle semantics. `datasource` is not necessarily a GUID: current examples include both GUID-shaped identifiers and a named token.

Process rules attach to root `rules[]`; field rules attach to the owning field's `rules[]`; form rules remain structurally supported. Current process rules serialize the process alias in `process`, and field rules serialize the owner GUID in `field`. Current `form` ownership keys are absent. Historical exports often retained null relationship keys. Do not require all three references or fill absent ones automatically.

Rule ordering matters. Preserve array order during edits, especially where the process configures `keepRuleExecutionOrder`. Saving, submission, closing, assignment, validation and navigation are separate operations. The exact asynchronous runner and error-stopping semantics require runtime evidence.

Outer `schedule` and `settings.task.schedule` are different locations. Only `default` is observed for the former in H, while `now` occurs in scheduled tasks; this does not create complete schedule enums. **Confirmed in C2026:** a schedule action requires a target field or rule. Resolve that target before treating the action as executable. Field targets are not limited to buttons; H §11.6 records a date-field target.

**Confirmed scheduled-rule target in C2026-23:** ST contains this descriptor:

```json
{
  "text": "Save form",
  "name": "a0bbe568-c130-4fae-a886-7e7e176bb790",
  "type": "rule",
  "parentName": "btnSave",
  "parentType": "field"
}
```

Here `name` contains the **target rule GUID**, matching SC `/forms/0/fields/0/rules/0/id`; `text` is a label. `parentName` identifies the owning field by its logical name, and `parentType` identifies its kind. Do not invent a target `id` or replace `name` with the rule title. Generic descriptor names remain kind-dependent. V1.1.0 checks the GUID shape of a scheduled target's `name` when `type` is `rule`; target existence and agreement with its parent remain external checks. The recorded ST-to-SC match is fixture evidence, not a general reference resolver. The example establishes `parentType: "field"`, not an exhaustive enum of possible parent kinds or universal requiredness of the parent keys.

The surrounding owner excerpt uses `rules/rule-schedule`, `enabled: true`, outer `schedule: "default"`, a task with `settings: {}` and `schedule: "now"`, empty `conditions`/`elseSettings`, and `hasElse: false`. Its `field` points to SC's textbox at `/forms/0/fields/1`, while the target save rule belongs to `btnSave`. The scheduling rule's attachment and the target rule's parent are separate references. The partial excerpt is not a complete rule or app validation fixture; ST preserves only the supplied target descriptor.

**Confirmed in C2026-23:** `hasElse` is a boolean in the server contract and defaults to false. `elseSettings` holds alternate settings for the **same action**. An omitted flag or explicit `false` leaves that configuration inactive; C2026 confirms that its operational validity is then ignored. Preserve retained alternate settings without repairing inactive targets/options. V1.1.0 applies action-specific alternate-setting constraints only when `hasElse` is explicitly `true`; the base `elseSettings` hash must still be an object when present. Do not coerce string flags or insert a missing flag during validation. SC demonstrates serialized omission consistent with the owner-confirmed default; it remains unexecuted evidence.

### Action catalogue

The current corpus contains 38 distinct actions. The following observed families are examples of coverage, not exhaustive implementation contracts:

| Action(s) | Settings and reference considerations |
| --- | --- |
| `rules/rule-setfield` | `outputMapping`; destination/source descriptors, expressions, or a left-only entry that clears its destination. |
| `rules/rule-hideordisable`, `rules/rule-makerequired` | Target/action entries; targets may be forms or fields. |
| `rules/rule-validation` | Configured message plus conditions; stop-on-error semantics unresolved. |
| `rules/rule-save`, `rules/rule-submit`, `rules/rule-close`, `rules/rule-delete` | Distinct persistence/navigation actions; empty settings can occur. |
| `rules/rule-assignform`, `rules/rule-gotoform` | Form descriptors, singular/plural collections and mode-specific picker settings. |
| `rules/rule-schedule` | Nested task; target field or rule required for execution; optional ordering/uniqueness settings. |
| `rules/rule-finditems`, `rules/rule-startprocess` | Query, mappings and external process context; start-process can be configured for lookup. |
| `rules/rule-addrow`, `rules/rule-removerow`, `rules/rule-looptable`, `rules/rule-tablesum` | Table/column/result references; data-row operations differ from editing field definitions. |
| `rules/rule-addtime`, `rules/rule-calculatetime`, `rules/rule-dateformat` | Date references and action-specific units/format settings. |
| `rules/rule-finduser`, `rules/rule-personattribute` | Principal/profile mappings. |
| `rules/rule-copyfile`, `rules/rule-generatedoc` | File-field descriptors and output destinations. |
| `rules/rule-sendemail`, `rules/rule-alert` | Recipient/target objects, content and delivery configuration. |
| `rules/rule-anonymouslink` | Lifetime/use settings and form/field descriptors; authorization remains external. |

Observed tenant actions include `client-rule/custom-id`, `go-to-next`, `go-to-previous`, `open-form-dialog`, `set-process-status`, `question-custom-answers`, `question-custom-score`, `show-hide-related-questions`, `set-field-title`, `append-user`, and `clear-user-picker` under the same `client-rule/` prefix. These names do not establish portable built-in capabilities or authorize guessed settings.

Sources: H §11; C2026 on schedule targets, clear mappings and inactive else branches; C2026-23 on the server default and rule-target descriptor; A–O actual rule trees; SC button rules; ST.

## 10. Conditions and descriptors

`rule.conditions[]` contains groups whose `conditions[]` contains conditions with `arg1` and, where serialized, `arg2` operands. Direct-rule groups require GUID IDs under C2026; individual condition-ID requiredness remains unconfirmed. Recursively nested groups are not established. Preserve `group` connectors; exact evaluation semantics still need the engine contract.

Direct conditions currently use `contains`, `eq`, `neq`, `gt`, `gte`, `lt`, `lte`, `isblank`, and `notblank`. Connectors include `and` and `or`. These observed tokens are not exhaustive enums. Do not import a broader query/page operator list as proof of process-rule support.

Operands can be sparse field, literal or system descriptors. Current unary conditions include 59 empty `arg2` objects and 164 `arg2` objects containing only `{"name":""}`. For example, A `/forms/0/fields/1/rules/0/conditions/0/conditions/0/arg2` is empty. Do not require `type`, `text`, `fieldType`, `id`, or dummy value/date keys on every operand.

A descriptor's `type: "field"` differs from the target entity's component type; that component identifier may appear as `fieldType`. A form descriptor can use `type: "form"` and a logical name without an ID. A scheduled-rule descriptor instead stores its rule GUID in `name` (§9). System descriptors can use `__Field`. A literal descriptor can carry `type: "text"` and text. A single closed descriptor union inferred from a few examples would be premature.

Settings-level filters currently contain another 94 groups and 138 conditions. C2026-23 confirms that query-filter groups managed by `rules/rule-conditions` require GUID IDs for UI deserialization and editing, even though the filters do not intrinsically require those IDs on the server. Generate IDs in those models. Schema enforcement covers applicable typed settings; alternate settings retained while `hasElse` is false or omitted bypass these subtype checks, so their UI readiness is not certified. Query context and operator metadata remain separate from direct rule conditions: do not combine the counts, assume interchangeable operators, or apply this contract to arbitrary settings objects called groups. Individual condition-ID requiredness is still unconfirmed.

Sources: H §§12–13; C2026 and C2026-23 on group identity and UI authorability; A–O direct condition trees and settings filters; ST for the rule-reference distinction.

## 11. Mapping and dependency semantics

Mapping families include `inputMapping`, `outputMapping`, `errorMapping`, `tableMapping`, nested `columnMapping`, and action-specific `mappings`. They are not one universal structure. Set-field commonly uses `left` as destination and `right` as source; cross-process mappings require separate source/target context.

**Observed:** some set-field output mappings omit `right` and instead supply `expression` with `hasExpression`, for example A `/forms/0/fields/1/rules/2/settings/outputMapping/0`. Other entries contain only the left descriptor without an expression, including A `/forms/1/fields/2/fields/1/rules/0/elseSettings/outputMapping/0`. **Confirmed in C2026:** this left-only set-field form clears the destination field; it is not an incomplete mapping. Resolve the destination, preserve the representation, and do not insert a dummy right operand or expression.

Current find-items `inputMapping` arrays also contain empty placeholder objects. An empty placeholder is not automatically equivalent to a left-only clear operation; semantics belong to the action and mapping family. Required-field mappings and person-attribute mappings use different shapes. Preserve editor metadata such as `lefterror` and `righterror` without making it compulsory everywhere.

Expressions and token-bearing strings introduce dependencies beyond descriptor objects. Examples in H include `GetFieldValue(...)`, `ProcessID()`, `User()`, `QueryString(...)`, `IsOnline()`, `createGuid()`, and `process.findFieldByName(...)`. Do not assume standard JavaScript semantics from a helper's name. Field names embedded in expressions or `[fieldName]` tokens must be reviewed during a rename.

External process references, datasource identifiers, component templates, files and principals require an authorized workspace catalogue. A descriptor belonging to a queried process must not be rewritten to a similarly named local field. Email recipient objects can describe selection modes and field references; attachment and document-template values can also be field descriptors, rather than literal URLs.

**Observed contextual differences:** a source-selection object under `settings.list` can use an integer `type` such as `100` or `101`, whereas field/literal descriptors use string kinds. For example, A `/forms/2/fields/8/fields/1/fields/1/settings/list/type` is `101`. Model source selections separately; do not broaden every descriptor's `type` merely to accept connector metadata. Email recipient objects can retain `field: null` in other selection modes, and four inactive alternate visibility actions retain a null target while `hasElse` is false. Preserve these states; an active unresolved target still needs a component completeness check.

Sources: H §§11.4, 13; C2026 on clear mappings and inactive targets; A–O settings, mappings and expressions.

## 12. Extension contracts and validation boundary

**Confirmed:** `client-field/<component-id>` and `client-rule/<component-id>` select tenant implementations receiving the model and arbitrary settings. Preserve unknown settings. Unknown outer-model retention is unresolved; the owner's original explanation was incomplete. A property being accepted by a schema does not prove it will survive every serializer.

**Proposed:** resolve optional developer-supplied settings schemas by exact component identifier, kind and compatible version. Keep registry/package metadata outside the persisted app. Unknown contract coverage should be reported separately from a known invalid value or an unavailable component. The owner's warning-only decision in H concerned widgets; identical severity for process fields/rules is a proposed policy, not a confirmed decision.

JSON Schema can check shape, recursion, declared types, explicit presence decisions, known enums and selected formats. It cannot alone establish:

- Root alias equality or workspace availability.
- Identity uniqueness across the app tree, enforcement of table-row/process field-name scopes, and row-name creation checks that account for containing table instances and edit history.
- Parent references matching containment, rule references matching attachment, and scheduled-rule target GUIDs agreeing with their parent context.
- Form activation links, populated `currentForm`, descriptor targets, or mapping direction.
- Expression validity, referenced tokens, component installation or version compatibility.
- External dependencies, principals, authorization, rule order, navigation reachability or execution behaviour.
- CSS availability and overrides, computed appearance, responsive behaviour, colour contrast, accessible semantics, focus visibility or usable interaction states (§14).

These require specialized integrity/runtime validation. Whole-object `uniqueItems` does not implement uniqueness by `id`. Defaults are not a permission to mutate input, and format checking must actually be enabled in the validator. Validating an email, deletion, or record-creation rule must not execute it.

Sources: H §§14–17; C2026; C2026-23.

## 13. Completion checklist and unresolved contracts

Before returning a generated or edited app:

1. Confirm it is one complete process definition with at least one form, or a `type: "Component"` definition with exactly one form; keep page models and orchestration metadata outside it.
2. Parse JSON without duplicate-key loss or type coercion. Preserve existing IDs, names, ordered collections and arbitrary settings.
3. Index actual form/field/rule entities and condition groups, including known query-filter groups; validate required GUID identities, duplicates, parent containment and owner references using the confirmed scope for each kind.
4. Enforce table-row/process field-name uniqueness and resolve descriptors by kind/context. Use the confirmed formula for newly generated row names; preserve existing prefix differences and do not equate row indices to array positions. Check Component process IDs and loaded `MajorVersion` references. Report unavailable dependencies without inventing replacements.
5. Apply v1.1.0 structural/known-settings validation and check active action completeness. Treat omitted `hasElse` as false without mutating input, and ignore inactive alternate operational configuration. Recognize left-only set-field mappings as clear operations; require and resolve schedule targets, including rule GUIDs stored in target `name`. Keep schema errors separate from coverage gaps.
6. Review tokens/expressions and affected references for changes; do not silently normalize unrelated serialization.
7. Check the workflow, security and component availability with the specialized tool. Preview or simulate only through a verified mechanism with appropriate side-effect handling.
8. Review branding using §14: hierarchy, grouping, responsive layout, consistent typography, appropriate class/settings combinations and accessible interaction states. Confirm target-workspace appearance through preview when available; report what was not rendered or tested.
9. Return the complete requested JSON plus concise diagnostics and the material unresolved assumptions. Never claim runtime correctness or visual/accessibility conformance from structural acceptance alone.

### Settled decisions and remaining gaps

Do not reopen the accepted baseline, process minimum form count, Component one-form model and version source, current `field.class` property, ordinary table-row field-name scope, direct-group GUIDs, string/empty-default settings, `showArrows` bug behaviour, left-only clearing, schedule target requirement, or ignored inactive else configuration. C2026 supplies those answers. C2026-23 additionally settles the false default for omitted `hasElse`, query-filter group GUIDs for UI authorability, the supplied rule-target serialization, and the table-row name creation formula.

Remaining limits concern condition-group uniqueness boundaries and individual condition IDs; row-index allocation/bounds and deeper nested-name resolution; scheduled-rule parent kinds beyond the supplied field example; and the complete operator, schedule and submit-mode contracts. Broader unverified areas remain serializer defaults other than `hasElse`, partial-model nullability and property retention, root-alias presence across import/export paths, populated `currentForm` and form-rule ownership, active component settings, numeric syntax/ranges and exact defaults, `en-AUS` implementation, Component upgrade identities/local overrides, and tenant-contract availability/severity. These limits do not undo the specific contracts now confirmed.

Resolve each point using current implementation evidence or an explicit owner decision. Record which assertion changed and retain a regression case. A plausible configuration, a historical export, and a verified runtime contract are different levels of evidence.

## 14. Process app branding and interface design

Branding is a fundamental part of the process design brief, as confirmed in CB. Apply the core directive in §2 from the first layout decision and carry it through forms, recursive field layouts and reusable Components. B supplies the supported visual vocabulary; the exports show how several of those treatments are serialized; BV provides a visual composition reference. Keep those sources distinct from the design recommendations below.

### 14.1 Design system and property placement

B states that the listed utilities ship in the default workspace global `app.css`, can be overridden, and are usually applied to `field.customCssClass`. They are documented defaults, not proof that a particular tenant's stylesheet is unchanged. Use the target workspace's existing palette, type treatments and component styles when available. A screenshot cannot establish exact CSS declarations, dimensions or breakpoint values.

Material Design supplies principles for hierarchy, grouping, spacing and interaction. It does not establish that a Material component library, font, icon set or token system is installed in Kianda. Implement those principles through the verified platform components and Bootstrap 3 layout conventions. Existing corpus icons include `fa fa-*` and `icon-*`; preserve them unless a supported replacement is deliberately selected. [MD; BS3; A–O]

| Property or location | Purpose and evidence |
| --- | --- |
| `field.class` | Current owner-confirmed layout property. The corpus contains `col-sm-*` widths and `pull-left`. Preserve the key; do not rename it to `cssClass`. |
| `field.customCssClass` | Additional visual classes. B recommends this location for its utilities. Values are class tokens without a leading CSS selector dot; multiple classes are space-separated, as observed in `section-title expandable-section`. |
| `field.settings.mobileClass` | Existing nested mobile layout setting; present on 50 fields. Its placement is observed. Do not move it to an outer property or assume how it wins against other classes without preview. |
| Component-specific `field.settings` | Native presentation options stay in their actual keys. Examples include `controlBgScheme` on static text and `colorScheme`, `buttonSize`, `alignButton` and `icon` on buttons. |
| `field.text` on `fields/field-text` | The static content styled by `section-title`. It is distinct from the field's design title and logical name. Preserve existing text/HTML when the change is only styling. |

Do not apply one utility to every field. Select it for its documented component and intended purpose. Preserve unrelated class tokens, empty settings, field names, IDs, rules, security and references during an edit. Changing a section's visual title does not authorize changing its logical name. Treat `settings.cardPanel` and `customCssClass: "panel-card"` as distinct: both occur in the corpus, and the former is serialized as an empty string in its 46 occurrences. [C2026; B; A–O]

### 14.2 Documented process-field utilities

The following catalogue transcribes the seven process-field entries in B. Configuration labels in this table are the guide's UI labels; the next subsection identifies which JSON keys are supported by the current evidence. These are useful recipes, not universal schema requirements.

| Class | Intended field and guide configuration | Documented treatment |
| --- | --- | --- |
| `panel-card` | `fields/field-panel`; Colour scheme = `panel-default`. | White panel with rounded corners for grouping related elements. |
| `radio-list-card` | `fields/field-list`; Display format = Radio list; List position = Vertical. | Radio choices in white cards with soft corners spanning the list width. Useful for prominent choices; its own surface works well outside another panel card. |
| `checkbox-list-card` | `fields/field-list`; Display format = Checkbox list; List position = Vertical. | Corresponding card treatment for multiple selections; the guide also recommends placement outside another panel card where appropriate. |
| `radio-list-button` | `fields/field-list`; Display format = Radio list; List position = Vertical. | Rounded button treatment for radio choices; the guide describes possible green/red treatment for Yes/No values. |
| `section-title` | `fields/field-text`; Colour scheme = `bg-primary`, `bg-warning`, `bg-info` or `bg-success`. | Section separator with larger `field.text`, soft corners and the selected background treatment. |
| `table-no-style` | `fields/field-table`. | Removes the usual Bootstrap 3 table presentation, such as grid lines and shading, for a repeating panel composition. |
| `image-thumbnails` | `fields/field-image`; Image source = File field; Display images inline = yes. | Equally sized thumbnails of uploaded pictures, using `object-fit: cover`. |

B also contains page/widget utilities. They are outside this process-app catalogue and do not introduce page/widget models or schema branches.

**Transcription note:** the DOCX contains an invisible U+200B after `radio-list-card` and `table-no-style`. The catalogue above intentionally uses clean class tokens. This is a documented transcription cleanup; no uploaded source or existing app class string was rewritten.

**Observed coverage:** the five exports contain 22 `panel-card` fields, 25 fields containing the `section-title` token, 10 `radio-list-button` fields, and two `table-no-style` fields. The other three utilities are documented by B but do not appear in these exports' `customCssClass` values. Absence does not contradict their documented availability. Conversely, existing classes such as `radio-button-list`, `toggle-block`, `expandable-section` and animation classes are observations, not a complete portable utility contract. `radio-button-list` and `radio-list-button` must not be silently conflated. [B pp. 1–2; A–O actual field trees]

### 14.3 Verified settings and unresolved mappings

| Design choice | Supported serialized representation | Evidence and limit |
| --- | --- | --- |
| Static section background | `settings.controlBgScheme: "bg-primary"` with `customCssClass: "section-title"`. | Observed at A `/forms/2/fields/9/fields/0`. B additionally documents `bg-warning`, `bg-info` and `bg-success` as UI choices; not every combination was present or rendered here. |
| Radio display | `settings.displayformat: "radiolist"`; direction in `settings.radiodisplayposition`. | The ten `radio-list-button` fields split into five `"vertical"` and five `"horizontal"` settings. B's vertical recipe is not an assertion that existing horizontal configurations are invalid. |
| Checkbox display | `settings.displayformat: "checkboxlist"`, with `settings.radiodisplayposition: "vertical"` in the observed examples. | I `/forms/0/fields/4/fields/0` and `/forms/4/fields/3/fields/0`. This supports the tokens; neither source establishes the new card class was attached there. |
| Images from an upload field | `settings.imagesource: "file"`, `settings.inlineImages: "yes"`, and `settings.fileSource` containing a field descriptor. | All 11 image fields use these keys. I `/forms/1/fields/5/fields/0/fields/1` references its sibling upload field at I `/forms/1/fields/5/fields/0/fields/2`. Resolve the actual source rather than copying that app's descriptor. |
| Panel colour scheme `panel-default` | UI instruction documented; JSON key/value placement unresolved. | No supplied export, handoff or current schema identifies the serialized mapping of this UI choice. Do not invent `settings.colorScheme`, assume `controlBgScheme`, or add `panel-default` to `customCssClass` solely because an open schema would accept it. |

The distinction matters for generation: known list/image settings can be authored using their verified keys, while the panel colour option needs a saved example or component contract before emitting a new value. Existing panels using `panel-card` remain valid evidence without that value. In all 132 observed panels, `controlBgScheme` is empty or absent; the guide does not justify rewriting those panels.

Preserve a list's intended selection semantics, labels and stored values. Manual choices remain newline-delimited strings in the known model. B does not establish the exact value matching or CSS selectors behind Yes/No colours. Do not change business values to obtain a colour, or use colour as the sole indication of selection or meaning. [B; H §9; A–O; W-Color]

### 14.4 Composition recipes grounded in the supplied apps

**Section heading followed by a content card.** A `/forms/2/fields/9` contains a static section heading and then a panel card containing comments and actions. The following is an exact projection of selected properties from its first two children. It is an explanatory excerpt, not a complete field array to paste over the existing children: identities, panel descendants, rules and unrelated settings are deliberately omitted and must be retained.

```json
[
  {
    "type": "fields/field-text",
    "customCssClass": "section-title",
    "showTitle": false,
    "text": "\nAction Closure<!---->\n\n<!---->",
    "settings": {
      "controlBgScheme": "bg-primary"
    }
  },
  {
    "type": "fields/field-panel",
    "class": "col-sm-12",
    "customCssClass": "panel-card",
    "showTitle": false
  }
]
```

For a new heading, author meaningful section text and choose an established background treatment. The existing HTML comments above are source serialization, not required markup. The example's `showTitle: false` prevents its design title from being separately displayed in that configuration; do not make this flag mandatory for every text or panel field. Use the card when it creates a useful group, and avoid unnecessary layers of nested cards. [A pointer above; B]

**A prominent choice selector.** Use the documented card or button class on a list with the corresponding selection mode. For a new radio button treatment, B's vertical configuration is supported by I `/forms/2/fields/7/fields/0/fields/0/fields/0`. The exact projection below omits its choices and other settings; it is not a complete list definition.

```json
{
  "type": "fields/field-list",
  "customCssClass": "radio-list-button",
  "settings": {
    "displayformat": "radiolist",
    "radiodisplayposition": "vertical"
  }
}
```

Choose card presentation for prominent decisions that benefit from room for labels; use the compact button treatment for short alternatives when it remains readable. These are design recommendations. Preview wrapping, selection, focus and disabled states; a horizontal-looking screenshot does not reveal the stored direction setting. [B; BV; I pointer above]

**A repeating panel.** I `/forms/2/fields/7` and `/forms/3/fields/3` use `table-no-style` on the table. Each table's row has a first child panel using `panel-card`; that panel contains the row's business fields. This supplies concrete containment for B's phrase “first-row field”: place the card panel inside the repeating row, with its inputs below it in the field tree. Keep the `fields/table-row` entity, row operations and table settings. Do not flatten the table or turn it into a static list of unrelated panels. Row names, IDs, scope and dynamic repetition retain the rules in §§4 and 8. This is an observed composition, not a requirement that every table have exactly one panel or one stored row. [I pointers above; B p. 2]

**Upload with a thumbnail preview.** Keep a real `fields/field-file` for upload and configure a `fields/field-image` to reference it through `settings.fileSource`, using the file/inline keys above. Add B's `image-thumbnails` treatment to the image field when a consistent preview is useful. This combines a documented class with observed settings; that class was not present on the corpus image fields. The supplied screenshot visually shows an upload list followed by two thumbnails. It does not establish click-to-enlarge behaviour, permissions or an exact thumbnail size. Since `object-fit: cover` may crop the visible image, preserve an appropriate means to inspect the full evidence through the available file/image controls. [B; BV; I `/forms/1/fields/5/fields/0`]

BV also shows a blue section band, neutral surroundings, a white panel holding three short choices, and separate full-width option cards. Use its grouping and hierarchy as visual reference. No source JSON or DOM was supplied for that screenshot, so attributing each visible surface to a precise class combination is an inference. Its application header, navigation and messaging overlay are surrounding product UI, not process-field models to generate.

### 14.5 Authoring practices for a cohesive interface

The following are proposed implementation practices for the owner's confirmed design objective. They supplement the documented class catalogue rather than imposing new serialized requiredness.

1. **Organize around the task.** Identify the form's purpose, the user's next decision and the main action. Group related inputs, separate meaningful stages with clear headings, and place help beside the decision it explains. Distinguish the primary action from supporting and destructive actions using established button settings and clear labels.
2. **Give the layout a consistent rhythm.** Align field edges, repeat section spacing, and leave more space between groups than within a related group. Use cards to make meaningful boundaries; avoid giving every individual input its own elevated container. Follow the existing workspace's spacing and radius treatments. No numeric spacing scale or corner radius has been supplied as a branding requirement.
3. **Use a responsive grid deliberately.** `col-sm-12` and `col-sm-6` are observed full- and half-grid choices. Standard Bootstrap 3 supports breakpoint-specific classes, but actual Kianda wrapping and mobile settings must be checked in the target workspace. Allow dense groups to stack on small screens, give long text and file controls sufficient width, and preserve a sensible reading and tab order. Do not require all sibling widths to total twelve or assume modern Bootstrap utility syntax. [BS3]
4. **Maintain a readable hierarchy.** Keep form purpose, section headings, labels, body/help text and actions visually distinct and consistent across related apps. Use the existing font family and supported type treatments; do not shrink labels or introduce an unverified font package to force a layout. Use colour and restrained elevation to support meaning. Material's hierarchy and grouping principles support this approach; its libraries and exact type tokens are not a Kianda dependency. [MD]
5. **Design for states and real content.** Check long labels, multiple uploads, empty lists, populated rows, validation messages, read-only and disabled controls, and selected/unselected choices. CSS supplies presentation; field settings and rules supply behaviour. An `expandable-section` token alone is not evidence of a functioning expand/collapse mechanism. Keep business values, validation and security independent of cosmetic changes.
6. **Carry the same language across Components.** Reuse established section, card and action patterns where the task is similar. A reusable Component still follows the loading/version contracts in §8. Check its appearance in the consuming form; a shared styling change can affect more than one app.

Use the existing utilities before proposing new CSS. If additional CSS is needed, identify the missing design capability, verify a supported scoping mechanism and assess its effect on other apps sharing the workspace. B explicitly warns that global changes can affect overall application use. Do not treat a request to style one process as a request to rewrite shared `app.css`, and do not invent an app-level CSS settings key or embed a framework dependency in the process JSON. [B p. 3]

### 14.6 Accessibility and visual validation outside JSON Schema

Make visible labels, readable content, keyboard operation and recognizable state changes part of the design review. Maintain visible focus indicators and convey meaning with labels or another usable cue alongside colour. For text contrast, use WCAG 2.2 SC 1.4.3 as a review target: at least 4.5:1 for ordinary text and 3:1 for qualifying large text, subject to the criterion's definitions and exceptions. Styling a field as a section title does not itself prove a semantic heading or an accessible name. These are design and rendered-interface checks, not claims of compliance from this document. [W-Contrast; W-Color; W-Focus]

Before delivery, review the actual process in its target workspace when a preview is available. Check large and small viewports, zoom and long content; verify contrast from actual rendered colours; inspect keyboard focus, labels and error/selection states; confirm thumbnails and repeating panels remain usable. Check that the intended classes exist and that tenant overrides do not obscure content or controls. Report a review limitation when preview, stylesheet or interaction evidence is unavailable rather than claiming a pass.

JSON Schema can validate the existing string/settings shapes. It cannot confirm stylesheet loading, CSS specificity or computed styles, element dimensions, usable wrapping, colour contrast, accessible names, semantic headings, focus order, thumbnail access or interactive feedback. Class presence is not a substitute for those checks. This branding addition does not change schema `1.1.0`, close tenant settings, require visual properties, regenerate identities or rename fields.

### 14.7 Remaining branding evidence and references

The new evidence leaves these implementation details explicit: the serialized key for the panel UI's `panel-default` option; the target workspace's deployed `app.css` and overrides; exact brand palette, font/type scale, spacing/radius tokens and breakpoint customizations; and the selectors/state behaviour behind value-specific Yes/No colours. A saved configured panel and the deployed stylesheet would resolve the most immediate gaps. They do not prevent applying the documented utilities and verified settings above.

Sources B and BV are supplied attachments, not runtime tests. The following external references support general design/review principles only; they do not establish Kianda contracts. Accessed 23 October 2026.

- **MD:** Official archived Material Design guidance on [principles](https://m2.material.io/collections/introduction-to-material-design/) and [layout grouping and containment](https://m2.material.io/design/layout/understanding-layout/). Used for general principles, not a requirement to install or pin a Material version.
- **BS3:** [Bootstrap 3.4 grid documentation](https://getbootstrap.com/docs/3.4/css/#grid). Describes the framework's standard grid; workspace overrides and Kianda's renderer remain separate evidence.
- **W-Contrast:** [W3C explanation of WCAG 2.2 SC 1.4.3](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html).
- **W-Color:** [W3C explanation of WCAG 2.2 SC 1.4.1](https://www.w3.org/WAI/WCAG22/Understanding/use-of-color.html).
- **W-Focus:** [W3C explanation of WCAG 2.2 SC 2.4.7](https://www.w3.org/WAI/WCAG22/Understanding/focus-visible.html).
