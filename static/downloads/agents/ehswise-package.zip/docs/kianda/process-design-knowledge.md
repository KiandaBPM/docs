# Kianda process design knowledge

**Baseline:** `0.1.0`, draft for owner review, 29 October 2026. **Documentation:** compact routing revision, 4 November 2026; approval/runtime status unchanged.  
**Scope:** stages, forms/sections, adaptive journeys, conditional validation, navigation, visual composition and builder handoff. Design concepts add no JSON properties. No target application/skill was executed when the baseline was prepared.

## Read by task

| Design work | Reference |
| --- | --- |
| Conditional state, overlapping decisions, re-entry, reversal, validation/navigation | [State and journeys](./process/design-journeys.md) |
| Permissions, consequential actions, reporting, existing records/offline use | [Ownership and data](./process/design-journeys.md#ownership-data-and-existing-records) |
| Application personas/roles and real workspace groups | [group-configurator](../../.agents/skills/group-configurator/SKILL.md); design roles before creating groups during implementation. |
| Datasource feasibility or related local processes | [query-configurator](../../.agents/skills/query-configurator/SKILL.md); current local Kianda process JSON/pending builder definitions can be used directly. |
| Substantial new/adaptive design or handoff | [Blueprint template](./process/design-blueprint.md) |
| Affected checks or readiness | [Acceptance scenarios](./process/design-review.md) |
| Supplied Incident architecture/patterns | [Annotated Incident](./process/incident-reference.md) |
| Exact JSON/settings or visual utilities | Relevant contract via [process knowledge](./process-knowledge.md), or [CSS guide](./css-style-guide.md) |

Read only what the task needs. A small layout/wording repair needs a design delta and affected-state checks; a substantial adaptive process needs an explicit journey and handoff. Authorized end-to-end work does not automatically pause after design.

## Design the experience

Decide business stages, form boundaries, sections, decisions, participants and actions before generating fields. Specify how earlier answers change applicable forms, visible sections, required information and the next reachable action. Compose the interface alongside the journey; the designer's role includes business structure and interaction, not only styling. Prefer the simplest experience satisfying actual requirements.

Distinguish stage (outcome/handoff), form (navigable activity/area), section (related information without independent lifecycle), branch (applicable work), action (specific effect), participant (contribution/access), related record (its own identity/lifecycle) and utility structure (implementation support). Stages/forms need not map one-to-one; save, navigation and completion differ; visibility is not authorization.

## Establish requirements and structure

Identify outcome, participants, inputs, decisions, evidence, completion criteria, reporting and constraints. Separate business policy, interaction choices and verified implementation. Never invent severity thresholds, obligations, retention or approval authorities; use symbolic policy references for unsettled decisions. Existing-app work must identify stable behavior/identities, open-record compatibility and scope.

| Situation | Starting structure/check |
| --- | --- |
| Small addition to the same person's current task | Conditional section; keep reading order/manageable size. |
| Substantial category worth revisiting | Separate form, possibly within one stage. |
| Later participant/different completion criteria | Form/stage with verified handoff and access. |
| Short secondary optional detail | Inline disclosure or supported dialog; essential work stays discoverable. |
| Similar entries sharing parent lifecycle | Native repeating table/cards; verify row operations/devices. |
| Independent ownership/status/access/reporting | Consider related processes; verify linking/reporting. |
| Stable section shared across apps | Consider a Component; verify loading/version/names. |

Choose boundaries by task, timing, ownership, volume, navigation and lifecycle; avoid giant forms and arbitrary fragmentation. Explain where stages/forms differ. A different responsibility alone does not require a new process instance.

## Compose important forms and states

Apply the owner's clean, professional enterprise style through native controls/workspace CSS. Material Design supplies principles, not a framework dependency. Describe purpose/help, initial decisions, section order, repeats, evidence controls, feedback and actions, including conditional/populated/error states.

Use meaningful headings, nearby help, coherent cards, adequate text/upload widths and sensible responsive stacking. Align visual, reading and keyboard order; make revealed content understandable and specify supported focus behavior when focused content disappears. Keep labels, focus indicators and errors. Choose patterns for their task and retain control semantics. Preview long/empty/populated content, read-only/selected states, narrow screens and keyboard use.

Use `field.class` for layout and `field.customCssClass` for additional styling; do not rename layout to `cssClass`. Business visibility cannot rely on CSS alone. Additional global CSS/JavaScript/custom components need a justified gap, scope and regression assessment; use existing native patterns when sufficient.

## Decisions and handoff

Record reversible assumptions. Unknown access, data-loss, completion or external-action consequences block their affected scope; continue independent safe work. Do not silently resolve conflicting requirements/contracts, repair unrelated defects or perform migration. Unless explicitly documented/observed, this guide is recommended design policy; task requirements take precedence within supported contracts/workspace instructions.

The builder must understand forms, predicates, reversal, navigation/completion, mechanisms and acceptance scenarios. Update the blueprint with reasons when implementation evidence changes it. Keep app requirements in the blueprint, technical contracts in their references and history in the changelog. Do not call unreviewed design approved or static work runtime-verified. [Source register](./process/evidence.md#design-source-register)
