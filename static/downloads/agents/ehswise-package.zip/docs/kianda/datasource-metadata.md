# Datasource discovery and consumer configuration

Use [query-configurator](../../.agents/skills/query-configurator/SKILL.md) when a lookup, native data rule, page query/filter or file destination needs existing datasource discovery. For current local Kianda processes, designers/builders can reference the definitions directly without invoking the skill or bridge. This reference owns connector interpretation; [agent bridge](./agent-bridge.md) owns transport, helper use, prerequisites and failures. No connection provisioning, credential management, query execution or upload operation is exposed by these discovery methods.

**Evidence:** owner-supplied metadata requirements and extension README, reviewed 7 November 2026. Connector shapes below are documented inputs for authoring, not runtime certification or additions to the accepted process `1.1.0` / draft page `1.0.0` schemas. Examples omit tenant values and are configuration fragments, not complete importable definitions.

## Select evidence and a connection

`listDatasources()` returns an array. The bridge preserves its entries unchanged; inspect the actual `id`, title and connector-type properties provided, without assuming every entry supplies all three. Resolve an absent type from trusted current connection/consumer evidence before applying a connector contract. Use the returned connection ID, including the named `kianda-data` token when confirmed. A displayed source label is not an ID.

Read the exact current consumer before changing it. For `kianda-data`, current local process JSON and the builder's draft definitions take precedence for fields being authored. Uncommitted or unpublished fields may correctly be absent from remote metadata. Build relationships from the actual local aliases, names, types, IDs and containment scope; preserve these references through publication. Record which producer processes/fields must be published before dependent consumers can run. Do not label an unassigned blueprint ID or planned field remotely available. Resolve any real conflict between local intent and server state rather than silently overwriting either.

Metadata nodes describe selectable resources and fields. They are **not** universal saved descriptors. Use the target surface's [process rules](./process/rules/core.md), [Find items](./process/rules/find-items.md), [field settings](./process/fields.md) or [page bindings](./page/bindings.md). A node's `fieldType` and a connector column's `fieldtype`/`data_type` have different meanings. Do not normalize them globally. In particular, process-bound page lists/charts/tiles can have `datasource: null`; their process scope is separate from a datasource-filter connection.

## Kianda Data (`kianda-data`)

| Client call | Response and selection |
| --- | --- |
| `metadata(id)` | Tree object with `text`, `selectable` and `nodes`. The Processes branch (`type: "processes"`) contains process nodes with `text`, logical `name`, `type: "process"` and `selectable: true`. The Files node has `type: "folders"`. |
| `metadata(id, { name: processAlias })` | **Array** of lightweight process-tree nodes, including common properties and forms; recursively inspect their `nodes`. Table fields are excluded. Do not treat this response as a full process definition or an empty result as proof no table data exists. |

Common properties use `type: "__Field"`, with names such as `__NAME`, `__STATUS`, `__CREATED` and `__CREATED_BY`; date properties may provide `fieldType: "DateTime"`. Forms (`type: "form"`) and panels can be nonselectable containers with selectable descendants. Regular field nodes carry their exact `name`, actual `id`, `type: "field"` and implementation `fieldType`, such as `fields/field-textbox`. Traverse containers; do not bind a nonselectable panel as a data value. Do not infer a missing selectable flag or invent a system-field implementation type.

Use the process alias for resource selection, not its title. Resolve repeated names with the real form/parent/row context. For unavailable metadata, tables or Components, inspect local process definitions and their [model contracts](./process/model.md); metadata omission does not override the documented limits of a consumer. Summaries do not independently index table cells, so knowing a table's definition does not make it queryable as an ordinary summary field.

Process-backed lookup records are an application architecture option for reference data. Choosing them does not implicitly authorize creating reference records or migrating external data.

## SharePoint (`sharepoint`)

Use `metadata(id)` with no connector-specific request. The response has `currentWeb` and may include `success`; inspect an explicit failure before interpreting the contents. A web supplies its `title`, `url`, `Id`, `lists` and `webs`. Visit `currentWeb.lists` and recurse through nested `webs` to retain each list's owning web. Do not merge same-title lists from different webs or use a list URL as its parent web URL.

Each list supplies `title`, numeric `type`, `url`, `fields` and optional source flags such as `isExt`/`baseType`. Numeric **`type: 101` identifies a document library**; ordinary lists in the example use `100`. Do not select a normal list as an upload library or convert these numeric types to strings.

Fields supply `title` (display label), `name` (internal name), `isreadonly`, `type: "spfield"` and `fieldtype` (for example `Text`, `Counter`, `Lookup`, `User`, `DateTime` or `File`). Use internal names such as `Title`/`ID` in bindings even when the displayed title differs. Readonly fields can be selected for compatible reads but must not become write targets. `isreadonly: false` alone does not establish every required write value, permission or special field serialization; verify lookup, person, multi-value and computed-column mappings against the consumer contract.

For a documented list selection, derive the saved `settings.list` from the actual list and owning web:

```json
{
  "text": "List display title",
  "type": 100,
  "url": "/sites/example/Lists/ReferenceData",
  "webUrl": "/sites/example"
}
```

Metadata `type: "spfield"` is not automatically the saved mapping operand type: [Find items](./process/rules/find-items.md) documents `type: "datafield"` with `fieldType` for its returned source fields. Use that surface's contract. SharePoint supports native find/create/update/delete consumers and document-library uploads, but metadata retrieval neither performs these operations nor proves the connection can write. Native CRUD action/settings contracts still need the target's current configuration evidence.

## SQL Server (`mssql`), MySQL (`MySQL`) and Oracle (`oracle`)

The owner specifies the same metadata pattern for these three types. Preserve the actual returned connector token; do not silently lowercase `MySQL`.

| Client call | Response and use |
| --- | --- |
| `metadata(id)` | Database object with `name`, `tables`, `views` and possibly `routines`. Entries have an exact `name`, `type` and `columns`; discovery columns may be empty. Inspect the actual collections rather than assuming routines are absent. |
| `metadata(id, { action: "table", name: selectedName })` | Details for the selected table in the response collections. Use `action: "view"` for a view or `"procedure"` for a routine; retain its exact qualified name. The request action is a metadata selector, not an executed SQL command. |

Detail `columns` contain `name`, `data_type`, `isKey` and `size`. Retain qualified resource and column names exactly. A column named `Id` with `isKey: false` is **not** evidence of a proven unique key; the supplied example marks all columns false. Likewise, `size: 0` does not establish a usable maximum or unlimited length. Confirm unique record identity and supported write mappings before configuring updates/deletes. Do not infer nullability, defaults, generated keys, routine parameter direction, return shape or permissions from absent properties.

Tables/views and supported native rules can supply lookup/read or CRUD consumers, subject to their actual operation contracts. **SQL connectors do not support file upload.** Select an existing Kianda Files or SharePoint library destination when the requirement includes files; do not invent a SQL blob upload setting.

The supplied requirements establish the metadata request/response pattern, not the full SQL `settings.list` or column-operand serialization for every consumer. Use current saved configuration, installed connector settings source or additional authoritative evidence to write those settings. If missing, deliver the resolved resource/column design and identify that exact implementation gap. Do not copy the raw metadata object into a rule or execute a procedure to discover its output.

## File-field destinations

The documented field implementation is **`fields/field-file`**. The requirements' prose also uses `fields/file-field`; use the canonical identifier established by the actual examples and [field catalogue](./process/fields.md).

The field's outer `datasource` identifies the selected existing connection. `settings.list` identifies the destination. These are selection fragments:

| Destination | Verified selection |
| --- | --- |
| Kianda Files | Outer `datasource: "kianda-data"`; `settings.list: { "text": "Files", "type": "folders" }`. Supplied example uses `settings.structure: "process"`. |
| SharePoint document library | Outer `datasource` is the discovered SharePoint connection ID; `settings.list` contains the actual library title as `text`, numeric `type: 101`, list `url` and owning `webUrl`. Supplied example uses `settings.structure: "none"`. |

Select the verified destination and choose upload behavior for the requirement. Example values for overwrite (`override`), removal, multiple files, media capture, drag/drop, badges and `fileNameMode` are not universal defaults. Preserve existing settings and their boolean/string wire types, mapping arrays, field identity and parent references. Do not copy sample GUIDs, tenant paths or transient upload-state values as configuration. Metadata does not establish folder creation semantics or special library-column mapping formats; resolve those from current settings/source if needed.

Configuring an upload destination does not upload a file, grant library access or test overwrite/delete behavior. Keep those runtime checks and their authorization separate.

## Other connectors and completion

Use actual metadata and available connector/consumer evidence for best-effort support beyond these types. [Find items](./process/rules/find-items.md#method-metadata-and-mapping-example) documents one Office 365 method tree; it is not a universal connector schema. Ask focused clarifications for consequential gaps, or record safe assumptions and coverage warnings in the application's change entry. Do not fabricate endpoint names, stored query shapes or read/write guarantees.

After configuration, check JSON/schema and affected references without altering schema identities or filling defaults. In application documentation, record the connection/resource choice, returned identity versus display field, mappings, local/remote evidence and publication dependencies. Separate local implementation, static validation, runtime verification and publication; metadata inspection alone completes only discovery. Keep full metadata payloads, credentials and bridge locator/token material out of application documentation and saved JSON.
