# Process validation and unresolved contracts

Read when checking a generated/edited definition, extending coverage or diagnosing a contract gap. Use [process-schema.json](../process-schema.json) unchanged at accepted `1.1.0`; its Draft 2020-12 versioned URN is local, not a published platform URI.

## Validation layers

| Layer | Check |
| --- | --- |
| Parse/structure | Parse complete JSON without duplicate-key loss. Enable `uuid`/`date-time` format checking. Validate actual recursion, required profile identities and known settings; do not fill defaults, coerce types, remove unknowns or rewrite IDs/names. |
| Integrity | Index actual entities/known groups; check process aliases, GUID uniqueness, field-name scopes, containment/owner agreement and references by kind/context. Whole-object `uniqueItems` cannot implement uniqueness by ID. |
| Active completeness | Resolve schedule targets and their parents; check active action options/dependencies. Apply same-action alternate settings only for explicit `hasElse: true`. Omitted flag defaults false. Recognize left-only set-field clearing. |
| Design/compatibility | Check applicability, validation, navigation, data-reversal policy, permissions, existing records and consequential action gates against the design. Review affected tokens/expressions and relevant external references. |
| Render/runtime | Through a verified mechanism, check lifecycle, dependency availability, actual styles, responsive/keyboard/error states and behaviour. Use appropriate handling of real side effects. Report unavailable evidence. |

A normal process needs at least one form; `type: "Component"` needs exactly one. Keep page models, test outcomes, blueprint labels and orchestration metadata outside the definition. Preserve unrelated settings/security/order and accepted omissions. Return the complete requested JSON with material diagnostics and assumptions; distinguish pre-existing errors, new errors, unavailable components and unknown contract coverage.

## Extension contracts

**Confirmed:** `client-field/<component-id>` and `client-rule/<component-id>` receive their model and arbitrary settings. Preserve unknown settings. Unknown outer-model retention is unresolved; schema acceptance does not prove every serializer retains a property.

For an actual extension implementation, consult [custom add-on contracts](../custom-addon-knowledge.md). **Proposed policy:** select optional developer-supplied settings schemas by exact identifier, component kind and compatible version. Keep registry/package metadata outside persisted JSON. Separate a missing contract from known-invalid configuration and unavailable implementation. H's owner decision to issue warnings concerned widgets; applying identical severity to process fields/rules is a proposal, not confirmation. [H §§14–17]

## Checks beyond JSON Schema

Schema alone cannot establish alias equality/availability; app-wide identity uniqueness; contextual field names; row-name creation correctness after edits; containment/attachment agreement; schedule-target parent agreement; form activation, populated `currentForm`, descriptor existence or mapping direction; expression/token validity; installation/version compatibility; principals/authorization; rule order, navigation reachability or execution.

It also cannot establish stylesheet loading/overrides, specificity/computed styles, wrapping/dimensions, contrast, semantic headings/accessibility names, focus order/visibility, thumbnail access or interactive feedback. Class presence and structural acceptance are not visual/accessibility conformance. Testing a configuration must not execute email, deletion or record creation. Report static, simulated, schema/integrity, rendered and runtime evidence separately.

## Settled owner decisions

Do not reopen these as unanswered: the accepted baseline; minimum form count; Component one-form model/loading/version source; `field.class`; table-row field-name scope; direct-group GUIDs; string/empty-default settings; `showArrows` bug; left-only clearing; required executing schedule target; ignored inactive else configuration (C2026); plus omitted `hasElse` default false, known query-filter GUIDs for UI authorability, supplied scheduled-rule target serialization and row-name creation formula (C2026-23). See [model](./model.md), [fields](./fields.md) or [rules](./rules.md) for the relevant contract only.

## Remaining evidence gaps

- Group uniqueness boundaries/cross-model collisions and individual condition IDs; row-index allocation/bounds/grammar and deeper nested-name resolution.
- Scheduled-target parent kinds beyond the field example; full operator, schedule and `submitMode` contracts; populated `currentForm` and complete form-rule lifecycle behavior. The November Aggregate example now establishes a populated form GUID in rule `form`.
- Serializer defaults except confirmed `hasElse`; partial-model nullability/retention; root-alias presence across import/export paths; historical `fieldsUpdated` versus `fieldsUpdate` spelling (schema comment).
- Active component settings, numeric grammar/ranges/concrete defaults, literal `en-AUS` implementation; Component upgrade identities, local overrides and rule `originalId`.
- Tenant-contract availability/severity; native validation stop behaviour and complete runner/transaction semantics. Custom-rule continuation after rejection is separately documented in [general.md](../general.md), so do not treat that specific point as unknown.
- Process-panel `panel-default` UI-to-JSON mapping; actual target CSS/overrides, palette/type/spacing/radius/breakpoint choices and value-specific Yes/No behaviour. Later CSS-source observations apply only to that snapshot, not every tenant.

Resolve an affected gap from current implementation evidence or an explicit owner decision. Record the changed assertion and a regression case. Do not change schemas to conceal a documentation ambiguity or infer runtime correctness from an accepted example. [H; C2026; C2026-23; B; BV]

## November rule configuration coverage

The [owner walkthrough](./evidence.md#rule-configuration-walkthrough) adds configuration/behavior evidence; the accepted schema remains unchanged.

- `FindItemsSettings.table` references `Descriptor`, so the captured `mapToTable: "no", table: null` fails that property check. Report this known mismatch; do not silently coerce/delete captured data or claim the example conforms.
- `rules/rule-meeting`, Process security and table lookup/update lack dedicated settings dispatch in baseline `1.1.0`. Open settings acceptance is not action-specific validation.
- The supplied full Find items and Aggregate rule objects omit outer `id`, required by the complete-entity Rule profile. Documentation uses settings excerpts, not importable full rules/processes.
- Count/Average operation tokens, some assignment/security mode tokens, enabled loop hooks and several optional behaviors were not serialized in supplied examples. Their UI labels or schema-allowed strings do not authorize guessing wire values.
- Static checks of documentation links, JSON excerpts and present schema property types do not test rule execution, effective permissions, mail delivery or publication.
