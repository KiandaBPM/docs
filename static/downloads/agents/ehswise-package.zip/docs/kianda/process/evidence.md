# Process evidence register

Read for provenance or historical discrepancies; ordinary edits can use the relevant technical reference directly. This preserves the source boundaries of accepted process schema/knowledge `1.1.0` (23 October 2026), branding revision 1, and the draft design guide `0.1.0` (29 October 2026). The compact documentation revision does not promote the design draft or change the schema. No Kianda application/skill was executed in a target workspace when those guides were prepared.

## Authority and sources

Latest **Confirmed** owner statements supersede earlier conflicts. **Documented** internal guidance applies within its stated scope and workspace overrides. **Observed** exports/fixtures show serialization; screenshots establish appearance only. **Historical** declarations are not current defaults. **Proposed** authoring/validation choices are policy, not deployed behaviour. **Unresolved** points need evidence, with data preserved meanwhile.

Source names below identify the preparation corpus, not guaranteed files installed in this bootstrap. Pointers refer to those exact snapshots; do not read a different revision at the same pointer as equivalent evidence.

| Label | Source and limits |
| --- | --- |
| H | `kianda-process-schema.md`, numbered sections, owner U1–U5 statements and historical P0/P1–P3 material. The older Json.NET schema and inventory were described, not directly compared against actual files. |
| C2026 | Owner follow-up, 22 October 2026: accepts `kianda-process-schema.json` as the first version; confirms field-name scope, number bug, string/default settings, group GUIDs, `class`, runnable rules and Component loading/versioning. |
| C2026-23 | Owner follow-up, 23 October: confirms boolean `hasElse` default false, query-filter UI GUIDs, a rule-target descriptor and row-name generation. Supersedes corresponding v1.0.0 gaps. |
| CB | Owner branding request, 23 October: professional, authoritative, clean apps using Material principles, hierarchy, whitespace, responsive layouts and consistent typography. |
| B | `Kianda Process Apps Styling Guide.docx`; field class table rendered pages 1–2, global `app.css` and workspace overrides page 3. |
| BV | `branding example.png`; no app JSON, stylesheet, computed styles or interaction states supplied. |
| A / E / I / IN / O | `action.json`, `event.json`, `incident.json`, `inspection.json`, `observation.json`. Current I/O differ from H's older examples. |
| S | Raw `simple-app.json`; invalid JSON because a comma is missing after the second button rule's `elseSettings: {}`. Source unchanged. |
| SC | Explicit derivative `fixtures/simple-app.syntax-corrected.fixture.json`, adding only that comma. All bare-app pointers refer here; syntax repair is not runtime/design validation. |
| ST | `fixtures/schedule-rule-target.owner-example.json`, exact C2026-23 target descriptor. Surrounding scheduling excerpt is partial, lacks outer rule ID and has a trailing comma. |

## Rule configuration walkthrough

**C2026-11 (6-7 November 2026):** owner-led Contact Form designer inspection at `blank.kianda.com`, supplied settings/full-rule JSON and explicit behavior clarifications. Adds platform configuration evidence for Send email/Meeting request, Set form field/shared expressions, Assign form, Process security, Start a process, Find items and four table operations. The Contact fields, principals, connection IDs and SharePoint paths are example-specific, not Kianda/EHSWise defaults.

The owner also supplied an Office 365 static metadata tree (`References[]`, recursive input/output parameters), parsed from the conversation attachment. The full tree and screenshot files are not installed as repository fixtures; the guides retain only the relevant contract and compact examples. Example excerpts omit repeated field IDs and outer rule metadata for size; they are not complete importable process definitions.

Owner-confirmed behavior includes Promise-backed expressions; audience modes/form-owner recipients; agent email defaults and disabled real-time process triggering; security override versus enable switches; lookup-by-record-ID; query cardinality/errors/permissions; loop initialization/async waiting; row counting and observer-driven aggregation. UI labels without supplied serialized values remain explicitly unresolved. The schema separately establishes the boolean `autoUpdate` property, not an enabled runtime test.

This evidence supplements accepted `1.1.0` without revising either schema identity or promoting page draft `1.0.0`. Full supplied Find items/Aggregate rule examples lack an outer rule `id`; preserve them as excerpts rather than claiming complete-entity schema conformance. The captured non-table Find items `table: null` conflicts with the schema's descriptor-only property. Meeting request, Process security and the two table lookup/update actions lack action-specific dispatch in that baseline. [Validation boundaries](./validation.md#november-rule-configuration-coverage)

No rule was executed to send mail, create/update records, mutate tables or test authorization. Owner statements and observed configuration are distinguished from independently verified runtime behavior. [Rule index](./rules.md)

## Agent configuration skills

**Owner confirmation, 7 November 2026:** query-configurator selects existing configured datasources and configures consumers; it does not provision connections. The supplied Metadata function requirements describe Kianda Data, SharePoint and SQL metadata/file destinations. Current local Kianda process definitions, including uncommitted or unpublished related fields, may be referenced directly without invoking discovery. Record file/publication dependencies rather than claiming those fields are live.

The supplied extension README and inspected bridge source establish datasource/metadata discovery and group listing/creation through the extension-installed helper. The owner authorizes persona/role architecture, real group bindings and creation of missing role groups once detailed design exists and implementation begins, superseding the earlier page principal-deferral policy. Membership stays with administrators. See [bridge](../agent-bridge.md), [query-configurator](../../../.agents/skills/query-configurator/SKILL.md) and [group-configurator](../../../.agents/skills/group-configurator/SKILL.md). These are source/owner contracts; this documentation task did not execute a live bridge operation, create a group, test access or publish configuration.

## Corpus counts and observations

| Source | Forms | Recursive fields | Rules | Direct rule groups | Direct conditions |
| --- | ---: | ---: | ---: | ---: | ---: |
| A | 4 | 122 | 110 | 53 | 58 |
| E | 4 | 169 | 117 | 62 | 77 |
| I | 12 | 385 | 264 | 144 | 174 |
| IN | 6 | 209 | 181 | 92 | 115 |
| O | 4 | 167 | 134 | 78 | 93 |
| Total | 30 | 1,052 | 806 | 429 | 517 |

Counts follow actual containment: descriptors are excluded from fields; query filters are excluded from direct conditions. There are 1,034 direct operands, 35 process-attached and 771 field-attached rules, with no form-attached rule observed. Absence does not remove supported form rules. Query filters separately have 94 groups/138 conditions. All 1,888 form/field/rule IDs are GUID-shaped and unique within each app.

Ordinary-field duplicate groups (four in E/I/O) remain distinct from repeated generated row names in separate table instances. Example A `/forms/3/fields/7/fields/12/fields/0/fields/0` and its second-row counterpart illustrate permitted repeated row-field names. The 19 rows under 18 tables are unique within each table; 18 current prefixes differ from parents without proven cause. [Model limits](./model.md)

Eleven `showArrows: "c"` occurrences are confirmed bugs; exact casing/types and empty values remain meaningful. Counts for values, textbox modes and relevant field examples live with [field contracts](./fields.md), avoiding another normative catalogue here.

## Bare-app omission fixture

C2026 describes S as one form, one textbox and one button. Corrected SC has one form/two fields, with button rules ordered `rules/rule-save` then `rules/rule-close`. Textbox settings are empty and its child `fields` is omitted; close omits `conditions`; both rules omit `schedule` and `hasElse`.

These are omission/default fixtures, not a reason to fill every historical model property. Empty settings do not establish that every native field/action runs without configuration. Fixed identities, timestamps and values are evidence, not new-app defaults. Raw S must fail parsing; only SC can proceed to schema validation. Neither was executed. [SC `/forms/0`, `/forms/0/fields/0/rules`, `/forms/0/fields/1`; H §§1–4, 16–18]

## Design-source register

The owner discussion of 29 October establishes complementary designer/builder roles, visual process design, forms versus dynamic sections and Incident as a reference pattern; it does not settle every runtime setting. `general.md` 1.0.0 and `css-style-guide.md` 1.0.0 (27 October) supply application/extension/reporting and presentation boundaries; their target runtime was not independently executed. Process knowledge is accepted `1.1.0`, branding revision 1. The selected `incident(1).json` version 136.0 is a separately fingerprinted historical example; see [its case reference](./incident-reference.md), not the unqualified I alias above.
