# Find items

Action: `rules/rule-finditems`. Generic data access for process records, data-source tables/lists and connector methods. [Rule index](../rules.md) · [conditions and descriptors](./core.md#conditions-and-descriptors). Examples are excerpts; resolve target-workspace connections and complete field descriptors/IDs.

Use [query-configurator](../../../../.agents/skills/query-configurator/SKILL.md) for existing connection/resource discovery and connector metadata. Current local Kianda process definitions, including new uncommitted/unpublished related fields, can be referenced directly without a bridge call; record their publication dependencies. This guide owns Find items serialization and behavior, not connection provisioning.

## Select the source

Top-level **rule** `datasource` identifies the configured connection; it is outside `settings`. The selector lists data sources (ID, title, type), then their entities/tables/methods on the right. `settings.list` selects that resource:

| Source example | `settings.list` |
| --- | --- |
| Kianda process records | `{"text":"Contact Form","name":"contact","type":"process"}` |
| SharePoint list | `{"text":"Countries","type":100,"url":"/sites/kianda/Lists/Countries","webUrl":"/sites/kianda"}` |
| Office 365 method | `{"text":"Find Groups","type":"method","isproc":true}` |

Preserve the connector's actual selection metadata. SharePoint `100` is numeric; it does not broaden field-descriptor `type` or establish all connector codes. Paths, titles, aliases and connection IDs are examples, not portable defaults.

## Inputs, outputs and errors

| Mapping | Direction / behavior |
| --- | --- |
| `inputMapping[]` | `left`: form field, literal or expression; `right`: source method input. A query without inputs can retain `[{}]`; that placeholder does not clear anything. |
| `outputMapping[]` | `left`: destination form/table-row field; `right`: returned source field, literal or expression. |
| `errorMapping[]` | `left`: destination form field; `right`: error message or literal. Connection failures such as missing credentials/network problems invoke it. |

No matches produce an **empty items array**, not a connection error. With `mapToTable: "no"`, only the first returned item is mapped; remaining items are ignored. Whether an empty result clears existing destination values was not established.

For table output, use `mapToTable: "yes"` and a `table` descriptor; output destinations are its column fields. `overrideTable: "yes"` replaces rows; Append is also available. With `mapToTable: "no"`, the supplied `table` is null; retained `overrideTable` and `serverPaging` have no meaning and can be removed.

**Schema boundary:** the unchanged `1.1.0` schema accepts a descriptor for `FindItemsSettings.table`, not null. It therefore rejects that captured non-table serialization; report the mismatch without silently coercing the source or claiming conformance. See [validation limits](../validation.md#november-rule-configuration-coverage).

The SharePoint example maps source Country (`name: "Title"`, `type: "datafield"`, `fieldType: "Text"`) to Country Name, and source item ID (`name: "ID"`, `fieldType: "Counter"`) to Country Code. The label Country Code does not turn the item ID into a country-code lookup.

Error mapping can use `{"text":"Error message","name":"__errorMessage","type":"errorMessage"}` or a literal such as `{"text":"Yes","type":"text"}`. In the walkthrough these populate ErrorMessage and DidErrorOccur; `"Yes"` is a string, not a boolean.

## Query options

| Setting | Contract / observed value |
| --- | --- |
| `filter[]` | Source-query criteria, separate from outer rule conditions; groups/operands use their contextual descriptors. |
| `rowLimit` | Max rows; examples serialize both `100` and `"1"`. Preserve wire type. |
| `sortBy`, `sortByDir` | Example `"__CREATED"`, `"desc"` selects newest first. UI also offers Ascending. |
| `processSortBy` | Process sort descriptor, e.g. `{"text":"Created","name":"__CREATED","type":"__Field","fieldType":"DateTime"}`. SharePoint shows source columns in its own sort selector. |
| `offlineCache` | **Enable offline cache**; `"no"` in examples. Cache lifetime/refresh behavior was not captured. |
| `serverPaging` | **Enable server paging**, table mode; `"no"` in examples. Page-size/fetch lifecycle was not captured. |
| `queryAnyProcess` | **Query any process matching query?**, process source only; examples use `"no"`. Enabled scope was not independently clarified. |
| `queryType` | Process sources only: `"default"` adds no creator/assignee restriction; Created By limits to records created by the current user; Assigned To limits to their current assignments. The latter two wire values were not supplied. |

**Permissions remain enforced:** inaccessible process records are not returned. Default query scope and the query-any option are not authorization bypasses. Source-specific controls differ; the Office 365 method screen does not expose process-query/filter/sort options.

## Method metadata and mapping example

Office 365's supplied metadata contains `References[]` entries with `name`, `desc`, `type`, and recursive `parameters`. `inout: "IMPORT"` describes inputs; `"EXPORT"` describes outputs; `STRUCTURE` groups child parameters. Find Groups (`findGroups` in the tree) has `criteria` inputs `id`, `displayName`, `mail`, `mailNickname`, and a `result` structure with returned properties. Use actual connector metadata; do not invent a universal column list or copy the entire tree into every rule guide.

```json
{
  "list": {"text": "Find Groups", "type": "method", "isproc": true},
  "inputMapping": [{
    "left": {"text": "Display Name", "name": "displayName", "type": "field"},
    "right": {"text": "displayName", "name": "criteria:displayName", "type": "IMPORT"}
  }],
  "outputMapping": [{
    "left": {"text": "Email", "name": "email", "type": "field"},
    "right": {"text": "mail", "name": "result:mail", "type": "System.Reflection.RuntimePropertyInfo"}
  }],
  "errorMapping": [], "rowLimit": 100,
  "mapToTable": "yes", "overrideTable": "yes", "serverPaging": "no",
  "table": {"text": "Similar Contacts Table", "name": "similarContactsTable", "type": "field", "fieldType": "fields/field-table"}
}
```

This excerpt belongs inside `settings`; retain the actual connection ID in outer `datasource`. It maps a form value into method criteria, then returned mail into a table column. The metadata also exposes methods that modify external state; being selectable as a connector method does not make every method read-only. Inspect its contract and authorized effect before executing it.
