# Send email and Meeting request

Actions: **Send email** `rules/rule-sendemail`; **Meeting request** `rules/rule-meeting`. Both share audience selection, Subject, HTML Body and attachments. Meeting request adds scheduling fields and hides CC in its designer. [Rule index](../rules.md) · [expressions](./expressions.md) · [shared contracts](./core.md).

## Audience configuration

For an application-role audience, use [group-configurator](../../../../.agents/skills/group-configurator/SKILL.md) and record the role-to-group mapping in application documentation. Use actual returned group principals in the supported audience shape; do not replace role groups with guessed individual users or email addresses. Membership setup and delivery verification remain separate from configuration.

From, To, CC and BCC each have an audience-picker icon and corresponding `from`, `to`, `cc`, `bcc` settings object. The shared picker offers:

| UI selection | `selectionMode` | Active configuration |
| --- | --- | --- |
| Any user or partner | `userpicker` | `users` array of selected identities, including people (`type: "person"`) and groups (`type: "group"`). |
| User(s) defined in a user field | `fieldpicker` | `field` references a `fields/field-userpicker` field. |
| Form owner(s) | `formowner` | `field` references a form (`type: "form"`, logical `name`); recipients come from that form's `assignTo`. |
| Email address in a field | `emailaddress` | `field` references any field, including a textbox, or contains literal addresses as below. |

The last mode is a combobox: select a field or type addresses at design time. Field selection and direct text have different descriptors:

```json
{
  "selectionMode": "emailaddress",
  "users": null,
  "field": {"text": "useremail@company.com, user2@company.com", "type": "text"},
  "text": "useremail@company.com, user2@company.com"
}
```

`fieldpicker` filters eligible fields to user pickers and extracts emails from user identities at runtime; `emailaddress` uses different field filtering/extraction. Do not treat the modes as interchangeable. Exact user-field extraction internals and additional literal delimiters were not captured.

Keep the principal objects returned by the picker: the examples include identity GUID, `username` or `email`, names and `type`; group metadata may differ from person metadata. Resolve principals in the target workspace. `text` is a designer summary, not the authoritative identity list: one supplied example selected a group omitted from that summary.

Confirming the picker with **OK** updates `text`: e.g. `Field:Responsible Manager`, `Form owner:Contact Review`, or `Field:Email Address`. An intermediate picker snapshot can still have empty/stale `text`. Unused `users`/`field` commonly remain null. Empty From was observed; its runtime sender fallback was not established.

## Content, attachments and delivery

| Setting | Contract |
| --- | --- |
| `subject` | String supporting field tokens and the shared expression builder. |
| `body` | HTML string, including tokens/expressions. Owner confirms a CodeMirror-backed HTML editor for rich templates and Outlook conditional HTML markup. |
| `attachments[]` | File-field descriptors (`fieldType: "fields/field-file"`); the toolbar's **File** button opens **Attach file to email**, then **Insert attachment**. These reference fields, not literal file URLs. |
| `sendVia` | **Send via connector**. Agent default: `"no"`. |
| `trackMail` | **Enable tracking**. Agent default: `"no"`. |

Use the two agent defaults unless explicitly requested otherwise. Enabled connector/tracking settings were not captured; the existing schema mentions `connectorId`/`saveSent` but does not establish their complete configuration or delivery behavior.

Settings excerpt (sample field names; resolve actual descriptors/IDs before authoring):

```json
{
  "from": {"selectionMode": "userpicker", "users": null, "field": null, "text": ""},
  "to": {
    "selectionMode": "emailaddress", "users": null,
    "field": {"text": "Email Address", "name": "emailAddress", "type": "field", "fieldType": "fields/field-textbox"},
    "text": "Field:Email Address"
  },
  "cc": {"selectionMode": "userpicker", "users": null, "field": null, "text": ""},
  "bcc": {"selectionMode": "userpicker", "users": null, "field": null, "text": ""},
  "sendVia": "no", "trackMail": "no",
  "subject": "New Contact: [displayName]",
  "body": "<p>Hello,</p><p>Contact email: [emailAddress]<br>ProcessLink(\"Review it here:\")</p>",
  "attachments": [{"text": "Contact Card", "name": "contactCard", "type": "field", "fieldType": "fields/field-file"}]
}
```

## Meeting request additions

Use the same content/audience configuration with action `rules/rule-meeting`, plus:

| Setting | Selected value |
| --- | --- |
| `fieldStartTime` | Date-field descriptor, e.g. `nextReviewDate`. |
| `fieldEndTime` | Date-field descriptor, e.g. `endTime`. |
| `location` | Field descriptor, e.g. textbox `location`. |

The supplied JSON retains `cc` even though CC is intentionally hidden for meeting requests; preserve retained configuration without inferring CC delivery. Time-zone handling, invitation updates/cancellations and enabled connector/tracking behavior remain unverified. Designer inspection did not send email or meeting invitations.
