# Form assignment and Process security

Use for form owners and instance access. Assignment is distinct from process security; UI visibility is not authorization. [Rule index](../rules.md) · [shared contracts](./core.md).

When an application role is required, use [group-configurator](../../../../.agents/skills/group-configurator/SKILL.md) to resolve real groups against the documented persona/role design. Group creation during implementation supplies an identity; apply the supported security/assignment configuration separately and leave membership to administrators.

## Assign form

Action: `rules/rule-assignform`. Select one or multiple forms and the users to own them.

| Setting | Meaning |
| --- | --- |
| `form` | Primary form descriptor. |
| `forms[]` | Additional targets; the walkthrough stores each actual descriptor in an entry's `field`, alongside empty `name`/`text`/`type` wrapper values. |
| `assignTo` | Assignment source; confirmed values here are `currentuser` and `anyuser`. |
| `override` | `"override"` replaces existing users. Append supports progressive ownership assignment; its serialized value was not supplied in the walkthrough. |

Picker modes are **Any user**, **Current user**, **Defined in a user field**, and **Form owner(s)**. A user picker field can capture dynamic process roles. Preserve mode-specific references; do not derive their unobserved enum values from these labels. The baseline schema also recognizes `userpicker`/`userpickers`, without establishing every mode's complete settings.

Sample settings excerpt (resolve actual form names):

```json
{
  "assignTo": "currentuser",
  "override": "override",
  "form": {"text": "Contact Form", "name": "contact", "type": "form"},
  "forms": [
    {"name": "", "text": "", "type": "", "field": {"text": "Contact Review", "name": "form2", "type": "form"}},
    {"name": "", "text": "", "type": "", "field": {"text": "Approval", "name": "approval", "type": "form"}}
  ]
}
```

All three forms are targets. Assigned form users also supply the audience for the email rule's [Form owner(s) mode](./email.md#audience-configuration).

## Process security

The rule can replace or append process security users and optionally change security settings. Its exact action identifier was not supplied; use the installed designer/export rather than inventing it. It has the same four user-source modes as Assign form, including dynamic user picker values and form owners. Explicit users can include groups.

| Setting | Meaning |
| --- | --- |
| `assignTo: "anyuser"`, `users[]` | Explicitly selected identities; this does not grant everyone access. Preserve actual picker objects. |
| `override: "override"` | Replace existing security users; Append is also available. |
| `enableProcessSecurity: "no"` | Leave security settings unchanged; only append/replace security users. |
| `enableProcessSecurity: "yes"` | Apply the rule's new security settings, including disabling security. |
| `enableSecurity` | Boolean enabled state applied when the override-setting switch is yes; `false` disables security. |
| `securityMode: "securityOnly"` | **Security users only can create, view and update**. |

The other displayed modes are **Security users can create, assign to can update, everyone else can view** and **Security users can create, assign to can view and update**. Their serialized mode values were not captured; do not guess them or import page-security enums.

The owner-confirmed example uses `enableProcessSecurity: "yes"`, `enableSecurity: true`, `securityMode: "securityOnly"`, and an explicitly selected Admins group. Its group object contains `id`, `username`, `email`, `firstName`, `lastName`, `type: "group"`. Use actual picker objects; neither `role` nor `userDisplayName` is required by this example.

Keep the string override-setting switch separate from the boolean enabled state. Verify effective access using the target instance and user; these settings and the walkthrough are not a permission test.
