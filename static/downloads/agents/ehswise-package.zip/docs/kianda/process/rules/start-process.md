# Start a process and update a related instance

Action: `rules/rule-startprocess`. Use native process creation/lookup with mappings to relate records and processes. [Rule index](../rules.md) · [shared mapping contracts](./core.md#mapping-and-dependency-semantics).

| Setting | Meaning |
| --- | --- |
| `process2` | Destination process alias, e.g. `contact`. |
| `lookup: "no"` | Create a new destination instance. |
| `lookup: "yes"`, `lookupField` | Update an existing instance identified by the value of the referenced source field. This is a record ID, not a process-design alias. |
| `inputMapping[]` | Source-to-destination assignments: `left` is the source field/text; `right` is the destination field. |
| `outputMapping[]` | On-success mapping: `left` is the source instance's destination field; `right` is the destination instance's returned field/system value. |
| `errorMapping[]`, `tableMapping[]` | Present but empty in the walkthrough; their configured behavior was not captured. |
| `trigger: "yes"`, `target` | Trigger the selected field or rule in the destination instance. Example: Save & Close button. |
| `realTime` | Without-delay server execution of destination rules. **Always set `"no"` in agent-authored rules** (owner policy). |
| `ensureOrder` | Execute in series rather than in parallel on the server; useful for stable one-after-another execution. The example uses `"no"`. |

In the Contact example, input mappings copy First Name, Last Name, Display Name and Email Address. On success, destination **Process ID** (`{"text":"Process ID","name":"__NAME","type":"__Field"}`) is written to source **Clone ID**. A later lookup uses that Clone ID to update the related record.

Compact lookup settings excerpt (resolve real field/target descriptors and IDs):

```json
{
  "process2": "contact",
  "lookup": "yes",
  "lookupField": {"text": "Clone ID", "name": "cloneID", "type": "field", "fieldType": "fields/field-textbox"},
  "inputMapping": [],
  "outputMapping": [{
    "left": {"text": "Clone ID", "name": "cloneID", "type": "field"},
    "right": {"text": "Process ID", "name": "__NAME", "type": "__Field"}
  }],
  "errorMapping": [], "tableMapping": [],
  "trigger": "yes",
  "target": {"text": "Save & Close", "name": "form1btnSubmit", "type": "field", "fieldType": "fields/field-button"},
  "realTime": "no", "ensureOrder": "no"
}
```

Resolve mapping sides independently even when both processes share field names or design IDs. Selecting a target button/rule executes its behavior; review its dependencies and conditions before chaining processes. Missing-ID/no-match behavior and failure/transaction semantics were not demonstrated. No instance was created or updated during documentation capture.
