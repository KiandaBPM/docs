# Expressions and Set form field

Use for calculated values or the shared expression builder used by Subject, Body, Set form field and other settings. [Rule index](../rules.md) · [shared contracts](./core.md). Examples are settings excerpts; compact descriptors must be resolved against the actual process, including IDs and row context.

## Choose the implementation mechanism

Prefer native **Set form field** (`rules/rule-setfield`) for calculations and derived values. A short inline JavaScript expression suits local work. Reusable or independently testable logic can call a global helper in `js/app.js`; that helper may return a value or a Promise. Keep assignment in the native rule where practical, with explicit inputs and returned outputs rather than hidden state mutation.

JavaScript, multiple steps, reuse or asynchronous work alone do not justify a custom rule, component, endpoint or service. Identify the unsupported requirement, considering security, execution context, lifecycle, scale and maintenance. Verify helper/library availability, result types, recalculation triggers and error behavior in the target workspace. Preserve working implementations during unrelated work; this policy does not authorize migration.

## Set form field

`settings.outputMapping[]` supports multiple assignments:

| Entry | Meaning |
| --- | --- |
| `left` + `right` | Destination field receives source field or literal value. |
| `left` + `expression` + `hasExpression: true` | Destination receives the evaluated expression, including Promise-based results confirmed by the owner. |
| `left` only, without expression | Clears the destination (owner-confirmed); do not insert a dummy source. |

```json
{
  "outputMapping": [
    {
      "left": {"text": "End Time", "name": "endTime", "type": "field", "fieldType": "fields/field-date"},
      "expression": "DateAdd([nextReviewDate],0,0,0,1)",
      "hasExpression": true
    },
    {
      "left": {"text": "Meeting Room", "name": "meetingRoom", "type": "field"},
      "right": {"text": "Location", "name": "location", "type": "field"}
    }
  ]
}
```

This adds one hour to Next review date and copies Location to Meeting Room. Expressions use the technical field name in square brackets, e.g. `[displayName]`, selected from fields throughout the process. Resolve repeated table-column names in their row context.

## Shared expression reference

The designer showed these entries. They are a reference list, not an exhaustive JavaScript/helper inventory.

| Expression | Result / purpose |
| --- | --- |
| `+`, `-`, `/`, `*`; `Sum(arg1, arg2, ...)` | Arithmetic; sum arguments. |
| `Date(arg1)` | Convert an argument to a date. |
| `DateAdd(dateArg, day, month, year, hour, min)` | Add the specified time increments. |
| `Status()`; `ProcessID()` | Current process status; process instance ID. |
| `FormOwner('formName')` | Owners of the named form. |
| `FormCompleted('formName')` | Completion date of the named form. |
| `Pad(value, size, symbol)` | Left-pad a value. |
| `QueryString('parameter')` | URL parameter, or empty string when undefined. |
| `IsOnline()` | `"yes"` or `"no"` connectivity result. |
| `ProcessLink()`; `ProcessLink("Review it here:")` | HTML link to the current instance; optional string sets visible link text. Use in email/HTML contexts. |
| `WorkspaceURL()` | Workspace URL. |
| `Digest()`; `Digest('fieldName1','fieldName2')` | Summary of changes to all or selected fields. |
| `GetFieldText('fieldName')`; `GetFieldValue('fieldName')` | Field text versus field value. |

Subject can combine literal text and references: `New Contact: [displayName]`. HTML Body can contain `[emailAddress]` and `ProcessLink("Review it here:")`. The Update table values example also uses JavaScript: `"Updated " + moment().format("YYYY MM")`; verify `moment` availability before reuse.

### Other useful refereces
''

Historical examples additionally reference `User()`, `createGuid()` and `process.findFieldByName(...)`; their occurrence does not establish a portable built-in or unrestricted runtime context. Promise completion support does not establish failure rollback or native validation stopping behavior; see [execution boundaries](./core.md#identity-attachment-and-execution).
