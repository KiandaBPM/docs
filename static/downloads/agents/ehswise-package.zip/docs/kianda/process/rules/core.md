# Shared rule contracts

Read for attachment, execution, alternate settings, scheduling, conditions or reference integrity. Baseline `1.1.0`; [source labels](../evidence.md). For action settings, use the [rule index](../rules.md).

## Rule engine
The rule engine is the service for coordinating the execution of rules within a process once execution is triggered. Once execution is triggered an async startRun method is triggered to run rules from the owner triggering the run. Rules of the target object are split into 3 phases of execution.

## Rule queues and rule execution loop and 
The concept of rule queues is used to separate diffent phases of rule execution. There are 3 separate rule queues:
- **Validation queue**:  is the first phase => This queue is responsible for validation; Field button `fields/field-button` has a special boolean setting (settings.validate) that causes it to validate fields marked as required (field.required = true). This phase also runs special `rules/rule-validation` when conditions defined in rule.conditions are met the validation error message is triggered. If either required validation or validation rules do trigger validationit will cause that the next phase will not run.
- **Rules queue**: This is the phase where all other rules are executed. If the validation queue exits with errors this phase does not run. Rules are executed in the order they are defined in the parent.rules array.
- **Save & Close queue**: This queue only executes once the rules queue completes. The `rules/rule-close` rule `rules/rule-save` rules are special rules that execute in this phase. Close rules are sorted automatically to ensure they run after the save rule. 

When a rule loop is triggered a startRun async function is started that starts by runing the validation queue function followed by rules queue and by the save queue.

The validation queue if finds required field errors or executes a rule-validation will force the termination of the startRun async execution with an error.

### Events
There are a few ways rules are trigered;
- **Onload rules** or process rules; process.rules are automatically executed when the process is loaded by the user. They are useful to ensure the pre-use setup is done. For example adding a set form field rule on the process to set the record date if the record date field is blank.
- **Form submit rules** or form rules; these are rules associated to form.rules. These rules only trigger when the form is submitted via the submit form rule. The submit form rule emits a special event that triggers any rules associated with the form. This is not used too often since developers favour including their rules directly in the submit button;
- **Field change**; field.rules are typically triggered by the change event of the field.value via its associated observer on the value property. This is the most comon form of rule triggering event;
- **Button click**; `fields/field-button` do not capture data so they instead are used to trigger rules directly via the click event.


## Identity, attachment and execution

`action` selects implementation; a rule GUID is identity and `title` is descriptive. Do not invent a rule `name`. Preserve `originalId` separately; originalId is used when cloning the process design into an instance as the original process design Id since the cloning requires thata the rule be assigned a unique id. `datasource` can be a GUID-shaped identifier or a named token. datasource is used when a rule keeps reference to a datasource such CRUD rules `rule-finditems`, `rule-createitem`, `rule-updateitem` and `rule-deleteitem`.

Root `rules[]` attaches process rules; field `rules[]` attaches field rules; form rules remain structurally supported. Historical process rules put the process alias in `process` and field rules put owner GUID in `field`; that corpus had no populated `form` ownership keys. The November walkthrough supplies a form-attached Aggregate table rule with the form GUID in `form`. Historical relationships sometimes retain nulls. Rules can exist at process, form or field level. A rule should only have one of the parent objects not null. Do not require/fill all three references; check actual containment and attachment. [H §11; A–O; C2026-11]

Always preserve array order, particularly. The result of one rule can be used in subsequent rules. Save, Submit, Close, Assign, Validate and Navigate are separate operations. The custom-rule contract documented in [the application model guide](../../general.md) waits for a returned Promise, ignores its return value and continues after a thrown error/rejected Promise. Gate dependent saving, submission, notification or navigation explicitly. This does not establish every native validation action's stop behaviour, complete asynchronous runner semantics or transactional rollback. Verify those separately.

Implement initial load, changes/reversal, draft reopening and direct navigation through verified lifecycle hooks. Presentation recalculation should be safe to repeat; do not make each recalculation create records, send notifications or repeat external requests. Effective applicability must govern validation, completion, calculations and reporting. Preserve the agreed data-reversal policy, including derived values and related actions. [Designer contract](../design-journeys.md)

## Alternate settings

**Confirmed (C2026-23):** server `hasElse` is boolean and defaults to false when omitted. `elseSettings` is alternate configuration for the **same action**, not a separate action. Omitted/false leaves it operationally inactive; C2026 confirms ignored operational validity in that state. Preserve retained inactive targets/options without “repairing” them. Do not coerce string flags or insert an absent flag during validation.

Schema `1.1.0` applies action-specific alternate-settings constraints only for explicit `hasElse: true`; a present `elseSettings` still must be an object. A schema pass therefore does not certify editor readiness of every inactive retained query filter. SC's omitted flags demonstrate compatible serialization, not a runtime test.

## Scheduling

Outer `schedule` differs from `settings.task.schedule`. H observes outer `default`; tasks use `now`. Neither is an exhaustive enum. **C2026 confirms an executing schedule needs a field or rule target** in the observed `settings.target`; field targets are not button-only (H includes a date target; schema commentary also records list/number targets).

**C2026-23 exact supplied rule-target descriptor (ST):**

```json
{
  "text": "Save form",
  "name": "a0bbe568-c130-4fae-a886-7e7e176bb790",
  "type": "rule",
  "parentName": "btnSave",
  "parentType": "field"
}
```

`name` is the target **rule GUID**, matching SC `/forms/0/fields/0/rules/0/id`; `text` is a label. `parentName` is the target owner's logical name; `parentType` its kind. Do not invent target `id` or replace `name` with a title. The example establishes `parentType: "field"`, not an exhaustive kind enum or universal parent-key requiredness.

The owner excerpt's scheduling rule attaches to SC's textbox (`/forms/0/fields/1`); its target save rule belongs to `btnSave`. Source attachment and target parent are separate references. The excerpt uses `rules/rule-schedule`, `enabled: true`, outer `schedule: "default"`, a task with `settings: {}`/`schedule: "now"`, empty `conditions`/`elseSettings` and `hasElse: false`. It lacks an outer rule ID and has a trailing comma, so only ST's descriptor is a fixture, not a complete rule/app.

Schema checks a present rule-target `name` as a GUID when `type: "rule"`; it deliberately does not require all active target keys in every disabled/incomplete serialization. Existence, completeness and parent agreement remain operational/integrity checks. Do not add an unobserved `settings.rule` property. [H §11.6; C2026; C2026-23]

## Conditions and descriptors

`rule.conditions[]` contains groups, each with `conditions[]` and operands `arg1`/serialized `arg2`. The accepted direct condition shape requires `operator` and `arg1`; direct groups require GUID `id` and a `conditions` array (empty is not rejected). Individual condition-ID requiredness and recursively nested groups are not established. Preserve `group` connectors; complete evaluation, arity and group-token semantics need the engine contract.

Observed direct operators: `contains`, `eq`, `neq`, `gt`, `gte`, `lt`, `lte`, `isblank`, `notblank`; connectors: `and`, `or`. These are not exhaustive enums. Do not import page/query operators as proof of direct-rule support.

Operands can be sparse field, literal or system descriptors. Unary examples include 59 empty `arg2` objects and 164 containing only `{"name":""}`; A `/forms/0/fields/1/rules/0/conditions/0/conditions/0/arg2` is empty. Do not require `type`, `text`, `fieldType`, `id` or dummy date/value keys on every operand.

| Descriptor context | Meaning/limit |
| --- | --- |
| `type: "field"` | Reference kind; target component type can appear as `fieldType`. |
| `type: "form"` | May use logical name without ID. |
| Scheduled `type: "rule"` | `name` holds rule GUID, with target-parent context above. |
| System | Can use `__Field`. |
| Literal | Can carry `type: "text"` and text. |
| `settings.list` source selection | Integer `type`, e.g. `100`/`101`, is connector/source metadata, not a reason to widen every descriptor kind. A `/forms/2/fields/8/fields/1/fields/1/settings/list/type` is `101`. |

A closed universal descriptor union is premature. Resolve by action, kind, process and row/parent context.

Settings-level filters contain a separate observed 94 groups/138 conditions. Groups edited by `rules/rule-conditions` need GUIDs for UI deserialization/editing (C2026-23), even though the server does not intrinsically need them. Schema applies that contract only in known typed settings; `FilterGroup` requires `id`, not universally `conditions`. Inactive else branches bypass subtype checks. Keep query contexts/operators/counts distinct from direct conditions and arbitrary settings objects; individual query-condition ID requiredness is also unconfirmed. [H §§12–13; C2026; C2026-23]

## Mapping and dependency semantics

Mapping families (`inputMapping`, `outputMapping`, `errorMapping`, `tableMapping`, nested `columnMapping`, action-specific `mappings`) are not interchangeable. Mapping direction is action-specific; see the table below. Cross-process mappings also need separate source/target context.

| Rule / mapping | `left` | `right` |
| --- | --- | --- |
| [Set form field](./expressions.md#set-form-field), output | Destination field | Source field/literal; expression can replace this side |
| [Find items](./find-items.md), input | Current form value | Source method input |
| Find items, output/error | Destination form/table field | Returned source value/error/literal |
| [Start a process](./start-process.md), input | Current instance value | Destination instance field |
| Start a process, output | Field in current instance | Value from destination instance |
| [Lookup value from table](./tables.md#lookup-value-from-table), output | Source table column | Destination form field |
| [Update table values](./tables.md#update-table-values), output | Destination table column | Source form value/literal; expression can replace this side |

**Confirmed left-only clear (C2026; [Set form field](./expressions.md#set-form-field)):** a `rules/rule-setfield` output entry with only `left` and no expression clears its destination. It is complete for that purpose; do not add a dummy right operand/expression. A `/forms/1/fields/2/fields/1/rules/0/elseSettings/outputMapping/0` is an example. Other entries omit `right` in favour of `expression`/`hasExpression`, e.g. A `/forms/0/fields/1/rules/2/settings/outputMapping/0`.

Find-items `inputMapping` can contain empty placeholders; an empty placeholder is not thereby a clear operation. Required-field and person-attribute mappings have other shapes. Preserve optional editor metadata such as `lefterror`/`righterror` without requiring it everywhere.

Review name dependencies in expressions, `[fieldName]` tokens, custom code and affected page bindings/CSS selectors during renames. H examples include `GetFieldValue(...)`, `ProcessID()`, `User()`, `QueryString(...)`, `IsOnline()`, `createGuid()` and `process.findFieldByName(...)`; their names do not establish standard JavaScript behaviour.

Resolve external processes, data sources, Components, files and principals through authorized workspace information. A queried-process descriptor must not be rewritten to a similarly named local field. Email recipients can encode selection modes/field references; attachment/document-template values may be descriptors rather than URLs. Recipients can retain `field: null` in other modes. Four inactive alternate visibility actions retain null targets with `hasElse: false`; preserve them. Active unresolved targets need completeness checks. [H §§11.4, 13; C2026; A–O]
