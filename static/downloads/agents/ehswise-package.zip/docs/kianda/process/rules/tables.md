# Native table operations

Use these rules on runtime table rows, not to edit table definitions. [Rule index](../rules.md) · [expressions](./expressions.md) · [mapping directions](./core.md#mapping-and-dependency-semantics). Settings examples use compact descriptors; resolve actual IDs and row context. Rule **Edit conditions** govern whether the action runs; table lookup/aggregate `filter[]` selects rows within that action.

## Loop table

Action: `rules/rule-looptable`.

| Setting | Meaning |
| --- | --- |
| `table` | Table to iterate. |
| `tableField` | Column field or rule to trigger for each row; example: Remove Duplicate button. |
| `enableStartAction`, `enableEndAction` | `"no"` in the supplied example. UI supports an action before/after the loop; enabled target-property names were not captured. |

The owner confirms all rules on the target field are initialized before the run and asynchronous rules are awaited until completion. This does not establish row-removal iteration semantics or failure rollback.

```json
{
  "enableStartAction": "no", "enableEndAction": "no",
  "table": {"text": "Similar Contacts Table", "name": "similarContactsTable", "type": "field", "fieldType": "fields/field-table"},
  "tableField": {"text": "Remove Duplicate", "name": "removeDuplicate", "type": "field", "fieldType": "fields/field-button"}
}
```

## Lookup value from table

`tableFrom` selects the source table; `filter[]` supplies **Table lookup conditions**. In `outputMapping[]`, **left is the source table column, right is the destination form field**. This direction is specific to this rule. The action identifier and no-match/multiple-match behavior were not supplied; do not import Find items behavior as proof.

```json
{
  "tableFrom": {"text": "Similar Contacts Table", "name": "similarContactsTable", "type": "field"},
  "outputMapping": [{
    "left": {"text": "Email", "name": "email", "type": "field"},
    "right": {"text": "Email Address", "name": "emailAddress", "type": "field"}
  }],
  "filter": [{
    "id": "99fd5985-f298-464d-acfa-1a6e97f30756", "group": "and",
    "conditions": [{
      "id": "13ddcdf1-0c71-460f-b302-3e1cf043320c", "operator": "eq", "group": "and",
      "arg1": {"text": "Email", "name": "email", "type": "field"},
      "arg2": {"text": "Email Address", "name": "emailAddress", "type": "field"}
    }]
  }]
}
```

The sample also maps table Display Name into form Display Name. Filter/group IDs above are example identities; generate appropriate unique IDs for new configuration, retaining existing IDs on edits.

## Update table values

`tableFrom` selects the table to update; `filter[]` selects matching rows. In `outputMapping[]`, **left is the destination table-row field**; `right` supplies a form field/literal, or `expression` with `hasExpression: true` supplies the computed value. Its action identifier was not supplied.

The walkthrough updates matching rows' Display Name with `"Updated " + moment().format("YYYY MM")`, using `hasExpression: true`. The export retains an earlier `right: {"text":"Updated","type":"text"}` alongside the active expression; do not mistake retained editor state for a second assignment. Optional `lefterror`/`righterror` strings also appear; preserve without requiring them.

## Aggregate table

Action: `rules/rule-tablesum`.

| Setting / option | Meaning |
| --- | --- |
| `tableFrom` | Table to aggregate. |
| `operation: "sum"` | Sum `columnFrom`, a numeric column; write to `resultField`. |
| Average | Also aggregates a numeric column; its serialized operation value was not supplied. |
| Count | Counts rows satisfying `filter[]` if defined; numeric-column selector is hidden. Its wire operation value was not supplied. |
| `filter[]` | Optional **Table aggregate conditions**. |
| `autoUpdate` | Baseline schema declares a boolean. Owner confirms the UI option uses an Ember service/field-value observers to recalculate on observed changes without rerunning the rule. An enabled JSON example was not captured. |

```json
{
  "operation": "sum",
  "tableFrom": {"text": "Similar Contacts Table", "name": "similarContactsTable", "type": "field", "fieldType": "fields/field-table"},
  "columnFrom": {"text": "cardsCount", "name": "cardsCount", "type": "field", "fieldType": "fields/field-number"},
  "resultField": {"text": "Total Cards", "name": "totalCards", "type": "field", "fieldType": "fields/field-number"}
}
```

The full supplied rule is form-attached (`form` contains a GUID). Empty/nonnumeric aggregation behavior, observer teardown and whether structural row changes trigger recalculation were not demonstrated. No table mutation or aggregate execution was tested during capture.
