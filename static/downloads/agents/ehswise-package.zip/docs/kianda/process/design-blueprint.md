# Designer-to-builder blueprint

Use for a substantial new/adaptive process. For small changes, document a compact delta and affected-state checks rather than reproducing the whole specification. This Markdown contract is not a process document or new JSON schema.

Keep it with the application's specifications. Follow workspace convention; absent one, propose `specs/process-designs/<process-alias>.md` within authorized documentation work. Do not create a separate `spec/` folder. Lightweight requirement/decision/test IDs may aid traceability; never add them as undocumented process JSON properties.

```markdown
# Process design: <title>

Status: draft | ready-with-assumptions | ready-for-implementation | blocked
Process alias/target: <actual or explicitly proposed>
Design revision/date: <revision>
Mode: new | modify | review
Sources/baseline: <requirements, files/revisions, reference versions>

## 1. Outcome, participants and scope
Business outcome, users, success criteria, non-goals and constraints.
Existing behaviours and identities to preserve.

## 2. Requirements and assumptions
| ID | Requirement/assumption | Source/status | Acceptance evidence |
| --- | --- | --- | --- |

## 3. Business stages and form structure
| Stage | Form/section | Purpose | Participant | Why this boundary? |
| --- | --- | --- | --- | --- |
Explain where stage and form boundaries differ.

## 4. Decisions and dependencies
| Decision | Source/allowed answers | Blank/unknown | Affected areas |
| --- | --- | --- | --- |
Effective predicates/truth tables, including overlapping choices.
Use conceptual notation, not purported runnable Kianda syntax.

## 5. State and transitions
| Target | Initial state | Applicability | Visible/editable when | Required for | Completion condition |
| --- | --- | --- | --- | --- | --- |
Entry, changes, re-entry, reopening and programmatic updates.
Logical owner of each target state; conflicting writers.

## 6. Earlier-answer changes and data treatment
| Change | Values affected | Preserve/clear/review | Reactivation/downstream effects |
| --- | --- | --- | --- |
Include derived values, evidence, related records and completed work as relevant.

## 7. Navigation, validation and actions
Reachable paths, error correction and each action's actual effect.
Success gates, persistence boundaries, side effects and failure recovery.

## 8. Visual composition
Section order, grouping, controls, responsive layout and key states.
Supported CSS patterns and justified custom dependencies.

## 9. Ownership, security and reporting
Conceptual roles mapped to verified configuration or administrator steps.
Where application roles are required, use group-configurator and maintain:

| Persona / application role | Responsibility / intended grants | Existing or proposed group name | Actual group ID / resolution status | Process/page/email targets | Administrator membership task |
| --- | --- | --- | --- | --- | --- |

Record reuse/create decisions and scope; leave IDs unresolved until discovered/created.
Design-only work does not create groups. During implementation update this mapping
with real group IDs, applied bindings and remaining membership/access checks.
Reporting fields, relationships and migration/compatibility needs.

## 10. Implementation mapping and unresolved contracts
| Design item | Native mechanism/verified dependency | Evidence | Gap/blocker |
| --- | --- | --- | --- |
No fabricated JSON keys, rule settings, principals or command names.
For relationships using newer local Kianda process fields, identify their source
files/pending builder definitions and required publication order separately from
what live metadata currently exposes.

## 11. Acceptance scenarios
| Test ID | Starting state/participant | Action | Expected result | Verification method |
| --- | --- | --- | --- | --- |

## 12. Handoff
Readiness, material assumptions, blockers and files expected to change.
Separate recommendations, approved policy and runtime observations.
```

Omit sections only when genuinely irrelevant to a small task. The builder consumes this contract; if implementation evidence requires a design change, update it with the reason. Obtain approval only when the user's workflow or a consequential unresolved decision requires it; authorized end-to-end work does not stop automatically after design. Choose meaningful scenarios from [the review reference](./design-review.md), without treating its entire list as mandatory for every edit.
