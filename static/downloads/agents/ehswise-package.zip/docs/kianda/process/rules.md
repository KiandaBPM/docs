# Rule index

Open only the reference needed for the task. Process baseline **1.1.0** is unchanged. Configuration details combine historical evidence with the owner's November 2026 walkthrough; [provenance and limits](./evidence.md#rule-configuration-walkthrough).

## Choose native logic first

Use **Set form field** for calculated values, including JavaScript expressions, global helpers and Promise results. Use native query, mapping and table rules for supported data operations. Identify an actual unsupported requirement before adding custom development. [Expressions and implementation choice](./rules/expressions.md)

## Configuration references

| Rule / action | Read |
| --- | --- |
| Send email `rules/rule-sendemail`; Meeting request `rules/rule-meeting` | [Email and meeting requests](./rules/email.md) |
| Set form field `rules/rule-setfield`; shared expression builder | [Expressions and value assignment](./rules/expressions.md) |
| Assign form `rules/rule-assignform`; Process security | [Assignment and security](./rules/assignment-security.md) |
| Start a process `rules/rule-startprocess`, including updating an existing instance | [Process linking and mappings](./rules/start-process.md) |
| Find items `rules/rule-finditems`: processes, SharePoint, connector methods | [Data queries](./rules/find-items.md) |
| Loop table `rules/rule-looptable`; Aggregate table `rules/rule-tablesum`; Lookup value from table; Update table values | [Table operations](./rules/tables.md) |
| Identity, attachment, order, alternate settings, conditions, descriptors, mapping direction | [Shared contracts](./rules/core.md) |
| Schedule a rule `rules/rule-schedule` | [Scheduling and target descriptors](./rules/core.md#scheduling) |

## Other rules and coverage

These entries retain historical action coverage and designer-visible names. They are discovery pointers, not complete settings contracts. Inspect current configuration before authoring an undocumented action; never derive its identifier from its label. The historical corpus's **38 actions** is a source count, not the current platform inventory.

| Family | Observed actions / designer labels |
| --- | --- |
| Workflow | `rules/rule-hideordisable`, `rules/rule-makerequired`, `rules/rule-gotoform` |
| Form actions | `rules/rule-validation`, `rules/rule-save`, `rules/rule-submit`, `rules/rule-close`, `rules/rule-delete`; operations remain distinct |
| Communications | `rules/rule-alert`, `rules/rule-anonymouslink` |
| Data | Set subform field; Create item; Update item; Delete item |
| Users | `rules/rule-finduser`, `rules/rule-personattribute`; Invite partner; Update user property |
| Files | `rules/rule-copyfile`, `rules/rule-generatedoc`; Convert to PDF; Generate excel workbook; Set existing file; Merge PDF; Create a file anonymous link |
| Tables | `rules/rule-addrow`, `rules/rule-removerow`; Import CSV; Export CSV; Copy table rows; Clear table rows; Sort table; Hide / Show column |
| Dates | `rules/rule-addtime`, `rules/rule-calculatetime`, `rules/rule-dateformat` |

Historical tenant extensions under `client-rule/`: `custom-id`, `go-to-next`, `go-to-previous`, `open-form-dialog`, `set-process-status`, `question-custom-answers`, `question-custom-score`, `show-hide-related-questions`, `set-field-title`, `append-user`, `clear-user-picker`. These are workspace dependencies, not portable native rules.

## Authoring boundaries

- Resolve actual identities, principals, data sources and row/process contexts. Mapping direction varies by action.
- Agent policy: keep email `sendVia`/`trackMail` at `"no"` by default; always author Start a process with `realTime: "no"`.
- Preserve unrelated identities, order, inactive settings and wire types. `hasElse` defaults false; alternate settings configure the same action. [Details](./rules/core.md#alternate-settings)
- [Static validation](./validation.md), runtime verification and publication are separate outcomes. The walkthrough inspected configuration; it did not execute these workflows.
