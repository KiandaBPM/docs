# Kianda application model

Source document **1.0.0**, prepared **27 October 2026**; reorganized **4 November 2026**. The owner-adopted process baseline is **1.1.0**; page authoring remains **draft 1.0.0**, not an accepted release or runtime certification. This is source-based documentation. Recommendations do not add platform capabilities.

## Choose the affected surface

Use only the task's relevant reference; this overview is optional when the surface is already known.

| Task | Entry point |
| --- | --- |
| Processes, forms, fields, rules, mappings, reusable process Components | [Process knowledge](./process-knowledge.md) and unchanged [process schema](./process-schema.json) |
| Pages, widgets, queries, filters, navigation, HBS columns | [Page knowledge](./page-knowledge.md) and [page schema](./page-schema.json) |
| Custom field/rule/page implementation | [Addon knowledge](./custom-addon-knowledge.md) |
| Layout, styling or responsive behaviour | [CSS guide](./css-style-guide.md) |
| Existing data-source selection, metadata and consumer configuration | [query-configurator](../../.agents/skills/query-configurator/SKILL.md), [metadata contract](./datasource-metadata.md) |
| Application roles and workspace group resolution | [group-configurator](../../.agents/skills/group-configurator/SKILL.md), [bridge contract](./agent-bridge.md) |
| Business requirements | Relevant workspace/product specifications and current application documentation |

The export contains Kianda definitions, classic Ember component source and global JS/CSS. It is not necessarily an Ember CLI/npm application: inspect available tooling; do not invent build scripts, registrations or standalone scaffolding. The original schema filenames were `kianda-process-schema.json` / `kianda-page-schema.json`; the extension-v2 installation names above do not change their versions, dialects or identities.

## Workspace and application boundaries

A workspace contains processes, pages, installed addons, shared assets and configuration; its APIs use that workspace's domain and authenticated context. Resolve IDs, URLs, principals and dependencies there. One process can support multiple pages, and a page can combine multiple processes.

EHSwise/ESG terminology, asset hierarchies and names such as `processSubject`, `processProjectCode`, `processCustomID` or a component named `workspaces` are product/application conventions, not universal Kianda primitives. Reuse the target product's conventions; inspect their real definitions.

| Location | Role |
| --- | --- |
| `processes/**/*.json` | Complete processes and reusable Component definitions |
| `pages/**/*.json` | Complete pages and widget settings |
| `components/{fields,rules,widgets}/` | Exported custom JavaScript/Handlebars source |
| `js/app.js` | Global JavaScript and local helpers |
| `styles/app.css` | Global CSS, imports and local overrides |
| `docs/kianda/`, `specs/` when present | Platform references and application requirements |
| Root `AGENTS.md`, `CHANGELOG.md` | Workspace operating and change-record policy |

Search relevant application directories recursively. Grouping folders/filenames do not determine aliases, routes or installed registrations. Use the actual exported layout.

## Models and persistence

| Model | Responsibility / boundary |
| --- | --- |
| Process definition | Forms, recursive fields, rules and settings; distinct from a submitted instance |
| Form | Process-owned fields and workflow/presentation; utility forms are possible |
| Field | Input or content/control/container, including buttons, panels, dialogs, tables and groups; may own fields/rules |
| Rule | Configured action attached to process/form/field; conditions and order affect workflow |
| Instance | Runtime business document with data/lifecycle distinct from design identity/version |
| Page / placed widget | Record-finding/reporting/navigation surface; placed identity is distinct from component type |
| Summary | Indexed projection/aggregate; changing a returned object does not save an instance |
| Reusable Component | Process with `type: "Component"` and exactly one form, loaded by `fields/field-component` |
| Custom addon | Field/rule/page implementation with per-use settings; distinct from a Component process |
| Data source | Workspace-resolved source used by supported controls/rules/widgets |

A process has at least one form. Its tree is root `forms[]` / optional `rules[]`, each form's `fields[]` / optional `rules[]`, and recursive field `fields[]` / `rules[]`. Example textbox/button/Save/Close contents are not a universal minimum. Traverse entity collections: a group field's `settings.fields[]`, selectors and mappings can contain **references**, not new child entities.

A Component field references the Component process through `settings.componentId`; the first form's content loads, and the referenced `MajorVersion` is stored in field `settings.version`. Do not simulate loading/upgrading by blindly copying expanded descendants. Upgrade identities and local override retention remain unresolved in the process source.

| Operation | Established effect |
| --- | --- |
| Local JSON edit | Local definition change; remote synchronization/publication follows the actual extension workflow |
| Developer component update | Documented compile/update of implementation, separate from configured uses |
| Save page/widget settings | Configuration persistence, independent of displayed records |
| Change runtime field `text`/`value` | Current model change; persist through Save rule/surrounding commit workflow |
| Execute custom rule | Action/model changes; an external effect may persist before the process save |
| Query summaries | Read indexed projections/aggregates |

**Custom rule failure does not stop the sequence:** the engine awaits `execute()`'s returned Promise, ignores its return value, and continues after throw/rejection. Later Save/notification/navigation actions need explicit success conditions. Prior field writes or external uploads are not rolled back. Exact hooks/notifications are in [field contracts](./addons/fields.md) and [rule execution](./addons/rules.md).

## Identity and references

| Identity | Handling |
| --- | --- |
| Process alias | Readable `id` / `name`; preserve accepted historical root-`id` omission and check equality when both exist |
| Page alias | For a new complete page, emit equal readable non-GUID `id` / `name`; check workspace uniqueness |
| Forms, fields, rules, placed widgets | Entity GUIDs; retain on edits, allocate for genuinely new entities |
| Addon identifier | Exact installed `client-field/`, `client-rule/` or `client-widget/` implementation, shared by configured uses |
| Summary instance identity | Use `Summary.name`; it need not be a GUID. `Summary.id` can carry a widget suffix; do not split it |
| Query identities | Apply the specific surface's contract, not a global rule for every `id` |

Titles are labels: changing one does not require renaming an alias/logical field or regenerating an ID. Repeated widget titles are allowed; connections use IDs. Field-name scope includes all descendants in the same table row; corresponding fields in different rows may repeat. A field outside rows is checked against all process fields, including rows. Components do not create a separate namespace. Resolve ambiguity using process/row/parent context; deeper nested-row scope remains qualified by the process guide.

Descriptor `type` identifies the reference kind; `fieldType` may identify its implementation. Page process-field bindings use exact `name` and the real field's outer `type` as `fieldType`, preserving punctuation including `?`. The scheduled-rule target's `name` instead stores a rule GUID with parent context. A descriptor is not a new entity. Renames/clones must follow real entity/reference relationships, including mappings, expressions/tokens, connections, templates, containers and CSS/DOM selectors; do not globally replace GUID-like strings or external references.

## Business and reporting choices

These are authoring practices, not new root process types. Reference records and transactions can both use ordinary processes; do not invent `Reference` / `Transaction` type values. Choose verified selectors/mappings and whether displayed reference data stays current or captures a value. Automatic cascades, deletes and synchronization are not implied.

Use a table for details sharing the parent lifecycle; consider separately related instances when children need independent ownership, status or reporting. Summaries index fields outside tables, including panels/dialogs, and custom fields' `field.text`; table cells and arbitrary nested custom-value properties are not independently searchable. Explicit reporting totals/fields need a supported maintenance design.

Indexing is asynchronous after save; a refresh may briefly return older values. Use the saved instance result/retrieval for immediate document confirmation rather than promising a fixed indexing delay. Raw REST summary results are arrays, with list totals in `total-items`; client-store metadata/cache are a separate layer. [Summaries contract](./addons/summaries.md)

Pages have an ordered widget array and separately ordered `settings.containers[]`. Widget `class` is layout and `customCssClass` is styling. A custom HBS column remains part of a native list. Author filter relationships in `settings.connections`; selections, `filterId` and incoming target copies are runtime state. Preserve fixed predicates and unrelated existing snapshots. Defaults apply before query-string values, which win on render. Filter fan-out and tile/chart drill-down are distinct; a tile does not automatically inherit a connected list's filters. [Page entry](./page-knowledge.md)

## Keep surface contracts separate

| Topic | Boundary |
| --- | --- |
| Relative dates | Saved page config retains relative operators without invented `date1`/`date2`; widgets prepare a copied request at refresh, and external REST callers prepare appropriate UTC boundaries themselves |
| Query IDs | Page groups **and conditions** require GUIDs. Process direct-rule and known settings-query groups require GUIDs; process individual-condition requiredness remains unconfirmed. Raw API illustrative IDs do not relax saved-page requirements |
| `processSource`, `isPartner` | Preserve historical page settings on unrelated edits; omit deprecated keys from new Summaries requests |
| Native widget vs API | A generic API/custom widget option does not establish a native settings/UI contract |
| Layout keys | Field/widget outer `class` differs from other legitimate `cssClass` contexts; no global rename |
| Versions | Documentation/schema versions, process design version, Component `MajorVersion` and instance version are distinct |

The supplied runtime is classic **Ember 2.18** with Handlebars and the installed **Bootstrap 3** environment. Do not infer newer Ember conventions, libraries or a Material component package. Summary records have documented IndexedDB-backed cache behaviour; visibility flags such as `offlineVisible` do not prove complete offline data, integrations or uploads.

Summaries enforce instance permissions for list and aggregate contributions; `queryType: "all"` means matching accessible records. Hidden fields are not field-level API security. Page `visibleTo` restricts loading; widget `visibleTo`, Link `users`, navigation/CSS hiding and membership helpers only affect presentation. Empty restrictions do not prove anonymous access. **Owner clarification, 7 November 2026:** design defines personas and roles; authorized implementation can resolve and bind actual workspace groups through [group-configurator](../../.agents/skills/group-configurator/SKILL.md), superseding the earlier page V1 principal deferral. Create groups only after detailed design when implementation begins; design-only work may look up and plan groups. Membership remains an administrator task, and group creation proves neither membership nor effective access. Preserve existing restrictions and Chart v2 definitions; do not author new Chart v2 under this page baseline. [Security handoff](./page/security.md)

## Evidence and completion boundaries

Both schemas are Draft 2020-12. Validate without coercing values, inserting defaults or removing unknown keys. Open settings are compatibility allowance, not proof invented keys work. Schema, semantic dependencies, runtime/visual checks, local writing, publication and instance saves are separate claims. An invalid historical fixture may correctly be rejected. Follow root change-record policy and keep diagnostics/transport metadata out of application JSON.

Evidence labels: **confirmed/documented** = explicit owner clarification or developer contract; **observed** = supplied example/source, not a universal default; **authoring practice** = recommendation; **unresolved** = needs current implementation/workspace evidence. Compare surface, phase and version before treating sources as contradictory. Do not let API guidance silently rewrite saved-page contracts or old examples broaden confirmed enums.

Use the [agent bridge contract](./agent-bridge.md) for current extension transport and supported operations. Local definition edits still require the extension's separate Publish workflow. Remaining limits include extension rename/delete details beyond the supplied README; alias alphabets/reserved names; some nested-row scopes; Component upgrades; installed addon/helper inventory; offline behaviour; rendering and effective permissions. Detailed qualifications stay with their topic references.

| Source label | Original supplied source |
| --- | --- |
| PROC | `kianda-process-schema-v1.1.0(1).zip`: knowledge, schema and README |
| PAGE | `kianda-page-authoring-v1.0.0(1).zip`: knowledge, schema and README |
| FIELD / RULE / WIDGET | `field-widget.md`, `rule-widget.md`, `page-widget.md` |
| SUMMARY | `summaries(1).md` |
| UPLOAD | `upload-public-file(1).js` / `.hbs` |
| WORKSPACE | Owner's extension-v2 layout/instructions used by the original authoring task |

Original filename citations are provenance, not a requirement to install those archives. They and historical reports/fixtures are not included in this bootstrap. Current documentation reorganizes those supplied claims; it does not independently certify the historical runtime or promote tenant principals/business records/URLs to portable defaults.
