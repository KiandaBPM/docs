# Page validation, limits and evidence

Source-based topic reference from [page-knowledge.md](../page-knowledge.md). Original section numbers are retained for source citations. Group-resolution policy follows the **7 November 2026** owner clarification; other evidence qualifications and the **draft v1.0.0** page baseline remain unchanged. Source labels are in the [source register](#201-sources-used).

Historical source archives, gold exports, fixtures and `kianda-page-validation-report.md` are provenance references; they are not included in this bootstrap. The source guide reports checks against four unchanged gold exports. Do not infer that those checks ran in the current workspace. The schema uses local identifier `urn:kianda:page-schema:1.0.0`.

### 1.1 Evidence labels

| Label | Meaning |
| --- | --- |
| **Confirmed** | Explicit platform-owner clarification. The latest clarification wins over an earlier unresolved point or proposal. |
| **Documented** | Stated in the owner-supplied Page Copilot draft or internal styling guide. |
| **Observed** | Present in a supplied export. This establishes a representation, not universal requiredness, defaults or runtime correctness. |
| **Profile / policy** | An explicit choice in this draft schema or a recommended agent practice. It is not a newly discovered server rule. |
| **Unresolved** | Not settled by the supplied sources. Preserve existing data and expose the uncertainty rather than inventing behaviour. |

Portable source labels are defined in the source register below. They refer to files and sections, not to transient chat links. The owner answers in `Pasted text(7).txt` supersede the handover's earlier open questions where they address the same point. The original Page Copilot's edit-only generator design and the prior assistant's patch protocol are historical, not the scope or persistence contract here.

The process schema and `process-knowledge.md` remain authoritative for process objects. Use their organizational conventions, but do not copy process-only properties into pages or infer that a page query is a workflow rule. In particular, the latest page-specific confirmation requires individual page-condition GUIDs; do not rewrite unrelated process contracts merely because this page guide has a stronger explicit confirmation.

## 16. Validation and diagnostic policy

### 16.1 Three separate layers

| Layer | What it can establish | What it cannot establish alone |
| --- | --- | --- |
| JSON parsing and structural schema | Valid JSON, required profile keys, known types, selected enums, GUID shapes, contextual settings constraints. | Alias equality, reference resolution, installed components, query meaning, permissions, rendering. |
| Semantic/integrity checks | Matching aliases, identity collisions, container/connection resolution, scoped binding consistency and known authoring-policy violations when sufficient inputs exist. | Actual server authorization, data quality, HBS compilation, mobile/offline behaviour or every runtime rule. |
| Runtime acceptance | Real initialization, filtering, navigation, compilation, role restrictions and rendered behaviour in the target workspace. | Completeness beyond the scenarios actually exercised. |

The provided schema is Draft 2020-12. Its versioned URN is a local identifier, not a hosted schema endpoint. Every reference in it is local. Use a validator that supports the dialect; enable `uuid` and `date-time` format checking. The GUID definition also has a pattern so a basic GUID-shape failure is caught even if format checking is disabled.

The schema deliberately does not coerce values, insert defaults, remove properties, remap IDs or normalize runtime state. Configure the integration likewise. `x-kianda-coverage` is an informational annotation on two partially covered settings definitions, not an executable validator or a capability registry; a validator with a strict custom-keyword policy may need to recognize that annotation.

### 16.2 Structural profile decisions

Owner-confirmed rules and draft profile choices are not interchangeable:

| Decision | Basis |
| --- | --- |
| Root `id` and `name` required | Explicit owner confirmation. |
| Root `title`, `settings`, `widgets` required | Chosen complete-document profile, consistent with the owner minimal examples. |
| Widget `id`, `type`, `settings` required | Chosen complete-widget profile; GUID identity and component settings are documented. |
| Widget `page`, title/frame/layout properties optional in schema | Universal input requiredness not established. New-authoring guidance emits the demonstrated envelope. |
| Container class strings required with a declaration | Chosen complete-container profile based on the supplied declarations. |
| Group and individual condition GUIDs required | Owner-confirmed UI authorability requirements for the shared model. |
| Process-field selectors require `fieldType` | Owner-confirmed importance for typed query execution. |
| Binary query operands require `type` | Owner-confirmed literal discriminator, applied to a complete binary-comparison profile. |
| HTML content / list fields / Link links / filter connections / walkthrough steps required for the corresponding known configuration | Explicit profile choices to describe usable configured widgets rather than all partial designer construction states. |
| Count has no required measure; sum/avg need a numeric selector | Documented tile contract. |
| Known native settings dispatch by exact `type` | Schema design: invalid known settings cannot bypass constraints through a generic fallback branch. |
| Open objects and opaque unknown settings | Confirmed extensibility direction plus compatibility policy; not a guarantee that arbitrary new settings work. |

Some known strings remain deliberately open, including chart aggregate spellings beyond the verified Count value, observed filter-mode catalogues and ancillary metadata with unknown non-null shapes. The knowledge file restricts new generation to supported patterns even when the compatibility schema accepts a broader representation.

Chart v2's structural acceptance is intentional for retained exports. Its V1 creation prohibition is an authoring-policy check, not a ban on preserving an existing document. The earlier V1 principal-assignment deferral is superseded by the 7 November 2026 owner clarification: [group-configurator](../../../.agents/skills/group-configurator/SKILL.md) can resolve and bind actual groups during authorized implementation after detailed design. This changes authoring policy and descriptive schema annotations, not structural assertions or the schema identity. Membership and effective-access testing remain separate.

### 16.3 Diagnostic convention

A useful diagnostic has `path`, `code`, `message` and an explicit severity. JSON Pointer paths identify the affected location. Keep diagnostics outside page JSON. These codes are a proposed integration convention, not a deployed Kianda API:

| Code / class | Handling |
| --- | --- |
| `E_PAGE_ALIAS_MISMATCH` | Block a complete page when `id` and `name` disagree. |
| `E_PAGE_GUID_ALIAS` / `E_PAGE_URL_UNSAFE` | Block new invalid aliases; still obtain the exact workspace naming rules. |
| `E_WIDGET_DUPLICATE_ID` | Block duplicate actual widget identities; repeated titles are allowed. |
| `E_PAGE_OWNERSHIP` | Block a serialized widget ownership mismatch. |
| `E_CONTAINER_NOT_FOUND` / `E_CONTAINER_DUPLICATE` | Resolve dangling or ambiguous named regions. |
| `E_CONNECTION_TARGET_NOT_FOUND` / `E_DRILLDOWN_TARGET_TYPE` | Resolve missing/incompatible known targets. |
| Binding error / ambiguity | Resolve real process fields and types; do not fabricate descriptors. |
| `W_WIDGET_SETTINGS_OPAQUE` | Preserve unknown tenant settings and report incomplete coverage. Missing installation is a separate availability issue. |
| `W_CAROUSEL_PARTIAL` | The known tenant carousel is only partially described; verify its installed implementation. |
| `W_CHART2_COMPATIBILITY` / `E_CHART2_NEW_AUTHORING` | Preserve existing Chart v2, but do not create it in V1. |
| `W_REPEATED_TARGET` | Review repeated connection targets; do not auto-deduplicate. |
| `W_CONTENT_FIRST_COLUMN` | Confirm the first-column-only Content styling matches the intended list. |
| `W_RUNTIME_DATE_BOUNDARY` / `E_RUNTIME_DATE_BOUNDARY` | Preserve existing captured relative dates with context; do not author concrete new relative boundaries. |
| `E_RUNTIME_FILTER_STATE` | Do not seed new canonical filters with runtime `filterId` state. |
| `E_V1_SECURITY_ASSIGNMENT` (historical) | Earlier V1 principal deferral; superseded for authorized group resolution by GROUP-2026-11. Do not reject a verified group binding solely under this historical policy. |
| Template/helper/action/asset coverage issue | Preserve unrelated legacy content; block or qualify new use according to its actual missing dependency. |

Unknown settings warnings do not mean that runtime or security checks passed. Standard JSON Schema validation does not itself emit these semantic warnings. The accompanying report records the subset actually checked by the analysis harness; it is not a shipped production semantic validator.

### 16.4 Minimum acceptance checklist

Before calling a page definition ready for runtime review, verify parse/schema success; page-alias consistency and workspace uniqueness; distinct widget identities; owning-page/container/connection resolution; process aliases and scoped field types; intended filter coverage; canonical new filter state; runtime-resolved relative dates; hidden template dependencies; supported helpers/actions; safe native navigation; preserved unrelated permissions; verified role-group bindings; and the remaining membership/security handoff.

Then distinguish explicitly what has not yet been checked: target-workspace installation, returned data and aggregate correctness, HBS compilation, cascade/reset behaviour, date boundaries, responsive display, accessibility and effective role access. Do not label all of these "validated" because the JSON schema passed.

## 17. Tenant add-on schemas: future direction

The owner requested a future way for tenant developers to provide settings schemas that can be side-loaded. This is not implemented by the supplied sources or this deliverable.

A proposed design is to associate an exact runtime type such as `client-widget/<component-id>` with a trusted, version-matched settings schema, plus separate authoring/dependency metadata. That metadata could describe reference-bearing properties, filter-target support, source/value contracts, tokens and required assets. The host, not an arbitrary page, should select the approved contract for the destination workspace.

Validate the common widget envelope first, then the matching add-on settings contract. Keep "unknown contract" distinct from "known contract violation". Preserve arbitrary settings when a trusted add-on is absent, with the agreed coverage warning. Never let an opaque fallback bypass a known native or installed add-on constraint.

Do not invent an existing manifest filename, registry endpoint, installation command or addon-discovery API. Do not add proposed registry metadata to saved page JSON. [HANDOVER sections 3.1, 14.5]

## 18. Remaining limits and runtime acceptance checks

The owner's answers resolve the principal blockers; the following narrower limits remain visible rather than being filled with guesses:

| Remaining point | Current handling | Evidence needed for fuller coverage |
| --- | --- | --- |
| Exact alias alphabet, reserved names and case rules | Generate conservative readable slugs and check known workspace aliases; preserve existing aliases. | Route/model validation contract. |
| Ancillary non-null metadata and originalId lifecycle | Preserve opaquely or with the observed type; omit on new pages where not needed. | Current model/serializer. |
| Untagged source-predicate duplication between `conditions` and `datasourceFilter` | Preserve fixed source intent; no automatic normalization. Incoming connection state is runtime-owned. | Source-query adapter/serializer. |
| Longer mixed Boolean chains | Keep grouping/order; avoid claiming unverified precedence. | Evaluator or exact examples. |
| Date-range upper boundary, DST and relative refresh timing | Let runtime compute; no author-generated boundaries. | Date adapter and scenario tests. |
| Query-string duplicate keys, empty values, history and cascade invalidation | Avoid conflicting newly authored keys and expose the unknown cases. | Filter/Link implementations. |
| Other Chart v1 aggregates/second series and `processSource` modes | Author verified patterns; preserve unknown existing strings. | Current chart/query settings code. |
| `mmoment-diff` spelling and full installed helper aliases | Preserve the reported list, use demonstrated helpers, verify questionable names before new use. | Installed helper registry/package configuration. |
| Full `execute` instance binding and `applyFilter` routing details | Preserve supplied signatures; do not invent dispatch payloads or target semantics. | Actual action implementations and calling examples. |
| Walkthrough selector/actions, non-empty carousel buttons and arbitrary tenant settings | Existing compatibility; new use requires verified component/DOM contracts. | Component sources/add-on schemas. |
| Cross-container rendering, offline data and full content sanitization | Configuration is not certification; review actual runtime. | Renderer and targeted workspace tests. |
| Group membership and effective role access | Resolve/bind actual groups through [group-configurator](../../../.agents/skills/group-configurator/SKILL.md) during authorized implementation; administrators configure membership. | Allowed/denied role tests and the relevant process/record-security contract; group creation alone proves neither. |
| Complete Link principal-object contract | Preserve existing profiles; bind resolved groups only through a verified control-specific representation. | Current picker/export contract where the bridge response is not sufficient. |

Chart v2 is not an unanswered V1 feature request: it is explicitly out of scope for new V1 authoring. Page-specific utility classes and Content's first-column behaviour are now resolved by the owner/guide, not still listed as missing evidence.

Suggested runtime scenarios are initial load with no URL; configured default; URL overriding that default; selection change; clear; parent/child cascade invalidation; navigation and reload; a date range crossing a local day/month/DST boundary; tile/chart drill-down; custom-column navigation; empty results; desktop/mobile presentation; and permitted/denied direct access after administrator security setup.

The page exports are not an HTTP API specification. Do not derive Summaries endpoints, authentication, record-security behaviour, HTTP pagination or update protocols from these settings. Use separately maintained, version-matched API documentation when such implementation is actually requested.

## 20. Source register and change traceability

### 20.1 Sources used

| Label | Source | Use and limits |
| --- | --- | --- |
| OWNER | `Pasted text(7).txt`, supplied 23 October 2026 | Owner answers to the seven clarification groups, minimal page examples, custom-column code/actions and Content CSS. Authoritative for the addressed facts unless superseded by a later clarification; illustrative snippets are not all strict JSON. |
| GROUP-2026-11 | Owner clarification, 7 November 2026; [group-configurator](../../../.agents/skills/group-configurator/SKILL.md) and [bridge contract](../agent-bridge.md) | Design establishes personas/roles. Actual groups may be resolved and bound during authorized implementation, with creation only after detailed design when implementation begins. Design-only work permits lookup/planning; membership remains an administrator task. Supersedes the earlier page V1 principal deferral without changing the draft page baseline or certifying runtime access. |
| HANDOVER | `kianda-page-handover(1).md` / `kianda-page-handover.md`, prepared 23 October 2026 | Detailed page synthesis, evidence distinctions, source inventory and earlier unresolved questions. Latest OWNER answers supersede addressed uncertainties. |
| DRAFT | Original `sources/original/Page Copilot.md` in the handover pack | Original page/widget/query sketches and registration settings. JavaScript-like examples, not a pre-existing schema. Its generator request is historical, not the current task. |
| G-HOME | `home-page-gold-example.json` | Original static/home/custom-carousel/walkthrough export; 9 widgets. |
| G-OBS | `observation-report-gold-example.json` | Original analytics/filter/chart/tile/list export; 16 widgets. |
| G-CREATE | `create-new-gold-example.json` | Original native process-launcher export; 4 widgets and 21 Link items. Contains private principal profiles; not bundled in the reusable examples. |
| G-PROJECT | `my-project-gold-example.json` | Original contextual/cascading-filter/card-list/custom-carousel export; 8 widgets. |
| STYLE | `Kianda Process Apps Styling Guide.docx`, supplied 23 October 2026 | Text of all three pages, including the three page-oriented CSS classes and global stylesheet override guidance. No computed-style/runtime verification claimed. |
| PROCESS | Accepted [process-knowledge.md](../process-knowledge.md) v1.1.0 and header/profile of [process-schema.json](../process-schema.json) v1.1.0 (original source filename `kianda-process-schema.json`) | Consulted for evidence labels, authoring organization, identity/binding context and schema conventions. Not re-audited as a complete process validation corpus for this page task. |

The prior refined Page Copilot and system prompt were available in the archive but were not promoted to platform contracts. No public-web material was used to fill gaps. The complete original page exports were parsed programmatically and their fingerprints checked against the handover.

### 20.2 What changed from the handover's unresolved state

The original page guide established both page aliases and server metadata ownership; complete workspace process inputs; the execution importance of field types; canonical filter connections and transient state; URL/default precedence and clear behaviour; individual condition GUIDs; operand text/value precedence; page-query exclusions and membership support; the historical V1 security deferral and visibility semantics; runtime date boundaries and end-user date-range timezone; custom-column allocation/name2/row mappings; supplied helpers/actions; the three native Link types and modal option; Chart v2's V1 exclusion; and verified page classes/Content styling. GROUP-2026-11 supersedes that principal deferral for authorized group resolution; the page-load versus presentation-only visibility boundaries remain.

It deliberately does not turn the remaining gaps into guessed defaults. The schema's requiredness choices, compatibility allowances and authoring policies are described separately from owner-confirmed platform behaviour.

Use the schema's unchanged structural assertions for structural checks. Historical validation reports describe source-package checks only; current validation and runtime evidence must be reported separately.
