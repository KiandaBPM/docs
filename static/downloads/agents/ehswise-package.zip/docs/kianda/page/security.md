# Page security and administrator handoff

Source-based topic reference from [page-knowledge.md](../page-knowledge.md). Original section numbers are retained for source citations. Group-resolution policy follows the **7 November 2026** owner clarification; other evidence qualifications and the **draft v1.0.0** page baseline remain unchanged. Source labels are in [validation and evidence](./validation-evidence.md#201-sources-used).

## 13. Group resolution, security and administrator handoff

### 13.1 Confirmed semantics

| Surface | Owner-confirmed behaviour |
| --- | --- |
| Page `visibleTo` | Controls page security. A user outside the configured group restriction is denied access to load the page. |
| Widget `visibleTo` | Controls client-side widget visibility. The page model is downloaded to the browser; hidden widgets are not a server-side secrecy boundary. |
| Link `users` | Similar visibility restriction for individual Link items. |
| Empty `visibleTo` / `users` arrays | That additional security restriction is not enabled. This does not establish anonymous access or disable underlying record authorization. |

The full interaction with `isPublic`, partner settings and other authorization layers is not supplied. `settings.hide`, `visible: false`, CSS hiding, list query scopes and `is-member` are not substitutes for appropriate security. [OWNER section 5]

### 13.2 New pages versus existing pages

**Owner clarification, 7 November 2026:** the earlier V1 principal-discovery deferral is superseded for authorized group resolution. The designer defines personas and application roles. Use [group-configurator](../../../.agents/skills/group-configurator/SKILL.md) to resolve existing groups and bind actual identities during authorized implementation; create missing groups only after detailed design when implementation begins. Design-only work may look up groups and record a plan, but does not create them. Use the [bridge contract](../agent-bridge.md) for transport rather than inventing calls or identities.

Page/widget `visibleTo` stores actual group IDs; Link `users` stores the verified principal representation required by that control. Do not insert a group response into every consumer unchanged. Omitted or empty restrictions remain unconfigured, and creating a group establishes neither membership nor effective authorization. Administrators manage membership.

For existing pages, preserve unrelated `visibleTo`, Link `users`, `adminOnly`, `isPublic` and process security. Do not clear existing restrictions to make an example reusable. Changing security must be within the authorized task, not a formatting operation.

Do not set `isPublic: true` by inference. Do not invent an administrator's identity, auto-select a similarly named group, or copy expanded user profiles from gold examples.

### 13.3 Required handoff when roles are part of the requested app

Record completed group bindings and a short, app-specific administrator checklist outside the persisted page JSON:

1. List each designed role, its resolved workspace group, whether reused or created, and any unresolved binding. Administrators assign and review group membership.
2. Record page-load restrictions already implemented through page `visibleTo`, with exact page aliases; identify any remaining authorized configuration or administrator steps.
3. Record additional widget/Link visibility rules and remaining setup, stating that these are presentation restrictions and cannot protect the downloaded model or data on their own.
4. Configure any outstanding underlying process/record permissions under the process security contract and verify their effect. Do not rely on page filtering to prevent unauthorized record access.
5. Test allowed and denied roles using direct page URLs, record access and navigation as well as menu visibility after membership and permissions are configured. Review public/partner settings where relevant before release.

For a role-sensitive app, report group resolution, persisted restrictions, membership setup and effective-access checks separately. Identify pending work and its effect on role-restricted release readiness. A group ID or a structurally valid page is not proof of secured runtime access. The original page-load versus visibility semantics remain [OWNER section 5]; the group-resolution update is [GROUP-2026-11](./validation-evidence.md#201-sources-used).
