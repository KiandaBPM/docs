# Page and widget model

Source-based topic reference from [page-knowledge.md](../page-knowledge.md). Original section numbers are retained for source citations; evidence status and unresolved qualifications are unchanged. The page authoring baseline remains **draft v1.0.0**. Source labels are in [validation and evidence](./validation-evidence.md#201-sources-used).

## 4. Page identity, root properties and metadata

### 4.1 Alias and navigation identity

`id` and `name` are aliases of the page identity and must both be present and equal. The general owner guidance describes routes `/pages/{id}` and `/dashboards/{id}`; the [EHSwise baseline](../../workspace/pages.md) uses `/dashboard/{page.id}`. This source difference does not establish interchangeable route spellings. Preserve working customer links and verify the target route before authoring navigation. Choose a unique, readable, URL-friendly, non-GUID alias; derive it from the page's purpose rather than treating a widget GUID as a route.

**Recommended new-authoring convention:** lowercase words separated by hyphens, such as `overdue-actions`. This convention is not an exhaustive platform alphabet. Exact reserved names, case sensitivity and all allowed URL characters remain unspecified. Check workspace collisions and preserve existing aliases. The schema checks non-empty strings; URL suitability and alias equality are semantic checks.

`title` is the visible navigation label and can differ from the alias. The gold `my-project` page has the title `Location`. Changing a title must not silently rename its route. `group` controls navigation grouping, and `sortOrder` orders the navigation entry. Neither is a widget container. [OWNER section 1; G-PROJECT root]

### 4.2 Root contract and chosen schema profile

| Property | Representation | Authoring guidance |
| --- | --- | --- |
| `id`, `name` | Non-empty strings | Required by the owner; equal, readable and non-GUID. |
| `title` | String | Required by this complete-document profile; write a useful visible label. |
| `settings` | Object | Required by this profile; `{}` is valid. |
| `widgets` | Array | Required by this profile; `[]` is valid. |
| `group` | String | Navigation grouping; choose intentionally. |
| `sortOrder` | Integer | Navigation order. No invented range restriction. |
| `visibleTo` | Array of principal IDs | Bind verified role-group IDs during authorized implementation under the [security policy](./security.md); preserve unrelated existing values. |
| `version` | String | Server-managed; may be omitted. |
| `modified`, `created` | Date-time strings | Server-managed; may be omitted. Do not forge them. |
| `modifiedBy`, `createdBy` | Strings | Server-managed principal references; may be omitted. |
| `isPublic`, `isPartner` | Booleans when present | Preserve existing flags. Do not infer public or partner access. |
| `urlPath` | Future parameter; null observed | Omit or retain null for new pages. Do not use it as a route allocator. |
| `groupIcon`, `partner` | Ancillary values; null observed | Non-null contracts remain unresolved; preserve without inventing new values. |

The two owner minimal examples show a valid empty page and a single HTML widget. They include some server metadata, but the owner's text explicitly permits omitting it. Metadata presence in a sample does not override that permission.

The uploaded snippets have JavaScript-style comments and trailing commas. The packaged owner fixtures remove only that syntax so they can be parsed as JSON. Separate new-authoring examples omit permitted server metadata. No runtime acceptance test was performed on those derivatives.

### 4.3 Page settings

| Setting | Meaning |
| --- | --- |
| `icon` | Navigation icon classes; use a verified workspace icon. |
| `showInBottomNav` | Boolean mobile-bottom-navigation setting. |
| `enableFavorite` | Boolean setting for saving page/URL combinations as favourites. |
| `hide` | Boolean navigation hiding. Direct navigation remains possible; this is not authorization. |
| `containers` | Ordered layout declarations with `name`, `desktopClass`, `mobileClass`. |
| `originalId` | Observed provenance metadata; preserve on edits and do not invent for new pages. |

Do not populate every absent flag based on intuition. Missing, false, null and empty values remain distinct. Validation does not insert defaults. [DRAFT page model; HANDOVER section 5]

## 5. Widget identity, envelope and serialization

### 5.1 Common envelope

| Property | Representation / role |
| --- | --- |
| `id` | GUID identity. Preserve on edits; allocate for a genuinely new widget. |
| `type` | Exact runtime component identifier. |
| `title` | Display label, not a unique identity. Repeated titles are supported. |
| `class` | Responsive grid classes, such as `col-md-4 col-sm-12`. Do not rename to `cssClass`. |
| `customCssClass` | Additional styling/behavioural class string, or null in exports. |
| `visible`, `showHeader`, `isCustom` | JSON booleans, not string flags. |
| `colorScheme` | Panel style string, such as `panel-default` or `panel-primary`. |
| `settings` | Object with common and component-specific settings. |
| `visibleTo` | Principal-ID array; client-side visibility restrictions, not page-load authorization. |
| `page` | Owning page alias when serialized; must match the containing page. Emit it for new widgets as shown in the owner sample. |
| `datasource` | Datasource reference or null; separate from process scope. |
| `groupName` | Ancillary property; null observed and non-null semantics unresolved. |

The schema requires widget `id`, `type` and `settings`. The other envelope keys remain optional for compatibility, because their universal input requiredness is not established. **New-authoring policy:** emit the owner's demonstrated envelope (`title`, `class`, `visible`, `showHeader`, `isCustom`, `colorScheme`, `page`) deliberately, rather than relying on unknown defaults.

Known native widgets use `isCustom: false`; tenant widgets use `isCustom: true`. A native list containing a custom HBS column is still a native list widget. Component IDs, field descriptors, Link items and walkthrough steps must not be confused with widget entities. [OWNER minimal HTML example; DRAFT widget model; HANDOVER section 6]

### 5.2 Common settings

`container` chooses a named page region; the empty string chooses the page body. `desktopVisible`, `tabletVisible`, `mobileVisible`, `onlineVisible` and `offlineVisible` are boolean settings. Device mappings described in the original sketch are md/sm/xs. These settings control visibility; they do not establish successful offline querying or cached-data availability.

Many process-bound lists, charts and tiles have `datasource: null`. Do not mark them unbound or insert `kianda-data` merely because the datasource property is null. Data-source filters can have `datasource: "kianda-data"` together with `settings.list` and process-field selectors; that is a different configuration.

### 5.3 Preserve exact wire types and casing

| Keep distinct | Reason |
| --- | --- |
| `visible: true` and `search: "yes"` | Outer boolean versus component string flag. |
| List `pageSize: "20"` and Chart v1 `pageSize: 30` | Different serialized types. |
| `pagingMode: "no"` and `false` | Traditional paging is the string, not a boolean. |
| Tile `tile: "count"` and chart `value1Exp: "Count"` | Different component contracts and casing. |
| `filterMode: "startswith"` and `operator: "startsWith"` | Filter UI mode versus query operator. |
| `textColour`, `cssClass`, `customCssClass`, `class` | Different real property names at different levels. |
| `processName: null` and a guessed process alias | Deliberate cross-process list scope versus single-process scope. |

Preserve unknown keys and values during edits. Open schema objects support forward compatibility; they are not permission to invent plausible settings names. A typo may remain structurally accepted and still do nothing at runtime.

### 6.1 Containers and order

Containers live in `page.settings.containers[]`, not in `widgets[]`. A declaration has `name`, `desktopClass` and **`mobileClass`**. The original draft's `mobileClas` spelling is a documented error; do not reproduce it.

Widgets remain in one ordered `widgets[]` array and select a container through `settings.container`. Keep both array orders. The precise cross-container rendering algorithm has not been supplied; do not promise that widget-array reordering alone overrides container order. When renaming a container, update every affected reference and review CSS selectors.

The property label `mobileClass` does not mean its class string targets only phones. Existing examples use `col-sm-*`; use the workspace's established responsive vocabulary and inspect the rendered result. Prefer predictable stacking and readable controls on small screens. [DRAFT page model; HANDOVER section 5.3]
