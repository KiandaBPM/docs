---
name: group-configurator
description: Resolve Kianda workspace groups for application roles whenever designing or implementing a process, page or email that requires a role. Design the role architecture, reuse suitable existing groups, and create missing application-prefixed groups during an authorized implementation. Do not use for ordinary contacts, user selection or membership administration.
---

# Kianda Group Configurator

Resolve application responsibilities to real workspace groups, then return the mapping to the calling designer/builder.

## Establish the role architecture

Locate the target workspace, requirements and current role design.

Define personas, responsibilities and intended permissions before choosing group names; reuse an adequate design. Contacts, literal addresses, current-user references and dynamic form owners do not automatically require groups. Share roles across screens when responsibilities and access scope fit.

Maintain one role mapping in the application's existing design and operating documentation:

- Persona/business role and responsibility.
- Intended grants and restrictions, identifying affected processes, pages, assignments and email audiences.
- Existing or proposed group name, verified group ID when resolved, and status: resolved, planned or blocked.
- Reasons an existing group is suitable, consequential open decisions, and administrator membership setup.

For review/chat-only work, return the mapping without editing documentation unless a written artifact was requested.

Separate page access, record access, form ownership and email audiences. An email group does not grant access to the linked record.

## Resolve existing groups

Read [the shared bridge contract](../../../docs/kianda/agent-bridge.md) for client use, results and failures. Use `listGroups(search)` and `createGroup(groupName)` through that helper.

Search by application prefix and role. Compare returned identities with application documentation/current references; reuse only when purpose, scope and authority fit. A similar name or a generic administrator group does not establish a suitable approver role.

Listing is capped at 1,000 with no exposed pagination: narrow searches before concluding absence. If matches remain ambiguous/capped or authority is unclear, ask the consequential question and leave the affected mapping unresolved. Clear documented matches need no routine question.

Use actual returned IDs; names are labels. Copy no example principals and infer no membership from identity fields.

## Respect the design and implementation boundary

**Design/review only:** discover groups read-only and propose missing ones. Do not call `createGroup`; planned groups have no IDs yet.

**Authorized build:** once detailed design exists and implementation has begun, automatically create required missing groups. Use the established application prefix, or derive one from its identity. Ask only for consequential naming/role ambiguity; the authorized build covers necessary provisioning without per-group approval pauses.

Immediately before creation, re-list the proposed name and reconcile suitable matches. Create each genuinely missing role once and record the returned identity. **Creation changes the server immediately without Publish**; local rollback does not undo it.

After failure, timeout or unexpected output, **do not retry automatically**. Re-list to reconcile; reuse a verified suitable result. If still uncertain, report provisioning blocked. Do not guess IDs, create another name or delete a possibly created group.

Membership is an administrator task. Record required membership setup; these operations cannot manage or verify members.

## Supply the correct consumer reference

Inspect the target and applicable contract:

| Consumer | Authoritative reference |
| --- | --- |
| Process/record security and form assignment | [Assignment and security](../../../docs/kianda/process/rules/assignment-security.md), [process schema](../../../docs/kianda/process-schema.json) and the target process. |
| Email or meeting role audience | [Email audiences](../../../docs/kianda/process/rules/email.md) and the target rule's audience mode. |
| Page, widget or Link restrictions | [Page security](../../../docs/kianda/page/security.md), [page schema](../../../docs/kianda/page-schema.json) and the target page. |

Consumers differ between ID arrays and rich principal objects. Apply the exact shape; preserve returned identity fields for rich objects without inventing emails/profile properties. If the representation remains unknown, report the missing contract rather than guessing.

Apply intended grants within scope and preserve unrelated restrictions. Visibility, assignment, audiences and authorization remain separate; group creation establishes neither security nor membership.

## Verify and return the mapping

Check resolved IDs, consumer shapes and documentation consistency; run the caller's structural/reference checks. Return reused/created/planned/blocked mappings, affected consumers, membership tasks and unresolved decisions.

Report creation, local configuration, runtime access/delivery testing and publication separately. Do not execute business/security actions to test discovery. Follow the workspace's change-record convention.
