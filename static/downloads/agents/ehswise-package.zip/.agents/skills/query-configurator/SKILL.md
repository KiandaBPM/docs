---
name: query-configurator
description: Select existing Kianda datasource connections and configure their consumers using connector metadata, including lookups, page queries, native data-rule mappings and file destinations. Use when a consumer needs remote source discovery or connector-specific configuration. Existing or pending local Kianda process definitions can be referenced directly without invoking this skill. Does not provision connections, manage credentials or execute queries.
---

# Query Configurator

Resolve a consumer's source and field references, then author only the configuration within the requested scope. Prefer native Kianda controls and rules. The bridge discovers configured sources and metadata; it does not write queries or execute business operations.

Locate the actual workspace root and read its instructions. Resolve the links below from this skill's installed location; use the workspace's equivalent shared references if relocated. Read [bridge access](../../../docs/kianda/agent-bridge.md) for the client, connection prerequisites and failures, then only the applicable connector section of [datasource metadata](../../../docs/kianda/datasource-metadata.md).

## Choose the evidence source

For `kianda-data`, first use the current local process JSON and the builder's current draft definitions. The designer/builder may bind those fields directly **without invoking this skill or calling metadata**, including relationships among processes being built together. Local additions may not yet exist on the server. Retain their real aliases, field names, types, IDs and containment context; record the dependent processes/fields and required publication order. A design-only field proposal is a planned dependency, not evidence of a live field or an assigned ID.

Use the bridge when local evidence is absent, incomplete, ambiguous or an external connector needs discovery. Discover the existing connection with `listDatasources()`; use its actual ID and verified connector type. Do not fabricate connection IDs, assume every list entry exposes `type`, create a replacement connection, or request credentials. If no suitable connection exists, complete independent configuration and state the administrator connection requirement.

## Configure the consumer

1. Inspect the exact current consumer and its source dependencies. Establish the resource, operation, returned/stored identity versus display text, fields, filters, sorting/limit, mappings and any upload destination needed by the task. For a design-only request, return these decisions and dependencies without modifying application configuration.
2. Retrieve only the metadata necessary to select the resource and fields. Reuse relevant results within this task; refresh when the source has changed or ambiguity remains. Follow connector-specific tree/array shapes, internal names, readonly markers and file capability in the shared reference. Metadata proves discoverability, not effective access, query results or operation success.
3. Serialize using the **consumer's** contract. Metadata nodes are discovery data, not complete saved field selectors or rules. Keep IDs, names, descriptor types and casing meaningful in that surface; never allocate a new field ID for a reference. Use [process fields](../../../docs/kianda/process/fields.md), [Find items](../../../docs/kianda/process/rules/find-items.md), [rule descriptors/mappings](../../../docs/kianda/process/rules/core.md), or [page bindings](../../../docs/kianda/page/bindings.md), [widgets](../../../docs/kianda/page/widgets.md) and [queries/filters](../../../docs/kianda/page/queries-filters.md) as applicable. File destinations are documented in [the metadata reference](../../../docs/kianda/datasource-metadata.md#file-field-destinations).
4. Preserve the consumer's existing identities, security, unrelated settings and deliberate empty values. In particular, process-bound page widgets may correctly have `datasource: null`; do not insert a connection merely because that value is null. Verify value/display choices, input/output mapping direction and field-type compatibility. New CRUD or SQL consumer settings need current serialization evidence where the shared contracts are incomplete; do not infer an action identifier or settings shape from a metadata object.
5. Validate edited JSON with the applicable unchanged schema and trace affected references, predicates and mappings. Review the diff. Read-only metadata inspection is not runtime query, upload or CRUD verification. Do not run a configured operation merely to validate its settings.

For another connector, make a best-effort configuration from its actual metadata, current consumer/source and available contract. Ask a focused clarification for consequential uncertainty; document safe remaining assumptions and coverage warnings in the application's change entry. Do not invent a production wire shape to bypass missing evidence.

## Return useful evidence

Record the selected connection/resource, consumer paths, mapped identity/display fields, evidence source (local draft or remote metadata), dependencies and unresolved assumptions in the existing application documentation and change entry when configuration changes. Keep credentials, bridge locators/tokens and full metadata dumps out of documentation and application JSON.

Report local implementation, static checks, runtime checks and publication separately. Identify pending process publication, administrator connection setup or missing consumer contracts precisely; return control to the calling designer/builder without restarting its workflow.
