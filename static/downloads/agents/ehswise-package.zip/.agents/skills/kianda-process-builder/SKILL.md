---
name: kianda-process-builder
description: Create, modify, repair, or validate Kianda process JSON in an exported workspace. Use for end-to-end process implementation, forms, fields, rules, conditional behaviour, process layouts, and targeted technical fixes. Coordinate the kianda-process-designer workflow when the request changes the user journey, then implement and verify the design using the workspace's Kianda knowledge and schema. Preserve existing identities and unrelated behaviour. Do not use for design-only discussions, page-only authoring, or standalone custom-component development unrelated to a process implementation.
---

# Kianda Process Builder

**Draft workflow version:** 0.1.0

Implement Kianda process definitions accurately, with a deliberate user experience and evidence-backed validation. Own the end-to-end implementation workflow when requested, using the designer for meaningful experience decisions rather than treating design as a final styling pass.

Follow applicable workspace instructions and the explicit task. Keep the business requirements, design blueprint, technical contract and validation evidence distinct. Do not claim that a valid JSON document is a working or published application.

## Inputs and outputs

Accept a build/change/repair request, business requirements or an existing design blueprint. Work against the actual target process definitions and installed references.

Produce complete changed process files, the associated design delta or blueprint where needed, required change documentation, and a concise implementation/verification report. In a file-based workspace, write the complete definitions to their appropriate files rather than returning only an illustrative fragment. When the user requests an inline definition, return the complete requested definition separately from diagnostics.

For validation-only or review-only requests, inspect and report without editing or executing the process's business actions. Do not modify runtime records as a substitute for changing a process design.

## 1. Resolve the target and operating boundaries

Locate the intended workspace root and read the applicable `AGENTS.md` files. Resolve the following paths from that root, **not from the skill directory**. Follow explicitly configured equivalent locations without moving or duplicating their contents.

Read `docs/kianda/general.md`, relevant `docs/kianda/process-knowledge.md` sections and `docs/kianda/process-schema.json`. Use the [process design guide](../../../docs/kianda/process-design-knowledge.md) to select task-relevant design policy; consult the [blueprint contract](../../../docs/kianda/process/design-blueprint.md) when a blueprint is needed and [acceptance scenarios](../../../docs/kianda/process/design-review.md) for affected checks.

Inspect the affected `processes/**/*.json` recursively. Read relevant specifications and existing design notes. Load `docs/kianda/css-style-guide.md` and `styles/app.css` for presentation changes. Load `docs/kianda/custom-addon-knowledge.md`, actual `components/` source and `js/app.js` only for involved custom dependencies. Inspect consuming pages and their references when a changed name, type or relationship affects them.

Identify available validators, runtime/preview access, repository state and the current extension's save/synchronization/publication behaviour. A local file write may participate in an extension workflow; do not promise isolation or remote publication without checking it. Keep any remote change within the user's authorized target and scope.

Do not create an Ember CLI, React, npm or other standalone application scaffold merely because exported Kianda files are not a conventional buildable project. Do not invent commands, tool names or a connected MCP service.

If essential technical references are absent, locate their documented equivalents. If they remain unavailable, produce the supported design/analysis and identify which implementation is blocked. Do not emit guessed production configuration.

## 2. Select the minimum necessary design work

Classify the request before editing:

| Request | Design treatment |
| --- | --- |
| New process or material change to stages, forms, branches, navigation, ownership, completion or conditional sections | Apply the designer workflow before implementation. |
| A sufficiently specified existing blueprint | Check it against the actual baseline; reuse it and fill only material gaps. |
| Small experience/layout improvement | Produce a compact design delta covering affected states. |
| Isolated syntax, serialization or reference repair with unchanged intended experience | Preserve the current design; use focused regression checks. |
| Validation/review only | Report findings; do not implement remedies without authorization. |

For required design work, use the available `kianda-process-designer` skill. In this repository its entrypoint is `.agents/skills/kianda-process-designer/SKILL.md`. If the host has no separate invocation mechanism, read that entrypoint and apply its workflow sequentially in the same task, then resume here. Do not pretend skill selection requires a new agent or an external command.

If the designer skill is not installed but the shared design guide is present, perform the relevant design steps and blueprint checklist from that guide and report this fallback. Do not skip design or duplicate a second designer implementation inside this skill.

Avoid recursive delegation: the builder coordinates; the designer returns a design artifact and does not call the builder. Do not demand approval after every design phase in an already authorized build. Pause only the consequential unresolved part when requirements, permissions or business policy genuinely prevent a safe implementation.

## 3. Check feasibility and establish traceability

Map each material design requirement and acceptance scenario to actual forms, fields, rules, settings or verified dependencies. Identify the source that establishes each non-obvious mechanism.

Use [group-configurator](../group-configurator/SKILL.md) for application-role bindings in processes, related pages and email. Once the detailed role design exists and authorized implementation has begun, reuse suitable groups or create missing groups and record actual identities, intended grants and administrator membership tasks in the application documentation. Group creation is immediate; it does not publish security settings or establish membership/effective access.

Use [query-configurator](../query-configurator/SKILL.md) for existing datasource/resource discovery and consumer configuration. For Kianda Data, directly resolve references from current local JSON, including new uncommitted or unpublished related processes; no skill/bridge call is needed when these sources suffice. Materialize pending builder definitions before final integrity checks, and document dependency/publication order rather than treating older live metadata as authoritative for new local fields.

Inspect all relevant writers to visibility, requiredness, values, completion and navigation. Establish how the current engine evaluates initial state, changes, re-entry and programmatic updates. Do not implement a truth table solely by adding more independent show/hide rules whose alternatives can contradict one another.

If the supported implementation requires a design change, document the reason and update the blueprint within scope. Do not silently substitute a different user journey. Distinguish an unavailable component from an unknown settings contract and a known-invalid configuration.

Build a scoped entity and dependency index for the affected work. Resolve descriptors by kind and process/row/parent context; include names embedded in expressions, mappings, tokens, custom code, page bindings and CSS selectors when those dependencies are affected. Do not traverse arbitrary settings keys as though they were entity collections.

Record existing defects that fall outside the request. Do not broaden a repair into an unauthorized cleanup or migration, and do not hide pre-existing failures when reporting validation.

## 4. Implement the smallest coherent change

### Select the simplest supported logic mechanism

Before introducing custom code, inspect the relevant native rules, expression capabilities, and existing workspace helpers documented in process-knowledge.md.

For calculations and derived field values, prefer the native Set form field rule (rules/rule-setfield) with an expression.

Use a short inline JavaScript expression when the calculation is clear and local to the process.

When logic benefits from reuse, clearer structure, or independent testing, prefer a suitable global function in js/app.js called from the expression. Such a function may return a value or a Promise.

Do not introduce a custom rule, component, API endpoint, or service solely because a calculation requires JavaScript, multiple steps, reuse, or asynchronous execution.

Before choosing custom rule/component development or server-side execution, identify the concrete requirement that native rules, expressions, and appropriate workspace helpers cannot satisfy. Consider security, execution context, lifecycle, scale, and maintainability rather than code length alone.

Keep value assignment in the native rule where practical. Prefer helpers with explicit inputs and returned outputs over hidden mutations of process state.

Verify field references, helper availability, result types, recalculation triggers, and failure behaviour. Do not invent expression settings or assume undocumented Promise semantics.

Preserve existing working implementations during unrelated changes. A native-first policy does not authorize an unsolicited migration.

Use the supported native forms, fields, rules, layout containers and reusable Components first. Introduce custom implementation only for an explicit gap or an established dependency, and follow its actual source and settings contract.

Follow `process-knowledge.md` and the schema for exact representation. In particular:

- Preserve existing process aliases, entity IDs, logical names, ordered arrays, security and unknown settings during edits. A label or styling change does not authorize renaming an identity or logical field name.
- For a new process, choose a workspace-available readable alias and keep `id` and `name` consistent when both are emitted. Preserve accepted historical omissions on unrelated edits. Allocate genuine new entity GUIDs and rewrite only references belonging to new/cloned entities.
- Enforce the documented process and table-row field-name scopes, including descendants and collisions with outside-row fields. Do not replace them with simple sibling-only or universal global uniqueness checks.
- Allocate required GUIDs for new condition groups in the documented models. Do not assume the same requiredness for every individual condition or arbitrary tenant setting.
- Keep component-specific settings in their documented settings objects. Preserve wire types, casing, empty strings and meaningful omissions; do not coerce all yes/no settings into booleans or all numeric-looking strings into numbers.
- Use `field.class` for layout and `field.customCssClass` for additional styling. Verify actual utilities and overrides. Do not rename the layout property to `cssClass`.
- Preserve rule attachment and deliberate order. Respect the false default of omitted `hasElse`; alternate settings belong to the same action. Do not repair retained inactive alternative targets as though they were executed.
- Preserve actual table-row entities and the verified Component loading/version model. Do not flatten rows, treat reference descriptors as children, or simulate Component upgrades by blindly replacing expanded trees.

Do not copy example business values, principals, tenant URLs, audit metadata or dependency IDs as defaults. Do not insert blueprint-only labels, test results or diagnostics into process JSON. An open schema/settings object is not permission to invent operational properties.

Preserve existing data-reversal policy unless a change is authorized. Apply the agreed policy across direct values, derived values, reporting projections and related actions; hiding a form alone does not implement the full policy.

Keep modifications inside the requested application scope. Add or change a related page, shared component, global style or JavaScript file only when it is necessary and authorized; explain the dependency and regression impact.

## 5. Implement lifecycle and action safeguards

Implement the blueprint's initial-load, change, reverse-change, draft-reopen and direct-navigation scenarios through documented mechanisms. Keep presentation recomputation safe to repeat, and do not attach record creation, notification or other consequential effects to every recalculation.

Implement effective applicability before applying conditional validation, completion or reporting. Do not mark a hidden form complete, treat stale retained answers as active, or assume disabling a required input makes submission valid.

Establish explicit success conditions for actions that depend on earlier validation, uploads, integrations or saving. `general.md` documents continuation after a custom rule throws or rejects; do not rely on such a failure automatically stopping a subsequent Save, Submit, notification or navigation rule. Verify native action behaviour separately.

Resolve real principals and permissions through authorized workspace sources. Preserve existing security and distinguish UI visibility from access enforcement. If required security configuration cannot be authored, provide an explicit administrator handoff and do not label that part production-ready.

Do not execute business actions merely to validate their settings. Use a permitted non-production target or an explicitly approved safe test setup for runtime tests with side effects. Do not commit, push, publish, migrate or delete records unless the current task and workspace workflow authorize that action.

## 6. Validate in separate layers

Use the project's documented tools where available. Inspect validator behaviour and scripts before executing them. Use read-only checks where possible; do not silently install dependencies, add frameworks or change schemas to make the output pass.

| Layer | Required checks | Honest completion claim |
| --- | --- | --- |
| JSON parsing | Valid syntax and duplicate-key detection where supported; no data loss through permissive parsing. | The checked files parse under the stated checks. |
| JSON Schema | Correct schema/dialect; applicable known settings; format checking; no coercion, defaults insertion or removal of unknown properties. | Conforms to the structural assertions actually checked. |
| Semantic integrity | IDs/names and scopes, ownership, references, aliases, mappings, active targets, installed dependencies and affected expressions. | The specific inspected relationships are consistent. |
| Design conformance | Blueprint requirements, effective predicates, inverse transitions, data policy, completion and navigation. | The implementation matches the reviewed design to the stated extent. |
| Runtime and visual | Actual initialization, choices, reverse changes, saves/reopens, failures, participant access, responsive and keyboard states. | Only the scenarios exercised behaved as recorded. |

Run available checks against the changed files and necessary dependants. Compare with the baseline when an existing file already fails. Separate newly introduced errors, pre-existing errors and contract-coverage gaps. Preserve unknown tenant settings; do not assign every coverage gap the same severity without a policy or evidence.

Select relevant behavioural tests from the [acceptance scenarios](../../../docs/kianda/process/design-review.md). Prioritize overlapping branches, shared targets, blank/unknown decisions, populated branch reversal, reopening, validation reachability, failure gates and existing-record compatibility.

Record commands/tools, targets, relevant versions and outcomes. If a validator or runtime is unavailable, say that layer was not run and provide concrete remaining checks. Do not treat a hand-simulated predicate or static source inspection as a passing live application test. Do not report the work fully validated while a required layer is unavailable or failing.

## 7. Review changes, document and hand off

Review the final diff for unintended identity, name, ordering, permission, metadata, styling, dependency or unrelated-file changes. Confirm the written files are complete process definitions and that diagnostics remain outside them.

Update the relevant blueprint when the implemented design changes. Follow the root `CHANGELOG.md` convention and update current application documentation where behaviour has changed. Do not create a new changelog format or make version/publication changes without instruction.

Return a concise report containing:

1. Implemented behaviour and the design decision or delta used.
2. Created/modified file paths and consequential dependency changes.
3. Checks actually run, their outcomes, and pre-existing versus introduced findings.
4. Remaining assumptions, blockers, administrator/migration steps and concrete runtime checks.
5. Publication status stated separately from file-writing and validation status.

Never claim "published", "runtime tested", "secure" or "accessible" from file creation or schema acceptance alone. When a portion remains blocked, deliver the safe completed work and identify the precise boundary rather than concealing the gap or substituting unsupported functionality.
