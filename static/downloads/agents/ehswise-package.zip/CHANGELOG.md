# Changelog

## Unreleased

### Documentation — 2026-11-04

- Reworked `AGENTS.md` and both process skills to select references by task, reuse existing context, and scale design/validation work to the requested change.
- Split `docs/kianda/` and `docs/workspace/` guides into short entry maps and focused references; retained technical contracts, baseline inventories, evidence labels and unresolved source discrepancies. Clarified conflicting navigation-route examples and several EHSwise baseline observations.
- Kept both JSON schemas and skill UI metadata unchanged. Checked schema integrity, skill structure, local links, source coverage and three documentation-retrieval scenarios. No customer application JSON or Kianda runtime was available for application testing; no workspace sync or publication was performed.
- Rollout: use the package for new workspaces; merge documentation changes into existing workspaces while preserving customer instructions and change history.
