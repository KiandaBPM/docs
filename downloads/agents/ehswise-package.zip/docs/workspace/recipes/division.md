# Proposed customization: Division above Project

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

These are owner-reviewed implementation proposals, not existing base-product features. Proposed names must be checked for collisions and applied consistently in the customer workspace.


**Requirement:** introduce Division as a workspace hierarchy level, with Projects cascading from the selected Division.

**Target relationship:** Division → Project → associated operational records. Division is represented by records of the existing EHS Asset process with Type `Division`.

## 1. Extend Asset types and parent relationships

In [asset.json](../../../processes/Data/asset.json):

- Add **Division** to the Type choices and configure the type-specific field/panel visibility.
- Reuse the common Title, Code, Display Name, and Active properties.
- Add a **Division lookup to Project records**, filtered to active assets whose Type is Division.
- Store the selected Division's code as the Project's parent reference; `divisionCode` is a proposed field name, not an existing contract.
- Create Division records and assign existing Projects to their Division. Plan the backfill explicitly so existing Projects are not silently assigned to an arbitrary Division.

The standard Country input on an Asset is an independent system country list; adding a business hierarchy requires the explicit parent relationship described above.

## 2. Extend the shared Workspaces component

In [workspaces.json](../../../processes/Data/workspaces.json):

- Add a Division selector before Project. Follow the existing Project selector pattern: display `displayName` and use `code` as the selected value.
- Filter Division choices to Type Division and Active Yes.
- Extend the Project options filter from **Type = Project AND Active = Yes** to also require **Project's divisionCode = selected Division code**.
- Require the parent selection before allowing a Project to be chosen when the module uses a Project association.
- When Division changes, clear an incompatible selected Project and its helper code, refresh Project choices, and handle any dependent child selections. Do not leave a previously selected Project from another Division attached to the record.
- Keep modules that support other or multiple workspace associations working; the hierarchy requirement should apply to the appropriate association rather than making every record globally require a Project.

A picker such as `processDivision` and helper such as `processDivisionCode` are possible new names. Keep their meanings and mappings consistent with the existing `processProject` and `processProjectCode` contracts. Persist Division context where Division-level summary queries, reporting, or security need it.

## 3. Propagate the component and context to consuming modules

Review the host processes that embed Workspaces and refresh their loaded component configuration using the workspace's established component update workflow. Host exports contain nested component fields, so changing only the shared definition does not establish that every host has updated.

Review module-specific workspace controls, preload rules, linked-record mappings, and derived data. Carry Division context into related Actions or other records where the intended queries/security require it. Check that opening an existing record initializes the correct Division and Project without resetting valid saved selections.

## 4. Update administration and operational pages

In [Assets.json](<../../../pages/EHS Admin/Assets.json>), add Division to the asset-type tabs so administrators can maintain those records. Ensure the Project editor exposes its new Division association.

In [my-project.json](<../../../pages/My Project/my-project.json>):

- Add a Division filter and connect it to the Project selector's new parent field. This must constrain the Project choices, not just the final Items list.
- Retain the existing Project code mappings: Items uses `processProjectCode`, while the carousel resolves the selected Asset by `code` and the `project` URL parameter.
- Preserve Division and Project in URL state and new-record links where the consuming processes support that context. A proposed `division` parameter must have matching preload handling.
- Clear stale Project URL/filter state when Division changes.
- Connect Division to the intended record widgets using the persisted Division field or an explicitly designed Project-based query. A Division filter does not automatically filter every widget.

The Country → Project filter connections in [hazard-library.json](../../../pages/Analytics/hazard-library.json) provide an existing filter-to-filter cascade example. They do not establish that stale child selections are automatically cleared by the runtime; verify that behavior.

## 5. Align reporting, access, responsibilities, and imports

- Add Division filters to affected reports and explicitly connect each intended list, chart, and tile. Preserve consistent scope across rate numerators and denominators. Existing reports use both Project display fields and Project code fields; inspect each mapping.
- Apply the customer's Division-level record and lookup access rules. Filtering a dropdown is separate from authorization.
- If responsibilities are configured at Division level, extend [configuration.json](../../../processes/Data/configuration.json) and the relevant consumers of [asset-responsible.json](../../../processes/Data/asset-responsible.json). Responsibility inheritance to Projects requires explicit configuration; it is not created by the hierarchy link.
- If bulk onboarding uses [asset-import.json](../../../processes/Data/asset-import.json), update the template, preview, and mappings for Division and Project parent codes. The documented matching defect requires Type + Code; do not copy a Code-only matching pattern.
- Add labels/translations and review offline-cached reference data. Decide whether historical operational records retain their original Division or follow future Project reassignment, then apply any backfill consistently.

## Verification checklist

Verify creation/editing of Divisions and Projects; selecting Division then Project; switching Division; clearing invalid Projects/child selections; reopening existing records; URL initialization; new-record context; security; responsibility scope; reporting totals; and cached/offline selection behavior.
