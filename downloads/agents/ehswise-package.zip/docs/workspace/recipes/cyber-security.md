# Proposed customization: Cyber Security Incident

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

These are owner-reviewed implementation proposals, not existing base-product features. Proposed names must be checked for collisions and applied consistently in the customer workspace.


**Requirement:** add **Cyber Security** as a top-level Incident Type with its own form, visible only when that type is selected.

Extend the existing [incident.json](<../../../processes/QHSE - Modules/incident.json>) process. The existing Security damage category captures physical security events such as burglary and vandalism. The new top-level Cyber Security type has its own data-capture step while retaining the Incident process identity and existing entry points.

## Suggested Cyber Security fields

Reuse common Incident Title, Description, Incident date/time, Reporter, Workspaces, Attachments, and Actions. Suggested new fields are:

| Field | Suggested control and purpose |
| --- | --- |
| Cyber incident category | Dropdown: Phishing, Malware/Ransomware, Account compromise, Unauthorized access, Data disclosure/loss, Service disruption, Other. |
| Discovered at | Date/time, separate from when the incident occurred. |
| Detection source | User report, monitoring alert, supplier notification, other. |
| Affected systems/services | Repeatable table: system/service name, asset reference where applicable, business owner, production/test environment. |
| Severity | Low, Medium, High, Critical. |
| Impact | Multi-select Confidentiality, Integrity, Availability, with an explanation of business impact. |
| Data exposure | Unknown, None identified, Suspected, Confirmed; optional data categories and approximate number of affected records. |
| Security response lead | Internal user picker for the person coordinating the response. |
| Containment details | What was done, when containment started, and when it was achieved. |
| Recovery details | Recovery work, service-restored date/time, and outstanding issues. |
| External reference | IT service-management ticket, supplier case, or external report reference. |

Keep initial reporting requirements small and allow investigation, containment, and recovery information to be completed during review. Required fields and stage-specific requirements are customer decisions, not established defaults for this proposed form.

## 1. Add the Incident Type choice

Append **Cyber Security** to `incidentType?radioCards.settings.choices`. Keep existing values compatible with saved records. Keep the process identity/title as Incident, so existing Create New links and Incident record-type tabs continue to handle the records. This is a top-level type addition; the damage selector `incidentType?checkboxCards` has separate behavior.

## 2. Create the new conditional form

- Title the form **Cyber Security Details**, with a unique technical name such as `cyberSecurity`, a new ID, and correctly linked parent references for its fields.
- Start with `visible: false` and activation consistent with the existing conditional forms, which use `activateWith: "form1"`.
- Configure Next/Save navigation between Circumstances, Cyber Security Details, and subsequent applicable forms.
- Use stable new field identities; `cyberCategory`, `cyberSeverity`, and `cyberDiscoveredAt` are proposed examples.

## 3. Implement Cyber-only visibility

The Incident Type field already has an ordered **Hide forms** reset followed by type-specific rules. Add the new form to that hide/reset target list, then add a show rule for **Incident Type = Cyber Security** with an explicit hide path when the condition is false.

| Selected Incident Type | Cyber Security Details form |
| --- | --- |
| Cyber Security | Visible |
| Near-miss, Incident, Accident, or blank | Hidden |

Apply and verify the condition on type changes and when opening a saved record; change-only handling is insufficient. Visibility does not remove stored field values. Retaining or clearing previously entered Cyber details when the type changes must be an explicit decision.

## 4. Add branch-specific validation

Extend `INC_BTN_validateForms` so Cyber-required fields are checked only when **Incident Type = Cyber Security**. Hidden Cyber fields must not block other types. Preserve Draft saving of incomplete records and configure any later review/closure requirements separately.

Decide which existing damage, investigation, and authority-reporting options apply to the Cyber branch. Adding the new type does not itself justify enabling Accident's People or Potential LTI fields. Review both enabled conditions and else behavior, including disabled legacy rules, rather than copying a visually similar branch blindly.

## 5. Include the form in assignments and access

Add the new form to the applicable explicit target lists in the process's initial **Assign forms** rule and in `GI_BTN_AssignRules`, including its **Remove permissions** reset and the Draft, Open, Closed, and reviewer assignments.

If IT/Security ownership is required, configure that routing and access deliberately. A response-lead field or a new type choice does not automatically assign the form or notify that person. Review relevant responsibility lookups and preserve the distinction between the response lead, Reporter, and originator.

## 6. Update generated reports, including closure

Add Cyber fields to the existing Word templates through appropriate conditional content, or introduce dedicated Cyber templates. Preserve the Generate Word Document contract using rich-text content controls tagged `kf:<field-name>`.

**Current source pitfall:** both existing non-Accident report branches also match Cyber Security: one for Investigation No and one for Investigation Yes. If dedicated Cyber report rules are added:

- Exclude Cyber Security from both existing non-Accident branches.
- Add mutually exclusive Cyber branches, with explicit investigation handling if different templates are required.
- Update the report-generation rule executed by **Close**, which currently regenerates the generic report.
- Keep the generated file destination and regeneration behavior consistent. The report rules write to `processReport`; overlapping branches or an unchanged Close rule can overwrite the intended Cyber PDF.

The new form alone does not make its fields appear in a generated report. Report template files can be hosted attachments rather than local source files.

## 7. Update Summary and notifications

Include relevant Cyber details in the Summary and generated outputs. Review the existing notification rules for the originator, additional selected people, and configured `incidentNotify` recipients. Configure any separate response-lead notification explicitly.

Preserve the distinction between report storage and email attachments. The current Incident notification rules do not automatically attach the generated PDF merely because it is saved on the record.

## 8. Review Analytics and record views

The Incident Type chart in [incident-report.json](../../../pages/Analytics/incident-report.json) groups dynamically by `incidentType?radioCards`, so the new value should appear after matching records exist. Verify the actual query and any customer-specific restrictions.

- Add Cyber fields to list/export columns where required, and add Cyber filters or tiles if requested.
- Review [accident-rate.json](../../../pages/Analytics/accident-rate.json) and its source counters so Cyber cases are not inadvertently treated as injury/LTI cases. Type changes must not leave stale data affecting safety metrics.
- Review whether generic authority-reporting flags should contribute to tiles labelled RIDDOR; the new type does not establish that reporting interpretation.
- Consult current reporting defects in [pages.md](../reports/known-issues.md). The Incident Project-filter source mismatch must be considered during verification rather than copied into new filtering.
- Existing operational Incident tabs continue to use the Incident process title. Adding a top-level type does not require changing that cross-process title contract.

## 9. Translate, document, and verify

Add translations for the choice, form, fields, and options. When implementation changes confirmed product behavior, update [modules.md](../modules.md), the relevant page guide, and the [application data model](../data-model.md).

Verify selecting/switching types; Draft save and reopen; conditional visibility and required fields; navigation; reviewer access and assignments; submission and closure PDFs; intended recipients; asynchronous server processing; and Analytics grouping/counts. Include regression checks for Near-miss, Incident, and Accident.
