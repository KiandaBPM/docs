# Energy & Waste

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [energy-registration.json](../../../pages/Analytics/energy-registration.json); source `energy-registration`.

The 30-row list contains custom ID, project, start/end dates (`ER_DATE_StartDate`, `ER_DATE_EndDate`), asset type, energy type/subtype, units, amount, other asset types, modifier, created and status. It sorts custom ID descending, enables OData export, and disables add/delete/bulk delete. The current chart grouping uses `ERE_TXTSIN_EnergyType`, while displayed selection fields include `ERE_LISTSIN_EnergyType`; preserve that distinction until process mappings are reviewed.

Project options come from Energy Registration `processProject` and target list, Status pie and Energy Type bar chart. Manual Date uses `__CREATED` on the list rather than the consumption start/end range. The three time counters use creation date for this week, previous month and previous year. Total Number of Energy and Waste Records counts records; it is not the sum of usage amounts across incompatible units.

Saved baseline detail: [widget, column and connection inventory](./inventories/energy-registration.md). Read it only when exact exported identifiers or settings are needed; compare current customer JSON before reusing them.

“Energy and Waste” is this page’s label. Its source is `energy-registration`, not evidence that it queries the separate [Waste Management definition](../../../processes/waste-management.json).
