# Permit to Work

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [ptw-report.json](../../../pages/Analytics/ptw-report.json); source `permit-to-work`.

Charts are Status, Project and PTW Type pies (`PTW_LSTSIN_TypePTW?radioCards`). The 30-row list includes custom ID, project, `processDate`, reporter, title, work description, type, PPE, rescue equipment, participant count and status. Custom ID descending, OData enabled, add/delete/bulk delete disabled.

Project options source PTW `processProject`; target list, Status/Project/PTW Type and Open/Extended/Closed tiles. The saved list connection metadata names `ncr`, despite the actual target list using PTW. One other target condition uses `selectAChecklist` as though it were the project field, and the Extended tile’s connected-list reference points to the NCR list ID rather than this page’s PTW list. These are configuration mismatches to resolve against intended filter coverage. Date Range targets the list's `Process Created Date`; period tiles use the same field. Active counts Open, Extended counts Extended, Closed counts Closed, plus total. The owner described extension as adding a phase while Open; do not infer a different workflow solely from a report tile called Extended.

Saved baseline detail: [widget, column and connection inventory](./inventories/ptw-report.md). Read it only when exact exported identifiers or settings are needed; compare current customer JSON before reusing them.
