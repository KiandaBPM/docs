# Accident Rates — export inventory

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [accident-rate.json](../../../../pages/Analytics/accident-rate.json); page ID `accident-rate`.

| Widget title / ID | Type and source query | Grouping / aggregation / fixed conditions | Connected list |
| --- | --- | --- | --- |
| First Aid Cases<br>`d90c47c0-2c89-4df4-8fa2-27b4fb7cc8a4` | widgets/widget-tile; incident; own / all | sum `firstAidCount` | b91838ae-2965-40aa-8170-96729363a564 — missing in page |
| Medical Treatment<br>`9248024f-a5f4-4b15-946b-a4c5ec2c7d82` | widgets/widget-tile; incident; own / all | sum `lostTimeIncidentCount` | b91838ae-2965-40aa-8170-96729363a564 — missing in page |
| Lost Time Cases<br>`fb254ef0-59f2-44a2-b33e-7a7918edaa03` | widgets/widget-tile; incident; own / all | sum `lostTimeIncidentCount` | b91838ae-2965-40aa-8170-96729363a564 — missing in page |
| RIDDOR Cases<br>`1e228678-944e-46e7-bc8c-b763b79a23ec` | widgets/widget-tile; incident; own / all | tile count; where (reportable_authorities contains Yes) | b91838ae-2965-40aa-8170-96729363a564 |
| AFR<br>`95444bdf-07be-49c8-9f51-dec62c259084` | client-widget/widget-tile; expressions over incident + hours-worked-data | `(AccidentCount * 100000) / WorkerHours`; sums `injuredPeopleCount` and `DATAMS_NUM_EmployeeHours` | No explicit connected-list setting |
| LTIR<br>`2931037e-1847-44f0-b30b-7c0e39d53e01` | client-widget/widget-tile; expressions over incident + hours-worked-data | `(LTICount * 200000) / HoursWorked`; sums `lostTimeIncidentCount` and `DATAMS_NUM_EmployeeHours` | No explicit connected-list setting |
| Hours Worked<br>`f48dfaac-be25-4344-b03f-0f59883623e8` | widgets/widget-tile; hours-worked-data; own / all | sum `DATAMS_NUM_EmployeeHours` | b91838ae-2965-40aa-8170-96729363a564 — missing in page |
| incidents this year<br>`ba792bfc-310e-4b8b-b7ff-933fefffd454` | widgets/widget-tile; incident; own / all | tile count; where (processDate isThisYear ) | b91838ae-2965-40aa-8170-96729363a564 |
| Incidents last year<br>`4b936433-e191-4f96-9906-2c3a2532dd12` | widgets/widget-tile; incident; own / all | tile count; where (processDate isPrevYear ) | b91838ae-2965-40aa-8170-96729363a564 |
| AFR - Accident Frequency Rate<br>`8e0bfc11-9336-4dc0-b878-b68e05763ab8` | client-widget/accident-rate; implementation owns queries | `timeFrame: Year`, `monthsCount: 6`, `afrFormula: (AccidentCount * 200000) / EmployeeHoursWorked` | No explicit connected-list setting |

**Filter: Project** (`360ef62a-b81c-4514-8a70-bd88280d3629`), dropdownlist; options source `asset`; display `displayName`; value `code`; URL parameter `project`.

Option constraints: `(type eq Project)`.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| RIDDOR Cases | `1e228678-944e-46e7-bc8c-b763b79a23ec` | `incident` | (processProjectCode eq {filterValue1} [saved: PRJ1]) |
| First Aid Cases | `d90c47c0-2c89-4df4-8fa2-27b4fb7cc8a4` | `incident` | (processProjectCode eq {filterValue1} [saved: PRJ1]) |
| Medical Treatment | `9248024f-a5f4-4b15-946b-a4c5ec2c7d82` | `incident` | (processProjectCode eq {filterValue1} [saved: PRJ1]) |
| Lost Time Cases | `fb254ef0-59f2-44a2-b33e-7a7918edaa03` | `incident` | (processProjectCode eq {filterValue1} [saved: PRJ1]) |
| Hours Worked | `f48dfaac-be25-4344-b03f-0f59883623e8` | `incident` | (processProjectCode eq {filterValue1} [saved: PRJ1]) |
| Total incidents | `ba792bfc-310e-4b8b-b7ff-933fefffd454` | `incident` | (processProjectCode eq {filterValue1} [saved: PRJ1]) |
| Previous year | `4b936433-e191-4f96-9906-2c3a2532dd12` | `incident` | (processProjectCode eq {filterValue1} [saved: PRJ1]) |

**Filter: Location** (`1fc6e8e2-8dfe-4bbf-97ba-61e7a154cedb`), dropdownlist; options source `asset`; display `displayName`; value `code`; URL parameter `location`.

Option constraints: `(type eq Site)`.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| First Aid Cases | `d90c47c0-2c89-4df4-8fa2-27b4fb7cc8a4` | `incident` | (processLocationCode eq {filterValue1} [saved: ST001]) |
| Medical Treatment | `9248024f-a5f4-4b15-946b-a4c5ec2c7d82` | `incident` | (processLocationCode eq {filterValue1} [saved: ST001]) |
| Lost Time Cases | `fb254ef0-59f2-44a2-b33e-7a7918edaa03` | `incident` | (processLocationCode eq {filterValue1} [saved: ST001]) |
| RIDDOR Cases | `1e228678-944e-46e7-bc8c-b763b79a23ec` | `incident` | (processLocationCode eq {filterValue1} [saved: ST001]) |
| Hours Worked | `f48dfaac-be25-4344-b03f-0f59883623e8` | `incident` | (processLocationCode eq {filterValue1} [saved: ST001]) |
| Total incidents | `ba792bfc-310e-4b8b-b7ff-933fefffd454` | `incident` | (processLocationCode eq {filterValue1} [saved: ST001]) |
| Previous year | `4b936433-e191-4f96-9906-2c3a2532dd12` | `incident` | (processLocationCode eq {filterValue1} [saved: ST001]) |

**Filter: Date Range** (`8194614d-1024-4101-bbdb-76a7cad61945`), daterange; options source `manual`; display ``; value ``; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Incidents **missing in page** | `b91838ae-2965-40aa-8170-96729363a564` | `incident` | (processDate gte {filterValue1} AND processDate lte {filterValue2}) |

Interpretation and discrepancy status: [report guide](../accident-rate.md). `{filterValue1}` / `{filterValue2}` are saved filter references; `[saved: ...]` is accompanying display text, not a universal fixed value. Empty date-operator operands can be normal.
