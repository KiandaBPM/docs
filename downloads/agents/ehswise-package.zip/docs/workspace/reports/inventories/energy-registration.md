# Energy & Waste — export inventory

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [energy-registration.json](../../../../pages/Analytics/energy-registration.json); page ID `energy-registration`.

| Widget title / ID | Type and source query | Grouping / aggregation / fixed conditions | Connected list |
| --- | --- | --- | --- |
| Energy Registrations<br>`da2a79c4-cd2c-4886-9fa3-33f814829b41` | widgets/widget-list; energy-registration; own / all |  |  |
| Created this week<br>`eed8002d-ed94-46dd-ae73-e7f83951e3c3` | widgets/widget-tile; energy-registration; own / all | tile count; where (__CREATED isThisWeek ) | da2a79c4-cd2c-4886-9fa3-33f814829b41 |
| Created previous month<br>`ead4da6b-6438-4b6c-ba6b-7709b76f70b5` | widgets/widget-tile; energy-registration; own / all | tile count; where (__CREATED isPrevMonth ) | da2a79c4-cd2c-4886-9fa3-33f814829b41 |
| Created previous year<br>`8cfd0495-e1fe-4975-ae46-a6ad3a4dcc69` | widgets/widget-tile; energy-registration; own / all | tile count; where (__CREATED isPrevYear ) | da2a79c4-cd2c-4886-9fa3-33f814829b41 |
| Status<br>`eef82b2f-c675-4c41-81a6-daf2af9af43c` | widgets/widget-chart; energy-registration; own / all | group __STATUS; chart pie | da2a79c4-cd2c-4886-9fa3-33f814829b41 |
| Energy Type<br>`78ff2ad4-1b70-4a28-92a5-75378fb76ce1` | widgets/widget-chart; energy-registration; own / all | group ERE_TXTSIN_EnergyType; chart bar | da2a79c4-cd2c-4886-9fa3-33f814829b41 |
| Total Number of Energy and Waste Records<br>`7381c8f1-7240-4da3-9be0-f5e5080e0001` | widgets/widget-tile; energy-registration; own / all | tile count | da2a79c4-cd2c-4886-9fa3-33f814829b41 |

**List: Energy Registrations** — page size 30; add no; delete no; bulk delete no; export yes.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| ID | `__NAME` | hidden |
| Energy Reg ID | `___CUSTOM_FIELD14` | Handlebars template |
| Custom ID | `processCustomID` | hidden |
| Project | `processProject` |  |
| Start date | `ER_DATE_StartDate` |  |
| End Date | `ER_DATE_EndDate` |  |
| Asset type | `ERE_LSTSIN_AggregatedAsset?inlineButtons` |  |
| Energy type  | `ERE_LISTSIN_EnergyType` |  |
| Energy subtype | `ERE_LISTSIN_EnergySubtype` |  |
| Unit | `ERE_LISTSIN_Units` |  |
| Amount | `ERE_NUM_SingularAmount` |  |
| Other asset types | `ERE_LSTSIN_AggregatedAsset` |  |
| Modified by | `__MODIFIED_BY` |  |
| Created | `__CREATED` |  |
| Status | `__STATUS` | hidden |
| Energy Registration Status | `___CUSTOM_FIELD13` | Handlebars template |

**Filter: Project** (`708adc8d-b447-40b6-be3a-a71c5e38f30b`), dropdownlist; options source `energy-registration`; display `processProject`; value `processProject`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Energy Registrations | `da2a79c4-cd2c-4886-9fa3-33f814829b41` | `energy-registration` | (processProject eq {filterValue1}) |
| Status | `eef82b2f-c675-4c41-81a6-daf2af9af43c` | `energy-registration` | (processProject eq {filterValue1}) |
| Energy Type | `78ff2ad4-1b70-4a28-92a5-75378fb76ce1` | `energy-registration` | (processProject eq {filterValue1}) |

**Filter: Date** (`9ddb765b-c51e-4087-82d2-926d384ac62b`), daterange; options source `manual`; display ``; value ``; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Energy Registrations | `da2a79c4-cd2c-4886-9fa3-33f814829b41` | `energy-registration` | (__CREATED gte {filterValue1} AND __CREATED lte {filterValue2}) |

Interpretation and discrepancy status: [report guide](../energy-registration.md). `{filterValue1}` / `{filterValue2}` are saved filter references; `[saved: ...]` is accompanying display text, not a universal fixed value. Empty date-operator operands can be normal.
