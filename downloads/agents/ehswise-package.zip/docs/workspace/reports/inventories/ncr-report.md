# Non Conformance Reports — export inventory

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [ncr-report.json](../../../../pages/Analytics/ncr-report.json); page ID `ncr-report`.

| Widget title / ID | Type and source query | Grouping / aggregation / fixed conditions | Connected list |
| --- | --- | --- | --- |
| Status<br>`bd519a71-d358-48ef-8cf5-7211fca8a20e` | widgets/widget-chart; ncr; own / all | group __STATUS; chart pie | 4e0d4095-8895-4997-95fe-27a60ae50c4f |
| Classification<br>`98526ed6-10c2-4e4f-a646-b596e30d85c7` | widgets/widget-chart; ncr; own / all | group Category; chart pie | 4e0d4095-8895-4997-95fe-27a60ae50c4f |
| Project<br>`cbd2a259-e853-4e83-8773-e362cd3fdd65` | widgets/widget-chart; ncr; own / all | group processProject; chart pie | 4e0d4095-8895-4997-95fe-27a60ae50c4f |
| NCR Records<br>`4e0d4095-8895-4997-95fe-27a60ae50c4f` | widgets/widget-list; ncr; own / all |  |  |
| Created this week<br>`acf36dcc-bd4c-419a-9d40-8693e92fb764` | widgets/widget-tile; ncr; own / all | tile count; where (Process Created Date isThisWeek ) | 4e0d4095-8895-4997-95fe-27a60ae50c4f |
| Created previous month<br>`8a2256e9-aa8a-4254-8e94-9c9ea63f395c` | widgets/widget-tile; ncr; own / all | tile count; where (Process Created Date isPrevMonth ) | 4e0d4095-8895-4997-95fe-27a60ae50c4f |
| Created previous year<br>`d4df8a50-c363-414b-9620-2f731055dc6c` | widgets/widget-tile; ncr; own / all | tile count; where (Process Created Date isPrevYear ) | 4e0d4095-8895-4997-95fe-27a60ae50c4f |
| Major<br>`95e4ffbe-c7f0-4971-a53a-8dfc35cdfd02` | widgets/widget-tile; ncr; own / all | tile count; where (Category eq Major) | 4e0d4095-8895-4997-95fe-27a60ae50c4f |
| Minor<br>`785c717b-7300-411c-91d2-6278d2c326a0` | widgets/widget-tile; ncr; own / all | tile count; where (Category eq Minor) | 4e0d4095-8895-4997-95fe-27a60ae50c4f |
| OBS and OFI<br>`d8d4dd67-7098-406a-b442-d726aec2ad48` | widgets/widget-tile; ncr; own / all | tile count; where (Category eq OBS OR Category eq OFI) | 4e0d4095-8895-4997-95fe-27a60ae50c4f |
| Total Number of NCRs<br>`45f5ff6b-4c42-457a-afd2-7a299572335a` | widgets/widget-tile; ncr; own / all | tile count | 4e0d4095-8895-4997-95fe-27a60ae50c4f |

**List: NCR Records** — page size 30; add no; delete no; bulk delete no; export yes.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| ID | `__NAME` | hidden |
| NCR ID | `___CUSTOM_FIELD11` | Handlebars template |
| Custom ID | `processCustomID` | hidden |
| Date and Time | `Process Created Date` |  |
| Title | `processSubject` |  |
| Classification | `Category` |  |
| Originator | `raised by` |  |
| Project | `processProject` |  |
| Owner | `manager` |  |
| Modified by | `__MODIFIED_BY` |  |
| Status | `__STATUS` | hidden |
| NCR Status | `___CUSTOM_FIELD10` | Handlebars template |

**Filter: Filter By Project** (`c3061c46-8e8c-4f38-bbb9-71be858ae0b3`), dropdownlist; options source `ncr`; display `processProject`; value `processProject`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| NCR Records | `4e0d4095-8895-4997-95fe-27a60ae50c4f` | `ncr` | (processProject eq {filterValue1}) |
| Status | `bd519a71-d358-48ef-8cf5-7211fca8a20e` | `ncr` | (processProject eq {filterValue1}) |
| Classification | `98526ed6-10c2-4e4f-a646-b596e30d85c7` | `ncr` | (processProject eq {filterValue1}) |
| Major | `95e4ffbe-c7f0-4971-a53a-8dfc35cdfd02` | `ncr` | (processProject eq {filterValue1}) |
| Minor | `785c717b-7300-411c-91d2-6278d2c326a0` | `ncr` | (processProject eq {filterValue1}) |
| OBS and OFI | `d8d4dd67-7098-406a-b442-d726aec2ad48` | `ncr` | (processProject eq {filterValue1}) |

**Filter: Date Range** (`bbe977ea-fad5-487e-aab6-d96dcb63993e`), daterange; options source `manual`; display ``; value ``; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| NCR Records | `4e0d4095-8895-4997-95fe-27a60ae50c4f` | `ncr` | (Process Created Date gte {filterValue1} AND Process Created Date lte {filterValue2}) |

Interpretation and discrepancy status: [report guide](../ncr-report.md). `{filterValue1}` / `{filterValue2}` are saved filter references; `[saved: ...]` is accompanying display text, not a universal fixed value. Empty date-operator operands can be normal.
