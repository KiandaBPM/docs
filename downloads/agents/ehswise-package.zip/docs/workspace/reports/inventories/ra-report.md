# Risk Assessments — export inventory

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [ra-report.json](../../../../pages/Analytics/ra-report.json); page ID `ra-report`.

| Widget title / ID | Type and source query | Grouping / aggregation / fixed conditions | Connected list |
| --- | --- | --- | --- |
| Status<br>`f0d79560-d5fa-48d4-8a04-56b70db1f316` | widgets/widget-chart; ra; own / all | group __STATUS; chart pie | cc9a083e-be95-4794-ab19-514c68fca93f |
| Project<br>`40f1d454-e71a-46fa-b64a-fdf57c077a1f` | widgets/widget-chart; ra; own / all | group processProject; chart bar | cc9a083e-be95-4794-ab19-514c68fca93f |
| Assessors<br>`7e344138-f972-477f-8a69-55036650ccbf` | widgets/widget-chart; ra; own / all | group assessors; chart pie | cc9a083e-be95-4794-ab19-514c68fca93f |
| Task Based<br>`d73edeb6-0ba0-4edf-a51c-22fbb1dcc2ef` | widgets/widget-tile; ra; own / all | tile count; where (typeOfAssessment eq Task based) | cc9a083e-be95-4794-ab19-514c68fca93f |
| Risk Assessments<br>`cc9a083e-be95-4794-ab19-514c68fca93f` | widgets/widget-list; ra; own / all |  |  |
| COSHH<br>`e408a92d-c728-4d78-956f-5dc2d47d6db1` | widgets/widget-tile; ra; own / all | tile count; where (typeOfAssessment eq COSHH) | cc9a083e-be95-4794-ab19-514c68fca93f |
| Created this week<br>`6b0fa04f-c86a-4a0e-811b-f0afb072d6d6` | widgets/widget-tile; event; own / all | tile count; where (__CREATED isThisWeek ) | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Created previous week<br>`da1a7337-b800-4efa-8769-87c6132c2352` | widgets/widget-tile; event; own / all | tile count; where (__CREATED isPrevWeek ) | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Created this year<br>`a8327942-3330-47d3-8146-b056f667e907` | widgets/widget-tile; event; own / all | tile count; where (__CREATED isPrevYear ) | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Overdue Review Date<br>`f1eb1a43-0050-4ae8-981b-b11dd4809f23` | widgets/widget-tile; ra; own / all | tile count; where (recommendedReviewDate isBeforeToday Toolbox) | cc9a083e-be95-4794-ab19-514c68fca93f |
| Risk Assessments<br>`d888560a-8546-489e-a77b-82b12bea2d61` | widgets/widget-tile; ra; own / all | tile count | cc9a083e-be95-4794-ab19-514c68fca93f |

**List: Risk Assessments** — page size 30; add no; delete no; bulk delete no; export yes.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| ID | `__NAME` | hidden |
| Custom ID | `processCustomID` |  |
| Created | `__CREATED` |  |
| Initiated by | `__CREATED_BY` |  |
| Area | `area` |  |
| Effective Date | `effectiveDate` |  |
| Review Date | `recommendedReviewDate` |  |
| Review Date Timeframe | `___CUSTOM_FIELD15` | Handlebars template |
| Operator | `operator` |  |
| Project | `processProject` |  |
| Assessor(s) | `assessors` |  |
| Assessment date | `processDate` |  |
| Close comment | `OBS_TXTMUL_CloseComments` |  |
| Version Number | `versionNumber` |  |
| Status | `__STATUS` | hidden |
| Review Date | `___CUSTOM_FIELD15` | Handlebars template |
| Risk Assessment Status | `___CUSTOM_FIELD8` | Handlebars template |

**Filter: Filter by Project** (`58aefa13-0334-494f-b07d-7ae67da08fa3`), dropdownlist; options source `event`; display `processProject`; value `processProject`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Risk Assessments | `cc9a083e-be95-4794-ab19-514c68fca93f` | `event` | (processProject eq {filterValue1}) |
| Assessors | `7e344138-f972-477f-8a69-55036650ccbf` | `event` | (processProject eq {filterValue1}) |
| Task Based | `d73edeb6-0ba0-4edf-a51c-22fbb1dcc2ef` | `event` | (processProject eq {filterValue1}) |
| COSHH | `e408a92d-c728-4d78-956f-5dc2d47d6db1` | `event` | (processProject eq {filterValue1}) |
| Overdue Review Date | `f1eb1a43-0050-4ae8-981b-b11dd4809f23` | `event` | (processProject eq {filterValue1}) |
| Risk Assessments | `cc9a083e-be95-4794-ab19-514c68fca93f` | `event` | (processProject eq {filterValue1}) |
| Status | `f0d79560-d5fa-48d4-8a04-56b70db1f316` | `event` | (processProject eq {filterValue1}) |
| Project | `40f1d454-e71a-46fa-b64a-fdf57c077a1f` | `ra` | (processProject eq {filterValue1}) |

**Filter: Date range** (`83f4d52b-7d3e-4581-bd90-2fa148b858e5`), daterange; options source `manual`; display ``; value ``; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Events **missing in page** | `6acb37ed-392c-477f-aa46-71e86e1da409` | `event` | (__CREATED gte {filterValue1} AND __CREATED lte {filterValue2}) |

Interpretation and discrepancy status: [report guide](../ra-report.md). `{filterValue1}` / `{filterValue2}` are saved filter references; `[saved: ...]` is accompanying display text, not a universal fixed value. Empty date-operator operands can be normal.
