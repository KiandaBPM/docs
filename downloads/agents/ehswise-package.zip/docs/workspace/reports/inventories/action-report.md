# Actions — export inventory

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [action-report.json](../../../../pages/Analytics/action-report.json); page ID `action-report`.

| Widget title / ID | Type and source query | Grouping / aggregation / fixed conditions | Connected list |
| --- | --- | --- | --- |
| Status<br>`93ec3954-2b40-447b-ae0d-3550023294b8` | widgets/widget-chart; action; own / all | group __STATUS; chart pie | b84cb3d7-7638-481e-98ac-a35b52ddc2da |
| Priority<br>`6ea8b601-fa9e-4acd-a6be-0117049cf949` | widgets/widget-chart; action; own / all | group ACT_LSTSIN_Priority?inlineButtons; chart pie | b84cb3d7-7638-481e-98ac-a35b52ddc2da |
| Checklist<br>`dc898dfc-2dd1-43d8-baff-0a8a3cc1a4aa` | widgets/widget-list; action; own / all | where (ACT_DATE_DueDate isBeforeToday {ACT_DATE_ActionCompleted} [saved: Date action completed] AND __STATUS eq Follow-up) |  |
| High Priority<br>`cbaae906-23cd-42df-b6f0-5cf29e2d99b0` | widgets/widget-tile; action; own / all | tile count; where (ACT_LSTSIN_Priority?inlineButtons eq High) | b84cb3d7-7638-481e-98ac-a35b52ddc2da |
| Actions<br>`b84cb3d7-7638-481e-98ac-a35b52ddc2da` | widgets/widget-list; action; own / all |  |  |
| Reported this week<br>`df6af641-117a-4e78-9253-781e45d6c336` | widgets/widget-tile; action; own / all | tile count; where (processDate isThisWeek ) | b84cb3d7-7638-481e-98ac-a35b52ddc2da |
| Reported previous month<br>`3da10166-fad9-4fdc-9236-e838777798d1` | widgets/widget-tile; action; own / all | tile count; where (processDate isPrevMonth ) | b84cb3d7-7638-481e-98ac-a35b52ddc2da |
| Reported previous year<br>`371fdb0a-6b88-43d7-8aca-3a18b0a17abe` | widgets/widget-tile; action; own / all | tile count; where (processDate isPrevYear ) | b84cb3d7-7638-481e-98ac-a35b52ddc2da |
| External Actions<br>`d803370a-9c89-4947-a92e-bab1c963a0fb` | widgets/widget-tile; action; own / all | tile count; where (internalExternalResponsible eq External) | b84cb3d7-7638-481e-98ac-a35b52ddc2da |
| Add Action<br>`ac9e8212-83e2-4e29-a101-c162ca5b0e21` | widgets/widget-link; ;  /  |  |  |
| Overdue Actions<br>`199f5760-e598-40af-b66c-e4c2c02ccb2a` | widgets/widget-tile; action; own / all | tile count; where (ACT_DATE_DueDate isBeforeToday  AND __STATUS eq Follow-up) | b84cb3d7-7638-481e-98ac-a35b52ddc2da |

**List: Checklist** — page size 10; add no; delete no; bulk delete no; export no.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| ID | `__NAME` | hidden |
| Process Name | `__PROCESS_NAME` | hidden |
| Modified | `__MODIFIED` | hidden |
| Action topic | `ACT_TXTSIN_Desc` | hidden |
| Priority | `ACT_LSTSIN_Priority?inlineButtons` | hidden |
| Due date | `ACT_LSTSIN_DueDate?inlineButtons` | hidden |
| Overdue Actions | `___CUSTOM_FIELD6` | Handlebars template |
| Status | `__STATUS` | hidden |
| Due date | `ACT_DATE_DueDate` | hidden |

**List: Actions** — page size 30; add no; delete no; bulk delete no; export yes.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| ID | `__NAME` | hidden |
| Custom ID | `processCustomID` | hidden |
| Action ID | `___CUSTOM_FIELD13` | Handlebars template |
| Created by | `__CREATED_BY` |  |
| Internal or external? | `internalExternalResponsible` |  |
| Created | `__CREATED` | hidden |
| Action topic | `ACT_TXTSIN_Desc` |  |
| Responsible users | `ACT_USER_ResponsibleUsers` |  |
| Priority | `ACT_LSTSIN_Priority?inlineButtons` | hidden |
| Priority | `___CUSTOM_FIELD18` | Handlebars template |
| Due date | `ACT_DATE_DueDate` |  |
| Date assigned | `processDate` |  |
| Project | `processProject` | hidden |
| Specific Location | `processLocation` | hidden |
| Action Status | `___CUSTOM_FIELD11` | Handlebars template |
| Status | `__STATUS` | hidden |
| Description of action taken | `ACT_TXTMUL_ActionsTaken` |  |
| Date action completed | `ACT_DATE_ActionCompleted` |  |
| Action completed by | `ACT_USER_ActionCompletedBy` |  |

**Filter: Filter By Responsibles** (`2c850f6b-ef3b-409c-88d3-a229a4147ba1`), dropdownlist; options source `action`; display `ACT_USER_ResponsibleUsers`; value `ACT_USER_ResponsibleUsers`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Actions | `b84cb3d7-7638-481e-98ac-a35b52ddc2da` | `action` | (ACT_USER_ResponsibleUsers contains {filterValue1}) |
| Status | `93ec3954-2b40-447b-ae0d-3550023294b8` | `action` | (ACT_USER_ResponsibleUsers contains {filterValue1}) |
| Overdue Actions | `199f5760-e598-40af-b66c-e4c2c02ccb2a` | `action` | (ACT_USER_ResponsibleUsers eq {filterValue1}) |
| High Priority | `cbaae906-23cd-42df-b6f0-5cf29e2d99b0` | `action` | (ACT_USER_ResponsibleUsers contains {filterValue1}) |
| External Actions | `d803370a-9c89-4947-a92e-bab1c963a0fb` | `action` | (ACT_USER_ResponsibleUsers contains {filterValue1}) |
| Priority | `6ea8b601-fa9e-4acd-a6be-0117049cf949` | `action` | (ACT_USER_ResponsibleUsers contains {filterValue1}) |
| Checklist | `dc898dfc-2dd1-43d8-baff-0a8a3cc1a4aa` | `action` | (ACT_USER_ResponsibleUsers contains {filterValue1}) |
| Completed on Time **missing in page** | `24aa5edd-7559-48ff-92d8-a98ba4f6fdbc` | `action` | (ACT_USER_ResponsibleUsers contains {filterValue1}) |

**Filter: Date Range** (`1385f920-78ee-47e6-b930-c9d702adf5a5`), daterange; options source `manual`; display ``; value ``; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Actions | `b84cb3d7-7638-481e-98ac-a35b52ddc2da` | `action` | (processDate gte {filterValue1} AND processDate lte {filterValue2}) |
| Checklist | `dc898dfc-2dd1-43d8-baff-0a8a3cc1a4aa` | `action` | (processDate gte {filterValue1} AND processDate lte {filterValue2}) |
| High Priority | `cbaae906-23cd-42df-b6f0-5cf29e2d99b0` | `action` | (processDate gte {filterValue1} AND processDate lte {filterValue2}) |
| External Actions | `d803370a-9c89-4947-a92e-bab1c963a0fb` | `action` | (processDate gte {filterValue1} AND processDate lte {filterValue2}) |

Interpretation and discrepancy status: [report guide](../action-report.md). `{filterValue1}` / `{filterValue2}` are saved filter references; `[saved: ...]` is accompanying display text, not a universal fixed value. Empty date-operator operands can be normal.
