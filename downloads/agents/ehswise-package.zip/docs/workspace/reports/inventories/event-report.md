# Events — export inventory

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [event-report.json](../../../../pages/Analytics/event-report.json); page ID `event-report`.

| Widget title / ID | Type and source query | Grouping / aggregation / fixed conditions | Connected list |
| --- | --- | --- | --- |
| Status<br>`489cba4f-8ef9-4ce2-a83a-3b8a0d287312` | widgets/widget-chart; event; own / all | group __STATUS; chart pie | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Project<br>`5916db6d-0f89-47de-949c-0dc7e2f6a58c` | widgets/widget-chart; event; own / all | group processProject; chart bar | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Event Type<br>`3b0879f0-dc17-4f60-b182-a0262ea7b4a1` | widgets/widget-chart; event; own / all | group eventType?radioCards; chart pie | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Induction<br>`90be57c4-bc52-4b39-bd78-c2d8b71eef1e` | widgets/widget-tile; event; own / all | tile count; where (eventType?radioCards eq Induction) | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Events<br>`6acb37ed-392c-477f-aa46-71e86e1da409` | widgets/widget-list; event; own / all |  |  |
| Drill<br>`517418cf-30e6-41ee-a5f5-260c35878342` | widgets/widget-tile; event; own / all | tile count; where (eventType?radioCards eq Drill) | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Created this week<br>`76d494f1-87bd-4557-9033-68bbbd65b64f` | widgets/widget-tile; event; own / all | tile count; where (__CREATED isThisWeek ) | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Created previous week<br>`211e354a-1110-42a7-a777-5f27c5f40ee0` | widgets/widget-tile; event; own / all | tile count; where (__CREATED isPrevWeek ) | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Created this year<br>`e6d8226c-7548-40de-b4a3-f2d941eec35f` | widgets/widget-tile; event; own / all | tile count; where (__CREATED isPrevYear ) | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Toolbox<br>`ea5d00d3-4ab2-4199-9317-8e1a2f996a43` | widgets/widget-tile; event; own / all | tile count; where (eventType?radioCards eq Toolbox) | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Training<br>`6ed10c67-bc4b-4b27-955d-1dd8ba3f2fa8` | widgets/widget-tile; event; own / all | tile count; where (eventType?radioCards eq Training) | 6acb37ed-392c-477f-aa46-71e86e1da409 |
| Total Number of Events<br>`e8a6174c-4cf3-4036-95f3-a1cb6088c6bb` | widgets/widget-tile; event; own / all | tile count | 6acb37ed-392c-477f-aa46-71e86e1da409 |

**List: Events** — page size 30; add no; delete no; bulk delete no; export yes.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| ID | `__NAME` | hidden |
| Event ID | `___CUSTOM_FIELD9` | Handlebars template |
| Custom ID | `processCustomID` | hidden |
| Event Type | `eventType?radioCards` |  |
| Title | `processSubject` |  |
| Project | `processProject` |  |
| Created | `__CREATED` |  |
| Initiated by | `__CREATED_BY` |  |
| Status | `__STATUS` | hidden |
| Event Status | `___CUSTOM_FIELD8` | Handlebars template |

**Filter: Filter By Project** (`6a6cde2a-98c4-4889-9d6d-14f6ab37d045`), dropdownlist; options source `event`; display `processProject`; value `processProject`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Events | `6acb37ed-392c-477f-aa46-71e86e1da409` | `event` | (processProject eq {filterValue1}) |
| Event Type | `3b0879f0-dc17-4f60-b182-a0262ea7b4a1` | `event` | (processProject eq {filterValue1}) |
| Induction | `90be57c4-bc52-4b39-bd78-c2d8b71eef1e` | `event` | (processProject eq {filterValue1}) |
| Drill | `517418cf-30e6-41ee-a5f5-260c35878342` | `event` | (processProject eq {filterValue1}) |
| Status | `489cba4f-8ef9-4ce2-a83a-3b8a0d287312` | `event` | (processProject eq {filterValue1}) |
| Toolbox | `ea5d00d3-4ab2-4199-9317-8e1a2f996a43` | `event` | (processProject eq {filterValue1}) |
| Training | `6ed10c67-bc4b-4b27-955d-1dd8ba3f2fa8` | `event` | (processProject eq {filterValue1}) |

**Filter: Date range** (`496cf03f-e349-4f8e-b74e-6fa4d5864f39`), daterange; options source `manual`; display ``; value ``; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Events | `6acb37ed-392c-477f-aa46-71e86e1da409` | `event` | (__CREATED gte {filterValue1} AND __CREATED lte {filterValue2}) |

Interpretation and discrepancy status: [report guide](../event-report.md). `{filterValue1}` / `{filterValue2}` are saved filter references; `[saved: ...]` is accompanying display text, not a universal fixed value. Empty date-operator operands can be normal.
