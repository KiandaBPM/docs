# Inspections — export inventory

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [inspections-report.json](../../../../pages/Analytics/inspections-report.json); page ID `inspections-report`.

| Widget title / ID | Type and source query | Grouping / aggregation / fixed conditions | Connected list |
| --- | --- | --- | --- |
| Status<br>`70a02f05-a458-4d67-a9c9-d0e629ba7a6a` | widgets/widget-chart; inspection; own / all | group __STATUS; chart pie | 41081568-83a6-47a3-9340-2e019d5eb19c |
| Project<br>`037d3c7e-7c66-471a-85af-6e44f6ab409f` | widgets/widget-chart; inspection; own / all | group processProject; chart pie | 41081568-83a6-47a3-9340-2e019d5eb19c |
| Checklist<br>`950bdbfd-20d6-464e-a5b9-0ba1863411a8` | widgets/widget-chart; inspection; own / all | group INS_LUPSIN_Checklist; chart bar | 41081568-83a6-47a3-9340-2e019d5eb19c |
| Pass<br>`343e184f-5f6d-46c3-b716-5e4897c7f349` | widgets/widget-tile; inspection; own / all | tile count; where (__STATUS eq Pass) | 41081568-83a6-47a3-9340-2e019d5eb19c |
| At Risk<br>`7090d8e2-5a68-49d9-9e35-0b8587ade025` | widgets/widget-tile; inspection; own / all | tile count; where (__STATUS eq At Risk) | 41081568-83a6-47a3-9340-2e019d5eb19c |
| Failed<br>`c713315b-4471-4c05-9988-9a083677587b` | widgets/widget-tile; inspection; own / all | tile count; where (__STATUS eq Failed) | 41081568-83a6-47a3-9340-2e019d5eb19c |
| Inspections<br>`41081568-83a6-47a3-9340-2e019d5eb19c` | widgets/widget-list; inspection; own / all |  |  |
| This Month<br>`c299d940-93c0-4e80-bfdf-9f0f6fa49dfc` | widgets/widget-tile; inspection; own / all | tile count; where (processDate isThisMonth ) | 41081568-83a6-47a3-9340-2e019d5eb19c |
| Last Month<br>`e5882b86-fab4-47ae-a44d-93aa479df227` | widgets/widget-tile; inspection; own / all | tile count; where (processDate isPrevMonth ) | 1bea60b6-e323-4382-8993-7ac9bcf22fc4 |
| Last Year<br>`00ad738c-62c3-4948-b8f7-47c35f50bc94` | widgets/widget-tile; inspection; own / all | tile count; where (processDate isPrevYear ) | 41081568-83a6-47a3-9340-2e019d5eb19c |
| Total Number of Inspections<br>`22990e12-4960-482a-a6c3-a31319d361d0` | widgets/widget-tile; inspection; own / all | tile count | 41081568-83a6-47a3-9340-2e019d5eb19c |

**List: Inspections** — page size 30; add no; delete no; bulk delete no; export yes.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| Inspection ID | `___CUSTOM_FIELD11` | Handlebars template |
| ID | `__NAME` | hidden |
| Custom ID | `processCustomID` | hidden |
| Audit type | `type-of-audit?radioCards` | hidden |
| Title | `INS_TXTSIN_UploadTitle` |  |
| Category | `category` |  |
| Checklist | `INS_LUPSIN_Checklist` |  |
| Project | `processProject` |  |
| When | `processDate` |  |
| Created by | `__CREATED_BY` |  |
| Status | `__STATUS` | hidden |
| Passed? | `___CUSTOM_FIELD12` | hidden, Handlebars template |
| Inspection Status | `___CUSTOM_FIELD13` | Handlebars template |
| _processSubstatus | `processSubstatus` | hidden |

**Filter: Filter By Project** (`b87f123c-1b00-4fff-a60e-822d272aee50`), dropdownlist; options source `inspection`; display `processProject`; value `processProject`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Audits | `41081568-83a6-47a3-9340-2e019d5eb19c` | `inspection` | (processProject eq {filterValue1}) |
| Status | `70a02f05-a458-4d67-a9c9-d0e629ba7a6a` | `inspection` | (processProject eq {filterValue1}) |
| Checklist | `950bdbfd-20d6-464e-a5b9-0ba1863411a8` | `inspection` | (processProject eq {filterValue1}) |
| Pass | `343e184f-5f6d-46c3-b716-5e4897c7f349` | `inspection` | (processProject eq {filterValue1}) |
| Inspections | `41081568-83a6-47a3-9340-2e019d5eb19c` | `inspection` | (processProject eq {filterValue1}) |
| At Risk | `7090d8e2-5a68-49d9-9e35-0b8587ade025` | `inspection` | (processProject eq {filterValue1}) |
| Failed | `c713315b-4471-4c05-9988-9a083677587b` | `inspection` | (processProject eq {filterValue1}) |

**Filter: Date range** (`0f7c4efd-0d7a-49d6-91b6-8dd389331ab3`), daterange; options source `manual`; display ``; value ``; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Audits **missing in page** | `1bea60b6-e323-4382-8993-7ac9bcf22fc4` | `audit` | (auditDate gte {filterValue1} AND auditDate lte {filterValue2}) |

Interpretation and discrepancy status: [report guide](../inspections-report.md). `{filterValue1}` / `{filterValue2}` are saved filter references; `[saved: ...]` is accompanying display text, not a universal fixed value. Empty date-operator operands can be normal.
