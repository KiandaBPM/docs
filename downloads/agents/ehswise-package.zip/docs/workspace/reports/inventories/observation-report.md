# Observations — export inventory

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [observation-report.json](../../../../pages/Analytics/observation-report.json); page ID `observation-report`.

| Widget title / ID | Type and source query | Grouping / aggregation / fixed conditions | Connected list |
| --- | --- | --- | --- |
| Status<br>`083f1822-35fc-49bd-aa18-515dbd6314b4` | widgets/widget-chart; observation; own / all | group __STATUS; chart pie | fadac495-db3e-4938-811e-de3badc44283 |
| Project<br>`3d1e106e-59cd-4712-91f1-e78135552783` | widgets/widget-chart; observation; own / all | group processProject; chart bar | fadac495-db3e-4938-811e-de3badc44283 |
| Observation Type<br>`c4e6c595-12a9-4641-908f-8418e15dbe2e` | widgets/widget-chart; observation; own / all | group OBS_LSTSIN_TopicType?radioCards; chart pie | fadac495-db3e-4938-811e-de3badc44283 |
| Total Number Observations<br>`11edbc5c-7308-43dd-af02-3bf74a3e1ad5` | widgets/widget-tile; observation; own / all | tile count | fadac495-db3e-4938-811e-de3badc44283 |
| Observations<br>`fadac495-db3e-4938-811e-de3badc44283` | widgets/widget-list; observation; own / all |  |  |
| Stop Work Authority?<br>`7178157c-9e81-4e86-a5a8-4880e5b46e47` | widgets/widget-tile; observation; own / all | tile count; where (OBS_YN_SWAUsed eq Yes) | fadac495-db3e-4938-811e-de3badc44283 |
| Reported this week<br>`c153d7c9-4b1b-4490-a75e-b7e6e8898f25` | widgets/widget-tile; observation; own / all | tile count; where (processDate isThisWeek ) | fadac495-db3e-4938-811e-de3badc44283 |
| Reported previous month<br>`9ca6118b-e994-4ade-9e72-1cab317b88c9` | widgets/widget-tile; observation; own / all | tile count; where (processDate isPrevMonth ) | fadac495-db3e-4938-811e-de3badc44283 |
| Reported previous year<br>`cfe36837-75bd-4980-a034-4435b9bd1df8` | widgets/widget-tile; observation; own / all | tile count; where (processDate isPrevYear ) | fadac495-db3e-4938-811e-de3badc44283 |
| Related to Subcontractor<br>`d357f10d-9620-47b9-ad6e-3ae5289678f2` | widgets/widget-tile; observation; own / all | tile count; where (isThisObservationRelatedToASubcontractor eq Yes) | fadac495-db3e-4938-811e-de3badc44283 |
| Positive Observations<br>`0e089c1d-34fc-4a40-b815-d655d8e860b3` | widgets/widget-tile; observation; own / all | tile count; where (OBS_LSTSIN_TopicType?radioCards eq Positive observation) | fadac495-db3e-4938-811e-de3badc44283 |

**List: Observations** — page size 30; add no; delete no; bulk delete no; export yes.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| ID | `__NAME` | hidden |
| Custom ID | `processCustomID` | hidden |
| Observation ID | `___CUSTOM_FIELD13` | Handlebars template |
| Observation type | `OBS_LSTSIN_TopicType?radioCards` |  |
| Project | `processProject` |  |
| Specific Location | `processLocation` |  |
| Asset | `subcontractor` |  |
| Title | `processSubject` |  |
| Reported on | `processDate` |  |
| Reported by | `OBS_USER_ReportedBy` |  |
| Stop Work Authority used? | `OBS_YN_SWAUsed` |  |
| Reported on behalf of employee | `OBS_USER_ReportedBehalfOf` |  |
| Reported on behalf of third party | `OBS_TXTSIN_ReportedBehalfOf` |  |
| Observation Status | `___CUSTOM_FIELD11` | Handlebars template |
| Status | `__STATUS` | hidden |

**Filter: Filter By Project** (`84697318-9100-47c1-b35e-bd046374b1de`), dropdownlist; options source `observation`; display `processProject`; value `processProject`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Observations | `fadac495-db3e-4938-811e-de3badc44283` | `observation` | (processProject eq {filterValue1}) |
| Status | `083f1822-35fc-49bd-aa18-515dbd6314b4` | `observation` | (processProject eq {filterValue1}) |
| Observation Type | `c4e6c595-12a9-4641-908f-8418e15dbe2e` | `observation` | (processProject eq {filterValue1}) |
| Observations | `fadac495-db3e-4938-811e-de3badc44283` | `observation` | (processProject eq {filterValue1}) |
| Stop Work Authority Used | `7178157c-9e81-4e86-a5a8-4880e5b46e47` | `observation` | (processProject eq {filterValue1}) |
| Related to Subcontractor | `d357f10d-9620-47b9-ad6e-3ae5289678f2` | `observation` | (processProject eq {filterValue1}) |

**Filter: Date Range** (`a33a8f21-88e0-4370-ba05-aeabb8a87163`), daterange; options source `manual`; display ``; value ``; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Observations | `fadac495-db3e-4938-811e-de3badc44283` | `observation` | (processDate gte {filterValue1} AND processDate lte {filterValue2}) |

Interpretation and discrepancy status: [report guide](../observation-report.md). `{filterValue1}` / `{filterValue2}` are saved filter references; `[saved: ...]` is accompanying display text, not a universal fixed value. Empty date-operator operands can be normal.
