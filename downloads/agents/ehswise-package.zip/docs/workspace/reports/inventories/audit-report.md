# Audits — export inventory

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [audit-report.json](../../../../pages/Analytics/audit-report.json); page ID `audit-report`.

| Widget title / ID | Type and source query | Grouping / aggregation / fixed conditions | Connected list |
| --- | --- | --- | --- |
| Status<br>`0c5866ba-3932-4389-81ab-ba214e326a84` | widgets/widget-chart; audit; own / all | group __STATUS; chart pie | 1bea60b6-e323-4382-8993-7ac9bcf22fc4 |
| Category<br>`db13625f-d71b-45e0-8229-2e09268e47dc` | widgets/widget-chart; audit; own / all | group category; chart pie | 1bea60b6-e323-4382-8993-7ac9bcf22fc4 |
| Projects<br>`501a91fd-40f8-47ac-bcb8-3716ea9faede` | widgets/widget-chart; audit; own / all | group processProject; chart bar | 1bea60b6-e323-4382-8993-7ac9bcf22fc4 |
| Audits<br>`1bea60b6-e323-4382-8993-7ac9bcf22fc4` | widgets/widget-list; audit; own / all |  |  |
| Audits this week<br>`6e43f4a2-2e60-4f5f-beba-3d6623031353` | widgets/widget-tile; audit; own / all | tile count; where (auditDate isThisWeek ) | 1bea60b6-e323-4382-8993-7ac9bcf22fc4 |
| Audits previous month<br>`a3acee4c-3098-41d5-8d95-e9522531d18b` | widgets/widget-tile; audit; own / all | tile count; where (auditDate isPrevMonth ) | 1bea60b6-e323-4382-8993-7ac9bcf22fc4 |
| Audits previous year<br>`3c247a40-5c3a-43d0-8150-7fe6c05bc201` | widgets/widget-tile; audit; own / all | tile count | 1bea60b6-e323-4382-8993-7ac9bcf22fc4 |
| Internal<br>`35a98175-5b85-4953-8b2b-5b28a6c9bda3` | widgets/widget-tile; audit; own / all | tile count; where (type-of-audit?radioCards eq Internal) | 1bea60b6-e323-4382-8993-7ac9bcf22fc4 |
| External<br>`d5ea4422-aaf6-41f7-bf0f-2764b916395f` | widgets/widget-tile; audit; own / all | tile count; where (type-of-audit?radioCards contains External) | 1bea60b6-e323-4382-8993-7ac9bcf22fc4 |
| Subcontractor<br>`cf8455e3-146e-404a-8d49-a069a284911c` | widgets/widget-tile; audit; own / all | tile count; where (type-of-audit?radioCards eq Subcontractor) | 1bea60b6-e323-4382-8993-7ac9bcf22fc4 |
| Total Number of Audits<br>`71e714de-07e7-48c8-8b25-1d914f0fa8c9` | widgets/widget-tile; audit; own / all | tile count | 1bea60b6-e323-4382-8993-7ac9bcf22fc4 |

**List: Audits** — page size 30; add no; delete no; bulk delete no; export yes.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| ID | `__NAME` | hidden |
| Audit ID | `___CUSTOM_FIELD13` | Handlebars template |
| Custom ID | `processCustomID` | hidden |
| Audit type | `type-of-audit?radioCards` |  |
| Category | `category` |  |
| Checklist | `INS_LUPSIN_Checklist` |  |
| Title | `processSubject` |  |
| Project | `processProject` |  |
| Audit date | `auditDate` |  |
| Created by | `__CREATED_BY` |  |
| Status | `__STATUS` | hidden |
| Standard | `standard` |  |
| Score | `totalScore` |  |
| Audit Status | `___CUSTOM_FIELD10` | Handlebars template |

**Filter: Filter By Project** (`0df05b80-b406-47f3-86f8-a60840c916e3`), dropdownlist; options source `audit`; display `processProject`; value `processProject`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Audits | `1bea60b6-e323-4382-8993-7ac9bcf22fc4` | `audit` | (processProject eq {filterValue1}) |
| Status | `0c5866ba-3932-4389-81ab-ba214e326a84` | `audit` | (processProject eq {filterValue1}) |
| Category | `db13625f-d71b-45e0-8229-2e09268e47dc` | `audit` | (processProject eq {filterValue1}) |
| Chart 13 | `501a91fd-40f8-47ac-bcb8-3716ea9faede` | `audit` | (processProject eq {filterValue1}) |
| Internal | `35a98175-5b85-4953-8b2b-5b28a6c9bda3` | `audit` | (processProject eq {filterValue1}) |
| External | `d5ea4422-aaf6-41f7-bf0f-2764b916395f` | `audit` | (processProject eq {filterValue1}) |
| Subcontractor | `cf8455e3-146e-404a-8d49-a069a284911c` | `audit` | (processProject eq {filterValue1}) |

**Filter: Date range** (`0830246b-eeaa-41d2-a069-585ca03166be`), daterange; options source `manual`; display ``; value ``; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Audits | `1bea60b6-e323-4382-8993-7ac9bcf22fc4` | `audit` | (auditDate gte {filterValue1} AND auditDate lte {filterValue2}) |

Interpretation and discrepancy status: [report guide](../audit-report.md). `{filterValue1}` / `{filterValue2}` are saved filter references; `[saved: ...]` is accompanying display text, not a universal fixed value. Empty date-operator operands can be normal.
