# Hazard Library — export inventory

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [hazard-library.json](../../../../pages/Analytics/hazard-library.json); page ID `hazard-library`.

| Widget title / ID | Type and source query | Grouping / aggregation / fixed conditions | Connected list |
| --- | --- | --- | --- |
| Total Number of Hazards<br>`22160dcd-ea62-454c-8e3e-c68ffb36925d` | widgets/widget-tile; hazard; own / all | tile count | a7a9cfce-2f7b-4dfc-a661-90e5c66f31ed |
| Very High Risks<br>`080e2bd4-c7ab-40b4-a477-f786fca47b4b` | widgets/widget-tile; hazard; own / all | tile count; where (riskRating gte 20) | a7a9cfce-2f7b-4dfc-a661-90e5c66f31ed |
| High Risks<br>`c306545a-aa67-41c5-9551-8b02c301a6d0` | widgets/widget-tile; hazard; own / all | tile count; where (riskRating gte 12 AND riskRating lte 19) | a7a9cfce-2f7b-4dfc-a661-90e5c66f31ed |
| Medium Risks<br>`839cfdc8-890f-4fd6-b489-282a024964a2` | widgets/widget-tile; hazard; own / all | tile count; where (riskRating gte 8 AND riskRating lte 11) | a7a9cfce-2f7b-4dfc-a661-90e5c66f31ed |
| Unlikely<br>`f6bd7d78-1666-4b70-83ea-e118c4877638` | widgets/widget-tile; hazard; own / all | tile count; where (riskRating gte 4 AND riskRating lte 7) | a7a9cfce-2f7b-4dfc-a661-90e5c66f31ed |
| Checklist<br>`8b4974d7-b52a-43f5-8682-58832a53be22` | widgets/widget-list; hazard; own / all | where (__STATUS eq Open) |  |
| Checklist<br>`e39c3d07-0db6-45cb-b03f-afec45958eaf` | widgets/widget-list; hazard; own / all | where (__STATUS eq Open) |  |
| Low Risks<br>`d582ba26-8a5b-4e06-9759-9dda95a0f6e2` | widgets/widget-tile; hazard; own / all | tile count; where (riskRating lte 3) | a7a9cfce-2f7b-4dfc-a661-90e5c66f31ed |
| Hazards<br>`a7a9cfce-2f7b-4dfc-a661-90e5c66f31ed` | widgets/widget-list; hazard; own / all |  |  |
| Create a Hazard<br>`bff57c0b-dff1-4f8a-b526-0bda846d700f` | widgets/widget-link; ;  /  |  |  |

**List: Checklist** — page size 10; add no; delete no; bulk delete no; export no.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| Top 10 Open Risks | `___CUSTOM_FIELD3` | Handlebars template |
| ID | `__NAME` | hidden |
| Modified | `__MODIFIED` | hidden |
| Title | `processTitle` | hidden |
| Status | `__STATUS` | hidden |
| Process Name | `__PROCESS_NAME` | hidden |
| Current Risk Rating | `riskRating` | hidden |

**List: Checklist** — page size 10; add no; delete no; bulk delete no; export no.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| ID | `__NAME` | hidden |
| Process Name | `__PROCESS_NAME` | hidden |
| Modified | `__MODIFIED` | hidden |
| Title | `processTitle` | hidden |
| Bottom 10 Open Risks | `___CUSTOM_FIELD5` | Handlebars template |
| Status | `__STATUS` | hidden |
| Current Risk Rating | `riskRating` | hidden |

**List: Hazards** — page size 20; add yes; delete yes; bulk delete no; export no.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| ID | `__NAME` | hidden |
| Process Name | `__PROCESS_NAME` | hidden |
| Modified | `__MODIFIED` | hidden |
| _Custom process ID | `processCustomID` |  |
| Hazard Type | `incidentType?radioCards` |  |
| Project | `processProject` |  |
| Report date and time | `processDate` |  |
| Category | `findingClassification?inlineButtons` |  |
| Control Measures | `controlMeasures` |  |
| Risk Owner | `riskOwner` |  |
| Likelihood | `currentStatelikelihood` |  |
| Severity | `currentStateseverity` |  |
| Current Risk Rating | `riskRating` | hidden |
| Risk Rating | `___CUSTOM_FIELD15` | Handlebars template |

**Filter: Filter by Hazard Type** (`60a36860-1ed8-4860-b4f9-17dae2fa9bf3`), radiolist; options source `hazard`; display `incidentType?radioCards`; value `incidentType?radioCards`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Checklist | `8b4974d7-b52a-43f5-8682-58832a53be22` | `hazard` | (incidentType?radioCards eq {filterValue1}) |
| Checklist | `e39c3d07-0db6-45cb-b03f-afec45958eaf` | `hazard` | (incidentType?radioCards eq {filterValue1}) |
| Hazards | `a7a9cfce-2f7b-4dfc-a661-90e5c66f31ed` | `hazard` | (incidentType?radioCards eq {filterValue1}) |

**Filter: Filter by Hazard Category** (`d94e839f-f945-4b5b-af4b-45846796419e`), dropdownlist; options source `hazard`; display `findingClassification?inlineButtons`; value `findingClassification?inlineButtons`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Checklist | `8b4974d7-b52a-43f5-8682-58832a53be22` | `hazard` | (findingClassification?inlineButtons eq {filterValue1}) |
| Checklist | `e39c3d07-0db6-45cb-b03f-afec45958eaf` | `hazard` | (findingClassification?inlineButtons eq {filterValue1}) |

**Filter: Filter by Country** (`b455bced-e9b6-4722-9047-3263f974560d`), dropdownlist; options source `hazard`; display `country`; value `processCountryCode`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Hazards | `a7a9cfce-2f7b-4dfc-a661-90e5c66f31ed` | `hazard` | (processCountryCode eq {filterValue1}) |
| Checklist | `8b4974d7-b52a-43f5-8682-58832a53be22` | `hazard` | (processCountryCode eq {filterValue1}) |
| Checklist | `e39c3d07-0db6-45cb-b03f-afec45958eaf` | `hazard` | (processCountryCode eq {filterValue1}) |
| Filter by Hazard Category | `d94e839f-f945-4b5b-af4b-45846796419e` | `` | (processCountryCode eq {filterValue1}) |
| Filter by Hazard Type | `60a36860-1ed8-4860-b4f9-17dae2fa9bf3` | `` | (processCountryCode eq {filterValue1}) |
| Very High Risks | `080e2bd4-c7ab-40b4-a477-f786fca47b4b` | `hazard` | (processCountryCode eq {filterValue1}) |
| High Risks | `c306545a-aa67-41c5-9551-8b02c301a6d0` | `hazard` | (processCountryCode eq {filterValue1}) |
| Medium Risks | `839cfdc8-890f-4fd6-b489-282a024964a2` | `hazard` | (processCountryCode eq {filterValue1}) |
| Unlikely | `f6bd7d78-1666-4b70-83ea-e118c4877638` | `hazard` | (processCountryCode eq {filterValue1}) |
| Low Risks | `d582ba26-8a5b-4e06-9759-9dda95a0f6e2` | `hazard` | (processCountryCode eq {filterValue1}) |
| Filter by Project | `f59b5277-260a-42b8-8743-241d64140b5e` | `` | (processCountryCode eq {filterValue1}) |

**Filter: Filter by Project** (`f59b5277-260a-42b8-8743-241d64140b5e`), dropdownlist; options source `hazard`; display `processProject`; value `processProjectCode`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Hazards | `a7a9cfce-2f7b-4dfc-a661-90e5c66f31ed` | `hazard` | (processProjectCode eq {filterValue1}) |
| Checklist | `8b4974d7-b52a-43f5-8682-58832a53be22` | `hazard` | (processProjectCode eq {filterValue1}) |
| Checklist | `e39c3d07-0db6-45cb-b03f-afec45958eaf` | `hazard` | (processProjectCode eq {filterValue1}) |
| Filter by Hazard Category | `d94e839f-f945-4b5b-af4b-45846796419e` | `` | (processProjectCode eq {filterValue1}) |
| Filter by Hazard Type | `60a36860-1ed8-4860-b4f9-17dae2fa9bf3` | `` | (processProjectCode eq {filterValue1}) |
| Very High Risks | `080e2bd4-c7ab-40b4-a477-f786fca47b4b` | `hazard` | (processProjectCode eq {filterValue1}) |
| High Risks | `c306545a-aa67-41c5-9551-8b02c301a6d0` | `hazard` | (processProjectCode eq {filterValue1}) |
| Medium Risks | `839cfdc8-890f-4fd6-b489-282a024964a2` | `hazard` | (processProjectCode eq {filterValue1}) |
| Unlikely | `f6bd7d78-1666-4b70-83ea-e118c4877638` | `hazard` | (processProjectCode eq {filterValue1}) |
| Low Risks | `d582ba26-8a5b-4e06-9759-9dda95a0f6e2` | `hazard` | (processProjectCode eq {filterValue1}) |

Interpretation and discrepancy status: [report guide](../hazard-library.md). `{filterValue1}` / `{filterValue2}` are saved filter references; `[saved: ...]` is accompanying display text, not a universal fixed value. Empty date-operator operands can be normal.
