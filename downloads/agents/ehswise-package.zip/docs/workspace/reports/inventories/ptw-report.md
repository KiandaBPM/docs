# Permit to Work — export inventory

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [ptw-report.json](../../../../pages/Analytics/ptw-report.json); page ID `ptw-report`.

| Widget title / ID | Type and source query | Grouping / aggregation / fixed conditions | Connected list |
| --- | --- | --- | --- |
| Status<br>`cf1642db-9915-4bb5-a054-0f954a99748e` | widgets/widget-chart; permit-to-work; own / all | group __STATUS; chart pie | 2e1c0474-9e5a-4f22-9fc9-eadd13d0cce0 |
| Project<br>`13c78a83-5d5c-43fd-a018-8ecd4d614565` | widgets/widget-chart; permit-to-work; own / all | group processProject; chart pie | 2e1c0474-9e5a-4f22-9fc9-eadd13d0cce0 |
| PTW Type<br>`50462785-4a76-403c-9426-94f5acf96eca` | widgets/widget-chart; permit-to-work; own / all | group PTW_LSTSIN_TypePTW?radioCards; chart pie | 2e1c0474-9e5a-4f22-9fc9-eadd13d0cce0 |
| PTW Records<br>`2e1c0474-9e5a-4f22-9fc9-eadd13d0cce0` | widgets/widget-list; permit-to-work; own / all |  |  |
| Created this week<br>`b2e4aed1-9c90-492d-853e-4dc66ff52476` | widgets/widget-tile; permit-to-work; own / all | tile count; where (Process Created Date isThisWeek ) | 2e1c0474-9e5a-4f22-9fc9-eadd13d0cce0 |
| Created previous month<br>`aea1aa7a-d294-4866-a87c-94d857d6e949` | widgets/widget-tile; permit-to-work; own / all | tile count; where (Process Created Date isPrevMonth ) | 2e1c0474-9e5a-4f22-9fc9-eadd13d0cce0 |
| Created previous year<br>`645992ca-b1ea-4d93-9d51-5a2ec367335f` | widgets/widget-tile; permit-to-work; own / all | tile count; where (Process Created Date isPrevYear ) | 2e1c0474-9e5a-4f22-9fc9-eadd13d0cce0 |
| Active<br>`a5338f93-4363-4643-9ade-d2ad84f65d02` | widgets/widget-tile; permit-to-work; own / all | tile count; where (__STATUS eq Open) | 2e1c0474-9e5a-4f22-9fc9-eadd13d0cce0 |
| Extended<br>`952e1c63-28b4-4458-b542-d49efdfc40e9` | widgets/widget-tile; permit-to-work; own / all | tile count; where (__STATUS eq Extended) | 4e0d4095-8895-4997-95fe-27a60ae50c4f |
| Closed<br>`5e597111-db57-4750-b138-68f6f6367ace` | widgets/widget-tile; permit-to-work; own / all | tile count; where (__STATUS eq Closed) | 2e1c0474-9e5a-4f22-9fc9-eadd13d0cce0 |
| Total Number of PTWs<br>`7b5bdd0b-581b-4706-b795-b95c44865bbe` | widgets/widget-tile; permit-to-work; own / all | tile count | 2e1c0474-9e5a-4f22-9fc9-eadd13d0cce0 |

**List: PTW Records** — page size 30; add no; delete no; bulk delete no; export yes.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| ID | `__NAME` | hidden |
| PTW ID | `___CUSTOM_FIELD11` | Handlebars template |
| Custom ID | `processCustomID` | hidden |
| Project | `processProject` |  |
| Date | `processDate` |  |
| Reported by | `PTW_USER_ReportedByCompany` |  |
| Title | `processSubject` |  |
| Status | `__STATUS` | hidden |
| Description of the works | `processDescription` |  |
| PTW type | `PTW_LSTSIN_TypePTW?radioCards` |  |
| PPE | `PTW_LUPMUL_PPE?checkboxCards` |  |
| Rescue equipment | `PTW_LUPMUL_RescueEquipment?checkboxCards` |  |
| Total number of participants | `PTW_NUM_Total` |  |
| PTW Status | `___CUSTOM_FIELD10` | Handlebars template |

**Filter: Filter By Project** (`b8708d67-e094-4dc0-8ed5-b34d868c934f`), dropdownlist; options source `permit-to-work`; display `processProject`; value `processProject`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| PTW Records | `2e1c0474-9e5a-4f22-9fc9-eadd13d0cce0` | `ncr` | (processProject eq {filterValue1}) |
| Status | `cf1642db-9915-4bb5-a054-0f954a99748e` | `permit-to-work` | (processProject eq {filterValue1}) |
| Project | `13c78a83-5d5c-43fd-a018-8ecd4d614565` | `permit-to-work` | (processProject eq {filterValue1}) |
| Active | `a5338f93-4363-4643-9ade-d2ad84f65d02` | `permit-to-work` | (processProject eq {filterValue1}) |
| Extended | `952e1c63-28b4-4458-b542-d49efdfc40e9` | `permit-to-work` | (processProject eq {filterValue1}) |
| Closed | `5e597111-db57-4750-b138-68f6f6367ace` | `permit-to-work` | (processProject eq {filterValue1}) |
| Project | `50462785-4a76-403c-9426-94f5acf96eca` | `permit-to-work` | (selectAChecklist eq {filterValue1}) |

**Filter: Date Range** (`0260f265-7348-433c-a93a-b3c538a0c38a`), daterange; options source `manual`; display ``; value ``; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| PTW Records | `2e1c0474-9e5a-4f22-9fc9-eadd13d0cce0` | `permit-to-work` | (Process Created Date gte {filterValue1} AND Process Created Date lte {filterValue2}) |

Interpretation and discrepancy status: [report guide](../ptw-report.md). `{filterValue1}` / `{filterValue2}` are saved filter references; `[saved: ...]` is accompanying display text, not a universal fixed value. Empty date-operator operands can be normal.
