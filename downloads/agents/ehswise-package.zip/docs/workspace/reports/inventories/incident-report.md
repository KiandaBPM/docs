# Incidents — export inventory

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [incident-report.json](../../../../pages/Analytics/incident-report.json); page ID `incident-report`.

| Widget title / ID | Type and source query | Grouping / aggregation / fixed conditions | Connected list |
| --- | --- | --- | --- |
| Status<br>`a4f2fb6b-cbac-4725-a7db-7363b191c973` | widgets/widget-chart; incident; own / all | group __STATUS; chart pie | b91838ae-2965-40aa-8170-96729363a564 |
| Incident Type<br>`9c178fbb-e30b-4b59-a4c2-2ad50c58b9f7` | widgets/widget-chart; incident; own / all | group incidentType?radioCards; chart bar | b91838ae-2965-40aa-8170-96729363a564 |
| Damage Type<br>`083a04df-a4b7-49c2-9945-fe436ccb2a4b` | widgets/widget-chart; incident; own / all | group incidentType?checkboxCards; chart pie | b91838ae-2965-40aa-8170-96729363a564 |
| Potential LTIs<br>`1cba681b-e2a1-42b8-98e9-b9d3529d6bd2` | widgets/widget-tile; incident; own / all | tile count; where (potential_LTI eq Yes) | b91838ae-2965-40aa-8170-96729363a564 |
| Created this week<br>`8f41bd17-c008-4dea-b13b-0ebcb761e2cc` | widgets/widget-tile; incident; own / all | tile count; where (__CREATED isThisWeek ) | b91838ae-2965-40aa-8170-96729363a564 |
| Investigation<br>`cd447919-e317-45fa-a7c3-307dbb67a144` | widgets/widget-tile; incident; own / all | tile count; where (investigation eq Yes AND __STATUS eq Open) | b91838ae-2965-40aa-8170-96729363a564 |
| Incidents<br>`b91838ae-2965-40aa-8170-96729363a564` | widgets/widget-list; incident; own / all |  |  |
| Created previous month<br>`8ef92740-199b-4a5f-bcee-bed78230cd4b` | widgets/widget-tile; incident; own / all | tile count; where (__CREATED isPrevMonth ) | b91838ae-2965-40aa-8170-96729363a564 |
| Created previous year<br>`a2af3b7f-07ca-4ff0-8896-214ebe9dd98c` | widgets/widget-tile; incident; own / all | tile count; where (__CREATED isPrevYear ) | b91838ae-2965-40aa-8170-96729363a564 |
| Reportable to Authorities / RIDDOR<br>`89d00355-229d-4a7e-9f73-3442e6a04a9e` | widgets/widget-tile; incident; own / all | tile count; where (reportable_authorities eq Yes) |  |
| Total Number of Incidents<br>`880f72af-b6ef-419c-96aa-300b02575a14` | widgets/widget-tile; incident; own / all | tile count | b91838ae-2965-40aa-8170-96729363a564 |

**List: Incidents** — page size 30; add no; delete yes; bulk delete no; export yes.

| Column caption | Internal field | Hidden / custom |
| --- | --- | --- |
| Incident ID | `___CUSTOM_FIELD9` | Handlebars template |
| Custom ID | `processCustomID` | hidden |
| ID | `__NAME` | hidden |
| Incident Type | `incidentType?radioCards` |  |
| Damage Type | `incidentType?checkboxCards` |  |
| Emergency? | `EmergencyInfo` |  |
| Incident date and time | `processDate` |  |
| Project | `processProject` |  |
| Created by | `__CREATED_BY` |  |
| Status | `__STATUS` | hidden |
| Potential LTI (>24h) | `potential_LTI` |  |
| Investigation | `investigation` |  |
| Incident Status | `___CUSTOM_FIELD8` | Handlebars template |

**Filter: Filter By Project** (`0cd45195-cfb0-4a84-a5a6-b5b5ebdf6c8d`), dropdownlist; options source `observation`; display `processProject`; value `processProject`; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Incidents | `b91838ae-2965-40aa-8170-96729363a564` | `incident` | (processProject eq {filterValue1}) |
| Status | `a4f2fb6b-cbac-4725-a7db-7363b191c973` | `incident` | (processProject eq {filterValue1}) |
| Incident Type | `9c178fbb-e30b-4b59-a4c2-2ad50c58b9f7` | `incident` | (processProject eq {filterValue1}) |
| Damage Type | `083a04df-a4b7-49c2-9945-fe436ccb2a4b` | `incident` | (processProject eq {filterValue1}) |
| Potential LTIs | `1cba681b-e2a1-42b8-98e9-b9d3529d6bd2` | `incident` | (processProject eq {filterValue1}) |
| Investigation | `cd447919-e317-45fa-a7c3-307dbb67a144` | `incident` | (processProject eq {filterValue1}) |
| Reportable to the Authorities / RIDDOR | `89d00355-229d-4a7e-9f73-3442e6a04a9e` | `incident` | (processProject eq {filterValue1}) |

**Filter: Date Range** (`270a2d84-63eb-4321-9001-373ae1ed2124`), daterange; options source `manual`; display ``; value ``; URL parameter ``.

| Saved target title | Target widget ID | Target process metadata | Conditions |
| --- | --- | --- | --- |
| Incidents | `b91838ae-2965-40aa-8170-96729363a564` | `incident` | (processDate gte {filterValue1} AND processDate lte {filterValue2}) |

Interpretation and discrepancy status: [report guide](../incident-report.md). `{filterValue1}` / `{filterValue2}` are saved filter references; `[saved: ...]` is accompanying display text, not a universal fixed value. Empty date-operator operands can be normal.
