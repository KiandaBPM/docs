# Accident Rates

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [accident-rate.json](../../../pages/Analytics/accident-rate.json); no main record list. Sources combine incident utility counts with hours-worked data.

- First Aid Cases sums `firstAidCount`; Medical Treatment and Lost Time Cases are both saved against `lostTimeIncidentCount` in the reviewed configuration. The Medical Treatment mapping is a source discrepancy to inspect rather than infer correctness from the caption.
- RIDDOR Cases counts `reportable_authorities contains Yes`.
- Hours Worked sums Employee hours (`DATAMS_NUM_EmployeeHours`) from `hours-worked-data`.
- Incidents this year / last year count incident `processDate` with `isThisYear` / `isPrevYear`.
- Custom AFR tile: numerator `incident.injuredPeopleCount`, denominator Employee hours; expression `(AccidentCount * 100000) / WorkerHours`.
- Custom LTIR tile: numerator `incident.lostTimeIncidentCount`, denominator Employee hours; expression `(LTICount * 200000) / HoursWorked`.
- Annual custom chart `client-widget/accident-rate` uses Year interval and six years, independently configured AFR expression. The saved page value was corrected to `(AccidentCount * 200000) / EmployeeHoursWorked`.

Project and Location selectors use Asset records and code values with URL `project` / `location`. Project restricts Type Project; the narrative baseline describes Location as Type Site / Active Yes, while its linked export inventory records only `(type eq Site)`. Verify the current option conditions to resolve that difference. Both have explicit links to the first-aid/medical/lost-time/RIDDOR/hour/year tiles. The Date Range targets incident `processDate`, but its saved target ID is absent from this page. It does not establish functional filtering of all rate widgets.

Implementations: [accident-rate.js](../../../components/widgets/accident-rate.js), [accident-rate.hbs](../../../components/widgets/accident-rate.hbs), [widget-tile.js](../../../components/widgets/widget-tile.js), [widget-tile.hbs](../../../components/widgets/widget-tile.hbs). Logo and `_CSS` are presentation widgets.

**Default defect remains in code:** although the page's chart setting is 200,000, the custom chart JavaScript fallback/initialization still uses `(AccidentCount * 20000) / EmployeeHoursWorked`. The owner confirmed 20,000 is an incorrect default requiring update. Distinguish a corrected instance setting from an unfixed implementation default. Formula differences between the AFR tile, LTIR tile and chart are otherwise intentionally supported, not automatically defects.

Saved baseline detail: [widget, column and connection inventory](./inventories/accident-rate.md). Read it only when exact exported identifiers or settings are needed; compare current customer JSON before reusing them.
