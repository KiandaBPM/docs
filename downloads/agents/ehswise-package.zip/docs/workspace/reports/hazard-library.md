# Hazard Library

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [hazard-library.json](../../../pages/Analytics/hazard-library.json); source `hazard`.

This report is also a maintenance entry point. Hazard Type radio filter uses `incidentType?radioCards`; Hazard Category dropdown uses `findingClassification?inlineButtons`; Country and Project use `processCountryCode` and `processProjectCode`. They source Hazard records. Country connects to Project and other filters; Country/Project also constrain the risk lists and band tiles, supporting cascading selection. Check the exact target table: Category currently targets only the two ranking lists, so its existence is not evidence every tile/main list is filtered.

Risk bands count `riskRating`: Very High ≥20, High 12–19, Medium 8–11, Unlikely 4–7, Low ≤3. A Total Number of Hazards tile is separate. Two 10-row lists restrict `__STATUS = Open` and sort `riskRating` descending (top) / ascending (bottom), rendering custom risk cards.

The 20-row main list includes custom ID, hazard type, project, date, category, controls, risk owner, likelihood, severity, and current rating. It enables add/delete but disables bulk delete/export, unlike most Analytics lists. Create a Hazard links to new Hazard and new RA. Multiple global/project/site/location variants of a hazard can be shown; the assessor chooses the applicable record rather than an automatic winning version being selected.

Saved baseline detail: [widget, column and connection inventory](./inventories/hazard-library.md). Read it only when exact exported identifiers or settings are needed; compare current customer JSON before reusing them.
