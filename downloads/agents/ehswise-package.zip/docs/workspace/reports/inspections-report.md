# Inspections

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [inspections-report.json](../../../pages/Analytics/inspections-report.json); source `inspection`.

Charts group Status and Project as pies and Checklist (`INS_LUPSIN_Checklist`) as bar. Pass / At Risk / Failed tiles count matching `__STATUS`; total counts inspection records. The 30-row list includes custom ID, title (`INS_TXTSIN_UploadTitle`), category, checklist, project, `processDate`, creator, status and substatus. It exports via OData and disables add/delete/bulk delete; custom ID descending.

Project options source Inspection `processProject`; target list, Status/Checklist charts, and outcome tiles. This Month / Last Month / Last Year use `processDate`. Date Range is still incorrectly configured against **Audit `auditDate` and a missing Audits list ID**. Last Month also retains an obsolete connection. Older evidence recorded the Failed tile's Project field as Laundry; the inspected JSON now uses `processProject` there. Keep the original defect history without asserting it is still present in that exact field.

Saved baseline detail: [widget, column and connection inventory](./inventories/inspections-report.md). Read it only when exact exported identifiers or settings are needed; compare current customer JSON before reusing them.
