# Reporting discrepancies in the 27 October baseline

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

The owner confirmed the reporting mismatches as bugs to document and fix later. Documentation work does not authorize silently changing report or process behavior. Record the following when choosing a generation example:

| Area | State in inspected source | Consequence for an agent |
| --- | --- | --- |
| Accident chart scale | Page instance 200,000; JS fallback/init 20,000 | Default remains a defect; preserve legitimate per-widget formula flexibility |
| Accident Date Range | Missing Incidents target ID | Reconnect to intended existing widgets |
| Action responsible-user filter | Missing Completed on Time target | Resolve target/removal using intended report design |
| Audit previous-year count | No date condition | Add intended previous-year condition when fixing |
| Events current-year tile | `isPrevYear` | Correct label/condition contract |
| Incident Project selector | Observation source | Use the intended Incident/hierarchy source |
| Inspection date range / Last Month | Audit field/list and stale connection | Use inspection field/real list target; older Laundry mapping is now `processProject` |
| NCR OBS/OFI | Current conditions use OR between OBS and OFI | Historical AND-condition defect is not present in the inspected source |
| PTW connections | Stale Extended ID, checklist used for project, NCR metadata | Review actual target and field mapping |
| RA filters/date widgets | Event sources/metadata, stale Events target, wrong-year condition | Rewire to RA as intended |
| Asset import | Owner says matching must use Type + Code | Do not use Code-only identity |
| Accident Medical Treatment | Saved sum duplicates lost-time field | Source observation requiring field mapping review; not independently confirmed by owner as a separate defect |

Do not convert every differing caption/metadata label into a runtime defect: a connection label can be stale while its ID and field are correct. Conversely a page can render successfully with missing filter targets. Compare IDs, actual field names, conditions and source process together.
