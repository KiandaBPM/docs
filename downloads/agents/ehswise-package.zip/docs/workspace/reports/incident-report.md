# Incidents

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [incident-report.json](../../../pages/Analytics/incident-report.json); source `incident`.

Charts group Status, Incident Type (`incidentType?radioCards`, bar), Damage Type (`incidentType?checkboxCards`, pie). The 30-row list includes incident/custom ID, type, damage types, emergency indicator, incident date/time (`processDate`), project, creator, Potential LTI, investigation flag and status. It sorts custom ID descending, exports through OData and permits delete; add/bulk delete are disabled.

Potential LTIs counts `potential_LTI = Yes`. Investigation counts `investigation = Yes` AND `__STATUS = Open`. RIDDOR/reportable counts `reportable_authorities = Yes`; total counts incidents. Time counters use `__CREATED` for this week/previous month/previous year. Date Range targets the list with `processDate`, meaning occurrence date rather than record-created date.

Project targets incident list/charts and potential-LTI/investigation/reportable tiles through `processProject`, but its option source is mistakenly **Observation**. This is an owner-confirmed bug; a new report should obtain the appropriate project choices rather than reproduce the wrong process source.

Saved baseline detail: [widget, column and connection inventory](./inventories/incident-report.md). Read it only when exact exported identifiers or settings are needed; compare current customer JSON before reusing them.
