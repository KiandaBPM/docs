# Observations

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [observation-report.json](../../../pages/Analytics/observation-report.json); source `observation`.

Charts group Status, Observation Type (`OBS_LSTSIN_TopicType?radioCards`), and Project. The 30-row list includes custom ID, type, project, location, asset, title, reported date (`processDate`), reporter, SWA and reported-on-behalf-of employee/third-party fields. Its saved Asset column uses field `subcontractor`; do not rename that mapping merely from its caption without following the process data. Custom ID descending, OData enabled, add/delete/bulk delete disabled.

Tiles count all observations, `OBS_YN_SWAUsed = Yes`, subcontractor-related records, and Positive observation. Project options source Observation `processProject` and explicitly target list, Status/Observation Type charts, SWA and subcontractor tiles. Date range targets list `processDate`; period counters use this-week/previous-month/previous-year. Positive observations are intentionally auto-closed in the base product; reporting should preserve this interpretation of status.

Saved baseline detail: [widget, column and connection inventory](./inventories/observation-report.md). Read it only when exact exported identifiers or settings are needed; compare current customer JSON before reusing them.
