# Events

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [event-report.json](../../../pages/Analytics/event-report.json); source `event`.

Charts group Status, Event Type (`eventType?radioCards`), and Project. The 30-row list includes custom ID, event type, title, project, created date, initiator and status; OData enabled, mutations disabled, custom-ID descending.

Project options come from Event `processProject`. Explicit targets are Events list, Event Type chart, Status and Induction/Drill/Toolbox/Training counters. Date range targets list `__CREATED`. Counters by type match the corresponding value; there is also total count. Time tiles use this week and previous week. **Created this year uses `isPrevYear`**, an owner-confirmed label/condition defect. Do not automatically copy it as current-year logic.

Saved baseline detail: [widget, column and connection inventory](./inventories/event-report.md). Read it only when exact exported identifiers or settings are needed; compare current customer JSON before reusing them.
