# Audits

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [audit-report.json](../../../pages/Analytics/audit-report.json); source `audit`.

Charts: Status pie (`__STATUS`), Category pie (`category`), Projects bar (`processProject`). The 30-row list has audit/custom ID, audit type, category, checklist, title, project, `auditDate`, creator, standard, total score and status. It sorts custom ID descending, exports via OData, and disables add/delete/bulk delete.

Project options come from Audit `processProject` and target list, Status, Category, Projects, Internal, External, and Subcontractor widgets. Date range targets the list's `auditDate`. Audit type counters use `type-of-audit?radioCards`: Internal equals Internal; External contains External; Subcontractor equals Subcontractor. Total counts all matching audit records. This week and previous month use `auditDate`; **previous year currently lacks its date condition**, an owner-confirmed defect.

Saved baseline detail: [widget, column and connection inventory](./inventories/audit-report.md). Read it only when exact exported identifiers or settings are needed; compare current customer JSON before reusing them.
