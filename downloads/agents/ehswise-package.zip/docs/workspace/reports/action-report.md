# Actions

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [action-report.json](../../../pages/Analytics/action-report.json); source `action`.

Status and Priority pie charts group `__STATUS` and `ACT_LSTSIN_Priority?inlineButtons`. A 10-row overdue list (widget titled Checklist) filters `ACT_DATE_DueDate isBeforeToday` AND `__STATUS = Follow-up`, sorting earliest due date first. High Priority counts Priority High; External Actions counts `internalExternalResponsible = External`; Overdue Actions uses the same overdue condition.

The 30-row Actions list sorts custom process ID descending and shows custom ID link, creator, internal/external responsibility, topic, responsible users, priority, due date, date assigned, project/location, status, action taken, completion date and person. Search, sorting, paging and OData export are enabled; add/delete/bulk delete are disabled. Add Action is a separate link to the Action process.

Responsible-user dropdown sources Action responsible users. It targets the list, Status/Priority charts, overdue/high/external tiles, and overdue list. One connection names a missing Completed on Time widget. Date Range applies `processDate` bounds to the main list, overdue list, High Priority and External Actions. Reported-this-week / previous-month / previous-year tiles use `processDate`. Preserve custom ID, priority and status templates and hidden backing fields.

Saved baseline detail: [widget, column and connection inventory](./inventories/action-report.md). Read it only when exact exported identifiers or settings are needed; compare current customer JSON before reusing them.
