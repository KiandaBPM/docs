# Risk Assessments

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [ra-report.json](../../../pages/Analytics/ra-report.json); main source `ra`.

Charts group Status, Assessors (`assessors`) and Project. The 30-row list includes custom ID, creation date, initiator, area, effective date, review date (`recommendedReviewDate`) and relative display, operator, project, assessors, assessment date (`processDate`), close comment, version and status. Custom ID descending, OData enabled, add/delete/bulk delete disabled.

Type tiles count `typeOfAssessment = Task based` or COSHH. Overdue Review Date uses `recommendedReviewDate isBeforeToday`; total counts RA. **Project dropdown is incorrectly sourced from Event**, and most of its target metadata also says Event. The period tiles query Event rather than RA, Created this year uses `isPrevYear`, and Date range targets a stale Events widget. These are owner-confirmed bugs; the main report's RA source does not make those other widgets correct automatically.

Saved baseline detail: [widget, column and connection inventory](./inventories/ra-report.md). Read it only when exact exported identifiers or settings are needed; compare current customer JSON before reusing them.
