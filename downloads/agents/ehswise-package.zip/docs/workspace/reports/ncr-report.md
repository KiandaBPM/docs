# Non Conformance Reports

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [ncr-report.json](../../../pages/Analytics/ncr-report.json); source `ncr`.

Charts group Status, Classification (`Category`), and Project. The 30-row NCR list includes custom ID, Date and Time (`Process Created Date`), title, classification, originator (`raised by`), project, owner (`manager`), modifier and status. It sorts custom ID descending, exports via OData, and disables add/delete/bulk delete.

Project options source NCR `processProject`; target list, Status/Classification charts and classification tiles. Date Range targets list `Process Created Date`; time counters use that same field with this-week/previous-month/previous-year operators. Major and Minor count `Category` values; total counts NCR records. **OBS and OFI combines `Category = OBS` OR `Category = OFI` in the current source**, matching the intended union semantics. The earlier AND-condition defect is not present in this inspected configuration.

Saved baseline detail: [widget, column and connection inventory](./inventories/ncr-report.md). Read it only when exact exported identifiers or settings are needed; compare current customer JSON before reusing them.
