# EHSwise report authoring

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

The 12 reviewed reports are customer configuration points. Filters, formulas, layout and rate definitions such as LTIR/RIDDOR can vary; each widget instance may intentionally use its own formula.

Most baseline layouts have Left `col-lg-9` and Right `col-lg-3`; Accident Rates adds full-width Middle metrics. Standard `widgets/widget-chart` charts normally count by `labelsField`; tiles count or sum. Lists preserve selected/hidden fields, sorting, paging, export controls and custom status/ID templates. Queries generally use `processSource: own`, `queryType: all`, plus fixed and connected conditions. The configuration does not imply a universal cross-module schema.

1. Choose a source module and enumerate its **actual internal field names and types**; do not derive them from a chart label.
2. Set page ID/title/group/containers and map EHS Admins visibility to the intended workspace group.
3. Configure the primary list: source, conditions, visible/hidden fields, sorting, page size, search, export, and mutation controls.
4. Add charts with grouping fields, count/sum aggregation and chart type. Add tiles with explicit conditions and aggregation.
5. Define each filter's option source, value/display fields, datasource conditions, URL behavior, and every target widget/condition.
6. For rates, state numerator, denominator, unit, scale factor, date scope, user/customer definition and zero-denominator behavior. The walkthrough did not establish a universal zero-hours behavior; inspect implementation before promising one.
7. Preserve custom-widget dependencies and instance settings; decide deliberately whether to change one instance or shared JS defaults.
8. Check all IDs and source/field references against the page and processes. Exclude the relevant [known baseline defects](./known-issues.md) from a new configuration.
9. Follow the user's requested validation scope. This reference describes what to inspect; documentation creation did not execute report queries or modify runtime configuration.

Select a report directly from [the page map](../pages.md#analytics). Each short report guide links its exact baseline inventory. Inventories retain legacy names, operators, query choices, connection IDs and defects for comparison; they are not templates to clone blindly. Compare the current JSON and the [dated discrepancy register](./known-issues.md) when the relevant issue is in scope.

Platform details: [native/custom widget contracts](../../kianda/page/widgets.md#7-native-and-custom-widget-contracts), [filter connections](../../kianda/page/queries-filters.md#10-filter-ownership-connections-url-state-and-dates), [Summaries data contracts](../../kianda/addons/summaries.md#9-reporting-through-summaries).
