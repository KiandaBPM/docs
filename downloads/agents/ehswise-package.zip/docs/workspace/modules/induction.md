# Induction player

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

**Definition:** [induction.json](../../../processes/Training/induction.json) · **New route:** `/forms/induction?isNew=1` · **Designer:** [induction-type.json](../../../processes/Data/induction-type.json) and [slide.json](../../../processes/Data/slide.json).

The player executes a selected training/induction. Its forms are Start (`start`), Induction (`induction`), Summary, and Utility. Available inductions depend on the customer's security configuration.

## Learner identity and assignment

Start asks for the induction, Myself or Someone else, and Workspaces. With Someone else, a table selects workers from the Workers list. Submission creates an anonymous link for **each selected worker**. Those workers are the learners; the creator who assigns the induction is not substituted as the learner.

Multiple workspace types can be selected. Customer security/hierarchy can restrict choices and enforce cascading Country → Project/Site selection. These choices do not themselves filter induction definitions except through the configured security model.

## Slides and quiz

Slides can be Image, Video, or Checklist. Rich text can supplement any type. Only images/videos have a minimum waiting timer. Setting timer seconds to **0 disables the wait**. Its purpose is to discourage skipping content immediately.

The learner completes checklist questions inside the player, typically using custom multiple-choice answers. Quiz result can set the induction to Passed or Failed; a failed quiz sets Failed. Requiring a failed quiz to repeat the preceding slide is a common customer configuration. The owner explicitly described it as **not a public base-product setting in the reviewed release**; exposing it as a configurable option is planned.

## Completion and certificate

Server rules generates the certificate and sends it by email to the **worker/learner**. The generated certificate is also stored as a separate Certificate record associated with the learner's Worker ID and email. The owner confirmed both operations; do not document certificate generation and worker email as alternatives.

Relevant source controls: `startIndution` creates worker-specific Induction records; `initializeInduction` generates anonymous access, sends assignment notification and loads content; `OBS_BTN_ServerRules` includes Generate certificate, Notify worker and certificate upload scheduling; `uploadCertificate` includes Create induction training certificate. Preserve worker identity, induction identity/title, expiry, file and URL mappings.


Designer, expiry and cloning: [Inductions](../pages/induction-design.md). Certificate data and reminders: [training relationships](../shared/training.md).
