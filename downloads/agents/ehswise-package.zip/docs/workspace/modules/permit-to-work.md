# Permit to Work (PTW)

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

**Definition:** [permit-to-work.json](<../../../processes/QHSE - Modules/permit-to-work.json>) · **New route:** `/forms/permit-to-work?isNew=1` · **Report:** [ptw-report.json](../../../pages/Analytics/ptw-report.json).

PTW records authorization, precautions, parties, checks, equipment and workers for a high-risk job and validity period. It supports digital and paper operation.

## Classification and branching

Types: General, Confined spaces, Lifting operations, Hot works, Working at height, and Electrical and mechanical. Choose exactly one mode:

1. **Complete your PTW digitally** — digital permit workflow.
2. **Upload a completed (paper) PTW** — upload a permit already completed outside EHSwise.
3. **Start your PTW digitally and complete on paper** — create/print a report, complete it on paper, and upload it later.

Workspace selection is required. Electrical and mechanical exposes LOTO; Confined spaces exposes gas-measurement/watchman controls. The saved forms are Classification, Circumstances, Involved parties, Checks, Equipment, Participants, LOTO, Confined spaces, Summary and Utility, with names prefixed `FORM_PTW_` except the shared Checklist form.

## Permit details / Circumstances

Required Title, Description of works, and Applicable Risk Assessment. **Applicable Risk Assessment is free text in this version**; linking an existing RA record is a common customization. Optional Additional Documentation and request Date. Date is the request date; First issue valid from/till define permit validity. Extension uses its separate valid-from/till fields.

Internal/External changes Reported by between a user picker and an outside person's text name; Company is available. Related to another PTW? exposes a linked permit selector. Multiple permits may need to apply to the same work, for example General plus Confined spaces.

## Involved parties and phases

The repeatable table holds Phase, Role, Internal/External, Name, Company and signature. Roles include Permit holder, Approver, Verifier and Isolating authority. Phases include First issue, Extension and Closure. External names use text; internal names use user selection. Requested phases add rows to this same table. A hidden print table is assembled for report output.

This version is designed for in-person signatures. **Individual signatures are not required by default.** The customer defines which approvals must be enforced during implementation. Do not interpret the page's instructional text about signatures as field-level mandatory enforcement.

## Checks, Equipment, Participants

- **Checks** loads a checklist appropriate to the high-risk task via the shared component.
- **Equipment** is shown for all permit types. Choices come from EHS Admin → Other lists, backed by equipment definitions such as [ptw-equipment.json](../../../processes/Data/ptw-equipment.json). Selection is optional. Other does not reveal a specialized field.
- **Participants** are the people actually doing the job. Teamlead identifies their team leader. Rows include phase, identity, company and signature. First issue and Extension can have different workers. A signature acknowledges the permit conditions/control measures; it is configurable and not mandatory by default. The process calculates total/internal/external participant counts.

## Confined spaces

Gas measurements is repeatable: Name of the person making the reading, Date and Time, oxygen, LEL, H₂S and CO. Multiple readings can be recorded. Watchman is repeatable with Name and IN/OUT times representing coverage periods; multiple watchmen are supported. Neither collection is required by default, but customers can configure requirements.

**No gas-reading limits are enforced by the base form.** Users interpret readings against the applicable site procedure and local requirements. The walkthrough included contextual operating reference values; those are not product validation constants and must not be converted into universal legal/safety thresholds by an AI agent.

## LOTO

Lock Out Tag Out records Equipment Isolated, Isolation Point, LOTO key no., Issued To, Locked out on and Lock released on. Key number is the company's actual key identifier. Issued To is the person who took the key to secure the equipment. The permit holder records release. Rows can be added/removed and are not required by default. The walkthrough did not establish any additional automatic interlock or validation of isolation correctness.

## Submission and lifecycle

Summary recaps permit, status timeline, properties, attachments/actions and optional confirmation. Originator receives the confirmation email. Submit validates PTW type, title, works description, applicable RA, workspace and permit holder. Customer-required signatures/checks may add validation.

- Normal submission enters **Open** with the demonstrated inline-approval arrangement.
- If the customer disables inline approval, the owner described submission entering **Reported**.
- While Open, the owner can **Extend**. This adds Extension signer rows and uses Extension valid from/till.
- **Close** sets Closed; **Suspend** sets Suspended.

Source anchors: `PTW_BTN_SubmitRules`, `PTW_BTN_ExtendRules`, `PTW_BTN_CloseRules`, `PTW_BTN_SuspendRules`, `PTW_BTN_ServerRules`, and `PTW_BTN_CreateReport`. The saved Extend chain sets status **Extended** with substatus **Extension**. There is a saved-source discrepancy for Suspend: the owner described **Suspended**, while the enabled saved rule sets global status **Closed** and `processSubstatus` **Suspended**. Preserve this distinction when diagnosing behavior; resolving it requires deciding the intended status contract and its report/assignment consumers. Report rules select templates by PTW type after sorting/copying involved-party rows to a print table.

When adding a PTW type, cover classification choice, applicable specialized forms/checklist, report-template condition, required-form validation, participants/signatures, phase transitions, and reporting filters. Do not copy only the card label.

Shared checks: [checklist runtime](../shared/checklists.md). Lookup definitions: [Other Lists](../pages/other-data-lists.md).
