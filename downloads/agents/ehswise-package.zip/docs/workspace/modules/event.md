# Event

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

**Definition:** [event.json](<../../../processes/QHSE - Modules/event.json>) · **New route:** `/forms/event?isNew=1` · **Report:** [event-report.json](../../../pages/Analytics/event-report.json).

Event complements training compliance by recording scheduled operational events and attendance. Forms are Classification (`form1`), Event Details (`form2`), Summary, and Utility. Workspaces is on Classification and at least one workspace is required.

| Event type | Details shown |
| --- | --- |
| Toolbox | Title and Event Details |
| Meeting | Title and Event Details |
| Training | Title, Event Details, training fields |
| Induction | Title and Event Details |
| Drill | Title, Event Details, drill fields |

Training includes course, Code, Generate training certificate?, Training Date, and optional Expiry Date. The course lookup reads [Training Course](../../../processes/Data/training-course.json); **Get Course Code** populates the code from the selection. Drill adds drill type, scenario/planned activities, and optional evaluation.

## Participants and certificates

Every event type displays Participants for worker sign-off. Worker selection reads [Worker](../../../processes/Training/worker.json) and populates name, role, company, ID, and subcontractor code. Other permits a free-text participant. Worker red-card information can be displayed. Multiple participants are supported.

Signatures are optional by default and can be required by customer configuration. Asking participants to sign a training record through email is a common customization; it is not the same as collecting signatures in person on the default Participants table.

For Training with Generate training certificate? enabled, **Generate training certs** loops participants. `generateCert` creates a PDF and starts [Certificate](../../../processes/Training/certificate.json), carrying course, worker ID, certificate file, expiry, company/subcontractor and notes. The saved generation condition requires a Worker ID; free-text Other participants do not satisfy it. Preserve that distinction when extending attendance capture.

Summary resembles Observation: shared Attachments/Actions, People to be notified, and Submit. The owner confirmed the submission notification behavior and additional recipients. Action assignment emails still come from Action. `OBS_BTN_ServerRules` contains ID generation, action creation, report generation, certificate loop, notification and save.

Certificate consumers: [Workers](../pages/workers.md), [Certificates](../pages/training-certificate.md), [training data producers](../shared/training.md).
