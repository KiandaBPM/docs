# Hazard library

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

**Definition:** [hazard.json](<../../../processes/QHSE - Modules/hazard.json>) · **New route:** `/forms/hazard?isNew=1` · **Library page:** [hazard-library.json](../../../pages/Analytics/hazard-library.json).

EHS personnel configure reusable hazards/risks with baseline controls and severity/likelihood, globally or for projects/sites/locations. RA selects these records. Multiple available hazard versions are displayed; **the assessor chooses the applicable version**.

Source forms: Classification (`form1-1`), Risk (`acceptedRisk`), Summary and Utility. Classification contains Hazard Type (General, Engineering, Safety, Chemical, Biological, Ergonomic), Title, Hazard Context, pictures, Workspaces, Reporter/date and Accepted Risk. Risk includes category, risk context, required Control Measures, Risk Owner, Likelihood, Severity and computed rating. Library categories include common hazards such as manual handling, chemical substance, confined spaces, electricity and moving machinery.

RA additional-control Action completion can append controls to this shared record. Altering hazard identity, scope or baseline fields therefore affects lookup selection, assessment creation and later action feedback. Do not resolve duplicate/versioned hazards by inventing automatic scope priority. Full hazard authoring/approval workflow was not demonstrated.

Assessment consumption and feedback: [RA](./ra.md).
