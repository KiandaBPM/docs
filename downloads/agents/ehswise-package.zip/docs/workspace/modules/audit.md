# Audit

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

**Definition:** [audit.json](<../../../processes/QHSE - Modules/audit.json>) · **New route:** `/forms/audit?isNew=1` · **Report:** [audit-report.json](../../../pages/Analytics/audit-report.json).

Audit combines the shared checklist with explicit Findings that can become NCRs. Forms: Classification (`audit`), General (`form8`), Checklist (`FORM_INS_Checklist`), Findings (`FIN`), Summary and Utility.

## Audit type and general information

| Type | Meaning confirmed by owner |
| --- | --- |
| Internal | Internal audit |
| Subcontractor | Audit of a subcontractor; reveals its selector/add controls |
| External - Certification | A dry run ahead of an external certification audit to check everything is in place |
| External - External stakeholders | External stakeholders participate in the external audit |

Classification also selects workspace, Category and Checklist. General captures required Title; optional comments, Standard and Audit date. Standard is the applied standard, such as ISO 9001. **Audit date is the actual audit date**, not a target or next review date.

Checklist uses the shared renderer, question-level Actions and score thresholds. Initially saved Great/OK/Failed text is replaced by the selected checklist's configured result labels at runtime.

## Findings → NCR

Findings is repeatable. A row captures finding topic, classification (Major, Minor, OFI, OBS), auditor remarks, proposed correction, and Finding Owner. Those classifications change the business meaning/outcome, not the default workflow stages.

The row's `FindingRules` / **Create NCR** rule starts [NCR](<../../../processes/QHSE - Modules/ncr.json>) when no Finding ID has already been stored. It triggers the target Submit button and maps:

| Audit finding data | NCR meaning |
| --- | --- |
| Finding topic | Title |
| Classification | Non conformance level (`Category`) |
| Remarks auditor | Remarks |
| Proposed correction | Recommendation by Originator |
| Finding Owner | Owner (`manager`) |
| Source Audit and date | Audit link and date |
| Workspace selections/codes | Same project/location/subcontractor context |
| Returned process ID | Stored back as Finding ID in the Audit row |

**Each finding's owner is assigned through the NCR process.** Keep row identity and the returned ID to avoid recreating duplicate NCRs on a later save/submission.

## Summary and server work

Summary includes audit properties, shared attachments, optional People to be notified and optional confirmation email. Server rules runs checklist actions, parent actions and findings, loads any checklist report template override, generates the report, notifies the originator when confirmation is selected and additional people when populated, and saves. Save Draft sets Draft. Owner confirmation of a finding's classification does not imply that the score determines NCR closure.

Question scoring: [checklist runtime](../shared/checklists.md). Resulting finding workflow: [NCR](./ncr.md).
