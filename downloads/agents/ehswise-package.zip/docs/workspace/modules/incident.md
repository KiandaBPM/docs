# Incident pack

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

**Definition:** [incident.json](<../../../processes/QHSE - Modules/incident.json>) · **New route:** `/forms/incident?isNew=1` · **Reports:** [incident-report.json](../../../pages/Analytics/incident-report.json), [accident-rate.json](../../../pages/Analytics/accident-rate.json).

Incident is one process combining Near-miss, Incident and Accident with conditional damage forms, authority reporting records, investigation, actions, notification and document generation. It is not one independent process per incident type.

## Classification and conditional forms

| Driver | Source field | Effect |
| --- | --- | --- |
| Incident Type | `incidentType?radioCards` | Manual single-choice Near-miss / Incident / Accident. Accident activates People and Potential LTI. |
| Damage type | `incidentType?checkboxCards` | Multi-select Assets / Quality / Environment / Reputation / Security. Adds corresponding detail forms where defined. |
| Reportable to authorities | `reportable_authorities` | Displays Authorities to record an externally made report. |
| Investigation | `investigation` | Displays Investigation, with optional reusable investigation checklist. |
| Emergency | `EmergencyInfo` | Captures emergency flag; do not infer an external emergency dispatch integration. |

Workspaces offers project, location, asset and additional subcontractor association. Required Reporter (`Reporter`) and incident date/time (`processDate`) are on Classification. Reporter is not automatically interchangeable with the hidden originator field.

Initial visible forms are Classification (`form1`), Circumstances (`form4`) and Summary (`FORM_OBS_Summary`). Options reveal People (`people`), Authorities (`authorities`), Assets (`assets`), Cost (`cost`), Quality (`quality`), Environment (`environment`), Security (`security`), and Investigation (`investigation`). The toggle field and Investigation form share the same name in different contexts; references include a type, so preserve both.

**Owner correction:** People is activated by **Accident**, not by Incident or a current People damage choice. Source contains an old Damage → People rule but it is disabled; People is not in the current damage choices. Reputation has no separate form and is described in the incident details.

Source detail: Incident Type first hides dependent forms and clears Damage type, then applies type-specific rules. Near-miss hides Duty of Notification/Investigation controls. Damage rules show Assets, Quality, Environment and Security; the enabled `Show Cost` condition covers **Assets or Security**. The walkthrough specifically demonstrated the Assets → Cost path. Changing these rules requires inspecting both enabled branches and else behavior so stale forms do not remain visible after a type change.

## Circumstances

Incident Title (`processSubject`) is required. Description of what happened/circumstances (`processDescription`) records the event and ongoing activity; `processDamage` is a conditional damage description. Picture areas support different levels of context: aerial/location, incident scene, contributing information, and damage/injury. These specialized pictures coexist with the shared Summary attachments.

## People and injury metrics

People is for Accident. It captures injury description and repeatable injured people (`victimsTable?nostyleTable`) plus repeatable witnesses (`witnessTable`). Multiple injured people and multiple witnesses are supported.

An injured-person row includes body-map annotation, employee/contractor choice (`InjuredPersonPosition?inlineButtons`), name, job/company details, injury type, first aid provided, classification, additional notes and any applicable time periods. Employees use a user picker (`InjuredPerson`). Other/contractor identity can be typed (`nameOfTheInjuredPerson`) with contracting company and company contact information.

Injury Classification choices include Lost Time Incident, Restricted Work, Medical Treatment, First Aid, Illness and Fatality. Lost Time, Restricted Work, Medical Treatment and First Aid contribute to Accident Rates figures. Do not count only process records when the configured report is meant to count injured people or days.

The Utility form stores `firstAidCount`, `lostTimeIncidentCount`, `medicalTreatmentCount`, `totalRestrictedWorkDays`, `totalLTIDays`, and `injuredPeopleCount`. Row/table rules update counters and time-based fields. Restricted Work and LTI have their own start/end and calculated day fields. These feed dashboard calculations together with Worked Hours.

Witness identity options include Employee, Contractor, Member of public and Other. Other reveals free-text witness name and company. Witness signature controls are available; customer-required signatures must be explicitly configured.

## Investigation

Investigation captures required investigation summary, optional uploaded report and Yes/No for using an investigation checklist. No hides the checklist. Yes selects a checklist such as a five-whys investigation, using the shared checklist capability. The saved Incident embeds `componentId=checklist-component-without-actions`; its separate Summary Actions component remains available for follow-up actions.

Root Cause and optional Secondary Root Cause come from [Root Cause](../../../processes/Data/root-cause.json), maintained at EHS Admin → Other Lists → Root Causes. Notes are available for each. Keep lookup data changes separate from changes to the inline environmental/material/quality choices below.

## Authorities

Repeatable Authority, Comments and Attachments capture reporting information. Authority is required in the saved row; Comments/Attachments are optional there. **The actual report to authorities occurs outside EHSwise.** Selecting Reportable records the reporting requirement and exposes this form; it does not submit a regulatory report automatically.

## Assets and Cost

Assets captures technical-incident type, priority, operational impact and repeatable damaged assets. Technical types: Machine faulty, Break-down, Electrical, Usability and Durability. Priority: Low, Medium, High, Critical. Impact asks if damage affects project/site operations; owner meaning includes decommissioning the asset and resulting project impact.

Damaged asset is text describing it (`damagedAsset`); Owner (`owner`) is the individual directly responsible. Do not assume this damage table is an EHS Asset record picker.

Cost records who pays (Internal/External), Value and Description per row. Totals `internalCost`, `externalCost`, `overallCost` aggregate the rows. No currency is indicated in this version. Cost row fields are optional by default. The source also permits Cost for Security damage as noted above.

## Quality

Simple required Category and optional Remarks; Other exposes Specify Other. Inline categories include Complaint; production loss/delay; production/specification deficiency with acceptance, repair/rework or rejection; unmet requirements/instructions/scope; documentation/reporting; incoming parts/goods/units; inspection/test criteria non-conformity; job execution; Other. Changing this classification does not automatically create an NCR; Audit Findings → NCR is a separate explicit integration.

## Environment

`environmentAspects` is an inline multiselect, not a lookup process. Values: Air emissions; Energy consumption; Fauna/flora; Soil emissions; Use of natural resources; Waste; Water emissions; Other. Other shows Specify Other.

The repeatable Materials table records Material, Medium, Amount and Unit. Amount is the material released; Unit is the measurement unit, for example kg or litres. Material row inputs are not enforced by default.

The inline Material options are Potential Acid Sulfate Soil; Analysing / testing (product for); Anti Corrosion / Erosion product; Cleaning / degreasing agent; Contaminated soil; Cooling systems (product for); Detection of water in oil (product for); Dredged material; Fuel; Glue / adhesive; Grinding (product for); Herbicide; Hydraulic oil; Insulation product; Lubricant; Paint; Rest control (product for); Radioactive product; Sludge/spent oil/waste/water/bilges; Soil remediation (additive for); Soldering (product for); Treatment of radiator (product for); Wastewater treatment (additive for); Water treatment (additive for); Welding / torch cutting (product for); Other. Preserve the saved wording unless changing the labels is part of the request.

Medium records where released: outside of containment; air; containment; ground/soil; groundwater; sewer system; water-lake; water-rainwater buffer; water-sea; water-waterway. These are inline Incident choices and are independent of the COSHH Material library.

## Security

Security Category is an inline multiselect: Armed Robbery, Burglary, Vandalism/Arson, Other and Bombing. Other expands a specification field. The repeatable Declaration table records Reference Number, Date Notified and an attached reference. The owner described these as information about the report. This declaration/report capture is separate from process access security and the Policies document-control workflow.

## Summary, submission, and server execution

Summary shows incident properties, generated PDF (`processReport`, titled Finalised report), shared Attachments/Actions and People to be notified (`OBS_USER_AddNotify`). Submit does not merely generate a local browser printout: it validates, runs local/save and assignment rules, and schedules Server rules on the server. Draft is excluded from the normal Server rules schedule. Scheduling is one-time, ordered and unique in the saved rule configuration.

Important hidden controls:

| Control name | Role |
| --- | --- |
| `INC_BTN_validateForms` | Type, title, workspace and relevant conditional-form validation |
| `OBS_BTN_LocalRules` | Open/submission UI and save chain |
| `OBS_BTN_SaveRules` | Draft subject/substatus, assignment schedule, server schedule and save |
| `generateCustomID` | Year/sequence-based custom incident ID |
| `lookupAssignees` | Responsibility lookups for reviewers/admins/project manager/Incident Notify |
| `GI_BTN_AssignRules` | Draft/Open/Closed/reviewer form assignments |
| `OBS_BTN_ServerRules` | Authoritative PDF/action/notification execution |

Enabled Server rules:

| Rule title | Effect / condition |
| --- | --- |
| Run Checklist Rules | Runs shared investigation checklist rules when selected and Open. |
| Run custom ID | Assigns the business ID if blank. |
| Run actions | Loops shared action rows, creating separate linked Action records. |
| Get Company Name | Populates email signature/company field. |
| Generate incident report | Non-Accident and no Investigation; uses `OBS_FILE_ObservationReportTemplate`. |
| Generate incident report - Accident | Accident and no Investigation; uses `reportTemplateAccident`. |
| Generate incident report - Investigation | Non-Accident with Investigation; uses `reportTemplateInvestigation`. |
| Generate incident report - Investigation and Accident | Accident with Investigation; uses `reportTemplateInvestigationAndAccident`. |
| Set substatus | Open and no assigned-to user → Pending assignment. |
| Show Close | Open → show Close comment/CLOSE; hide Submit. |
| Notify Originator | Emails `processOriginator`. |
| Notify Additional People | Emails the selected People to be notified when populated. |
| Notify incident Notify | Emails `incidentNotify`, populated by responsibility Configuration. |
| Save form | Persists generated data and rule results. |

All four document rules save PDF to Finalised report. The three email rules use incident type/business ID in the subject and include incident context and an access link. **The saved settings do not attach the PDF to these emails**; report generation and email attachment are distinct. Owner confirmed the three recipient groups and server-side execution.

Closing uses Close comments, Closed by/date and the Close control. Assignment rules vary by Draft, Open and Closed. A new conditional form must be covered in explicit assignment lists as well as in UI visibility.

## Changing classifications

For a new top-level type or damage category, use [the Incident change recipe](../recipes/incident-type.md). The proposed [Cyber Security example](../recipes/cyber-security.md) includes form access, report regeneration, and notification details.

Shared investigation runtime: [checklists](../shared/checklists.md). Report metrics: [Accident Rates](../reports/accident-rate.md).
