# Checklist runner

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

**Definition:** [checklist.json](<../../../processes/QHSE - Modules/checklist.json>) · **New route:** `/forms/checklist?isNew=1`.

This versatile module runs a configured checklist and generates its report. It is a distinct product module from Inspection, although both use the same checklist component. The saved process has a Checklist form (`form1`) and Utility rather than Inspection's inspector and confirmation stages.

The required Checklist selector reads Checklist Type. Selection loads metadata/questions. A direct link can include a `checklist` parameter to preselect the desired checklist. The demonstration's selected checklist had been chosen manually; it is not a hard-coded default.

Question controls follow their definitions, with optional help, comments, picture and New Action. Workspaces must have at least one selection. Summary fields within the main form include required Title, When, Originator, and Checklist Status. Save draft sets Draft and saves. Submit validates workspace, completes the checklist, schedules submit rules, generates a PDF, stores its report, and sets scoring status when applicable. The business ID uses the `CHK_{YYYY}_` namespace.

The report notification is sent only to the **originator** by default. Each separately created Action notifies its own responsible party through Action assignment. The saved email rule retains the inherited title **Inspection Notification**; do not mistake that title for a process dependency on Inspection.

Anchors: `form1btnSubmit`, `INS_BTN_SubmitRules`, `INS_BTN_SaveChecklist`, and shared question/action buttons. Checklist-specific templates can override the host's default template.

Question definitions and score contracts: [checklist runtime](../shared/checklists.md); authoring/import: [Checklist library](../pages/checklist-data.md).
