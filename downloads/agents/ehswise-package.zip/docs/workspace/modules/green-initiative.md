# Green Initiative

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

**Definition:** [green-initiative.json](<../../../processes/QHSE - Environment/green-initiative.json>) · **New route:** `/forms/green-initiative?isNew=1`.

No detailed owner walkthrough was performed. Source forms cover Environmental aspect, Workspaces, Green initiative, Actions, Attachments and Summary. It captures proposed initiative, environmental impact/estimated impact, whether materials are reused and Executed versus Idea/Suggestion. Source contains feedback/approve/reject controls and notification/assignment rule chains. These controls alone do not establish every approval scenario or current customer policy. Inspect conditions, security and template links before modifying the module.

Follow-up Actions use the [central Action process](./action.md); approval behavior remains source-specific.
