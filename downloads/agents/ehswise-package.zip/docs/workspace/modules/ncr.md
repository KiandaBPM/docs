# Non Conformance Report (NCR)

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

**Definition:** [ncr.json](<../../../processes/QHSE - Modules/ncr.json>) · **New route:** `/forms/ncr?isNew=1` · **Report:** [ncr-report.json](../../../pages/Analytics/ncr-report.json).

Owner-confirmed lifecycle: **Submission → Review → Closure**. NCR captures a non-conformance and its follow-up workflow. Audit findings can create linked NCRs and pass ownership; it can also be entered from Create New.

Source forms are Classification (`form1NCR`), Actions, Summary and Utility. Classification includes Originator (`raised by`), Date and Time (`Process Created Date`), required Owner (`manager`), Category (`ncrCategory`), Title, Remarks, non-conformance level (`Category`: Major/Minor/OFI/OBS), optional impact, images and Recommendation by Originator. Audit-linked fields include Audit, Auditor, Audit Date and Go to audit. Shared Actions supports separate linked action records. Summary provides attachments, notification selection and closure controls.

The saved Server rules generates a report, creates actions and sends Notify. This source inventory does not establish every customer review approver, escalation or closure-approval rule. The walkthrough stopped at high-level coverage, so retain that limit when designing changes. Audit classification meanings do not automatically constitute separate NCR workflows.

Creation mappings: [Audit findings](./audit.md#findings--ncr).
