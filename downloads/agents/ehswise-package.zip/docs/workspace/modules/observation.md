# Observation

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

**Definition:** [observation.json](<../../../processes/QHSE - Modules/observation.json>) · **New route:** `/forms/observation?isNew=1` · **Report:** [observation-report.json](../../../pages/Analytics/observation-report.json).

## Classification and circumstances

Forms: `FORM_OBS_Classification`, `FORM_OBS_Circumstances`, `FORM_OBS_Summary`, and Utility. Classification offers Unsafe observation, Positive observation, and Improvement idea. Unsafe observation reveals **Stop Work Authority used?** SWA records a worker/contractor exercising the right and obligation to stop an unsafe task. Selecting Yes tags the process type accordingly.

Workspaces can associate the same observation with multiple types. Continue validates at least one selection. Circumstances captures required Title; optional Description and proposed action; optional picture; Reported on; and Reported by. Change reported by permits reporting for another employee or a manually named third party. **The submitter remains the creator and originator even when Reported by names someone else.** Related-subcontractor controls reveal a subcontractor selector and an Add Subcontractor dialog using EHS Asset type Subcontractor.

## Summary, actions, and notification

Summary displays record/workspace properties and expandable shared Attachments and Actions. Actions contains the immediate-action explanation and Add New Action. On submission, Server rules loops action rows and starts distinct linked Action records.

The optional confirmation checkbox sends email to the **submitter/originator**, not to the Reported by person. People to be notified adds interested parties in CC. The responsible rule is **Notify Originator & additional People** under `OBS_BTN_ServerRules`. Keep recipients and the confirmation condition together when changing email behavior.

Positive observations intentionally default to **Close observation right away**; they do not require action or investigation in the base product. Close-right-away exposes closure fields and a Close path. Ordinary observations provide Submit and an Open follow-up path. Public/anonymous Observation submission is supported; internal notification/confirmation controls are hidden for public use.

Implementation anchors include the Classification type rules, `OBS_BTN_LocalRules`, `OBS_BTN_SaveRules`, `OBS_BTN_ServerRules`, `OBS_BTN_Close`, and the action-row `_ACTION RULES`. The server chain generates the observation PDF, sets substatus, notifies, and saves. A change to the apparent reporter must not silently change the originator or notification recipient.

Shared details: [hierarchy](../shared/hierarchy.md); [Actions and attachments](../shared/actions-and-attachments.md).
