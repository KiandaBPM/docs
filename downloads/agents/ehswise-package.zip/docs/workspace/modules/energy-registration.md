# Energy Registration

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

**Definition:** [energy-registration.json](<../../../processes/QHSE - Environment/energy-registration.json>) · **New route:** `/forms/energy-registration?isNew=1` · **Report:** [energy-registration.json](../../../pages/Analytics/energy-registration.json).

No detailed owner walkthrough was performed. Source shows Workspaces, Consumption period, Asset type, Energy type, Equipment, Source and Summary forms. Inputs include a no-consumption period option, start/end, asset type/subtype, paying party, energy type/subtype, amount/unit, equipment and consumption evidence/source. Helper fields include emission/conversion-factor data. Associated lookups include Energy Type, Energy Unit and Equipment.

This inventory is sufficient to locate the feature, not to infer approved emissions factors, reporting scopes, calculation semantics or regulatory coverage. Trace lookup records, submit rules and report widget calculations for a requested change. Customer omission from Create New is supported.

Reporting semantics: [Energy & Waste](../reports/energy-registration.md). The separate [waste-management.json](../../../processes/waste-management.json) exists; its presence does not establish an Energy Registration dependency or a completed Waste Management workflow.
