# Action Plan

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

**Definition:** [action-plan.json](<../../../processes/QHSE - Modules/action-plan.json>) · **New route:** `/forms/action-plan?isNew=1`.

An Action Plan bundles separate Actions into a coordinated corrective or preventive plan. Customers focused purely on EHS often hide it because it also covers Quality responsibilities.

- **Corrective plan:** for example, coordinate multiple parties restoring a high-tension transformer after a major incident.
- **Preventive plan:** investigate and change the conditions that led to the occurrence to reduce recurrence.

Their technical workflows are similar but the business purposes are distinct. Do not merge these categories simply because the form implementation is shared.

Classification (`form1_ActionPlan`) includes Originator, Date and Time, Title, Description, Type of Plan and Workspaces. The separate optional When date is the **plan date**; individual Actions each have their own due date.

Actions (`FORM_OBS_Actions`) uses the shared component. It allows immediate-action notes and new internal/external action rows. The plan needs at least one Action for submission. Server rules creates separate Action records linked to the plan.

Summary (`FORM_ActPlan_Summary`) displays information, attachments and Follow up/Reported By. **Reporter is the key owner of the plan.** The **Notify** rule sends email to the **originator**, with the generated PDF report; ownership and notification recipient must not be conflated. Submission validates title, description, workspace and action count and completes the plan. Save Draft keeps it editable.

Shared entry fields and mappings: [Actions and attachments](../shared/actions-and-attachments.md).
