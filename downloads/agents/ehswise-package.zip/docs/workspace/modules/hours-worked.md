# Worked Hours

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

**Definition:** [hours-worked.json](<../../../processes/QHSE - Modules/hours-worked.json>) · **New route:** `/forms/hours-worked?isNew=1` · **Daily data:** [hours-worked-data.json](../../../processes/Data/hours-worked-data.json).

Worked Hours supplies exposure hours used in incident/accident-rate calculations. It records aggregate project/category totals, **not individual worker timesheets**.

Form 1 selects the project in Workspaces (`FORM_MS_POVO`). Measure (`FORM_MS_Measure`) selects a month/date range and Employee, Subcontractor or Temporary category, then displays daily cells in a week/weekday matrix with a period total. Custom permits a **custom date range**. Users should complete all relevant categories together to avoid duplicate registration.

**Bulk Update** opens a dialog for a total number and divides it equally across the matrix cells. Source also exposes Daily/Total and options such as overwrite existing data/exclude weekends; the owner explained the total-spreading path. Do not infer unconfirmed rounding or holiday behavior. The UI warns that background processing/visualization takes time and asks users to wait approximately ten minutes before changes and refresh afterward.

Technical anchors include `MS_LSTSIN_MissingRanges?inlineButtons`, `MS_DATE_StartDate`, `MS_DATE_EndDate`, `MS_LSTSIN_EmployeeType?inlineButtons`, `MS_TBL_Measures?nostyleTable`, weekday-hour fields, `MS_NUM_TotalRangeHours`, `MS_BTN_BulkUpdate`, `MS_BTN_RawRules`, and submit rules. The raw rule chain creates/updates daily Hours Worked Data records.

Change the daily data mapping, date/category identity and aggregation/report consumers together when changing the matrix. Rate formulas are widget/customer-specific; do not hard-code one denominator multiplier into this module.

Rate consumers: [Accident Rates](../reports/accident-rate.md).
