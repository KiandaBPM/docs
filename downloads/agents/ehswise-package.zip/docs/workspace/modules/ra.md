# Risk Assessment (RA)

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

**Definition:** [ra.json](<../../../processes/QHSE - Modules/ra.json>) · **New route:** `/forms/ra?isNew=1` · **Report:** [ra-report.json](../../../pages/Analytics/ra-report.json).

Forms: Details (`form1`), Assessment (`risks`), Actions (`FORM_OBS_Actions`), Summary and Utility. `typeOfAssessment` selects Task based or COSHH.

- **Task based:** hazards of tasks/roles, for example lifting boxes onto a conveyor; assess existing risk and the controls needed to mitigate it.
- **COSHH:** risks inherent in chemical materials; determine PPE and precautions needed while using/handling/maintaining them.

## Details and COSHH material data

Task based requires Area, Description of Task/Role, Effective Date, Review Date and Operator. Operator and assessor signature controls are available but not required in the demonstrated base configuration. Assessor(s) permits multiple users. Origin contains assessment date, Reported by and optional subcontractor association. Shared Workspaces links the context and can use the customer's cascade/security model.

COSHH replaces task-specific details with Substance, Supplied By, SDS file, revision, description and hazard-property indicators. `substance` looks up [COSHH Material](../../../processes/COSHH/material.json), prepopulating `suppliedBy`, `sDSFile`, `revision`, `substanceDescription` and properties such as Oxidising, Explosive, Flammable, Toxic, Corrosive, Human Health and Gas under pressure. **The assessor can edit these values in the RA.** The SDS file belongs to the Material and can be opened from the assessment. Editing assessment inputs does not imply a write-back to the Material library.

## Assessment and scales

Assessment displays Severity, Likelihood and score bands above the assessments table as a visual key. The walkthrough configuration uses:

| Score | Severity | Likelihood |
| --- | --- | --- |
| 1 | Negligible — unlikely to cause injury | Improbable — very unlikely |
| 2 | Minor — first aid / acute illness | Remote — unlikely |
| 3 | Moderate — serious injury/illness EMT | Possible — reasonably likely |
| 4 | Serious — major LTA / chronic illness | Probable — likely |
| 5 | Critical — fatality | Almost Certain — very likely |

Risk score = severity × likelihood. Visible bands: 1–3 LOW; 4–7 UNLIKELY; 8–11 MEDIUM; 12–19 HIGH; 20–25 VERY HIGH. These are saved/walkthrough configuration values, not asserted universal safety scales.

**Add Risk** opens a risk dialog. Title (`findingTopic`) is the actual Work Element, such as lifting boxes. Hazard (`findingClassification?inlineButtons`) comes from the shared [Hazard library](<../../../processes/QHSE - Modules/hazard.json>). Selecting a hazard provides baseline description, existing controls, severity and likelihood. These are editable by the assessor by default; customers often make existing controls read-only.

Hazards may be global or scoped to project/site/location. If multiple versions appear, **the assessor chooses the applicable version**; there is no confirmed automatic precedence rule. In COSHH, configured chemical hazards are chosen **independently of the selected substance**; the dropdown is not filtered by that material.

## Residual risk and actions

Next - Residual Risk captures Additional Controls, Future Severity, Future Likelihood, Responsible Person and Target Completion Date. It calculates residual score using the same multiplication and bands. Add Risk & Close returns the risk to the table; Update Risk & Close edits an existing entry. Users can bundle as many risk rows as needed.

The table (`findings?nostyleTable`) presents Work Element, Hazard, Status, and visual Current/Future State cards side by side. Row fields include current and future score/control data, `assessmentRiskID`, `assessmentHazardID`, action IDs and flags. Preserve those links when changing the display.

The Actions tab lists actions associated with additional controls and allows additional actions. **RA-created actions are internal-user only.** On completion of an additional-control action, its additional controls are added to the existing controls of the associated shared Hazard record, so later assessments can use the improved controls. Preserve scope and library identity: this is a meaningful shared-data update, not just a local status badge.

Source anchors include `riskActionUrlID`, `riskActionProcessURLID`, `actionCreatedFlag`, `assessmentCreatedFlag`, `INS_TABLE_ChecklistActions?nostyleTable`, `actionRiskID`, `actionHazardID4`, `updateStatusesFromAction`, `setStatusToComplete`, `updateHazard1` and the Action module's Update back to RA rule. The source also has a Create Action from this Hazard? control and copied hidden finding/NCR rule structures. Trace active triggers and conditions before using them; their presence does not mean that ordinary RA risk rows are Audit Findings or always create NCRs.

The walkthrough did not trace every action-creation flag or button callback. Owner-confirmed behavior is that additional-control actions are listed, can be completed by internal responsible users, and completion updates the shared risk's existing controls. Treat the exact creation timing of any newly customized path as a source-tracing task rather than inventing a new business rule.

## Summary and server work

Summary is mainly informational. It recaps assessor, task/material context, dates, operator, properties and Finalised report; provides People to be notified and Submit. It does not introduce another assessment method.

`OBS_BTN_ServerRules` assigns ID, runs ordinary and risk actions, generates RA and people reports, merges generated PDFs, sends originator/additional notifications and saves. `updateStatus` updates action status/counts and regenerates the report. Review/close controls also exist in saved source beyond the walked creation flow; exact customer approval requirements were not established.

## Changing risk behavior

- Library field changes: review Hazard → Add Risk lookup mappings → assessments table → Actions feedback → visual/report templates → RA Report.
- New scale: change numeric mappings, labels, displayed keys/cards, score band conditions, report visuals and Hazard defaults together.
- Read-only existing controls: enforce the assessor input rules without blocking the intended action-completion update to the shared library.
- Substance-specific hazard filtering would be new behavior, not the documented default.

Related libraries: [Hazard](./hazard.md), [COSHH Material](../pages/coshh-materials.md). Action completion callback: [Action](./action.md#parent-linkage-and-ra-feedback).

The completion target is labelled `Update statuses from action`; its technical anchor is `updateStatusesFromAction`.
