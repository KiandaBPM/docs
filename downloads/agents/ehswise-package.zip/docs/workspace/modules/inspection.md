# Inspection

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

**Definition:** [inspection.json](<../../../processes/QHSE - Modules/inspection.json>) · **New route:** `/forms/inspection?isNew=1` · **Report:** [inspections-report.json](../../../pages/Analytics/inspections-report.json).

## Purpose and forms

Inspection records workplace checks using a configured checklist, workspace association, inspectors, scoring, and follow-up actions. The source forms are `FORM_INS_Type` (Inspection details), `FORM_INS_Checklist` (Checklist), `FORM_INS_General` (Inspectors), `FORM_INS_Confirm` (Confirm), `FORM_INS_Summary` (saved-record Summary), and `FORM_INS_Utility`.

1. **Inspection details:** required Title and When; Workspaces; required Category; and Checklist. Category is sourced from the Checklist Type `industry` field. Choosing a category exposes/filter-selects the checklist; choosing a checklist loads its ID, scoring, questions, and report settings. A `checklist` URL parameter can preselect a checklist for direct entry links.
2. **Checklist:** question types depend on the selected checklist. Rows may show guidance, comments, picture/media attachments, and New Action. New Action is linked to that question; related-question rules can also require/create an action.
3. **Inspectors:** repeatable rows with Internal/External Company choice, Name, Job Title, and an optional signature. Internal uses a user picker and populates name/job title. External uses a display-name text box. Multiple inspectors/signers are supported. **Signatures are not mandatory in the demonstrated default configuration**; customers decide their requirements.
4. **Confirm:** the user confirms the information and submits. Tabs are directly selectable in the demonstrated configuration. Next changes the form and does not submit.

## Completion

Save draft sets Draft, saves, and permits editing. Submit completes the inspection, generates its report, sends notification email, and sets the scored status to Pass, At Risk, or Failed according to the shared boundaries. A completed workflow and a scored display status are related but distinct concepts; inspect both submit and scoring rules.

Implementation anchors: `INS_BTN_ConfirmSubmit` performs validation and schedules `INS_BTN_SubmitRules`. The latter assigns a custom ID, schedules Checklist rules, refreshes related actions, loads a checklist-specific report template when configured, generates the report, sets status, sends `Inspection Notification`, applies assignments, and saves. Initialization preloads project/asset data, reads `checklist`, sets the process URL ID, and refreshes actions for existing records.

## Modification dependencies

- New checklist/category: change checklist records and category/filter metadata, not the Inspection question table manually.
- New response type or score behavior: inspect Checklist Type, Question, component runtime, report output, and all host processes.
- Required inspector signature: change the inspector row control plus validation/submission rules; account for internal and external names and multiple rows.
- New report: inspect the host's default template and the chosen checklist's Enable Report Template override.

Shared details: [checklist runtime](../shared/checklists.md); [hierarchy and workspace fields](../shared/hierarchy.md).
