# Action

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

**Definition:** [action.json](<../../../processes/QHSE - Modules/action.json>) · **New route:** `/forms/action?isNew=1` · **Report:** [action-report.json](../../../pages/Analytics/action-report.json).

## Purpose and responsibility

Action is a central record type created standalone or from other modules. Its source forms are `FORM_ACT_Action` (Action), `FORM_OBS_Workspaces` (Workspaces), `FORM_ACT_FollowUp` (Follow-up), and Utility. Do not implement a separate action workflow in every parent module.

The entry form captures Action topic (`ACT_TXTSIN_Desc`), action description (`ACT_TXTMUL_Desc`), Date assigned, Priority (Low/Medium/High), and due date. Immediate action taken (`ACT_YN_ImmediateAction`) expands a text field describing what was done at the time.

Due-date choices are 1 day, 7 days, 14 days, or Custom. Relative choices count from today; Custom exposes a date input. `ACT_LSTSIN_DueDate?inlineButtons`, `ACT_DATE_DueDate`, and `_DATE RULES` are useful anchors.

`internalExternalResponsible` switches responsibility:

| Responsibility | Inputs and behavior |
| --- | --- |
| Internal | Responsible users (`ACT_USER_ResponsibleUsers`); assignment rules and email notify those users. |
| External | Company selects a Subcontractor record; Contact Email (`externalEmail`) is populated from it. Anonymous-link rules email access to that outside party. The person need not have an ordinary internal account. |

Next opens the workspace stage before standalone submission. The generic Action workspace form has older individual controls rather than assuming every host uses an identical Workspaces component layout.

## Follow-up and closure

The responsible party records Description of action taken, completion date, completed-by identity, optional Lessons learned, and evidence. The public/external flow substitutes text for an internal completed-by user picker.

- `requireActionCompleteEvidence` makes `actionCompletionEvidence` mandatory. Owner intent: require a picture evidencing completed work.
- Without Originator closes action, **COMPLETE** schedules `_Close Action` (`performCloseAction`), submits the record with Closed status, and sends closure notification.
- With Originator closes action, completion is sent to the initiator for approval. The initiator can **CLOSE ACTION** or **REQUEST CHANGES**. A completion notification is not itself closure approval.
- Request Changes appends history/comments, sets `processSubstatus` to `Requires Change`, and notifies the responsible internal users or external email.

`ACT_BTN_SubmitRules` creates the business ID, processes internal/external responsibility, notifies the initiator, schedules external notification and assignment rules, exposes Follow-up, enforces evidence when selected, and saves. `externalNotification` contains Anonymous form link and Notify External. `ACT_BTN_ApprovalAcceptRules` assigns Follow-up, sends the assignment email/alert, and sets `Pending follow-up`.

## Parent linkage and RA feedback

Source fields include `sourceProcess`, `ACT_TXTSIN_SourceID`, `ACT_TXTSIN_SourceProcessName`, and `ACT_TXTSIN_SourceCustomID`. Follow-up offers Go to Origin. For an RA additional-control action, `performCloseAction` includes `Update back to RA`, which matches the Action URL ID in the RA's action table and triggers `updateStatusesFromAction`. Preserve this completion callback when modifying shared actions.

The source contains the RA callback on the close chain; do not infer that every standalone Action has a meaningful RA target. Read lookup and linked-source values before changing this rule.

Shared data-entry and parent mappings: [Actions and attachments](../shared/actions-and-attachments.md). RA completion feedback is in [RA](./ra.md#residual-risk-and-actions).
