# EHSwise page and report map

Base-product walkthrough/export: **27 October 2026**. Choose the named page or report below; compare its saved settings with the current customer workspace. Report inventories are optional detail linked from each report, and preserve dated IDs/conditions including known defects.

Dashboard routes use `/dashboard/{page.id}`. Captions, groups, filenames, page IDs, process names and process titles can differ: Location is `my-project`; cross-process Risk Assessment records use title `RA`. EHS Admin and Analytics use EHS Admins visibility in the baseline; customer group identities and record access must be verified separately.

## Operational and administrative pages

| Page | Dashboard route | Focused guide |
| --- | --- | --- |
| Home | `/dashboard/index` | [Home](./pages/index.md) |
| Create New | `/dashboard/create-new` | [Create New](./pages/create-new.md) |
| My Overview | `/dashboard/my-overview` | [My Overview](./pages/my-overview.md) |
| Location | `/dashboard/my-project` | [Location](./pages/my-project.md) |
| Assets | `/dashboard/my-asset` | [Assets](./pages/my-asset.md) |
| Subcontractor | `/dashboard/subcontractor` | [Subcontractor](./pages/subcontractor.md) |
| Training → Workers | `/dashboard/workers` | [Workers](./pages/workers.md) |
| Training → Certificates | `/dashboard/training-certificate` | [Training Certificates](./pages/training-certificate.md) |
| Training → How-to Guides | `/dashboard/ehswise-guides` | [How-to Guides](./pages/ehswise-guides.md) |
| Policies | `/dashboard/policies` | [Policies](./pages/policies.md) |
| EHS Admin → Projects & Assets | `/dashboard/Assets` | [Projects & Assets administration](./pages/Assets.md) |
| EHS Admin → Checklists | `/dashboard/checklist-data` | [Checklist library and designer](./pages/checklist-data.md) |
| EHS Admin → Inductions | `/dashboard/induction-design` | [Induction library and designer](./pages/induction-design.md) |
| EHS Admin → COSHH material library | `/dashboard/coshh-materials` | [COSHH material library](./pages/coshh-materials.md) |
| EHS Admin → Other Lists | `/dashboard/other-data-lists` | [Other Lists](./pages/other-data-lists.md) |
| EHS Admin → Admin Data | `/dashboard/admin` | [Admin Data](./pages/admin.md) |
| EHS Admin → Languages | `/dashboard/languages` | [Languages](./pages/languages.md) |

Additional exported Site/Office/Lessons Learned/Vault pages have [limited-coverage notes](./pages/additional.md).

## Analytics

| Report | Page ID | Focused guide |
| --- | --- | --- |
| Accident Rates | `accident-rate` | [Meaning and baseline settings](./reports/accident-rate.md) |
| Actions | `action-report` | [Meaning and baseline settings](./reports/action-report.md) |
| Audits | `audit-report` | [Meaning and baseline settings](./reports/audit-report.md) |
| Energy & Waste | `energy-registration` | [Meaning and baseline settings](./reports/energy-registration.md) |
| Events | `event-report` | [Meaning and baseline settings](./reports/event-report.md) |
| Hazard Library | `hazard-library` | [Meaning and baseline settings](./reports/hazard-library.md) |
| Incidents | `incident-report` | [Meaning and baseline settings](./reports/incident-report.md) |
| Inspections | `inspections-report` | [Meaning and baseline settings](./reports/inspections-report.md) |
| Non Conformance Reports | `ncr-report` | [Meaning and baseline settings](./reports/ncr-report.md) |
| Observations | `observation-report` | [Meaning and baseline settings](./reports/observation-report.md) |
| Permit to Work | `ptw-report` | [Meaning and baseline settings](./reports/ptw-report.md) |
| Risk Assessments | `ra-report` | [Meaning and baseline settings](./reports/ra-report.md) |

## Shared page tasks

- Query/URL/card/tab integration or a label change: [page contracts](./pages/contracts.md).
- New or adapted report: [authoring](./reports/authoring.md).
- Known defects and source discrepancies: [dated register](./reports/known-issues.md), plus each affected report guide.
- Hierarchy customization: [Division example](./recipes/division.md).

Exact source paths are in each topic. Generic platform serialization, widgets and conditions are indexed in [Kianda page knowledge](../kianda/page-knowledge.md); use the section matching the task.
