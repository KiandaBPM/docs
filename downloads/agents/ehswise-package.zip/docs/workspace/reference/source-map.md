# Source map and naming boundaries

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

| Location | What it controls |
| --- | --- |
| [pages/](../../../pages/) | Dashboard page definitions: identity, grouping/order, access, containers, widgets, filters, templates, and query connections. |
| [processes/QHSE - Modules/](<../../../processes/QHSE - Modules/>) | Main operational processes such as Incident, Action, Inspection, Audit, RA, NCR, PTW, and Worked Hours. |
| [processes/Data/](../../../processes/Data/) | Shared components, reference libraries/designers, lookup records, configuration, import utilities, and derived data. |
| [processes/Training/](../../../processes/Training/) | Worker, Certificate, and Induction player processes. |
| [processes/COSHH/](../../../processes/COSHH/) | COSHH Material records. |
| [processes/Policies/](../../../processes/Policies/) | Controlled-document workflow. |
| [processes/QHSE - Environment/](<../../../processes/QHSE - Environment/>) | Energy Registration and Green Initiative processes. |
| [components/fields/](../../../components/fields/) | Custom form-field behavior and templates, including the induction player and language tooling. |
| [components/rules/](../../../components/rules/) | Custom rule implementations and designer settings templates. |
| [components/widgets/](../../../components/widgets/) | Custom dashboard widgets and their settings/rendering templates. |
| [js/app.js](../../../js/app.js) | Workspace startup hooks, modal links, offline synchronization, guided-tour links, and translation integration. |
| [styles/app.css](../../../styles/app.css) | Workspace-specific presentation; also imports a remotely hosted base stylesheet. |
| [.kianda/workspace.json](../../../.kianda/workspace.json) | Local workspace/tenant binding and mappings for pulled processes, pages, globals, and extensions. Preserve its binding; do not copy workspace keys or tenant values into documentation. |

This repository is a serialized Kianda workspace with custom extensions. It does not contain the entire Kianda runtime. Runtime platform services, hosted files, tenant configuration, and attachments can be dependencies that are not represented by local source files. The local workspace metadata is ignored by [the Git configuration](../../../.gitignore).

## EHSwise naming boundaries

A process definition is a JSON template; a process instance is saved data; a form is a step inside that process; a dashboard page can query multiple process types. An Asset can represent a hierarchy item, physical asset or Subcontractor. A Custom Process ID is the human-facing business identifier, distinct from a record ID or definition name. Summary queries are configurable record projections/aggregations.

Dashboard routes are also written as `/dashboard/{pageId}`. Stored option values, technical field names (including punctuation such as `?inlineButtons`), IDs and display/translated text are distinct contracts. Preserve existing identities unless the change requires otherwise. Search technical names and visible text when tracing expressions, mappings, report tags, queries and translations.

Generic structure belongs to [Kianda containment](../../kianda/process/model.md#containment-and-the-accepted-profile), [process identities](../../kianda/process/model.md#process-aliases-and-entity-ids), [page identity](../../kianda/page/model.md#4-page-identity-root-properties-and-metadata), and [custom addon contracts](../../kianda/custom-addon-knowledge.md#host-contracts). Custom JS/HBS runs in the platform runtime rather than as standalone Node modules.
