# Offline and localization integration

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

EHSwise is a PWA. The service worker caches the runtime, while refresh/offline synchronization caches process definitions and configured lookup data in IndexedDB. [The app hook](../../../js/app.js) compares process versions, synchronizes processes and custom widget types, and preloads lists/find-item queries that opt into `offlineCache`. Inspect [offline-data.json](../../../processes/Data/offline-data.json) and [ensure-offline.js](../../../components/rules/ensure-offline.js) when changing offline reference data. Do not assume a server-only report/email rule executes while disconnected.

English is the base language. The Languages page supports automatic translation and manual overrides, including process fields. Selected language is saved to the user's profile when translations are enabled. Missing translation keys fall back to the English label. [The app translation hooks](../../../js/app.js) and [language-translation field](../../../components/fields/language-translation.js) use page/widget/field/checklist identifiers, so renamed or added elements need translation coverage. Runtime language data is a hosted `lang.json` file; it is not present as a local source file here.

Cached definitions are not another record type; local edits do not prove that an already cached device refreshed. The walkthrough did not establish all end-to-end synchronization internals. Home’s offline preparation messaging and refresh guidance are in [Home](../pages/index.md); translation administration is in [Languages](../pages/languages.md).
