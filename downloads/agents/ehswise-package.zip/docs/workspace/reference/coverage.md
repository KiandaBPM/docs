# Evidence, coverage and roadmap

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Detailed walkthrough coverage includes operational navigation, administration and libraries, 12 Analytics pages, and the main modules through Task based and COSHH RA. Worked Hours, NCR, and Hazard were concluded at a higher level, supplemented by inspected source. Energy Registration and Green Initiative appear in the Create New catalog but did not receive the same detailed module walkthrough. Other source features, such as Lessons Learned, were not part of this documentation exercise.

Planned/in-progress capabilities described by the product owner include AI-generated checklist drafts with review/publishing, AI-generated inductions/training, improved checklist report-template generation, configurable induction failure/retake behavior, and broader subcontractor document/review management. Treat them as roadmap items until the actual implementation is confirmed. A legacy Plant asset type remains unused and is intended for later removal.

Generic Kianda mechanics are routed through [the platform map](../../kianda/general.md); select only the task-relevant section.

## Module limits and source discrepancies

- The documentation exercise did not change process JSON, publish a workspace, send notifications, or execute module submissions to validate new changes.
- The live checklist renderer and saved definitions contain inherited controls/names. Use `enabled`, conditions and actual mappings; a copied title alone is not evidence of current behavior.
- Inspection signatures are optional in the demonstrated base setup. Earlier general comments about signatures being required were explicitly corrected.
- Score boundaries are the owner's final Pass ≥ high, At Risk strictly between low/high, Failed ≤ low. N/A/unanswered behavior must not be replaced with an exclusion assumption.
- Incident People is driven by Accident. The older Damage → People rule is disabled. Cost is source-enabled for Assets or Security; the owner demonstrated Assets.
- Incident notification PDFs are generated/stored separately; the inspected three notification settings do not attach them.
- PTW Suspend was described by the owner as setting Suspended. The saved enabled rules set global Closed and substatus Suspended; Extend sets global Extended and substatus Extension. This source discrepancy was documented, not changed.
- Anonymous subcontractor onboarding links are non-expiring in the documented version. Do not apply an assumed link lifetime to other workflows without inspecting their own rule.
- RA hazards are independent of substance and multiple hazard versions are chosen by the assessor. No automatic scope precedence was confirmed.
- Worked Hours is aggregate project/category exposure, supports custom date range, and Bulk Update total spreading. It is not a worker-level payroll module.
- Detailed NCR approval roles, complete Hazard lifecycle, every RA action-creation callback and the environmental modules were outside the agreed walkthrough scope. Trace source and ask targeted product questions if a future modification depends on those details.
- Customer reporting formulas may vary (for example LTIR/RIDDOR). The owner identified the saved Accident Rates multiplier/default and report-filter inconsistencies as bugs to fix later; see [pages/reporting documentation](../pages.md). They were not fixed as part of this documentation.

The relationship map also mentions membership, My Office/My Site and other source definitions outside the walkthrough. Their presence alone is not a completed workflow specification. Diagrams and shared fields do not establish foreign keys, cascades, inherited permissions, mandatory links or deletion semantics.
