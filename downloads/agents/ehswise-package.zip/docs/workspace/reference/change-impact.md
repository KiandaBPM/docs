# EHSwise change dependencies

Use only the row matching the request. This is a dependency map, not an approval gate. Read the actual current source and preserve customer changes; [AGENTS.md](../../../AGENTS.md) owns the editing workflow.

| Change | Product references | Contracts to trace |
| --- | --- | --- |
| Add/restrict a module | [Create New](../pages/create-new.md), module’s own guide, [identity/access](./people-and-access.md) | Process ID/title; `link.users`; direct process access; assignments; lookup/report scope; Home shortcuts; type tabs; translations |
| Hierarchy level | [Hierarchy](../shared/hierarchy.md), [Division example](../recipes/division.md) | Asset Type/panels/parents; shared and embedded selectors; selected codes; URL state; responsibilities/inheritance; records, reports and offline lookups |
| Checklist type/question/scoring | [Runtime](../shared/checklists.md), [designer](../pages/checklist-data.md) | Choice and Question schema; import/export; mandatory/visibility/related-question rules; scores/output; host submit/report |
| Required signature | Relevant module | Correct row; Internal/External identity; active-branch validation; customer approval policy; generated report and public flow |
| Action input/closure | [Action](../modules/action.md), [shared fields](../shared/actions-and-attachments.md) | Create/edit dialogs; embedded hosts; Start Action mappings; evidence/approval; parent/returned IDs; RA completion callback |
| Event type/training compliance | [Event](../modules/event.md), [training](../shared/training.md) | Branch clearing/validation; participant Worker IDs; certificate inputs; expiry/reminders; Induction and manual producers; report filters |
| Incident type | [Generic recipe](../recipes/incident-type.md), [Cyber proposal](../recipes/cyber-security.md) | Branch visibility/validation; counters; report and close regeneration; assignments; originator/additional/`incidentNotify`; analytics |
| Risk controls or scale | [RA](../modules/ra.md), [Hazard](../modules/hazard.md) | Lookup/dialog/table; keys/cards; numeric bands; Action feedback; shared Hazard updates; reports |
| Reporting | [Report authoring](../reports/authoring.md), exact report guide | Fields, widgets/connections, date basis, scope, aggregation, OData, formulas and access |
| Notifications | Relevant module; [identities](./people-and-access.md) | Originator/reporter/worker/responsible identity; conditions; CC/groups; attachments; asynchronous ordering |
| Lookup/process title | [Other Lists](../pages/other-data-lists.md), [page contracts](../pages/contracts.md) | Title-based checklist load and `__PROCESS_TITLE`; IDs; old captured values/links; translations; no implicit historical migration |
| Branding/navigation | [Home](../pages/index.md), [runtime](./runtime.md), [source map](./source-map.md) | Hosted images/styles; HTML/cards; CSS; carousel; tours/selectors; mobile layout |

Identify whether the changed object is a library record, execution record, nested row, embedded component, server rule, page query or widget implementation. Follow the relevant current IDs, conditions, trigger buttons and mappings. Copied material/reference values may intentionally be editable receiving-record data. Consider existing records, exports, generated reports, emails, schedules and caches; record unresolved product behavior instead of inferring it from a copied control title.
