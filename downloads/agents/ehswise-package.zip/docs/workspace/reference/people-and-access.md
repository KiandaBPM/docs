# People, identities and access

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

These are product personas. They are not all separate built-in security roles.

| Persona | Typical work | Access/configuration considerations |
| --- | --- | --- |
| General authenticated user / originator | Create operational records, view own pending work, report on behalf of someone else, receive submission confirmations. | Home and the base operational navigation serve general users. Process and site security can restrict data or module access. |
| EHS professional, assessor, inspector, auditor | Perform inspections/audits, investigate incidents, choose applicable hazards, evaluate controls and residual risk, raise actions and findings. | Assignments and configured workspace access determine available records. Checklist labels and risk scales affect interpretation. |
| Responsible person / action owner | Receive and complete assigned follow-up work, provide evidence where required. | Actions support internal users and external subcontractor contacts; RA-created actions are internal only in the discussed configuration. |
| Permit owner / holder, team lead, participant | Issue and manage a permit, record approvals and acknowledgments, extend/suspend/close, participate in high-risk work. | The specific approval and signature requirements are implementation choices; an available signature control is not necessarily mandatory. |
| Worker / learner | Hold training certificates, participate in training events, complete induction slides and quizzes. | A Worker record is distinct from an authenticated user account. Anonymous induction links can be created for individual workers. |
| Subcontractor contact | Supply company details/documents or complete an externally assigned action. | Anonymous links are used for specific flows. Do not assume the recipient has an internal account. |
| EHS administrator | Maintain assets/hierarchy, responsibility configuration, checklists, inductions, substances, lookup lists, translations, and administrative data. | The EHS Admin folder is restricted to the **EHS Admins** group in the base product. |
| EHS leader / reporting consumer | Review compliance, overdue inspections/training, incidents, action performance, and rate calculations. | Analytics is restricted to EHS Admins in the base product. Reports and metric definitions are often customized. |
| Onboarding/configuration team | Adapt the workspace to the customer, configure security/hierarchy/approvals, import reference data, change reports and branding. | Must trace changes across processes, embedded components, pages, templates, rules, translations, and security. |

## Identity distinctions that affect behavior

- **Creator / submitter / originator** is not always the person shown in **Reported by**. For example, an Observation can be reported on behalf of someone else, while its confirmation email goes to the submitter.
- **User** is an account that can be selected in an internal user picker. **Worker** is a training/compliance record and can exist without an account. **Other/External** modes often use text fields instead of user pickers.
- An **Action owner**, **asset owner**, **assessor**, **reporter**, and **permit holder** have different responsibilities. Do not substitute one for another when mapping fields or recipients.
- **People to be notified** and configured module notification recipients are separate sources. Some modules email the originator automatically; others expose a confirmation toggle. Check the specific module's rules.

## Access control

There are several independent access/presentation layers:

1. Page/folder visibility, such as EHS Admin and Analytics access through `visibleTo`.
2. Create New link visibility through `link.users`.
3. Process-level security governing direct form URLs and record access.
4. Customer-specific site/project hierarchy security affecting selectable and visible data.
5. Form, field, and action visibility/enabled/required conditions governing workflow presentation.

Hiding a link or tab does not secure its direct route. A requirement such as “only group X can create Risk Assessments” needs both the entry-link behavior and process security. Preserve the distinction between a UI filter and authorization. Anonymous subcontractor/induction/action flows require their own intended scope and recipient mappings; the subcontractor details link discussed in the walkthrough does not expire by default.

Security inspection starts with process `enableSecurity`, `securityMode` where present, `owners` and `administrators`, per-form `owners`/`security`, anonymous-access settings, and assignment-rule targets. These are source entry points, not a universal group-grant recipe. Confirm the platform security semantics and the destination workspace's group identities before applying a permission change; display visibility and form ownership are not interchangeable with process authorization.

## Baseline navigation restrictions

EHS Admin pages and the 12 Analytics pages have the EHS Admins visibility group in this export: `624882d9-abec-4454-9e6e-779b35a2218b`. This identifier belongs to this workspace; map it to the intended customer group when porting configuration. Page visibility does not replace process-level security or record access rules. Default ordinary pages generally have empty page `visibleTo` lists; this does not establish unrestricted record access.

Default Create New links generally have empty `link.users` restrictions. Customer restrictions must distinguish new-record access, existing records/form assignments, lookup access and report access. Hiding unused Action Plan or environmental links is common customer configuration, not proof that their records or dependencies are absent.
