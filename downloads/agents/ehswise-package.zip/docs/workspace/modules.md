# EHSwise module map

Base-product walkthrough/export: **27 October 2026**. Open the one module relevant to the task; verify its current customer source, enabled rules, conditions, targets, mappings and else branches. Technical names and stored values differ from labels. Detailed walkthrough coverage does not assert every customer approval path.

New records use `/forms/{processId}?isNew=1`; Home also uses `gotoForm(processName, isNew)`. A module missing from Create New can still have records or dependencies. Existing records may appear through My Overview, Location, Assets, Subcontractor or Admin Data according to filters and access.

## Module catalog

| Module / process ID | Focused guide | Coverage | Report |
| --- | --- | --- | --- |
| Inspection / `inspection` | [Behavior and anchors](./modules/inspection.md) | Detailed | [Guide](./reports/inspections-report.md) |
| Action / `action` | [Behavior and anchors](./modules/action.md) | Detailed | [Guide](./reports/action-report.md) |
| Observation / `observation` | [Behavior and anchors](./modules/observation.md) | Detailed | [Guide](./reports/observation-report.md) |
| Event / `event` | [Behavior and anchors](./modules/event.md) | Detailed | [Guide](./reports/event-report.md) |
| Checklist runner / `checklist` | [Behavior and anchors](./modules/checklist.md) | Detailed | Shared record/training views |
| Action Plan / `action-plan` | [Behavior and anchors](./modules/action-plan.md) | Detailed | Shared record/training views |
| Induction player / `induction` | [Behavior and anchors](./modules/induction.md) | Detailed | Shared record/training views |
| Audit / `audit` | [Behavior and anchors](./modules/audit.md) | Detailed | [Guide](./reports/audit-report.md) |
| Permit to Work (PTW) / `permit-to-work` | [Behavior and anchors](./modules/permit-to-work.md) | Detailed | [Guide](./reports/ptw-report.md) |
| Incident pack / `incident` | [Behavior and anchors](./modules/incident.md) | Detailed | [Guide](./reports/incident-report.md) |
| Risk Assessment (RA) / `ra` | [Behavior and anchors](./modules/ra.md) | Task based / COSHH | [Guide](./reports/ra-report.md) |
| Worked Hours / `hours-worked` | [Behavior and anchors](./modules/hours-worked.md) | Matrix confirmed | [Guide](./reports/accident-rate.md) |
| Non Conformance Report (NCR) / `ncr` | [Behavior and anchors](./modules/ncr.md) | High level | [Guide](./reports/ncr-report.md) |
| Hazard library / `hazard` | [Behavior and anchors](./modules/hazard.md) | High level | [Guide](./reports/hazard-library.md) |
| Energy Registration / `energy-registration` | [Behavior and anchors](./modules/energy-registration.md) | Source only | [Guide](./reports/energy-registration.md) |
| Green Initiative / `green-initiative` | [Behavior and anchors](./modules/green-initiative.md) | Source only | Shared record/training views |

## Shared and supporting contracts

| Concern | Read when affected |
| --- | --- |
| Hierarchy, codes, responsibilities | [Hierarchy](./shared/hierarchy.md); [Projects & Assets](./pages/Assets.md) |
| Checklist questions, scoring, component variants | [Runtime](./shared/checklists.md); [library/designer/import](./pages/checklist-data.md) |
| Action rows, parent links, attachments, embedded component updates | [Shared components](./shared/actions-and-attachments.md) |
| Save/submit, server rules, documents | [Execution](./shared/execution.md) |
| Worker, Certificate, course, role and producers | [Training](./shared/training.md) |
| Induction Type and slides | [Designer](./pages/induction-design.md) |
| COSHH Material | [Material library](./pages/coshh-materials.md) |
| Lookups and document control | [Other Lists](./pages/other-data-lists.md); [Policies](./pages/policies.md) |

Restrictions: [Create New](./pages/create-new.md) and [people/access](./reference/people-and-access.md). Change dependencies: [impact map](./reference/change-impact.md). Scope and source discrepancies are retained in each topic, with an optional [coverage register](./reference/coverage.md).
