# Assets

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [my-asset.json](<../../../pages/My Asset/my-asset.json>); ID `my-asset`.

Assets gives a physical-asset view of records. It follows the Location page's carousel → dropdown → type tabs → Items pattern, using URL `asset` and `tab` instead of `project`.

- Asset dropdown reads active Asset records with `type = Asset`, displays `displayName`, and stores `code`. Saved demo default is `LD001`.
- Selector connects `processAssetCode = filterValue1` to Items and `code = filterValue1` to the My Asset Banner.
- Carousel `parameter: asset` displays description, location, owner, a pencil to edit the selected asset, and a QR code for `/dashboard/my-asset?asset={code}`. Its saved heading contains legacy text My Project; preserve the difference between a display-template caption and data source identity.
- Tabs are Inspection (default), Action, Audit, Observation, Event, Hazard, Incident; they match `__PROCESS_TITLE`. Customers sometimes change these according to which records can be linked to assets.
- ID, Creator, and Status filters use the same common summary properties as Location.
- The page's new-record links include ADD ASSET, opening the new Asset dialog. The owner emphasized this as an important route for creating assets. Existing assets are edited from the carousel pencil.

Example: `/dashboard/my-asset?asset=LD001&tab=Inspection`.

## New/edit Asset behavior relevant to this page

The Asset process is [asset.json](../../../processes/Data/asset.json). Type controls panels and fields. `displayName` is calculated from title and code, for example **Ladder - 0001**. The asset owner is notified on the configured inspection schedule. This supports EHS leaders in identifying assets that have not been inspected regularly enough. When changing the schedule or display name, inspect the Asset rules and consuming dropdowns/templates, not just this page.
