# Additional exported pages: limited coverage

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

These definitions exist and should be considered when searching dependencies, but their business rules were not confirmed by the product owner in this exercise.

| Page | Observed implementation |
| --- | --- |
| [my-site.json](<../../../pages/My Site/my-site.json>) / `my-site` | Site-focused variant of carousel + asset selector + type tabs + Items. Both carousel and selector use URL `locationCode`; tabs include Action, Inspection, Observation, Hazard, RA, Incident, PTW, Audit, Event, NCR, Action plan. |
| [my-office.json](<../../../pages/My Office/my-office.json>) / `my-office` | Office-focused variant using `locationCode`, Items, common filters and process-title tabs. |
| [lessons-learned.json](<../../../pages/Lessons Learned/lessons-learned.json>) / `lessons-learned` | Person/action-bar, welcome-banner, HTML tiles and custom `level-1-search` widget. |
| [lessons-learned2.json](<../../../pages/Lessons Learned/lessons-learned2.json>) / `lessons-learned2` | Lessons Learned Items source `lessons-learned`; search/category/discipline filters with URL state; category data references `sub-category`, discipline references `knowledge-vault`. |
| [lessons-webinar.json](<../../../pages/Knowledge Vault/lessons-webinar.json>) / `lessons-webinar` | Video Player and Vault Cast Gallery lists read `lessons-learned`; video selector uses URL `video`; search/category/banner/CSS widgets. |
