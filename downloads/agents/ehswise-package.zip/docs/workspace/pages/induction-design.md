# Induction library and designer

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [induction-design.json](<../../../pages/EHS Admin/induction-design.json>); ID `induction-design`.

This is the training/induction content library. New Induction Design opens [induction-type.json](../../../processes/Data/induction-type.json) as a form rather than a new modal in the saved page. The searchable 15-row list reads Induction Type and opens its designer. Supporting processes are [slide.json](../../../processes/Data/slide.json) for content and [induction.json](../../../processes/Training/induction.json) for the learner player.

## Induction Type designer

The initial form captures title/description. The Slides form manages ordered slides and enable-expiration / expires-after-completion settings. Expiration is particularly relevant to high-risk jobs. Clone creates a new induction including **all slides**. It does not merely copy a title pointing at the original slides. Slide ordering, callback/refresh behavior, linked checklist IDs, and media URLs are structural dependencies.

## Slide editor and runtime implications

Slide Type can be **Image**, **Video**, or **Checklist**. Rich-text content can add guidance alongside any of those types. Image/video slides have a timer in seconds intended to prevent users skipping training content too quickly; **0 disables the wait**. Checklist slides do not have that timer. The slide stores title, content, media/files, order, parent campaign/induction ID and checklist identity as applicable.

Learners complete the checklist inside the player. These are commonly custom multiple-choice answers. Customers often customize failed-checklist behavior to force revisiting the previous slide. The owner corrected this point: it is **not a public setting in the main product yet**; a configurable option is planned for the next release.

AI generation of complete inductions/training is underway. Keep this separate from the currently available manual designer. For learner identity, anonymous links, result status, certificate generation, and worker email behavior, read [Induction](../modules/induction.md).

Runtime implementation: [induction-slides.js](../../../components/fields/induction-slides.js) and [induction-slides.hbs](../../../components/fields/induction-slides.hbs). Inspect these with process rules for navigation, timers or quiz changes. The exact timer field is `slideDuration(InSeconds)`.
