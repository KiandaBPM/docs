# Projects & Assets administration

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [Assets.json](<../../../pages/EHS Admin/Assets.json>); ID `Assets` (capital A); data [asset.json](../../../processes/Data/asset.json).

This is the central maintenance page for hierarchy/workspace data used across modules and a frequent onboarding customization point. The Manage Assets widget opens New Asset, Configuration, and Bulk Import Assets in modals. Tabs filter Asset `type`; saved options are Project, Site, Location, Subcontractor, Office, Asset with Project default. All Assets is a custom-card list of Asset records with display name, type, active state, and record identity.

Type is defined by the Asset process. Its value controls which panels/fields are shown. Title, Code, Display Name, and Type are shared properties consumed widely by dropdowns and pages. A historical Plant asset type remains in parts of the process but is unused; the owner plans to remove it. Do not promote Plant to a supported default hierarchy level merely because its configuration remains.

## Responsibilities configuration

The special Configuration action opens `/forms/configuration?isNew=1` in a new-form modal using [configuration.json](../../../processes/Data/configuration.json).

1. Select the Asset Type, then the specific Asset.
2. Continue to load the module-responsibility table, populated from Process Responsible records in [asset-responsible.json](../../../processes/Data/asset-responsible.json).
3. Assign people to the responsibility rows and submit.
4. The process creates/updates responsibility configuration records for the selected Asset ID/code context.

Responsibilities apply only to the configured asset by default. Inheritance can be delivered through onboarding configuration; it is not inherent in the base selection flow. **Submitting a blank row clears that responsibility assignment.** Preserve this clearing behavior when changing table persistence. Module server rules consume these responsibility records, including incident notification recipients. Inspect topic codes and the selected asset mapping, not only visible topic labels, when adding a responsibility.

The saved Configuration process additionally contains an Overview form and a Groups entry point. That source presence is not an owner walkthrough of a separate groups-security flow; inspect it if that feature is in scope.

## Bulk Import Assets

Bulk Import Assets opens [asset-import.json](../../../processes/Data/asset-import.json). It provides a sample Excel template and a table for bulk entry/import. Imported data is previewed and can be edited manually before submission. Validation is limited in the reviewed version.

**Owner-confirmed defect:** matching existing assets should use **Type AND Code**. The reviewed import behavior did not use the required composite match. Document and address it as a defect when import work is requested; do not copy the insufficient matching rule into a new implementation. Stronger validation is a future improvement discussed by the owner, not a shipped guarantee.

## Subcontractor self-service Asset screen

With Type Subcontractor, an administrator can send an email containing an anonymous link so the subcontractor can provide details and attach documents. The Anonymous form link rule generates a link that **never expires** in this version. Do not infer expiry from an unrelated field or a default assumption. The response updates the subcontractor information through the configured process flow.

The owner described a future subcontractor-management version with regular review and separate document maintenance similar to worker certificates. This is roadmap information, not current functionality.

Shared field names and responsibility consumers: [hierarchy](../shared/hierarchy.md). Proposed hierarchy customization: [Division → Project](../recipes/division.md).
