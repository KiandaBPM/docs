# Other Lists

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [other-data-lists.json](<../../../pages/EHS Admin/other-data-lists.json>); ID `other-data-lists`.

Lookup data is stored as small process records, usually one-page forms with limited rules. The page groups inline lists and modal add/edit links.

| List | Definition | Important fields / consumers |
| --- | --- | --- |
| Worker Role | [worker-role.json](../../../processes/Data/worker-role.json) | Role, Department; worker records and filters |
| Training Courses | [training-course.json](../../../processes/Data/training-course.json) | Course, Code, Active; certificate training selection/code |
| Energy Type | [energy-type.json](../../../processes/Data/energy-type.json) | Energy subtype, Unit, AssetType, Title; energy registration |
| Energy Unit | [energy-unit.json](../../../processes/Data/energy-unit.json) | Title, Energy Type, Unit; energy registration |
| PTW Equipment | [ptw-equipment.json](../../../processes/Data/ptw-equipment.json) | Title, Category, Applicable PTW; equipment options in permits |
| Root Cause | [root-cause.json](../../../processes/Data/root-cause.json) | Root Cause; incident investigations |

**Owner-confirmed update semantics:** editing these choices changes future selections; it does not rewrite the captured values of historic records. Do not implement retroactive migrations merely to update a dropdown label. If a customer explicitly requests a migration, treat it as separate work with an impact assessment.
