# Workers

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [workers.json](../../../pages/Training/workers.json); ID `workers`; data [worker.json](../../../processes/Training/worker.json).

Purpose: manage worker training compliance. New Worker opens a modal; Import Workers opens [worker-import.json](../../../processes/Data/worker-import.json); Go To Certificates opens `training-certificate`. The base lets anyone create/import workers. Customer onboarding usually adds security, so do not assume that open creation is the final customer policy.

The 20-row Workers list renders a card with picture/default avatar, display name and initials, role, subcontractor or Internal, training status, and red-card indicator. Cards open the worker profile in a modal. Supporting hidden fields include picture URL, worker ID/account, subcontractor code, display name, initials, role, expiring training information, and `issueRedCard`.

| Control | Source / target |
| --- | --- |
| Worker Name | Free text; `displayName contains filterValue1` |
| Company | Asset records restricted to Subcontractor; display name / code; target `processSubcontractorCode` |
| Role | Worker Role records; target worker `role` |
| Status | Ok, Due, Expired; target `trainingStatus` |
| All Workers tile | Count Worker; connected to Workers list |
| Red Card Workers tile | Count Worker with `issueRedCard = Yes`; connected to Workers list |

A red card means repeated safety offences. Typically the worker is sent to mandatory training/induction and a formal record is created. It is a safety/compliance concept, not simply another certificate expiry status.

## Worker profile and certificate upload

Individual training certificates are uploaded from the worker profile using [certificate.json](../../../processes/Training/certificate.json). The date shown is the **expiry date**. Reminder days are configurable and shared across training types; users can change them. The training dropdown is maintained in EHS Admin → Other Lists (Training Courses). Selecting training populates its code. Certificates have automatic reminder behavior; preserve the worker/certificate relationship when altering forms or notifications.
