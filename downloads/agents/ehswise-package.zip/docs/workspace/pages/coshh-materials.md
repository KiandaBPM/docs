# COSHH material library

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [coshh-materials.json](<../../../pages/EHS Admin/coshh-materials.json>); ID `coshh-materials`; data [material.json](../../../processes/COSHH/material.json).

This page maintains a library of hazardous/risky chemical substances. It includes a custom banner carousel, Supplied By filter, Add Chemical modal link, and a 10-row material card list. The list exposes substance, material code, supplier, status and revision. Its datasource is COSHH Material (`material`).

The New Material dialog captures the material metadata and hazardous properties used by COSHH Risk Assessment. The owner confirmed that the relevant hazard details are separate inputs rather than automatically inferred from one another. Details carry into [ra.json](<../../../processes/QHSE - Modules/ra.json>): selecting a substance populates supplier, revision, SDS/file, description and hazard properties; the assessor can edit these in the assessment. The SDS belongs to the material record and can be opened from the assessment.

COSHH RA hazards are independently selected from the configured hazard library; they are **not filtered by the selected substance**. Material-library hazards/properties and the shared Hazard records used for risk scoring are related concepts but distinct data.

The supporting Material record also stores a next SDS check date; metadata and hazard indicators are entered separately, not inferred from an uploaded SDS.
