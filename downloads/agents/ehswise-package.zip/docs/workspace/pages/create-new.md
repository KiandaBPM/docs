# Create New

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [create-new.json](<../../../pages/Create New/create-new.json>); ID/group `create-new` / `Create New`.

This is an ordinary dashboard page. CSS presents its menu entry as a primary button pinned at the top of the left menu. Its function is to make all available record creation actions easy to find.

The Links widget creates Inspection, Action, Observation, Event, Checklist, Action plan, Induction, Audit, Permit to work, Incident, Risk Assessment, Hazard, Non-conformance, and Hours Worked. A separate Energy Links widget creates Energy Registration and Green Initiative. Each is a process link that opens `/forms/{process-name}?isNew=1`; the saved links use `autoAppendQuery: true`.

Customers commonly hide unused modules, especially Action plan or energy/waste modules, and restrict others, such as Risk Assessment, to specific groups. `link.users` controls link visibility. Apply process security as well so a user cannot bypass the menu restriction by opening the form URL directly. The base JSON has empty `users` restrictions and `adminOnly: "no"`; these values are configuration, not a recommended permission policy for every customer. For each new or renamed module, update this page, any Home shortcut, relevant location/asset/subcontractor tabs, Analytics, and translation labels.
