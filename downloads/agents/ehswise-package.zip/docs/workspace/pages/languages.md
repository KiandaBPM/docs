# Languages

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [languages.json](<../../../pages/EHS Admin/languages.json>); ID `languages`; custom widget [lang.js](../../../components/widgets/lang.js) / [lang.hbs](../../../components/widgets/lang.hbs).

English is the default language. Add Language enables other languages. Automatic translation can populate values, and administrators can override translations manually. Process-field labels are translated here as well as the application interface.

When translation is enabled, a user's language selection is saved to their profile and used on the next visit. If the key for that language is missing, the interface falls back to the English label. Preserve keys and fallback behavior when changing labels, adding types, or moving fields. A missing translation is a missing language-specific key, not evidence that the underlying process field is absent.
