# Home

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [index.json](../../../pages/Dashboard/index.json); ID `index`; group `Dashboard`.

## Purpose, content, and customer variation

Home is the landing page for all users. Its base content is static and does not change with selected project or role. The main actions are three HTML shortcuts: **Record Event**, **Create observation**, and **Conduct an inspection**. They call `gotoForm('event', true)`, `gotoForm('observation', true)`, and `gotoForm('inspection', true)` respectively. The first parameter names the process; the second is the new-instance Boolean. These duplicate a convenient subset of the Create New catalogue. Customers sometimes add more main-action links.

The full-width custom carousel supplies banner imagery and welcome messaging. The owner said this is usually the first customer branding change; branding creates a sense that the system belongs to the customer. Edit images, text, and layout without changing process targets accidentally. The accompanying HTML About Section explains offline refresh.

EHSwise is a PWA. The service worker caches application runtime; the refresh gesture additionally caches process JSON definitions in IndexedDB to enable full offline use. Treat the runtime cache and cached process definitions as separate concepts when explaining offline preparation. The Home instructions advise refreshing before going offline and preserving the session/cache during offline use.

## Hidden onboarding walkthroughs

There are five `widgets/widget-walkme` widgets. They may be hidden in normal use by CSS classes while remaining visible in the page designer. Their step `type` is either `popup` or `click`; click steps navigate the interface using selectors. Walkthroughs are executable UI dependencies, not just descriptive copy.

| Walkthrough / CSS hook | What it teaches | Significant selectors and targets |
| --- | --- | --- |
| Welcome to EHSwise / `getting-started-guide` | Toolbar, offline refresh, notifications, profile; left menu; EHS Admins; Checklists; creating/configuring assets; Location banner/selector/tabs; Create New; energy/waste modules | `#right-nav-toolbar`, `.sidebar > .nav`, `li[data-group="EHS Admin"]`, `li[data-name="Assets"] > a`, `.slide-title`, `.widget-filter-tabs`, `li[data-name="create-new"] a` |
| `invite-team-guide` | Navigate to Team, open Manage Team Members, enter first/last/display names and email, then save invitations | `li[data-name="team-setup"]`, `.button-panel:first` |
| `create-projects-guide` | Open Projects & Assets, create an asset, select Type, complete type-specific fields, save | `li[data-name="Assets"] a`, `.button-panel:first` |
| `observation-guide` | Choose Location, favourite it, open Create New → Observation, select unsafe, fill details, review Summary and submit | `li[data-name="my-project"] a`, `.page-widget[title="Project"]`, `a[title="Add to favourites"]`, `.button-panel:contains(Observation)`, `.form-field[data-name="OBS_LSTSIN_TopicType?radioCards"]`, `button[data-name="OBS_BTN_ContinueClassification"]`, `.form-tab-list li[data-name="FORM_OBS_Summary"]`, `button[data-name="OBS_BTN_Submit"]` |
| `checklist-guide` | Open checklist library/designer, edit/reorder questions, scales/export; explain import and blank checklist creation | `li[data-name="checklist-data"] a`, `.widget-list`, `.widget-list a.btn:first`, `.button-panel:last` |

The welcome popup links to the four shorter guides with `data-guide` values. Its audit/inspection guide link is commented out. Existing selector strings include legacy caption assumptions: the current Location widget is titled Location while guide selectors mention Project; `energy-waste-modules` is saved without a CSS class prefix; Team setup is referenced although no matching page definition is in this export. These are source observations requiring UI review if altering guides. Do not assume they have all been demonstrated to work. Renaming widget titles, menu groups, field names, CSS classes, or button order can break guide navigation.
