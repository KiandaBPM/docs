# How-to Guides

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [ehswise-guides.json](../../../pages/Training/ehswise-guides.json); ID `ehswise-guides`.

This Training child page contains three HTML widgets: End User Guides, EHS User Video Guides, and PDF Guides. It is a help-content page rather than a workflow-data list. The page was identified in navigation but not walked through individually. Inspect its HTML links and media when changing guidance; keep Home selector-driven walkthroughs separate from this guide library.
