# Admin Data

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [admin.json](<../../../pages/EHS Admin/admin.json>); ID `admin`.

This page exposes the broad record list with filtering, configured summary fields, selected-row bulk delete and export. It uses Kianda's schemaless summaries model to request fields across different process types. Common columns are record ID, status, process title, created-by/date, `processCustomID`, and code. Fields need not have identical form schemas in every module, but the requested property names must match saved data.

The owner's high-level description was all system records. The actual saved All Records list excludes several supporting/master-data processes, including question, team-member, ehswise-lite-members, Checklist Type, asset, induction-type, root-cause, ptw-equipment, worker, energy-unit, energy-type, training-course and worker-role. Consequently **all** means the configured operational scope, not literally every process record. Review the conditions before using this page as a complete backup or inventory.

The list enables search, column filtering, sorting, 20-row load-more paging, delete, bulk delete and export. Bulk delete applies **only to selected rows**. The owner confirmed OData export respects the filters and selected fields. The current page also saves `exportdataFormat: excel`; inspect the actual export control/platform behavior when extending it rather than assuming a single format from the caption. This is an administrative view; preserve its EHS Admin access boundary.
