# Subcontractor

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [subcontractor.json](../../../pages/Subcontractor/subcontractor.json); ID `subcontractor`.

This is a focused view of subcontractor-specific records, including workers. Its dropdown reads active Asset records with `type = Subcontractor`, displays `displayName`, stores `code`, and updates URL `subcontractor`. The carousel uses `parameter: subcontractor`, displays description/country/active information, and provides an edit pencil. Saved demo default `JohnLTD` is just example data.

The selector connects Items through `processSubcontractorCode`; Tabs restrict `__PROCESS_TITLE`. Choices are Worker (default), Induction, Inspection, PTW, Action, NCR, Observation, Incident, Audit, Event. ID, Creator, and Status filters target Items. The custom card needs common process fields plus worker role/originator where relevant. The saved list also contains `processName: worker`; inspect the dynamic tab behavior and summaries query when changing it rather than inferring that a fixed Worker source is sufficient for all tabs.

Example: `/dashboard/subcontractor?subcontractor=JohnLTD&tab=Worker`. When customer site security is applied, users only see subcontractors permitted to them. Treat selector visibility and underlying record security as coordinated parts of that behavior.

The subcontractor self-service flow belongs to the Asset process and is described in [Projects & Assets](./Assets.md#subcontractor-self-service-asset-screen).
