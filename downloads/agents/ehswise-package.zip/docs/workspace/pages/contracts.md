# EHSwise page integration contracts

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

A menu caption, group, filename, page ID, process name and process title can differ. Location uses `my-project`; cross-process Risk Assessment tabs use title `RA`. Dashboard routes use `/dashboard/{page.id}`; creation uses `/forms/{process.name}?isNew=1`; existing records use `/forms/{record-id}`.

## Queries, filters and templates

- Cross-process Items lists use shared properties, and may omit a single `processName`. The filter editor’s **Associated process (for filtering only)** supplies field metadata; it does not constrain the list to that process. Type tabs apply `__PROCESS_TITLE`.
- Source settings include `processName`, `processSource`, or `settings.list`; `queryType` controls assignment/creator/matching scope. Preserve conditions as well as sources.
- `settings.connections` maps `widgetId` targets and conditions. Charts/tiles may use `connectTo`. A visible filter does not establish coverage of every widget.
- `enableQueryString`, `queryParameter`, and `updateURL` control filter URL state; carousel `parameter` reads it. Links with `autoAppendQuery` carry context to processes whose preload rules consume it. URL context grants no record access.
- Card columns use Handlebars `html`, often relying on hidden list fields. Preserve those dependencies and existing-record identity links.

Native filter/HTML type aliases are `widgets/widget-filter` and `widgets/widget-html`; `client-widget/...` denotes a custom implementation. Generic serialization and widget catalogues live in [Kianda page envelopes](../../kianda/page/model.md#5-widget-identity-envelope-and-serialization), [query contracts](../../kianda/page/queries-filters.md#9-query-groups-conditions-and-operands), [filter/URL contracts](../../kianda/page/queries-filters.md#10-filter-ownership-connections-url-state-and-dates), and [HBS columns](../../kianda/page/templates-navigation.md#11-custom-hbs-list-columns-helpers-and-actions). Use the section matching the edit.

## Record-type tabs

1. Resolve the exact process title, not just its creation-route name.
2. Confirm that the module saves the relevant shared workspace code (`processProjectCode`, `processAssetCode` or `processSubcontractorCode`) and common card fields.
3. Add the matching title to the Tabs options and preserve `__PROCESS_TITLE` target conditions.
4. Keep URL `tab` and the intended default selection aligned with available values.
5. Retain hidden data required by the custom Items card and ensure its record link opens the right instance.
6. Add/adjust creation access in Create New and process security when relevant.

## Label and navigation changes

Check page ID versus display title, links, query parameters, template field references, translation keys, walkthrough selectors, reporting group fields and process security. A process title used in `__PROCESS_TITLE` tabs is an integration contract; changing the title alone may make records disappear from views.
