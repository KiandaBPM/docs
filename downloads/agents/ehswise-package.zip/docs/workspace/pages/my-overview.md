# My Overview

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [my-overview.json](<../../../pages/My overview/my-overview.json>); ID `my-overview`.

This page helps the current user find unfinished assigned work and records they previously started. It has two HTML section headings and two cross-process list widgets.

| List | Query behavior | Conditions in saved JSON |
| --- | --- | --- |
| Records Awaiting My Input | `processSource: own`, `queryType: assignedTo`; UI setting **Matching condition and assigned to current user** | `__STATUS != Closed` AND `processCustomID` is not blank |
| My Records / Records Submitted By Me | `processSource: own`, `queryType: createdBy` | `processSubject` is not blank AND `__PROCESS_NAME != certificate` |

The owner specifically explained that the Awaiting Input condition uses the **Custom Process ID (Calculate in the server)**. Do not replace the assignment query with a creator query: the same user can create a record while a different person must act on it. Custom cards depend on common properties including custom ID, subject, project/location, status, process title, and record identity. Existing-record links route to the instance. A new module that should appear here must populate the common summary properties and assignments expected by these lists.
