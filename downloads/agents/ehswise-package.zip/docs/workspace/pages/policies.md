# Policies

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [policies.json](../../../pages/Policies/policies.json); ID `policies`; data [document.json](../../../processes/Policies/document.json).

Policies is the document library and document-control entry point. Opening a card opens the Policy/Document record, from which the actual file can be opened. The card includes originator, custom ID/title, creation date, status and document type. Approved status has a distinct icon.

The page includes document-type and Location filters. Document Type reads Document `businessUnit`; Location reads EHS Asset Site records using display name/code. **Review This Month** is based on `nextRevisionDate`, meaning next review/revision date, not the upload date. The list uses standard record identity plus custom fields; retain fields referenced by its template.

The owner described policy creation/document control as EHS Admins by default. The saved New Policy link and widget have empty user restrictions, so the page configuration alone does not prove enforcement; inspect process security and customer onboarding configuration before changing access.

## Document control approval screen

Origin follows the customer's hierarchy: Group means company-wide; Site means the document/policy applies to one site. Submitting starts a **serial approval** workflow. Each approver acts in turn; after everyone approves, the record becomes Approved. Do not implement a parallel or first-approval-wins model when customizing this workflow. Apply customer hierarchy and document scope consistently to selection, record access, and reporting.
