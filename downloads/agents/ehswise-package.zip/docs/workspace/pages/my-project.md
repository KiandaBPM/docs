# Location

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [my-project.json](<../../../pages/My Project/my-project.json>); caption **Location**; ID `my-project`.

This is the principal operational page. The default shows a Project-level hierarchy; customers often add Country, Region, Site, or other levels. The shared source is [EHS Asset](../../../processes/Data/asset.json), while operational forms embed [Workspaces](../../../processes/Data/workspaces.json) to associate records to that hierarchy.

## Selection and connections

1. The **Location** dropdown reads active Asset records with `type = Project`; displays `displayName`, stores `code`, and writes URL `project` (`enableQueryString`/`updateURL`). `PRJ1` is the saved demo default, not a cross-customer constant.
2. The **My Project** custom carousel reads the selected Asset through `parameter: project`. Its template presents description, location, Local EHS, dates, edit pencil, and QR code. The selector also explicitly connects `code = filterValue1` to the carousel.
3. The dropdown connects the Items list by `processProjectCode = filterValue1`.
4. The **Tabs** radio filter writes URL `tab` and connects `__PROCESS_TITLE = filterValue1` to Items. Default choices: Action, Inspection, Observation, Incident, Event, RA, Hazard, Induction, Action Plan, Audit, NCR, PTW. Titles must match actual process titles; adding a visible label alone is insufficient if its title differs.
5. Items is a cross-process list with a custom card field and common fields (`processCustomID`, `processSubject`, `__STATUS`, `__NAME`, creator, created, and substatus).
6. Three additional filters target Items: ID contains `processCustomID`; Creator contains `processOriginator`; Status equals `__STATUS` with Open, Closed, Follow-up, Draft options.
7. NEW RECORD navigates to Create New and appends the query string, preserving workspace context for processes that consume it.

Example: `/dashboard/my-project?project=PRJ1&tab=Action`. The banner's pencil opens the selected Asset record in a modal. The QR image encodes the project view using the Asset code. The template is part of carousel settings; supporting implementation is [carousel-widget.js](../../../components/widgets/carousel-widget.js) and [carousel-widget.hbs](../../../components/widgets/carousel-widget.hbs).

## Adding a hierarchy level

Coordinate Asset Type choices, relevant type-specific fields, parent references, Workspaces component, dropdown sources/conditions and cascade wiring, URL parameters, summaries properties, page filters, record access security, responsibility configuration, and affected reporting. A common onboarding change adds Country or Region to Asset Type, adds a matching parent field to Projects/Sites, then filters child choices by the selected parent. Country alone on the standard new-asset screen is an independent system country list; it does not automatically create a customer hierarchy relationship.

Implementation example: [add Division above Project](../recipes/division.md).
