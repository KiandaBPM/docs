# Checklist library and designer

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [checklist-data.json](<../../../pages/EHS Admin/checklist-data.json>); ID `checklist-data`.

This shared library supplies inspections, audits, standalone checklists, incident-investigation checklists, induction quizzes and other consumers. A checklist definition is the **Checklist Type** process, technically [audit-type.json](../../../processes/Data/audit-type.json); the filename does not mean only audits use it.

New Checklist opens a new Checklist Type modal. Import Checklist opens [checklist-import.json](../../../processes/Data/checklist-import.json). The page has a category filter using `industry`, a searchable 15-row checklist list with custom cards, and a header HTML widget. Clicking a library item opens its designer; Preview lets an administrator view the checklist quickly before use.

## Import: public library and file

The public checklist library is shared across customer workspaces and contains examples created by Kianda. **Download creates a local customer-library copy** for publishing/customization; it is not a live reference that automatically keeps all customers' copies synchronized.

File import includes a sample Excel template so customers can model questions for import. The owner confirmed that duplicate handling is supported; the exact matching policy was not described in the walkthrough, so inspect the import rules before changing or promising replace/merge behavior. Maintain compatibility between file import and designer export.

## Checklist designer

The designer stores checklist name (`auditName`), category (`industry`), version, description, report-template choice/file, scoring setting, question configuration, and order. Adding a checklist starts with its name, then opens the designer.

Supported question choices in the saved designer are:

| Choice | Intent / related configuration |
| --- | --- |
| OK, Not OK, NA; Yes, No, NA | Preset answer families |
| Section Header | Organizes questions; does not request an answer |
| Custom | Administrator-defined possible answers and scores |
| Dropdown List | Configured dropdown answer options |
| EHS Asset List | Asset selector; includes Asset Type configuration |
| Worker List | Worker selector with selection-mode configuration |
| Single Line Textbox; Multi Line Textbox | Free text |
| Date; Date and Time | Temporal values |
| Signature | Signature answer |
| File Upload | Files/evidence |

Question configuration includes text, code, type, possible answers, score, sort order, and mandatory-question toggle. The table persists question IDs and ordering; reordering is more than a visual change. When adding a new answer type, update the designer, question persistence, reusable runtime [checklist-component.json](../../../processes/Data/checklist-component.json), import/export mapping, and report rendering together.

## Scoring and labels

Checklist scales are editable in a dialog. They define thresholds against aggregated question scores and configurable display labels (`greatStatusLabel`, `okStatusLabel`, `failedStatusLabel`). These labels replace initial Pass/At Risk/Failed labels at runtime in consumers such as Audit. The owner stated that **Custom and Dropdown List questions contribute to scoring**. Unanswered questions are **not ignored**; the resulting score remains lower and may fail to reach the pass threshold. Do not silently rescale totals to only answered questions.

The confirmed boundary logic from the Inspection walkthrough is:

- Pass: total score **greater than or equal to** PassScore.
- At Risk: total score **greater than** FailScore and **less than** PassScore.
- Failed: total score **less than or equal to** FailScore.

NA answers are typically configured as zero. Customer choices and scoring configuration can differ; read the actual definition rather than assuming universal per-answer weights.

## Custom Word report and Excel reuse

Enable Report Template allows a custom Word template for generated inspection/checklist reports. Kianda's **Generate word document** rule parses rich-text content controls tagged `kf:<name-of-field>`. Preserve field names/tags and nested table mappings when changing a template or source fields. The planned next designer version can generate a custom report template from an existing Word document; that is roadmap work.

The top-right export/download action exports the checklist to an Excel template. Customers can modify questions and reimport for quick reuse. Export fields include category, checklist name, question, question code, answer type, order, help text, and custom answer configuration. Keep export schema aligned with the import template.

**Roadmap:** AI-generated checklists with draft → administrator review/correction → publish to library. Do not treat an AI draft as a published checklist in the current flow.

Preview source: [check-list-tester.json](../../../processes/Data/check-list-tester.json). Runtime answer fields, title-based question loading, scoring names and component variants are in [shared/checklists.md](../shared/checklists.md).
