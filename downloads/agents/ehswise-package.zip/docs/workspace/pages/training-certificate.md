# Training Certificates

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Definition: [training-certificate.json](../../../pages/Training/training-certificate.json); ID `training-certificate`; default visible to everyone, subject to customer security.

This page lists the certificates themselves. Upload Certificate opens a new Certificate modal. The 20-row list's custom card shows training title, worker, company, status, and time relative to the expiry date; it opens the Certificate instance.

Filters are Course, Company, Status, Expiry Date Range, and Worker:

- Course uses Training Course `course` and filters Certificate `processSubject`.
- Company uses Subcontractor Asset `code` and filters `processSubcontractorCode`.
- Status offers Ok / Due / Expired and filters `trainingStatus`.
- Expiry range applies inclusive `gte`/`lte` to `expiringTrainingDate`.
- Worker displays Worker `displayName`, stores `processWorkerID`, and filters Certificate `workerID`.

The owner explained that statuses are expiry-based and use Ember Moment helpers for their presentation. The inspected card reads stored `trainingStatus` to choose green/check (Ok or empty), amber/hourglass (Due), or red/exclamation (Expired), then uses `moment-from-now` with `expiringTrainingDate`. Therefore changing expiry semantics requires following the Certificate/Worker calculation and reminder rules as well as this rendering template; the page alone does not prove all calculation behavior.
