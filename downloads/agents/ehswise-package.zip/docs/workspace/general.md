# EHSwise workspace guide

EHSwise supports environment, health, safety and quality operations on Kianda: observations/incidents, inspections/audits, risk assessments, follow-up actions, permits and training compliance. Location, asset, subcontractor and personal views query related records; they do not create separate copies of operational data.

## Evidence and customer scope

This package records an owner walkthrough and export inspected **27 October 2026**. It is a base-product reference for customer bootstrap work. Verify the destination workspace’s current fields, IDs, roles, hierarchy, formulas, approvals, branding and enabled modules. A dated export can differ from the live customer configuration; use current source to determine what an edit changes, and preserve unresolved conflicts with owner-confirmed intent.

**Walkthrough confirmed** = explained/corrected product behavior; **source detail** = observed export implementation; **customer configuration** = a deployment choice; **roadmap** = planned, unconfirmed capability. Exact report IDs and demo defaults are baseline evidence, not portable customer constants.

## Select the relevant entry

Read only the needed route and its matching topic. These files are alternatives, not a sequence.

| Task | Start here |
| --- | --- |
| Process/form behavior, fields, submit or closure rules | [Module map](modules.md) |
| Dashboard, navigation, list, filter or report | [Page and report map](pages.md) |
| Cross-record creation, lookup or feedback relationship | [Dependency map](data-model.md) |
| Hierarchy or workspace selector | [Hierarchy contract](./shared/hierarchy.md) |
| Reusable checklist or score | [Checklist runtime](./shared/checklists.md) or [designer](./pages/checklist-data.md) |
| Action entry, linked actions or shared attachments | [Shared components](./shared/actions-and-attachments.md) |
| Server execution, business IDs or generated documents | [EHSwise execution](./shared/execution.md) |
| Ownership, identity or access meaning | [People and access](./reference/people-and-access.md) |
| Source locations or naming | [Source map](./reference/source-map.md) |
| Offline data or translations | [Runtime integration](./reference/runtime.md) |
| Scope, uncertainty or planned capability | [Coverage](./reference/coverage.md) |

## Recipes

Owner-reviewed proposals: [Division → Project](./recipes/division.md), [Cyber Security Incident](./recipes/cyber-security.md). These are customization examples, not assertions that either feature exists in a customer workspace. For other changes, [the impact map](./reference/change-impact.md) names the affected contracts.

Generic Kianda JSON, widget and addon mechanics live in [the platform entry map](../kianda/general.md). [AGENTS.md](../../AGENTS.md) owns the working procedure. Product references explain intent and dependencies; inspect the current field/rule/widget/security setting when implementing.
