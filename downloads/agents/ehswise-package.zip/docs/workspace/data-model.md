# EHSwise data relationships

This is a logical process-record model, not a SQL schema. Shared fields and arrows do not establish foreign keys, automatic synchronization/cascades, inherited permissions, mandatory relationships or deletion behavior. Baseline: owner walkthrough/export **27 October 2026**; verify the customer’s current mappings.

## Relationship meanings

| Operation | Meaning |
| --- | --- |
| Creates / updates | A rule starts/updates a separate process record; inspect conditions, mappings, lookup keys, trigger and server scheduling. |
| Looks up / selects | Values may be copied into the receiving record; live synchronization is not implied. |
| Embeds | Component fields/rules become part of a parent definition; this alone creates no separate business record. |
| Lists / filters / aggregates | A page queries records; URL state, conditions and explicit widget connections set scope. |
| Contains rows | Repeating data remains in its parent unless a separate create rule is established. |

## Dependency map

| Domain | Established relationship | Focused references |
| --- | --- | --- |
| Workspace context | `asset` supplies Project/Site/Location/Office/Asset/Subcontractor selections; embedded `workspaces` copies context to operational records. `configuration` creates/updates/clears `asset-responsible` by selected asset. Default responsibility scope is that asset. | [Fields and consumers](./shared/hierarchy.md), [administration](./pages/Assets.md) |
| Checklist library → execution | `audit-type` + `question` supply ordered definitions/scales; `checklist-component` variants embed in Inspection, Checklist, Audit, PTW, Incident investigation and Induction. They do not create a standalone Checklist record in each host. | [Runtime](./shared/checklists.md), [designer/import/preview](./pages/checklist-data.md) |
| Actions and audit findings | Parent/question action rows create central `action` records with source/returned IDs. Audit Findings creates separate `ncr` records and stores returned NCR IDs. Action Plan requires at least one Action. | [Shared mappings](./shared/actions-and-attachments.md), [Audit](./modules/audit.md), [Action Plan](./modules/action-plan.md), [NCR](./modules/ncr.md) |
| Worker → training evidence | Worker is a record, distinct from an account. Manual upload, eligible Training Event rows and successful Induction completion create worker-linked Certificates. Induction Type owns ordered Slide definitions; Someone Else creates individual learner inductions/links. | [Training producers](./shared/training.md), [Event](./modules/event.md), [Induction](./modules/induction.md), [designer](./pages/induction-design.md) |
| Hazard → RA → Action feedback | RA can contain multiple risk rows selected from global/scoped Hazards. COSHH Material copies editable substance details; it does not filter the Hazard choice. Completing an additional-control Action calls RA and adds controls to the associated shared Hazard. Hidden Audit-labelled RA/NCR rules remain source-only legacy, not a confirmed normal relationship. | [RA](./modules/ra.md), [Hazard](./modules/hazard.md), [Material](./pages/coshh-materials.md), [Action callback](./modules/action.md#parent-linkage-and-ra-feedback) |
| Incident and rates | Incident types/damage selections reveal forms in one process. People, witnesses, cost and report metadata remain nested data. Injury Utility counters and `hours-worked-data` feed Accident Rates. Worked Hours captures aggregate project/category daily data, not worker timesheets. | [Incident](./modules/incident.md), [Worked Hours](./modules/hours-worked.md), [rates](./reports/accident-rate.md) |
| PTW | Phases, signer/participant rows, gas readings and LOTO belong to one permit; Related PTW links separate records. Base Applicable Risk Assessment is free text. PTW equipment uses `ptw-equipment`, distinct from `equipment`. | [Permit contracts](./modules/permit-to-work.md), [lookups](./pages/other-data-lists.md) |
| Environment | `energy-registration` uses Energy Type/Unit and equipment lookups; Energy & Waste is its report label. `green-initiative` can create follow-up actions. End-to-end environmental workflow, emissions-factor semantics and the separate `waste-management` process were not established. | [Energy](./modules/energy-registration.md), [Green Initiative](./modules/green-initiative.md), [report](./reports/energy-registration.md) |
| Pages, policies and configuration | Operational views, Admin Data and Analytics query records; they are not separate business entities. Policies manages Document records with serial approval. Lookup changes affect future selections; translations/caches/workspace binding are separate configuration/runtime concerns. | [Page/report map](pages.md), [Policies](./pages/policies.md), [lookups](./pages/other-data-lists.md), [runtime](./reference/runtime.md), [source map](./reference/source-map.md) |

For an edit spanning these relationships, use [the change-impact map](./reference/change-impact.md). Limited coverage and historical/source disagreements remain in their focused topics; a copied control or caption alone does not establish behavior.
