# Hierarchy and workspace associations

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

The [EHS Asset process](../../../processes/Data/asset.json) is the shared hierarchy and asset data model. Its active Type options are Project, Site, Location, Subcontractor, Office, and Asset. Common fields `type`, `title`, `code`, and `displayName` support dropdowns throughout the product. The default display name concatenates title and code. A former Plant type is unused legacy configuration.

The [Workspaces component](../../../processes/Data/workspaces.json) embeds workspace selectors in many module forms. Typical technical fields are `processProject`, `processLocation`, `locationType`, `subcontractor` (sometimes titled Asset), and helper codes `processProjectCode`, `processLocationCode`, `processLocationCodeType`, `processAssetCode`, and `processSubcontractorCode`. Do not infer a field's business meaning from its legacy name: inspect its current title, lookup filter, and mapping.

Multiple associations are supported, for example an Observation can refer to a project, location, and asset simultaneously. Customer hierarchies can introduce Country or Region and require cascading selection; some form flows require the parent first. The walkthrough's Inspection followed a parent-to-child cascade. These are related behaviors: supporting multiple associations does not remove hierarchy constraints.

The [Configuration process](../../../processes/Data/configuration.json) edits responsibility records in [Process Responsible](../../../processes/Data/asset-responsible.json), keyed to the selected asset. Responsibility applies to that configured asset by default; inheritance requires onboarding configuration. Submitting a blank responsibility row clears that assignment. Module `lookupAssignees` and assignment rules consume these records to populate reviewers, administrators, and notification recipients. A new hierarchy level may need changes in all of these consumers, not just another dropdown.

## Reference and selection boundaries

An EHS Asset is overloaded reference data: hierarchy items, physical assets and subcontractors use types of the same `asset` process. Country on the standard Asset screen can be an independent system country list; a Country/Region/Division business hierarchy needs explicit parent references. Type + Code is the intended asset-import match, not a documented database uniqueness constraint.

Administration and its clearing/import/self-service behavior: [Projects & Assets](../pages/Assets.md). Location page mappings and URL context: [Location](../pages/my-project.md). Proposed customization: [Division recipe](../recipes/division.md).
