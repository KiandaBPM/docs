# Checklist runtime and scoring

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

The chain is:

1. [Checklist Type](../../../processes/Data/audit-type.json) (`audit-type`) holds checklist metadata, category, scales, template, and question ordering.
2. [Question](../../../processes/Data/question.json) (`question`) holds the question definition, answer options, scores, mandatory/visibility rules, help, and related-question behavior.
3. [Checklist Component](../../../processes/Data/checklist-component.json) (`checklist-component`) loads and renders questions within a host module.
4. The host module schedules question/action rules, sets its process status, generates its report, and sends its own notifications.

Inspection, Audit, standalone Checklist, Incident investigation, PTW Checks, and checklist slides in training reuse this capability. Incident's saved investigation component reference specifically selects the [without-actions variant](../../../processes/Data/checklist-component-without-actions.json), while the owner described it as the shared checklist mechanism. Inspect the host's `componentId` rather than assuming every consumer embeds the same variant. A checklist is also part of an induction quiz; it is not restricted to inspections.

The designer offers convenience choices such as Yes/No/N/A or OK/Not OK/N/A, plus Custom, Dropdown List, Section Header, EHS Asset List, Worker List, text, date, date/time, signature, and file upload. Only Custom and Dropdown List question types contribute configured answer scores, as confirmed by the owner. Convenience answer presets can be represented through custom configurations. Do not assume a universal two-choice Yes/No schema or one response field for every question.

Key runtime names include `INS_TABLE_Checklist?nostyleTable`, `INS_TXTSIN_QuestionID`, `INS_TXTSIN_QuestionResponseType`, `INS_TXTSIN_ChecklistOutputResponse`, `answerValue`, `customAnswerConfiguration`, `customAnswerOptions`, `relatedQuestionsConfiguration`, `isMandatory`, `visibility`, `auditType`, `checklistTitle`, `checklistCategory`, `totalScore`, `highScore`, `lowScore`, and `scaleStatus`. `INS_BTN_ChecklistLoad` loads records from Question, filtered by checklist name/title, ordered by question `order`; this title-based relationship matters when renaming checklists.

**Scoring boundaries, corrected and confirmed by the owner:**

| Result | Comparison |
| --- | --- |
| Pass | Total score ≥ PassScore / high score |
| At Risk | Fail Score / low score < Total score < PassScore / high score |
| Failed | Total score ≤ Fail Score / low score |

N/A commonly has score 0. Unanswered scored questions do not earn points and can lower the final result below the pass threshold; do not assume that unanswered questions are excluded from the scoring basis. A source rule titled `Remove question if unanswered` is not evidence that an unanswered scored question is ignored by the owner's scoring policy. Read its conditions and distinguish cleanup/output processing from scoring semantics.

Labels are configurable. Audit's initially saved Great/OK/Failed labels are replaced at runtime by the selected checklist labels. Designer fields `highScore`, `lowScore`, `greatStatusLabel`, `okStatusLabel`, and `failedStatusLabel` and runtime fields `greatStatus`, `okStatus`, `failedStatus` must remain aligned.

## Library versus execution records

Embedding this component does not create a separate standalone Checklist runner record. Metadata and questions remain library records; each host owns its captured answers and execution report. Authoring, question-choice catalogue, preview and import/export are in [Checklist library](../pages/checklist-data.md).

Exact threshold expressions used in the relationship notes: Pass `total >= PassScore`; At Risk `FailScore < total < PassScore`; Failed `total <= FailScore`.
