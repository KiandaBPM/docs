# Shared Actions and attachments

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

The [Actions component](../../../processes/Data/actions-component.json) collects an immediate-action explanation and repeatable follow-up actions. Its dialog supplies topic, action description, priority, due date, responsibility, and optional evidence/originator-closure settings. Hosts commonly collect rows first; server rules then create one separate [Action record](<../../../processes/QHSE - Modules/action.json>) per row on submission. A checklist question also has a question-associated action dialog and may create actions through configured question rules.

Frequently reused anchors include `INS_BTN_EditCLActionRules` (`_ACTION RULES`), `INS_TXTSIN_EditCLActionUrlID`, `actionProcessURLID`, and `Start Action Process`. Preserve the parent/source ID, source process/name, custom ID, question ID where applicable, workspace codes, responsible party, due date, and returned Action ID. Otherwise the Action can exist but lose its link to its source or its status feedback.

The host's confirmation/report email and an Action assignment email are separate events. Action emails are sent by the Action module during assignment, including anonymous external assignment. RA's own action interface is restricted to internal users even though the generic Action module supports external parties.

## Attachments

The [Attachments component](../../../processes/Data/attachments-component.json) provides optional multiple pictures/camera capture, previews, and additional file uploads. It is reused by most modules, commonly in a collapsible Summary panel. Some hosts already have their own picture fields and hide the component's picture input. Check host initialization rules before exposing a duplicate control.

## Shared component changes

The host JSON contains embedded component content as well as its reference/configuration. Do not assume editing a component source automatically updates every saved host export. Inspect the component's settings and the host's embedded fields, use the project's established component update/publish workflow, and review the affected host definitions. Preserve host-specific differences, such as RA's internal-only actions or a host hiding duplicate attachment pictures.

Embedded components use `fields/field-component`, with `componentId` and `componentLoaded` in host settings. Shared action-entry definitions are [action-dialog-component.json](../../../processes/Data/action-dialog-component.json) and [edit-action-dialog-component.json](../../../processes/Data/edit-action-dialog-component.json). Attachments remain parent form data; each upload does not imply a separate attachment business process. For generic component containment/loading, see [Kianda process authoring §8](../../kianda/process/model.md#reusable-components).
