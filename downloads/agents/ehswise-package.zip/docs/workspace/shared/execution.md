# EHSwise execution and output contracts

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

Many processes contain hidden Utility forms and rule buttons. A displayed Next button may only change the visible form. Save Draft usually saves data and keeps it editable. Submit may schedule a sequence of server-side rules rather than performing every action in the browser. Inspect the host's exact rule chain before modifying scheduling or status logic.

Common hidden controls include `OBS_BTN_LocalRules`, `OBS_BTN_SaveRules`, `OBS_BTN_ServerRules`, custom-ID buttons, `lookupAssignees`, and `GI_BTN_AssignRules`. Similar names across processes do not imply identical behavior. Examine enabled rules and mappings inside each host. `processCustomID` is a business identifier; `processURLID` and the process instance ID serve navigation and linking. Do not substitute them blindly.

Reports commonly use the Generate Word Document/document-generation rule and Word templates containing rich-text content controls tagged `kf:<field-name>`, often saved as PDF to a report field. A template is not just a page widget. Modify field references, template tags, conditional template selection, generated file destination, and notification attachments together when the requested change requires them. Template binaries may be stored as process file references rather than readable files in this repository.

A report saved on a record is not automatically attached to a notification. Submission can return before scheduled server work completes. See [Incident](../modules/incident.md#summary-submission-and-server-execution) for the recorded scheduling, branch and recipient example; [Kianda rule attachment/order](../../kianda/process/rules.md#identity-attachment-and-execution) and [mapping semantics](../../kianda/process/rules.md#mapping-and-dependency-semantics) cover platform mechanics.
