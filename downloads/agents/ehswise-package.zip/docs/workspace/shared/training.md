# Training records and certificate producers

Baseline: owner walkthrough and saved export inspected **27 October 2026**. Verify this contract and any saved settings against the current customer workspace before changing them.

[Worker](../../../processes/Training/worker.json) supports the Worker Training Card, identity/company/role, certificates and compliance. A red card indicates repeated safety offenses and typically mandatory training/induction with a formal record. Default create/import access is broad; onboarding usually applies security.

Certificates uploaded through the card are individual training records. The displayed date is expiry. Training/course choices are configured in EHS Admin lists; selected training populates Code, which the user can change. Reminder-day options are configurable and shared across training types.

[Certificate](../../../processes/Training/certificate.json) stores worker link/ID/email, training, certificate file/URL, expiry, reminders and notes. It schedules due/expired notifications. [Training Certificate page](../../../pages/Training/training-certificate.json) shows expiry-based compliance; the saved card reads `trainingStatus` and uses ember-moment helpers to render expiry dates. Trace Certificate/Worker calculation and reminder rules to change the status semantics. Do not conflate a rendered date-based badge with a separately persisted process status. By default the certificate page is visible to all users; customer security may narrow it.

Related lookups/import: [Training Course](../../../processes/Data/training-course.json), [Worker Role](../../../processes/Data/worker-role.json), [Worker Import](../../../processes/Data/worker-import.json). Event Training and Induction can create Certificate records programmatically, so changes to required certificate inputs must cover both producers and manual upload.

One Worker can have multiple Certificates. Worker records can exist without authenticated user accounts. Training Events create certificates only for eligible Worker-linked participant rows; induction completion creates a learner-linked certificate and emails that worker. Free-text Other participants are not automatically Worker records. Inspect [Event](../modules/event.md), [Induction](../modules/induction.md), and [Certificate rendering](../pages/training-certificate.md) only for the producer or consumer being changed.
