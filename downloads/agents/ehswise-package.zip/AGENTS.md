# Working in an EHSwise workspace

This is an exported Kianda application: process/page JSON, custom JavaScript/Handlebars components, and shared CSS/JS. Work on the requested customer workspace; do not scaffold a separate application. Resolve paths below from the workspace root.

## Read by task

Inspect the affected source and choose the relevant row. Read a guide's short entry map, then only the topics needed for the change. Reuse material already read in this task. Expand to dependencies when evidence requires it; do not preload every guide, module, page, schema or skill.

| Task | Entry points |
| --- | --- |
| Process implementation, repair or validation | `kianda-process-builder`; [process contracts](docs/kianda/process-knowledge.md); affected entry in [EHSwise modules](docs/workspace/modules.md). |
| Process journey, branching, forms or experience design | `kianda-process-designer`; [design method](docs/kianda/process-design-knowledge.md). |
| Page, widget, query, filter or navigation | [Page contracts](docs/kianda/page-knowledge.md); affected [EHSwise page](docs/workspace/pages.md); supplying processes. |
| Custom field, rule or page addon | [Addon contracts](docs/kianda/custom-addon-knowledge.md) and installed component; process/page contract where embedded. |
| Styling or responsive layout | [CSS guide](docs/kianda/css-style-guide.md), `styles/app.css`, and affected template/configuration. |
| Cross-module relationships | Relevant [data-model](docs/workspace/data-model.md) section and linked sources. |
| Unfamiliar platform/product concept | Needed section of [Kianda general](docs/kianda/general.md) or [EHSwise general](docs/workspace/general.md). |
| Documentation/instruction edit | Affected documents and callers; use application-building workflows only if application behavior also changes. |

Use the full [process](docs/kianda/process-schema.json) and [page](docs/kianda/page-schema.json) schemas in validators. For authoring, inspect applicable definitions and referenced dependencies. Process **1.1.0** is owner-adopted; page **1.0.0** is draft. Preserve schema identities. Structural acceptance does not establish runtime correctness or publication.

## Locate the source

- Pages: `pages/`; addons: `components/fields/`, `components/rules/`, `components/widgets/`.
- Main modules: `processes/QHSE - Modules/`; shared Components/reference data: `processes/Data/`.
- Workers/training: `processes/Training/`; chemicals: `processes/COSHH/`; documents: `processes/Policies/`; environment: `processes/QHSE - Environment/`.
- Shared behavior: `js/app.js`; styles: `styles/app.css`; workspace binding/artifact map: `.kianda/workspace.json`.

Product guides describe the shared baseline, including limited walkthroughs and historical observations. Verify customer identities, dependencies and reported defects against current files. Hosted templates, language data and runtime services may have no local copy. Preserve workspace binding and keep credential values out of documentation/output.

## Change rules

- Preserve unrelated edits, stable IDs/names, wire types, omissions, unknown settings, security and ordered arrays. Keep small edits localized.
- Prefer native rules. Start calculations with Set form field expressions and suitable `js/app.js` helpers; identify an unmet requirement before introducing custom infrastructure. Do not migrate working code incidentally.
- Trace affected nested fields/tables/Components, rules, expressions, mappings, pages, reports and code. Inspect shared definitions and host configurations before assuming propagation.
- Distinguish authenticated users, Worker records, contacts, originators and business owners. Rate formulas and signature/approval requirements are customer policy. UI visibility, hidden fields and URL filters do not enforce authorization.
- For material process-journey changes, the builder coordinates the designer and reuses an adequate blueprint. Targeted technical fixes need focused regression checks. Design-only work changes design documentation only; review-only work stays read-only. Avoid recursive skill invocation and added approval pauses in an authorized build.
- Check actual extension save/sync/publish behavior. Execute business actions, publish, migrate or delete only within existing authorization. Continue independent work when uncertainty blocks one part.

## Verify and document

Check changed JSON, applicable schema assertions and affected references. Verify runtime/visual behavior where the environment and task permit; account for asynchronous work and offline caches. Separate baseline failures from new ones. Never invent a validator command or equate source inspection with a live test.

For each substantive task, add one concise **Unreleased** entry in [CHANGELOG.md](CHANGELOG.md): purpose/result, affected paths, checks/outcomes, limitations, and required configuration/migration/publishing steps. Update relevant workspace docs when confirmed behavior changes; distinguish customer customization from the shared baseline.

Finish with changed behavior/files, the change entry, evidence and outstanding work. State local edits, static checks, runtime checks and publication separately.
