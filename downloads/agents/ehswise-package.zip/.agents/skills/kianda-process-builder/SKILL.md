---
name: kianda-process-builder
description: Create, modify, repair or validate Kianda process JSON in exported workspaces. Use for forms, fields, rules and process behavior; coordinate kianda-process-designer when the user journey changes. Exclude design-only, page-only and standalone addon tasks.
---

# Kianda Process Builder

Implement the authorized process change and report actual verification. This remains a draft workflow. Follow workspace `AGENTS.md`; resolve paths from the workspace root, including configured equivalents.

## 1. Scope and targeted reading

Inspect the affected process, requirements/blueprint and current diff. Review/validation requests authorize inspection/reporting only. Change definitions rather than runtime records. Localize small edits while leaving complete process files; if explicitly returning inline JSON, provide the complete requested definition with diagnostics separate.

Use `docs/kianda/process-knowledge.md` as the contract map. Read relevant topics and schema definitions; use complete `docs/kianda/process-schema.json` programmatically for validation. Consult `docs/kianda/general.md` for unresolved platform boundaries. Load CSS, addon, global JS, page and EHSwise module references only for affected dependencies.

Establish available validators/runtime access and actual extension save/sync/publish behavior. Do not invent tools, commands or missing contracts, or scaffold an unrelated application. Deliver supported work and identify any blocked part.

## 2. Right-size design

| Request | Treatment |
| --- | --- |
| New process; changed stages, forms, branches, navigation, ownership or completion | Apply `kianda-process-designer` before implementation. |
| Adequate existing blueprint | Verify against current source and reuse. |
| Small experience/layout change | Record a compact design delta and affected-state checks. |
| Syntax/reference repair with unchanged experience | Preserve design; use focused regression checks. |

Designer entry: `.agents/skills/kianda-process-designer/SKILL.md`. Apply it sequentially in this task if no invocation mechanism exists. If unavailable, use `docs/kianda/process-design-knowledge.md`, `docs/kianda/process/design-blueprint.md` and the applicable cases in `docs/kianda/process/design-review.md`; report the fallback. The builder coordinates; the designer returns without invoking the builder. Do not add approval checkpoints to an authorized build.

## 3. Trace behavior

Map material requirements and tests to real forms, fields, rules/settings and verified dependencies. Inspect all writers to affected visibility, requiredness, values, completion and navigation, including initialization, re-entry and programmatic changes. Shared targets need a coherent effective predicate; independent show/hide writers can conflict.

Resolve descriptors by entity kind and process/row/parent scope. Follow affected expressions, mappings, tokens, custom code, page bindings and selectors; arbitrary settings are not entity collections. Explain necessary design changes. Distinguish unavailable dependencies, unknown contracts and invalid configuration. Report unrelated defects without expanding scope.

## 4. Implement contracts

- Prefer native `rules/rule-setfield` expressions for calculated values. Use a short local expression or suitable `js/app.js` helper with explicit inputs and returned value/Promise. Verify result types, triggers, availability and failure behavior. JavaScript complexity or asynchronous work alone does not justify a custom service/rule; preserve working implementations during unrelated edits.
- Preserve aliases, IDs, scoped names, ordering, security, unknown settings and wire representations. Allocate documented identities for new/cloned entities and rewrite their references only. New process `id`/`name` aliases agree when both emitted; preserve accepted historical omissions on unrelated edits.
- Check recursive table-row name scopes and actual Component loading/version behavior. Distinguish group GUID requirements from individual conditions and arbitrary tenant settings. Do not flatten rows, treat descriptors as children, or replace expanded Component trees blindly.
- Use `field.class` for layout and `field.customCssClass` for extra styling. Preserve Yes/No versus boolean, numeric strings and meaningful omissions. Keep type-specific settings in their contract.
- Preserve rule attachment/order and the false default of omitted `hasElse`. Alternative settings belong to the same action; retained inactive targets are not executed references to repair.
- Keep example principals, URLs, audit metadata, business values and blueprint-only concepts out of runtime configuration. Change related pages/components/global code only when necessary and authorized.

## 5. Lifecycle and data policy

Separate effective applicability from visibility, validation, completion, reporting and authorization. Preserve or explicitly change branch-reversal treatment for direct/derived values, evidence and related actions. Hidden forms and retained answers do not establish completion/applicability.

Make presentation recalculation repeatable across load, changes, reversal, reopening and direct navigation; separate consequential effects. Gate dependent actions on explicit success: a custom rule throwing/rejecting does not establish that later Save/Submit/notification/navigation stops. Verify native actions separately.

Use real authorized principals. Preserve security; provide an administrator handoff for required configuration that cannot be authored. Exercise side-effecting runtime scenarios only in the authorized target/test setup.

## 6. Verify and finish

Inspect existing tools before running them. Do not change schemas, coerce/default/remove data, or add frameworks merely to pass validation.

| Layer | Check |
| --- | --- |
| Parse/schema | Syntax, duplicate keys where supported, correct dialect, formats and applicable settings. |
| Semantics | Scoped identities, owners, references, mappings, active targets, dependencies and expressions. |
| Design | Blueprint, effective predicates, inverse transitions, data policy, completion and navigation. |
| Runtime/visual | Relevant load/change/reopen/failure, access, responsive and keyboard scenarios actually exercised. |

Select applicable cases from `docs/kianda/process/design-review.md`, especially overlaps, blank decisions, populated reversals and existing records; keep isolated fixes focused. Check changed files and necessary dependants; distinguish new failures, baseline defects and coverage gaps. Preserve unknown tenant settings.

Review the diff. Update blueprint/delta, relevant docs and `CHANGELOG.md` under workspace policy. Report behavior, paths, commands/tools/targets and outcomes, unresolved assumptions, administrator/migration steps and publication status. Identify unavailable checks explicitly. File writing, static reasoning and schema acceptance are separate from runtime, security, accessibility and publication evidence.
