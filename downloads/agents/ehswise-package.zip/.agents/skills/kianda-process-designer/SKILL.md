---
name: kianda-process-designer
description: Design or review Kianda process journeys, stage/form/section boundaries, adaptive branching, navigation, conditional validation and visual composition. Produce a blueprint or focused design delta with acceptance scenarios, including the design phase of an authorized build. Exclude isolated technical repairs and process JSON implementation.
---

# Kianda Process Designer

Design how participants complete the process: stages, forms, decisions, actions, feedback and visual composition. This remains a draft workflow. Follow the task and workspace `AGENTS.md`; resolve paths from the actual workspace root or configured equivalents.

## 1. Mode and evidence

Review-only: inspect/report without writing files unless a report is requested. Design-only: write requested design documentation and applicable change record; do not edit application JSON, components, global CSS/JS or runtime records. During an authorized build, return the design to its coordinating builder.

Inspect relevant requirements, blueprint and affected process structures. Use `docs/kianda/process-design-knowledge.md` as the task map; open only the design topics needed. Use the blueprint for substantial journeys and acceptance cases for affected states. Resolve technical questions through selected `docs/kianda/process-knowledge.md` topics/schema definitions. Load CSS, addon, general-platform, EHSwise and page references only when the design depends on them.

Use current files for identities/dependencies. Distinguish historical examples, source behavior, business policy and confirmed platform mechanisms. Record missing evidence: conceptual work may proceed with explicit assumptions, but an unverified capability is not implementation-ready.

## 2. Outcome and architecture

Identify participants, starting information, decisions, evidence, completion and reporting needs. Inspect affected forms, control fields and all state-writing rules; preserve out-of-scope behavior and existing-record paths. Cite requirement sections, aliases and JSON Pointers where useful.

Separate business stages from forms. Choose forms, sections, dialogs, repeating tables, reusable Components and related records by task coherence, volume, timing, ownership and lifecycle. A stage need not equal a form; a separate form need not require another participant. Prefer inline conditional sections for small extensions of the same task. Keep utility structures outside the intended user journey.

Prefer verified native capabilities and existing patterns. Reuse settled requirements/adequate blueprints. State reversible assumptions; continue independent work when a consequential business/security decision blocks one part.

## 3. Adaptive behavior and calculations

For each decision, specify allowed answers, exclusive/overlapping choice, blank/unknown state, dependencies and effects. Include parent applicability so retained child values cannot activate an irrelevant branch.

Specify applicability, visibility, editability, requiredness, completion, authorization and data treatment separately. These are design concepts, not new JSON keys. Use decision tables for overlapping branches/shared targets. Define one effective predicate per target; account for all writers, selection order, deselection and re-entry.

Cover initial entry, direct navigation, user/programmatic changes and reopening. Make presentation recalculation repeatable and separate from side effects. A field-change rule alone does not establish initialization.

For derived values, define inputs/output, trigger, missing/invalid inputs, overrides, recalculation, pending and failure states. Prefer native rules/expressions; identify a concrete gap before prescribing custom code or a service. Leave serialization/helper implementation to the builder while recording execution/security constraints.

## 4. Data, actions and navigation

Specify what happens to populated answers, evidence, derived values, related records and completed work when decisions reverse: preserve, clear, confirm or restrict/review reclassification. Preserve existing policy during unrelated changes.

Define next/previous destinations, direct access and recovery when the current form becomes irrelevant. Distinguish validation for drafts, progression, submission and final completion; make corrections reachable. Define action success conditions. A rejected rule does not establish that later actions stop. Map permissions separately from presentation and identify administrator setup rather than inventing principals.

## 5. Visual composition

Describe each important form's purpose, guidance, section order, choices, repeating content, evidence, feedback and actions. Cover relevant initial, conditional, populated, error and read-only states.

Use supported controls and workspace CSS utilities: hierarchy, spacing, responsive grouping and consistent typography. Material Design principles do not establish that a Material component library is installed. Account for narrow screens, long labels, keyboard order, focus and revealed content. Prefer scoped changes; preserve data/security semantics.

A composition/wireframe is design evidence. Claim runtime, visual or accessibility verification only for actual inspected scenarios.

## 6. Proportionate handoff

For substantial journeys, use `docs/kianda/process/design-blueprint.md`: outcome/scope, requirements, stage/form structure, decisions/states, data policy, actions/navigation, composition, security/reporting, implementation mapping, tests and readiness. Use an existing specification location; otherwise use `specs/process-designs/<process-alias>.md` when file output is authorized.

For small changes, record target, before/after behavior, predicate/layout choice, data/security impact, implementation evidence and acceptance checks. A review needs findings/proposed remedies; avoid unnecessary documents.

Use relevant cases from `docs/kianda/process/design-review.md`, including reversals, overlaps, saved-record re-entry, failures and existing-record compatibility. Separate static reasoning from runtime evidence, and approval from technical readiness. Record confirmed mechanisms, reusable dependencies, unresolved contracts and blockers.

When coordinated by `kianda-process-builder`, return the blueprint/delta to that workflow. Do not invoke the builder or spawn an agent merely to select a skill. Continue an authorized build without adding a design approval checkpoint. Independently, stop at the requested design/review scope.

Follow workspace change-record policy for substantive authorized documentation changes. Report decisions, artifact path if written, readiness, assumptions/blockers and checks, allowing implementation to resume without repeating discovery.
