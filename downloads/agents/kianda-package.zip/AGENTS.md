# Working with Kianda documentation and workspaces

This checkout maps to **KiandaBPM/agent-docs**, the base agent documentation for building and modifying Kianda low-code applications.

This package can be installed into an application workspace containing process/page definitions, custom components, JavaScript, CSS and workspace metadata. Inspect the actual target workspace before assuming these resources exist.

## Product knowledge map

The four documents below are intentional placeholders in the base package. They establish a common structure for application knowledge. Product documentation sets populate them with confirmed requirements, walkthrough findings and source evidence. Empty sections do not establish application behaviour or completed review coverage.

1. Read [general.md](./docs/workspace/general.md) for product purpose, personas, terminology, architecture, security, offline behavior, localization, and modification planning.
2. Read the relevant section of [modules.md](./docs/workspace/modules.md) for form/workflow behavior, field and rule contracts, reusable components, notifications, and module modification guidance.
3. Read [pages.md](./docs/workspace/pages.md) for operational/admin page behavior, navigation, filtering, reporting queries, widget dependencies, and known reporting defects.
4. Consult the [application data model](./docs/workspace/data-model.md) for relationships between modules, supporting processes, embedded components, and pages.
5. Before modifying an application, read its populated product guidance and exact current source files. Where documentation is incomplete, inspect available source and record material unknowns. Do not infer application behaviour from placeholder headings.

### Documentation structure

Keep application documentation modular. Create a separate document for each module, application page or substantial functional area. Use the existing documentation layout; where none exists, place detailed documents in topic subfolders, such as `docs/workspace/modules/<module-alias>.md`, `docs/workspace/pages/<page-alias>.md` and `docs/workspace/<area>.md`. If the content warrants it create multiple documents inside of `docs/workspace/<area>/<doc>.md` and make `docs/workspace/<area>.md` an index. Create documents when there is content to record; small subjects may remain together until separate documents improve navigation and maintenance.

Keep the general, module, page and data-model guides concise. They should explain the overall structure and link to detailed documents rather than accumulate all application knowledge in one file. Keep detailed field/rule explanations with their module, widget/query explanations with their page, and cross-application relationships in the data model.

Split cross-cutting topics, such as security or integrations, into dedicated documents when their detail warrants it. Link to shared explanations and platform contracts instead of duplicating them. Use relative links and update affected indexes and references whenever documents are added, moved or renamed.

Populate relevant sections progressively from agreed requirements, current source and observed behaviour. Label proposed behaviour separately from implemented configuration and attach evidence to the relevant claims. Record material unknowns explicitly; omit or mark genuinely irrelevant sections rather than inventing content to complete a template. Substantive application changes must update the affected guide entries, detailed documents and relationship maps.

### Kianda platform knowledge map

Start with the platform [general.md](./docs/kianda/general.md) for the Kianda application model, runtime boundaries, workspace resources, and authoring workflow. Use the relevant platform contracts alongside populated product guides and the actual source available in the target application workspace:

| Work | Platform references |
| --- | --- |
| Processes, forms, recursive fields, rules, mappings, or reusable Component processes | [process-knowledge.md](./docs/kianda/process-knowledge.md) and [process-schema.json](./docs/kianda/process-schema.json). |
| Pages, widgets, queries, filters, navigation, or custom list-column templates | [page-knowledge.md](./docs/kianda/page-knowledge.md) and [page-schema.json](./docs/kianda/page-schema.json), together with the supplying processes. |
| Custom JavaScript/Handlebars field, rule, or page widgets and their settings contracts | [custom-addon-knowledge.md](./docs/kianda/custom-addon-knowledge.md), the installed component source, and the applicable process/page references above. |
| Layout, branding, CSS classes, styling, or responsive behaviour | [css-style-guide.md](./docs/kianda/css-style-guide.md) and the effective workspace stylesheet. |
| Select existing datasource connections/resources or configure their consumers | [query-configurator](./.agents/skills/query-configurator/SKILL.md), [datasource metadata](./docs/kianda/datasource-metadata.md) and the consumer's process/page contract. |
| Application personas/roles for processes, pages or email | [group-configurator](./.agents/skills/group-configurator/SKILL.md), the application role design and the affected security/audience contract. |

The process package is the owner-adopted **1.1.0** baseline; the page package is **draft 1.0.0**. Preserve those status distinctions. Schemas describe structural contracts; passing a schema check does not establish correct permissions, complete dependency resolution, runtime behaviour, or publication. Preserve their versioned schema identities when changing local filenames. Do not invent platform behaviour from a product example.

## Application source map

These are typical locations in an exported application workspace. Discover the actual layout recursively; product documentation may provide more specific mappings. Missing directories do not require creation merely to match this table.

| Change area | Typical sources, when present |
| --- | --- |
| Navigation, dashboards, widgets and filters | `pages/**/*.json` and `components/widgets/`. |
| Processes, forms, workflow and reusable Components | `processes/**/*.json`. |
| Custom fields | `components/fields/`. |
| Custom rules | `components/rules/`. |
| Shared client helpers and startup behaviour | `js/app.js`. |
| Styling and branding | `styles/app.css` and affected templates. |

## How to make a coherent modification

- Identify whether the request changes a stored option/value, a label, a process definition, an instance, a page query, an embedded component, a custom extension, or security. These are different contracts.
- Search for both the technical field/option name and its displayed text. Inspect process-level rules, form rules, and recursively nested field/component/table rules, including hidden controls and utility forms.
- Preserve unrelated existing changes. Do not reformat or regenerate whole JSON definitions for a small edit.
- Preserve stable IDs/names and referenced widget targets unless the change requires migration. Cloned objects need appropriate unique identities and corrected references.
- Trace linked records and outputs: parent/child mappings, custom IDs, report template tags, generated files, scheduled server jobs, recipients, and summary fields used by reports.
- For shared components, inspect both the shared definition and the host's loaded nested component configuration. Confirm the workspace's update/propagation mechanism before changing all hosts.
- For navigation/filter changes, inspect URL parameters, value/display fields, tab titles, per-widget connection IDs/conditions, card templates, carousel content, and guided-tour selectors.
- For hierarchy changes, trace the application's type and parent fields, reusable hierarchy components, mappings, responsibilities, dependent filters, security and reporting.
- For access changes, configure process/record security as well as UI visibility. `link.users`, `visibleTo`, a hidden field, or a selected URL parameter is not a replacement for authorization.
- Preserve distinctions between authenticated users, business records representing people or organisations, external contacts, record originators, reporters and task owners when mapping identities or notifications.
- Treat rate formulas and approval/signature requirements as customer-specific. Do not impose a formula or mandatory signature based only on a label or visible control.
- Consult the page guide's known defects before copying a report. A historical bug is not an intended configuration pattern; verify whether the current source has already corrected it.

## Native-first Kianda implementation

Prefer supported Kianda configuration and native rules over custom development. For calculated field values, first consider Set form field expressions, then reusable global helpers in js/app.js.

Follow the detailed logic-selection guidance in docs/kianda/process-knowledge.md. Before adding a custom rule, component, endpoint, or service, identify the requirement the native approach cannot adequately satisfy.

## Kianda process design and implementation

Use `docs/kianda/process-design-knowledge.md` for process experience design.
Keep `process-knowledge.md`, `process-schema.json` and `css-style-guide.md` as the technical and styling references under `docs/kianda/`.

For design-only or experience-review requests, use `kianda-process-designer`.
Do not modify application JSON, components, CSS/JavaScript or runtime records as part of a design-only request.

For process creation, implementation, repair or validation, use `kianda-process-builder`. Before implementing a new or materially changed user journey, apply `kianda-process-designer` and produce or update the appropriate blueprint. Reuse an adequate existing blueprint. Do not require a full redesign for an isolated technical fix.

The builder coordinates the workflow; the designer returns the design and must not invoke the builder recursively. Continue through an authorized end-to-end build without an unnecessary approval pause. Keep consequential unresolved requirements as explicit blockers for the affected scope.

Follow the existing specification and CHANGELOG.md conventions. Report file changes, structural validation, runtime testing and publication as separate outcomes. Never infer access control from UI visibility.

For application roles, design personas, responsibilities and intended permissions first, and use `group-configurator` whenever a process, page or email requires a specific role. Document role-to-group mappings and intended grants in the application specifications. Discover/reuse groups during design; create missing groups only after a detailed design exists and authorized implementation has begun. Creation takes effect immediately without Publish; group membership remains an administrator task. Verified group bindings now replace the earlier page-authoring policy of leaving all new principal restrictions unconfigured; this does not replace process/record security or access testing.

Use `query-configurator` for existing configured datasource discovery and consumer configuration. For Kianda Data, the designer/builder may directly use current local process JSON, including uncommitted or not-yet-published related processes/fields, without invoking the skill or bridge. Reconcile any builder changes still pending a file write before final validation, and record publication dependencies rather than claiming those fields are already live. Shared bridge setup and operation boundaries are in [agent-bridge.md](./docs/kianda/agent-bridge.md).

## Checks and completion

- Validate edited JSON syntax and the affected field/widget/rule references. Review the diff for unintended identity, security, metadata, or formatting changes.
- Verify the requested behavior at the appropriate scope. Browser submission and workflow controls can create records, send emails, delete data, or schedule server jobs; choose verification consistent with the user's authorization.
- Keep runtime assumptions explicit. Server-generated IDs, reports, emails and background processing may be asynchronous. Cached process definitions or lookup data can require offline refresh.
- Update the relevant product guide and relationship diagram if a confirmed behavior or dependency changes. Distinguish current configuration, customer customization, roadmap, and unresolved/source-only details.
- Summarize the changed behavior, affected sources, checks performed, and material limits. Do not claim a deployment, runtime check, or generated output that did not occur.

## Scope and local metadata

Application coverage is established by the populated product guides and their recorded evidence. The base placeholders make no claim that particular modules, pages, reports or workflows have been reviewed. Distinguish confirmed requirements, inspected configuration, observed runtime behaviour and unresolved questions.

When present in an application workspace, local `.kianda/workspace.json` binds the workspace to its tenant and maps source artifacts. Preserve those bindings and keep keys or credential values out of documentation and task output. Hosted files, report templates, runtime language data and platform services may have no local copies.

## Completion and change documentation

For every substantive workspace change:

1. Add or update an entry under Unreleased in [CHANGELOG.md](./CHANGELOG.md).
2. Explain the requirement or problem and the resulting behaviour.
3. Identify the affected processes, pages, components and important paths.
4. Record the validation actually performed and its outcome.
5. State checks that were not performed and any remaining limitations.
6. Document required configuration, migration or publishing steps.
7. Update current workspace documentation when behaviour, architecture,
   component settings or operating procedures change.

Use one entry per coherent task. Keep entries concise and factual.

Distinguish local implementation, static validation, runtime verification
and publication. Only report a stage as completed when there is evidence.

When finishing, identify the change entry and any outstanding work.
