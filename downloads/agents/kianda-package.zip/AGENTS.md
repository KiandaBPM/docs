# Working in the Kianda workspace

This repository contains a Kianda workspace: declarative page/process definitions plus custom JavaScript, Handlebars, and CSS extensions. Use the product documentation below to understand intent before modifying configuration.

## Product knowledge map

1. Read [general.md](./docs/workspace/general.md) for product purpose, personas, terminology, architecture, security, offline behavior, localization, and modification planning.
2. Read the relevant section of [modules.md](./docs/workspace/modules.md) for form/workflow behavior, field and rule contracts, reusable components, notifications, and module modification guidance.
3. Read [pages.md](./docs/workspace/pages.md) for operational/admin page behavior, navigation, filtering, reporting queries, widget dependencies, and known reporting defects.
4. Consult the [application data model](./docs/workspace/data-model.md) for relationships between modules, supporting processes, embedded components, and pages.
5. Read the exact current source files before implementing. These documents describe the walkthrough and inspected configuration, not every future customer variation.

### Kianda platform knowledge map

Start with the platform [general.md](./docs/kianda/general.md) for the Kianda application model, runtime boundaries, workspace resources, and authoring workflow. Use the relevant platform contracts alongside the workspace product guides and the actual workspace source:

| Work | Platform references |
| --- | --- |
| Processes, forms, recursive fields, rules, mappings, or reusable Component processes | [process-knowledge.md](./docs/kianda/process-knowledge.md) and [process-schema.json](./docs/kianda/process-schema.json). |
| Pages, widgets, queries, filters, navigation, or custom list-column templates | [page-knowledge.md](./docs/kianda/page-knowledge.md) and [page-schema.json](./docs/kianda/page-schema.json), together with the supplying processes. |
| Custom JavaScript/Handlebars field, rule, or page widgets and their settings contracts | [custom-addon-knowledge.md](./docs/kianda/custom-addon-knowledge.md), the installed component source, and the applicable process/page references above. |
| Layout, branding, CSS classes, styling, or responsive behaviour | [css-style-guide.md](./docs/kianda/css-style-guide.md) and the effective workspace stylesheet. |

The process package is the owner-adopted **1.1.0** baseline; the page package is **draft 1.0.0**. Preserve those status distinctions. Schemas describe structural contracts; passing a schema check does not establish correct permissions, complete dependency resolution, runtime behaviour, or publication. Preserve their versioned schema identities when changing local filenames. Do not invent platform behaviour from a product example.

## Source map

| Change area | Sources to inspect |
| --- | --- |
| Navigation, widgets, filters, operational dashboards | [pages/](./pages/) and [custom widgets](./components/widgets/). |
| Main form/workflow modules | [processes/QHSE - Modules/](<./processes/QHSE - Modules/>). |
| Reusable form components, reference data, configuration/import utilities | [processes/Data/](./processes/Data/). |
| Workers, certificates, induction runtime | [processes/Training/](./processes/Training/) and [custom fields](./components/fields/). |
| Chemical materials | [processes/COSHH/](./processes/COSHH/). |
| Document control | [processes/Policies/](./processes/Policies/). |
| Environmental modules | [processes/QHSE - Environment/](<./processes/QHSE - Environment/>). |
| Shared client startup/offline/translation behavior | [js/app.js](./js/app.js). |
| Styling/branding | [styles/app.css](./styles/app.css) and affected page HTML/templates. |
| Custom rules | [components/rules/](./components/rules/). |

## How to make a coherent modification

- Identify whether the request changes a stored option/value, a label, a process definition, an instance, a page query, an embedded component, a custom extension, or security. These are different contracts.
- Search for both the technical field/option name and its displayed text. Inspect process-level rules, form rules, and recursively nested field/component/table rules, including hidden controls and utility forms.
- Preserve unrelated existing changes. Do not reformat or regenerate whole JSON definitions for a small edit.
- Preserve stable IDs/names and referenced widget targets unless the change requires migration. Cloned objects need appropriate unique identities and corrected references.
- Trace linked records and outputs: parent/child mappings, custom IDs, report template tags, generated files, scheduled server jobs, recipients, and summary fields used by reports.
- For shared components, inspect both the shared definition and the host's loaded nested component configuration. Confirm the workspace's update/propagation mechanism before changing all hosts.
- For navigation/filter changes, inspect URL parameters, value/display fields, tab titles, per-widget connection IDs/conditions, card templates, carousel content, and guided-tour selectors.
- For hierarchy changes, trace Asset Type and parent fields, the Workspaces component, module mappings, responsibility configuration, cascade filters, security, and Analytics.
- For access changes, configure process/record security as well as UI visibility. `link.users`, `visibleTo`, a hidden field, or a selected URL parameter is not a replacement for authorization.
- Preserve the distinction between authenticated users, Worker records, subcontractor contacts, record originators, reported-by people, and action/permit owners when mapping identities or notifications.
- Treat rate formulas and approval/signature requirements as customer-specific. Do not impose a formula or mandatory signature based only on a label or visible control.
- Consult the page guide's known defects before copying a report. A historical bug is not an intended configuration pattern; verify whether the current source has already corrected it.

## Native-first Kianda implementation

Prefer supported Kianda configuration and native rules over custom development. For calculated field values, first consider Set form field expressions, then reusable global helpers in js/app.js.

Follow the detailed logic-selection guidance in docs/kianda/process-knowledge.md. Before adding a custom rule, component, endpoint, or service, identify the requirement the native approach cannot adequately satisfy.

## Kianda process design and implementation

Use `docs/kianda/process-design-knowledge.md` for process experience design.
Keep `process-knowledge.md`, `process-schema.json` and `css-style-guide.md` as the technical and styling references under `docs/kianda/`.

For design-only or experience-review requests, use `kianda-process-designer`.
Do not modify application JSON, components, CSS/JavaScript or runtime records as part of a design-only request.

For process creation, implementation, repair or validation, use `kianda-process-builder`. Before implementing a new or materially changed user journey, apply `kianda-process-designer` and produce or update the appropriate blueprint. Reuse an adequate existing blueprint. Do not require a full redesign for an isolated technical fix.

The builder coordinates the workflow; the designer returns the design and must not invoke the builder recursively. Continue through an authorized end-to-end build without an unnecessary approval pause. Keep consequential unresolved requirements as explicit blockers for the affected scope.

Follow the existing specification and CHANGELOG.md conventions. Report file changes, structural validation, runtime testing and publication as separate outcomes. Never infer access control from UI visibility.

## Checks and completion

- Validate edited JSON syntax and the affected field/widget/rule references. Review the diff for unintended identity, security, metadata, or formatting changes.
- Verify the requested behavior at the appropriate scope. Browser submission and workflow controls can create records, send emails, delete data, or schedule server jobs; choose verification consistent with the user's authorization.
- Keep runtime assumptions explicit. Server-generated IDs/reports/emails and Worked Hours processing may be asynchronous. Cached process definitions or lookup data can require offline refresh.
- Update the relevant product guide and relationship diagram if a confirmed behavior or dependency changes. Distinguish current configuration, customer customization, roadmap, and unresolved/source-only details.
- Summarize the changed behavior, affected sources, checks performed, and material limits. Do not claim a deployment, runtime check, or generated output that did not occur.

## Scope and local metadata

The detailed walkthrough covers the main modules through Risk Assessment, operational/admin pages, and 12 Analytics reports. Worked Hours, NCR, and Hazard have narrower walkthrough coverage; other catalog entries are explicitly marked in the module guide. Read source and resolve material unknowns when a later task needs more detail.

Local [.kianda/workspace.json](./.kianda/workspace.json) binds this checkout to a workspace and maps source artifacts. Preserve its tenant/workspace binding and keep its keys or credential values out of documentation and task output. Hosted files, report templates, runtime language data, and the platform runtime may not have local copies.

## Completion and change documentation

For every substantive workspace change:

1. Add or update an entry under Unreleased in [CHANGELOG.md](./CHANGELOG.md).
2. Explain the requirement or problem and the resulting behaviour.
3. Identify the affected processes, pages, components and important paths.
4. Record the validation actually performed and its outcome.
5. State checks that were not performed and any remaining limitations.
6. Document required configuration, migration or publishing steps.
7. Update current workspace documentation when behaviour, architecture,
   component settings or operating procedures change.

Use one entry per coherent task. Keep entries concise and factual.

Distinguish local implementation, static validation, runtime verification
and publication. Only report a stage as completed when there is evidence.

When finishing, identify the change entry and any outstanding work.
