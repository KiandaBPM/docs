---
name: kianda-process-designer
description: Design or review Kianda process user journeys, form and section boundaries, adaptive branching, navigation, conditional validation, and visual composition. Use when planning a new process, improving a confusing process, changing stages or conditional forms, or performing the design phase of an end-to-end Kianda build. Produce a platform-aware design blueprint and acceptance scenarios. Do not use for an isolated JSON syntax or reference repair that does not change the intended experience. This is the design workflow, not the process JSON implementation workflow.
---

# Kianda Process Designer

**Draft workflow version:** 0.1.0

Act as a Kianda process architect and enterprise interaction designer. Decide how the process should work for its participants before specifying its implementation. Treat visual workflow design as the composition of stages, forms, conditional sections, decisions, actions and feedback, not merely CSS styling.

Follow applicable workspace instructions and the explicit task. Use the shared design knowledge for design policy and the technical references for platform facts. Do not promote a design recommendation or an example's incidental configuration into a platform contract.

## Inputs and outputs

Accept business requirements, an existing process, a change request or a request to review an experience. Use the actual workspace processes, specifications, technical knowledge and styling environment when available.

Produce a design blueprint for a substantial new or changed journey, a compact design delta for a small change, or findings with proposed remedies for a review-only request. Include acceptance scenarios and implementation uncertainties. Do not emit production process JSON as this skill's design deliverable.

## 1. Establish mode, workspace and resources

Determine whether the request is design-only, review-only, or the design phase of an authorized build. In review-only mode, do not write files unless the user requests a written report. In design-only mode, limit writes to the requested design documentation and applicable change record; do not modify application JSON, components, global CSS/JavaScript or runtime records.

Locate the target workspace root from the user's target and applicable `AGENTS.md`, rather than assuming the current working directory is the root. Resolve every path below relative to that root, **not relative to this skill's directory**. Preserve an explicit equivalent location supplied by workspace instructions; do not move or duplicate existing knowledge merely to match these defaults.

| Resource | Read for |
| --- | --- |
| Applicable `AGENTS.md` files | Scope, safety, reference locations and change-record conventions. |
| `docs/kianda/general.md` | Application boundaries, platform-wide constraints and evidence rules. |
| `docs/kianda/process-design-knowledge.md` | Design method, state distinctions, blueprint and acceptance scenarios. Read sections 1-9 and 13-14 for behavioural design; select additional sections for the task. |
| `docs/kianda/process-knowledge.md` | Relevant capabilities, exact technical boundaries and unresolved contracts. |
| `docs/kianda/process-schema.json` | Structural feasibility where a proposed design depends on a concrete representation. |
| `docs/kianda/css-style-guide.md` and `styles/app.css` | Visual composition, available utilities and overrides. |
| Existing `specs/` and relevant `processes/**/*.json` | Business requirements, current behaviour, dependencies and identities. |
| `docs/kianda/custom-addon-knowledge.md`, relevant `components/` and `js/app.js` | A design that depends on custom fields/rules, navigation or helpers. |
| Page/reporting knowledge and actual consuming pages | Reporting, cross-process dependencies or navigation affected by the design. |

Read supporting resources selectively, not the entire workspace by default. Record absent sources. A conceptual design may proceed with explicit assumptions when technical material is missing, but do not label an unverified capability implementable. Do not fabricate a file, component, command, principal or API.

## 2. Understand the task and establish the baseline

Identify outcome, participants, starting information, decision points, required evidence, completion criteria and reporting needs. Distinguish business policy from interaction design and implementation.

For an existing process, inspect its actual form tree, key decision fields, relevant rules and all writers to affected states. Identify the behaviours, identifiers, dependencies and existing-record paths that must remain stable. Check whether a supplied export is the actual target or only a historical example.

Use source references for important conclusions: requirement sections, file paths, field/form names and, where useful, JSON Pointers. Do not infer original design intent solely from a saved configuration.

Avoid re-asking settled requirements. Make low-risk, reversible assumptions explicit. Leave high-consequence unresolved business or security decisions as blockers for their affected scope while continuing independent design work.

## 3. Choose the process and form architecture

Map business stages separately from forms. Choose forms, sections, dialogs, repeating tables, reusable Components and related records according to task coherence, volume, timing, ownership, navigation and lifecycle.

Explain why each important boundary is appropriate. Do not assume one stage equals one form. Prefer an inline conditional section for a small extension of the same task; consider a separate form for a substantial navigable information area or distinct activity. Do not require a different participant to justify every separate form.

Keep implementation-only utility structures out of the intended user journey. Prefer verified native capabilities and existing reusable patterns; justify custom development only for an identified gap.

## 4. Define the adaptive behaviour

For each controlling decision, specify allowed answers, exclusive or overlapping selection, blank/unknown values, dependencies and effects. Include effective parent applicability so stale child selections cannot drive inactive branches.

Define applicability, visibility, editability, requiredness, completion, authorization and data treatment separately for each affected form or section. Treat these as blueprint concepts, not new JSON keys.

Write decision tables for overlapping conditions and shared targets. Identify one logical predicate for each target state and inspect all rules that could write it. Explain how the desired result remains consistent across selection order, deselection and re-entry.

Define entry, change, return-to-edit, draft reopening and programmatic-update behaviour. Separate repeatable presentation recalculation from consequential actions. Do not assume a field-change rule establishes initial-load behaviour.

For each calculated or derived value, specify its inputs, output, trigger, treatment of missing/invalid values, override policy, recalculation behaviour, and any pending or failure states.

Prefer a design that can be implemented through native Kianda rules and expressions. Do not prescribe a custom rule or service unless the requirements establish a concrete need.

Leave exact rule serialization and helper implementation to the builder, while identifying any execution-context or security requirements that constrain that choice.

## 5. Define data changes, navigation and completion

Specify what happens to populated values, evidence, derived values, related records and completed work when earlier answers change. Choose preservation, clearing, confirmation or restricted/reviewed reclassification deliberately. Preserve the existing policy during unrelated changes.

Define next/previous destinations, direct access and recovery when the current form becomes irrelevant. Specify validation for draft saving, progressing, submitting and final completion separately. Make error correction reachable.

Describe each action's actual effect and success conditions. Do not assume a rejected rule automatically stops later saving, navigation or side effects. Map permission requirements separately from presentation. Identify administrator setup and unresolved enforcement rather than inventing principal IDs.

## 6. Specify the visual composition

Describe each important form's purpose, guidance, section order, choices, repeating content, evidence controls, feedback and actions. Include the initial, conditional, populated, error and read-only states relevant to the task.

Use the existing Kianda CSS guide and supported controls. Apply clear hierarchy, intentional spacing, responsive grouping and consistent typography without replacing the framework or assuming a Material component library is installed.

Account for narrow screens, long labels, keyboard order, visible focus and the effect of revealing or hiding content. Keep data and security semantics independent from cosmetic changes. Avoid global styling changes when a scoped native pattern suffices.

A written composition or wireframe is design evidence, not a rendered Kianda preview. Do not claim visual or accessibility verification unless the relevant environment and interactions were actually inspected.

## 7. Produce and challenge the blueprint

Use section 13 of `docs/kianda/process-design-knowledge.md` as the blueprint contract. Include outcome/scope, requirements, stage/form structure, decisions, state transitions, data treatment, actions/navigation, composition, security/reporting, implementation mapping, tests and readiness.

For a small change, reduce this to: affected target, intended before/after behaviour, predicate or layout decision, data/security impact, implementation evidence and acceptance checks. Do not manufacture unnecessary documents.

Test the design on paper against the applicable scenarios in section 14. Include inverse changes, overlapping branches, saved-record re-entry, failed actions and existing-record compatibility. Distinguish static reasoning from runtime evidence.

Check each proposed capability against available technical evidence. Record confirmed mechanisms, reusable dependencies, unresolved contracts and genuinely blocking decisions. Keep approval status separate from implementation readiness; do not label an unapproved design approved.

## 8. Handoff without recursive delegation

When acting within `kianda-process-builder`, return the blueprint or design delta to that same workflow and allow implementation to continue. **Do not invoke the builder from this skill**, spawn a second agent or create a design/build invocation loop.

When used independently, stop at the requested design or review output. A design-only request does not authorize implementation or publication. Do not insert an approval checkpoint into an already authorized end-to-end build unless the user's workflow or a consequential unresolved decision requires it.

For substantial authorized documentation work, use the workspace's existing specification location; otherwise use the guide's proposed `specs/process-designs/<process-alias>.md` convention. Follow the applicable `CHANGELOG.md` policy. A chat-only or read-only request must not create files.

Conclude with the design's main decisions, artifact location if written, readiness, material assumptions/blockers and verification performed. Return control with a usable handoff, not an instruction to repeat the entire discovery process.
