# Workspace application data model and dependency map

This is a logical model for agents modifying this workspace. It combines the product walkthrough with the saved process and page definitions. It is not a relational database schema: Workspace stores process records, nested form/table values, and linked record identifiers; pages query those values through Kianda lists and summaries. A field shared by several processes is not automatically a database foreign key.

Read this alongside the [workspace architecture](./general.md), [module guide](./modules.md), and [page guide](./pages.md). Source links below point to the editable JSON or widget code. The diagrams describe the documented base product; customer hierarchy, security, approvals, report formulas, and visible modules can differ.

## Reading the diagrams

| Relationship label | Meaning for a modifying agent |
| --- | --- |
| **creates / updates** | A rule starts or updates a separate process record. Inspect its conditions, input/output mappings, lookup keys, trigger target, and server scheduling. |
| **looks up / selects** | A form loads values from another process. Loaded values can be copied into the receiving record; do not assume live synchronization. |
| **embeds** | A process reuses a component definition. The component contributes fields, tables, and rules inside its parent; this alone does not create a separate business record. |
| **lists / filters / aggregates** | A page queries records. Widget connections, URL parameters, and filter conditions determine its scope. |
| **contains rows** | Repeatable data belongs to the containing record unless a separate create rule is documented. |

Arrows are directional dependencies with explicit labels. They do not imply automatic cascade updates, inherited permissions, mandatory relationships, or deletion behavior. Cardinalities are stated only where the walkthrough or rules establish them.

## 1. Overall application map
<!-- Application map is built using mermaid -->