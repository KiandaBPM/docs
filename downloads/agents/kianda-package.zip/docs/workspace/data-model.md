# Workspace application data model and dependency map

**Status: application knowledge placeholder.** This document reserves the shared structure for product-specific knowledge. Populate it with confirmed requirements and evidence when documenting an application.

Use this guide for the overall relationship map and consequential dependencies. A Kianda application model is not a relational database schema: it describes process records, nested form/table values and linked record identifiers, with pages querying supported values through lists and summaries. A field shared by several processes is not automatically a database foreign key.

Read this alongside the [workspace architecture](./general.md), [module catalogue](./modules.md), and [page catalogue](./pages.md). Follow the shared [evidence guidance](./general.md#evidence-and-open-questions). Keep detailed field/rule inventories in individual module documents and widget/query details in individual page documents. Split substantial functional-area models into separate documents and link them here, following the [documentation structure](../../AGENTS.md#documentation-structure).

## Scope and coverage

Identify the application area covered, requirements and source revisions consulted, and material gaps. Record customer variations where relevant. An intended relationship may be documented before source exists, provided its proposed or agreed requirement status is explicit.

## Core records and reusable structures

List the main business concepts and their implementing processes, reference records, repeating tables or reusable Components. Distinguish separate record instances from embedded content and reference descriptors. Add actual aliases, source links and module-document links as they become available.

| Business concept | Implementation / alias | Record ownership or containing structure | Source / evidence |
| --- | --- | --- | --- |

<!-- Add application-specific rows only when requirements or source establish them. -->

## Reading the diagrams

| Relationship label | Meaning for a modifying agent |
| --- | --- |
| **creates / updates** | A rule starts or updates a separate process record. Inspect its conditions, input/output mappings, lookup keys, trigger target, and server scheduling. |
| **looks up / selects** | A form loads values from another process. Loaded values can be copied into the receiving record; do not assume live synchronization. |
| **embeds** | A process reuses a component definition. The component contributes fields, tables, and rules inside its parent; this alone does not create a separate business record. |
| **lists / filters / aggregates** | A page queries records. Widget connections, URL parameters, and filter conditions determine its scope. |
| **contains rows** | Repeatable data belongs to the containing record unless a separate create rule is documented. |

Arrows are directional dependencies with explicit labels. They do not imply automatic cascade updates, inherited permissions, mandatory relationships, or deletion behavior. State cardinality only when established by an explicit requirement or evidence, and identify whether it is intended or confirmed.

## 1. Overall application map
<!-- Add a Mermaid application map when relationships have been established. -->

Show core processes, supporting records, reusable Components and supplying/consuming pages. Use the directional labels above and identify proposed relationships. Add smaller linked diagrams when one overview becomes difficult to read; do not infer cardinality or access from arrows.

## Key relationships

Record consequential links using actual logical keys and scoped mapping references when known. Link detailed module/page explanations instead of duplicating them.

| From → To | Mechanism | Linking fields / mapping | Update behaviour | Evidence / status |
| --- | --- | --- | --- | --- |

<!-- Add lookup, create/update, embedding or containing-row relationships as established. -->

For each consequential relationship, explain whether values are copied snapshots, references or explicitly refreshed values. Establish cardinality, ownership/lifecycle, missing-record handling, deletion/retention and propagation only where supported. Record unknowns rather than assuming cascades, synchronization or inherited permissions.

## Reporting dependencies and change impact

Identify pages/reports consuming each process and any maintained totals or reporting projections, linking their detailed documentation. Record the producer, update trigger and relevant indexing or refresh limits. When a key, relationship or lifecycle changes, identify affected lookups, mappings, Components, security, reports and existing records, including any migration or publication dependency.

## Open questions and decisions

Record unresolved linking, cardinality, ownership, propagation, deletion or migration questions and the evidence needed to settle them. Distinguish intended access from tested authorization and identify external dependencies when relevant. Update the map and relationship entries as requirements, implementation or observed behaviour change.
