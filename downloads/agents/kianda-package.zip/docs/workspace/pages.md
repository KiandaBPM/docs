# Workspace pages and report configuration

This is the page reference for agents changing this workspace. It combines the product owner's walkthrough with the page JSON inspected . Read [general.md](./general.md) for product concepts and architecture, [modules.md](./modules.md) for operational processes, and [the application data model](./data-model.md) for relationships.

The walkthrough describes the base product and common customer changes. A saved page definition describes this workspace's current configuration. Keep those two evidence sources distinct: customer security, branding, hierarchy, formulas, and workflow can vary. Roadmap features are explicitly identified below. Current source differences are recorded in this document.

## Navigation and page identity
