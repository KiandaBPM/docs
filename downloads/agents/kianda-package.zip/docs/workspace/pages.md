# Workspace pages and report configuration

**Status: application knowledge placeholder.** This document reserves the shared structure for product-specific knowledge. Populate it with confirmed requirements and evidence when documenting an application.

Use this guide as a concise catalogue of the target application's pages and reports. Read [general.md](./general.md) for product concepts and architecture, [modules.md](./modules.md) for operational processes, and [the application data model](./data-model.md) for relationships.

Populate progressively from agreed requirements, inspected definitions and observed runtime behaviour, following the [evidence and open-question guidance](./general.md#evidence-and-open-questions). Record coverage, source differences, customer variations and proposals explicitly. Missing knowledge remains unresolved; mark a topic not applicable only when established.

## Navigation and page identity

Describe the overall navigation, entry points and page relationships briefly. Identify the source and coverage of that description. Keep displayed titles distinct from stable aliases and actual source identities. Link page details from the catalogue below; do not infer that hidden navigation restricts access.

## Page catalogue

Add one row per known page or report with a link to its detailed document and actual definition when available. Do not add example pages merely to populate this template.

| Page/report and detail document | Purpose and audience | Alias/source | Supplying processes | Evidence and coverage |
| --- | --- | --- | --- | --- |

## Detailed page documents

Create one separate document per application page, following the existing layout. Where no layout exists, use `pages/<page-alias>.md` relative to this guide. This is a naming pattern, not an instruction to create an empty file. Use additional documents for substantial reporting areas and link shared material instead of duplicating it.

Each page document should cover:

- **Purpose and navigation:** intended audience, entry points, links, URL parameters and relevant workflow context.
- **Data and presentation:** supplying processes/datasources, field bindings, important widgets/templates, reporting measures and maintained projections. Link exact definitions and the relevant [platform contracts](../kianda/page-knowledge.md); avoid exhaustive widget inventories.
- **Filters and actions:** base queries, value/display fields, defaults, clearing, cascades and connected targets; drill-down, record navigation and actions with side effects.
- **Access:** intended roles and verified group bindings, page/data access requirements, record-security dependencies and access tests. Distinguish visual visibility from authorization.
- **Changes and verification:** affected modules/consumers, acceptance scenarios, expected records/totals, scoped checks, observed results and confirmed defects. Record untested behaviour, required configuration and publication status separately.
- **Evidence and open questions:** support consequential claims and identify unresolved behaviour or missing dependencies.

## Maintenance

Update the page document and this catalogue after substantive changes. Reconcile affected module/data-model links and reporting projections. Keep confirmed defects separate from intended configuration and proposed improvements.
