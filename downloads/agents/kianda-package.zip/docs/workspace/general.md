# Workspace product and architecture guide

**Status: application knowledge placeholder.** This document reserves the shared structure for product-specific knowledge. Populate it with confirmed requirements and evidence when documenting an application.

Use this guide as the application overview and navigation entry point. Populate relevant sections progressively from agreed requirements, current source and observed behaviour. Until populated, this placeholder establishes no product configuration or completed review coverage. Platform contracts are available in the [Kianda application model](../kianda/general.md).

## Read this documentation together

| Document | Purpose |
| --- | --- |
| [AGENTS.md](../../AGENTS.md) | Agent entry instructions and modification workflow. |
| [modules.md](./modules.md) | Module catalogue linking to individual module behaviour, dependencies and modification guidance. |
| [pages.md](./pages.md) | Page catalogue linking to individual navigation, query, reporting and modification guidance. |
| [Application data model](./data-model.md) | Overall relationships and links to detailed models where needed. |

Follow the [documentation structure](../../AGENTS.md#documentation-structure). Keep this overview concise; link substantial functional areas and shared topics to their own documents. Populate catalogue links only when the documents exist.

## Purpose and scope

Describe the application's outcomes, intended users, included areas, boundaries and important customer variations. Record requirements awaiting implementation separately from current behaviour.

## Personas and terminology

Define business personas, responsibilities and application-specific terms. Link detailed role/access documentation and actual role-to-group mappings when available; a named persona alone establishes no permission.

## Architecture and operating constraints

Summarize the main process, page, Component and integration boundaries, linking the [data model](./data-model.md). Identify relevant security, offline, localization, reporting and operational constraints. Link detailed shared topics instead of repeating them across modules.

## Evidence and open questions

Attach evidence to consequential claims and catalogue entries. A document may contain different evidence states together:

| Evidence state | What to record |
| --- | --- |
| Requirement / proposed | The agreed or proposed behaviour and its source; implementation may still be pending. |
| Inspected configuration | Actual source path and scoped alias, field/rule name or JSON Pointer; include the inspected revision when relevant. |
| Runtime observation | Environment, date, scenario and result actually observed. |
| Unresolved | What remains unknown, its impact and the clarification or check needed. |

Record scope and source coverage as content is added. Omit irrelevant sections or mark them not applicable with a reason; an empty section is not evidence of absence. For a new application, reconcile intended behaviour with implementation as it develops. For an existing application, distinguish source-derived observations from business intent. Update affected entries and links when substantive changes alter the application.

