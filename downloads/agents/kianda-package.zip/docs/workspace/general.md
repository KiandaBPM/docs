# Workspace product and architecture guide

This is the entry point for understanding and modifying the workspace. It consolidates the product-owner walkthrough and the workspace definitions. It describes the product configuration represented here.

## Read this documentation together

| Document | Purpose |
| --- | --- |
| [AGENTS.md](../../AGENTS.md) | Agent entry instructions and modification workflow. |
| [modules.md](./modules.md) | Module behavior, field/rule dependencies, shared components, and modification guidance. |
| [pages.md](./pages.md) | Navigation, operational/admin pages, reporting configuration, and page modification guidance. |
| [Application data model](./data-model.md) | Logical relationships between modules, supporting processes, components, pages, and reports. |

