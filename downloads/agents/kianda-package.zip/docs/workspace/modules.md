# Workspace modules: product behavior and modification guide

This guide describes the process modules and the relationships an AI agent must preserve when modifying this workspace. It combines the product owner's walkthrough and corrections with the saved process definitions. Read [general.md](./general.md) for product context and architecture, [pages.md](./pages.md) for navigation and reporting, and the [application data model](./data-model.md) for relationships.

## 1. Scope, evidence, and terminology
