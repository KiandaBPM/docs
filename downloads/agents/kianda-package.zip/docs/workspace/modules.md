# Workspace modules: product behavior and modification guide

**Status: application knowledge placeholder.** This document reserves the shared structure for product-specific knowledge. Populate it with confirmed requirements and evidence when documenting an application.

Use this guide as a concise catalogue of the target application's process modules. Read [general.md](./general.md) for product context and architecture, [pages.md](./pages.md) for navigation and reporting, and the [application data model](./data-model.md) for relationships.

## 1. Scope, evidence, and terminology

Record the application areas covered, module terminology, available definitions, walkthroughs and material gaps. Distinguish agreed requirements, inspected source and observed runtime behaviour using the [evidence and open-question guidance](./general.md#evidence-and-open-questions). Record customer variations and proposed changes explicitly. Mark a section not applicable only when its irrelevance is established; missing knowledge remains unresolved.

Populate progressively as the target application becomes known. Do not infer behaviour from headings or create sample business records to fill this template.

## 2. Module catalogue

Add one row per known module, linking its detailed document and actual implementing definitions when available. Keep dependencies and coverage brief here; explain them in the linked document.

| Module and detail document | Purpose | Implementing processes | Dependencies | Evidence and coverage |
| --- | --- | --- | --- | --- |

## 3. Detailed module documents

Create one separate document per module, following the existing application layout. Where no layout exists, use `modules/<module-alias>.md` relative to this guide. This is a naming pattern, not a file to create before the module is known. Split substantial functional areas further when helpful and link shared explanations instead of duplicating them.

Each module document should cover:

- **Purpose and scope:** business outcome, terminology, requirements, exclusions and current implementation status.
- **Journey and responsibilities:** stages/forms, entry and completion conditions, branches, navigation, ownership, role-to-group mappings and intended permissions.
- **Configuration and dependencies:** important fields/rules, reusable Components, related records, mappings, notifications, generated outputs and reporting consumers. Link exact definitions and the relevant [platform contracts](../kianda/process-knowledge.md); avoid exhaustive field inventories.
- **Modification and verification:** affected dependencies, configuration or migration/publication steps, acceptance scenarios, checks performed, results and remaining limits. Keep structural validation, runtime observations and publication separate.
- **Evidence and open questions:** support consequential claims, identify unresolved behaviour and record the clarification or test needed.

## 4. Maintenance

Update the module document and this catalogue when behaviour or dependencies change. Update affected page and data-model references, and record confirmed defects separately from intended behaviour.
