# Kianda styling — entry guide

Source guide **1.0.0**, prepared **27 October 2026**; navigation reorganized **4 November 2026**. Baselines: process **1.1.0**, page **draft 1.0.0**, existing **Bootstrap 3** styling. Evidence is documentation/source inspection, not executed UI or accessibility certification.

Apply the owner’s clean enterprise/Material Design objectives through supported components and styles actually present in the workspace. No Material library, new framework, font/icon set or numeric token system is implied. Inspect `styles/app.css`, inherited sources and relevant overrides before relying on a class.

## Read by task

| Task | Direct reference |
| --- | --- |
| Set layout/styling keys or preserve a legacy `cssClass` | [Persisted properties](./styling/properties.md) |
| Apply an established process/page utility and required native settings | [Utility recipes](./styling/utilities.md) |
| Style a page card list in `Content` | [First-column contract and supplied CSS](./styling/page-lists.md) |
| Investigate a colour, separator, selector/cascade issue or inherited/local source | [Source observations and evidence](./styling/source-evidence.md) |
| Compose a screen, add scoped CSS or review interaction/accessibility | [Design and verification](./styling/design-review.md) |

## Correct properties

Process fields and placed page widgets use outer **`class`** for layout and **`customCssClass`** for extra class tokens. Keep field `settings.mobileClass` nested. Page containers use `name`, `desktopClass`, **`mobileClass`**; widgets select them with `settings.container`. Native Link items legitimately use item-level `cssClass`. Do not perform a global key rename or invent a process-panel colour key from widget `colorScheme`.

Classes are space-separated tokens without leading dots or invisible U+200B characters. Preserve unrelated tokens, identities, data, rules, bindings and permissions. CSS does not replace native selection/configuration settings or create behaviour/security.

## Verified utility routing

| Process fields | Page widgets |
| --- | --- |
| `panel-card` — panel grouping | `widget-section-title` — HTML heading frame |
| `radio-list-card`, `checkbox-list-card` — respective vertical selection controls | `widget-filter-tabs` — radio-list filter appearance |
| `radio-list-button` — radio-choice treatment | `widget-filter-compact` — reduced frame padding |
| `section-title` — static text with native background setting | `Content` is a **container name**, not a utility; it hides list header and every cell after the first |
| `table-no-style` — repeating table composition | Use page utilities on page markup; process utilities are not interchangeable |
| `image-thumbnails` — image field using a file source | Hidden card/list columns can still supply required projected data |

The process-panel serialized setting for the UI colour choice `panel-default` remains unresolved. `settings.cardPanel`, `.card-panel` and `panel-card` are distinct. The styling prose mentions Yes/No colours, but the inspected `radio-list-button` selectors use **`OK`, `NOK`, `N/A`**; local Yes/No rules target `?inlineButtons`. The prose describes a faint heading separator, but the inspected `widget-section-title` rule does **not** declare one. Preserve these evidence distinctions; details are linked above.

The inherited EHSwise stylesheet snapshot is provenance for one source, not a portable tenant URL or proof every workspace loads it. Review effective CSS and affected consumers for shared changes. Schema acceptance cannot establish computed styles, wrapping, focus, accessibility or correct interactions; report source inspection and runtime verification separately under root policy.
