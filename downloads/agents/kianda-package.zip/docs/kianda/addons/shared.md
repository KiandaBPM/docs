# Shared addon implementation and configuration

Source-based topic reference from [custom-addon-knowledge.md](../custom-addon-knowledge.md). Original section numbers are retained for source citations; evidence status and unresolved qualifications are unchanged. Source labels and verification limits are in [addon evidence](./evidence.md#15-source-register).

## 3. Shared implementation rules

### 3.1 Use the supported Ember environment

The supplied guides use classic Ember component modules:

```javascript
import Ember from "ember";

export default Ember.Component.extend({
  // Component methods, computed properties, actions and lifecycle hooks.
});
```

Use `this.get(...)`, `this.set(...)`, `setProperties`, Ember-aware collection operations, classic computed properties and service injection as demonstrated by the current implementation. Do not introduce Octane tracked properties or newer template syntax based solely on contemporary Ember examples. Call `this._super(...arguments)` when overriding inherited lifecycle hooks. Use ordinary method syntax for component methods so `this` remains the component; arrow callbacks inside those methods can retain it. [F §§4,11; R §9; W §§2,8]

Allocate mutable component-local arrays and objects per instance in `init()`. Store serializable configuration on the appropriate model; keep loading flags, errors, request counters, timers, DOM nodes, browser `File` objects and external SDK instances on the component. For field and rule widgets, `settings()` is a Designer initialization hook. Page widgets use ordinary lifecycle hooks; the supplied page contract does not establish a `settings()` convenience hook. The properties `field.settings`, `rule.settings` and `widget.settings` contain configuration data.

The documented environment includes `ember-moment` 8.0.1, `ember-truth-helpers` 2.0.0 and `ember-collection` 1.0.0. Page-widget documentation also lists bundled Chart.js, Bootstrap/BootstrapDialog, Kendo, Moment, jQuery/jQuery UI, Summernote and Babel. Verify the installed library version before using version-specific APIs. FullCalendar is an external dependency in the supplied examples, not a bundled Kianda guarantee. [F §11; R §7; W §13]

### 3.2 Preserve configuration and data types

The field, rule and widget models initialize a separate settings object. Initialize individual missing options, preserving intentional `false`, `0` and empty strings:

```javascript
// Fragment inside the appropriate settings or initialization method.
if (this.get("field.settings.placeholder") === undefined) {
  this.set("field.settings.placeholder", "Enter a reference");
}
```

Do not replace the entire settings hash to introduce defaults. It may contain existing custom configuration, engine diagnostics or page-filter state. Use the settings owner for the addon type: a rule's triggering `field` is not its configuration owner.

Inspect each contract's exact values and casing. Outer field flags are booleans; many native settings use strings. A custom widget may deliberately choose its own values. Do not globally coerce `"yes"`, `"no"`, `"Yes"`, booleans and empty defaults into one representation. Preserve unknown settings during unrelated edits. Report incomplete contract coverage separately from a known invalid setting. The warning-only treatment is confirmed for opaque page-widget settings; extending the same severity policy to custom fields/rules is a recommended policy here, not an established engine behaviour. [P §§6–7,12; Q §§16–17]

### 3.3 Own resources and asynchronous state

Mount DOM-dependent integrations after insertion into the relevant view. Use the component's own element, `this.$(...)`, or an instance-specific ID such as `elementId`. A shared component name is not a unique DOM identifier.

When a callback resolves, check that the component remains active, refers to the same model and still permits the operation. Re-enter Ember's run loop with `Ember.run` or `Ember.run.join` when publishing bound state from external callbacks, following the supplied examples. Unsubscribe listeners and dispose of timers, location watches, chart/calendar instances and SDK elements on teardown. Clean up mode-specific resources when editability changes as well as on destruction.

An `async` keyword alone does not make the host wait for callback work. Likewise, `this.send(...)` dispatches an action; do not use it as a general awaitable completion contract. Keep essential work in methods whose returned Promises are explicitly awaited by their caller. [F §§4,8–10; R §6; W §8]

### 3.4 Keep operations and permission checks in their proper context

Use escaped Handlebars output for ordinary record text, filenames and error messages. Rich HTML needs an established trusted-source and sanitization policy. Do not interpolate record values into executable JavaScript or depend on hidden UI to protect accessible data.

Use the current platform session, adapter or supported connector for authenticated operations. Do not embed tokens or secret credentials in component code, saved settings or public assets. An API operation can complete remotely before a later process save; neither an ignored late callback nor a failed process save reverses that external effect. Design retries and partial-completion handling for the particular integration. [F §§9–11; R §§6,10; W §§11–13]

## 7. Configuration interfaces and validation

Common supported controls include `input`, `textarea`, `field-picker`, `radio-button`, `person-picker` and `rich-text`. Page configuration also uses `process-picker`, `rules/rule-conditions` and other controls documented for that context. Use the actual binding: a picker reference uses `value`, radio selection uses `group`, and rich-text content uses `contents`. Scope radio-group names with `elementId` when multiple instances can render together.

Useful documented fragments include:

```handlebars
{{radio-button name=(concat this.elementId "-mode")
  label="Keep case" value="preserve" group=this.rule.settings.caseMode}}
{{radio-button name=(concat this.elementId "-mode")
  label="Uppercase" value="upper" group=this.rule.settings.caseMode}}

{{rich-text contents=this.rule.settings.message height=220
  sanitize=true showCodeview=false showImageDialog=true showFontName=false}}
```

These control options describe UI behaviour; the custom implementation must use the stored settings. Picker output shape is context-specific. A person-picker result is not guaranteed to be one username string. Do not infer a helper or option's existence from its name. [F §11; R §7; W §5]

### 7.1 Field and rule configuration saves

Use required controls for mandatory settings. For additional synchronous checks, field and rule models expose a `saving` event:

- Set `args.isError = true` when rejecting the configuration.
- Append a clear message to `args.errors`.
- Preserve existing errors and failure state from other validators.
- Use a stable callback reference; detach a prior registration before adding it again and remove it on destruction from the same model.

This validates Designer configuration, not an instance Save rule. Do not assume asynchronous validators are awaited. Load required remote information beforehand and validate its resulting state synchronously. Runtime checks remain necessary because references can be deleted and older configurations can be imported. [F §5; R §5]

### 7.2 Page configuration differs

The supplied page-widget contract has **no equivalent `saving` validation event**. Use the global settings dialog's required-control validation and validate the saved settings again before the component performs a query or operation.

The settings dialog and runtime view share the same `widget` model but have separate component-local state and DOM. Do not call `widget.save()` from a picker or callback. Let the page designer own persistence; do not assume cancelling the dialog provides a transaction boundary for arbitrary mutations. [W §§2,5]
