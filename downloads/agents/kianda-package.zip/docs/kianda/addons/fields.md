# Custom field widgets and field APIs

Source-based topic reference from [custom-addon-knowledge.md](../custom-addon-knowledge.md). Original section numbers are retained for source citations; evidence status and unresolved qualifications are unchanged. Source labels and verification limits are in [addon evidence](./evidence.md#15-source-register).

## 4. Custom field widgets

### 4.1 Render all four modes

| Exact `displayMode` | Required interpretation |
| --- | --- |
| `design` | Designer-canvas preview; show an informative, non-operating preview |
| `edit` | Editable runtime UI; user actions may update the field |
| `display` | Read-only representation of stored data, including a disabled field |
| `settings` | Configuration UI bound to `field.settings` |

The literal is `design`, not `designer`. Kianda supplies insertion convenience methods `edit()`, `display()` and `settings()` when the corresponding mode is active. There is **no `design()` convenience hook**, and field mode hooks are **not awaited**. They are not guaranteed to run again whenever `displayMode` changes. Use explicit context-change handling for long-lived resources. [F §4]

Guard active integrations with the actual editable state. Uploading, geolocation acquisition or payment initialization must not begin merely because the control appears on the Designer canvas. Respect `field.enabled` and `field.visible`, including when delayed work completes.

### 4.2 Maintain text, value and rule notification

`field.value` is polymorphic: it may be a scalar, object or array according to the field's contract. `field.text` is its readable representation. Neither property should contain transient loading/error messages masquerading as business input.

| Update pattern | Rule-notification consequence |
| --- | --- |
| `field.set("value", nextValue)` changes the top-level value | Triggers the field's attached rules |
| Only `field.text` changes | Explicit value notification is needed when this logical edit should trigger rules |
| An existing value object's properties change | Use Ember-aware setters, finish the logical update, then notify `value` |
| An existing value array changes | Use Ember-aware collection operations, finish the update, then notify `value` |

For a text field with matching text and value, set readable text first:

```javascript
// Fragment in an editable action after context/input validation.
const field = this.get("field");
field.set("text", nextText);
field.set("value", nextText);
```

Rules observing the changed value can then see matching text. Do not add a second `notifyPropertyChange("value")` after the same top-level replacement. When intentionally keeping the same structured value or using text-only data, notify once after all relevant changes:

```javascript
// Existing structured object; this widget's value contract must allow it.
Ember.set(field.get("value"), "description", nextDescription);
field.set("text", nextDescription);
field.notifyPropertyChange("value");
```

A rule triggered by this notification can hide or remove the control. Finish component-local presentation changes before publishing the final value when the remaining code assumes the component is still rendered. Review direct and indirect update cycles. Updating several fields is not an atomic transaction. [F §§2–3,6,8]

### 4.3 Persistence and runtime validation

A field widget updates the current model; it does not call `process.save()` to persist its own data. Use the process's Save rule or surrounding commit workflow. Saving reusable widget code, saving the process definition and saving a running instance are different operations.

Required-input validation examines meaningful `field.text`/`field.value` content. A component-local `isBusy` or `errorMessage` does not automatically block submission. An object containing a pending external-operation reference may be nonempty without satisfying the business requirement. Model and validate the completion requirement explicitly in the process.

When clearing data, clear corresponding readable text. When replacing data asynchronously, decide whether a previous valid result remains acceptable until replacement succeeds. A native browser file input is empty after reopening even when a valid uploaded reference is stored; do not force a replacement by blindly binding that input's `required` attribute to `field.required`. [F §§3,5,9]

### 4.4 Process and child field access

Use `await this.get("field.process")` inside an asynchronous method when the relationship may still be resolving. Check for absence and recheck the current model after waiting. The field model resolves the wrapping process; copying legacy `.content` unwrapping everywhere is unnecessary.

Use the actual `fields` relationship for child field models and `parentField` for their inverse. Object properties inside `field.value` are not independent field models. A table-row helper's `subFields` has a different context; do not invent `field.subFields` as a generic relationship.

Create missing child models deliberately and once, using the supported store/relationship pattern; preserve existing children, identities and names. Normal display/rendering must not continually recreate them. Persist them through the surrounding design or instance workflow. Selecting existing utility fields through `field-picker` is another supported composition pattern. [F §§6–7; P §§4,6]

## 5. Field references and platform field APIs

A `field-picker` normally stores a descriptor, not a live model. Its `text` is the selection label, not the field's current contents. A literal input can instead be `{ "type": "text", "text": "Site" }`.

| API | Contract used by the supplied guides |
| --- | --- |
| `process.findFieldByName(name)` | Resolve a process field by name; check the result |
| `process.findFieldByRef(reference)` | Resolve a field reference; may return `undefined` |
| `process.getFieldRefText(reference)` | Read current field text or literal text; may return `undefined` |
| `field.get("value")` / `field.get("text")` | Read the resolved model's actual data |
| `process.setField(field, value, text)` | Update a field, optionally supplying separate display text; triggers that field's rules and may return a Promise |

Await `setField` when subsequent work depends on the update. Lists backed by data sources and user pickers can need asynchronous resolution. A field component awaiting it sequences that component's action; it does not make the process wait for all of the field's asynchronous activity.

Use `allowText=false` for a destination. Validate existence, compatible value shape and contextual identity before writing. Resolve references from the current process at runtime rather than retaining Designer models. Preserve row context for table operations.

A descriptor's `type: "field"` identifies its reference kind, while `fieldType` identifies the referenced field's outer control type. For newly authored page selectors, the page contract requires the matching `fieldType`; do not invent IDs or flatten all descriptors into one universal shape. Preserve exact stored names, including suffixes containing `?`. [F §7; R §§3–4; Q §8]
