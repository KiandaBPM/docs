# Summaries reporting contract

Source-based topic reference from [custom-addon-knowledge.md](../custom-addon-knowledge.md). Original section numbers are retained for source citations; evidence status and unresolved qualifications are unchanged. Source labels and verification limits are in [addon evidence](./evidence.md#15-source-register).

## 9. Reporting through Summaries

### 9.1 Choose the right data contract

The Summaries endpoint is `POST /api/summaries` and returns a JSON array. Inside a Kianda page widget, the recommended simple client path is `store.query("summary", query)` with `preferOnline: true`; await its single Promise in an internally handled asynchronous method.

| `action` | Result interpretation |
| --- | --- |
| `list` | Summary records with projected `properties` |
| `tile` | Aggregate at `firstObject.properties.value` in the Ember result |
| `chart` | Grouped `properties.labels`, `values1` and any configured additional series |

`preferOnline` is a client-store option, not a server `Query` member. Direct REST consumers read the returned array and, for list totals, the `total-items` response header. `data.meta` is client metadata; the sources do not establish a universal `data.meta.totalItems` property. A datasource service's `select` action and `result.items` are a separate integration contract. [S §§2–5,8,10–13; W §§7,11]

For a count restricted to one configured process, the core request is below. Blank or omitted `info.process` can search across processes accessible to the user, so this example rejects a missing process selection. [S §3]

```javascript
// Fragment: the caller must validate settings, prepare conditions, handle
// failures and stale responses, and coordinate the stable dataset identity.
const processName = this.get("widget.settings.processName");
if (typeof processName !== "string" || !processName.trim()) {
  throw new Error("Count: select a process before loading data.");
}
const data = await this.get("store").query("summary", {
  action: "tile",
  info: {
    process: processName,
    queryType: "all",
    tile: "count",
    id: this.get("widget.id") + "-count"
  },
  fields: ["__PROCESS_NAME"],
  conditions: conditions,
  rowLimit: 1,
  preferOnline: true
});
const raw = data.get("firstObject.properties.value");
```

Here `rowLimit: 1` follows the aggregate request pattern; it does not mean only one matching instance is counted. Keep a returned numeric zero distinct from missing data. For a sum or average, use a verified numeric field and exact `sum` or `avg` setting. A missing denominator or nonpositive hours value should not become a plausible rate. [S §10; W §§3,9]

### 9.2 Scope, projection and identity

Use `info.process` to restrict one process and exact stored field names in projections. The supported relationship filters are `all`, `assignedTo`, `createdBy` and `modifiedBy`. `all` still applies instance permissions. Omit deprecated `processSource` and `isPartner` from newly constructed Summaries requests; preserve legacy page serialization according to its own authoring contract rather than indiscriminately rewriting it.

Fields outside tables, including panels/dialogs, are indexed. Custom fields expose their `field.text`; arbitrary nested properties in structured custom values are not independently searchable. Table-cell content and client-calculated `___CUSTOM_FIELD*` columns are outside the server projection contract. Maintain a useful text representation or explicitly designed reporting fields when a custom value must be searched.

Use `summary.name` for opening or addressing an instance. With `isListWidget: true`, `summary.id` can include a widget suffix; do not split it to guess the original name. For new list widgets, explicitly request the needed fields through a nonempty `fields` array, use zero-based `info.page`, and choose bounded page sizes and suitable deterministic sorting. These page-size and sorting choices are authoring recommendations, not a claim that the server enforces a particular upper limit or order. Use the documented date/number `sortFieldType` where appropriate. Typed companions such as `_utc` and `_number` can be absent for empty values. [S §§1,3–5,8; W §7]

### 9.3 Conditions, dates and access

A query has one level of groups containing individual conditions, not an arbitrary recursive Boolean tree. Preserve connectors and operator spelling. When persisting page-widget conditions, follow the page guide's GUID requirements for both groups and individual conditions. Process direct-rule groups and known settings-level query-filter groups also require GUIDs, but individual-condition ID requiredness remains unconfirmed in those process contexts. Follow the relevant process contract. Descriptive IDs in REST tutorial snippets are not templates for Designer-ready saved pages. Do not import the entire query operator catalogue into direct process-rule conditions. [Q §§1,9–10; P §§4–5,10]

Author relative-date configuration without hard-coded resolved boundaries; call `parseDateConditions` on the request copy at refresh time. Generated explicit reporting periods need an intentional calendar/timezone policy. The tutorial use of UTC monthly buckets is not a universal workspace timezone rule. Appending a range to `(A) OR (B)` requires preserving its Boolean meaning; the supplied examples' top-level `and` restriction is an example limitation, not an API restriction.

Indexing after an instance save is asynchronous. A refresh can briefly show prior values; do not claim that a successful save synchronously updates every dashboard. Permissions govern contributing instances for lists and aggregates. Hiding a field or widget is presentation, not field-level API security. Cached public-file scripts also do not guarantee offline reporting data, especially with the recommended online query path. [S §§1,6–8; W §§7,9,13; Q §§9–10]

The page package excludes new native Chart v2 authoring in V1. That policy does not prohibit the Summaries `chart` action or a verified custom Chart.js implementation. Preserve existing Chart v2 definitions under the page guide's compatibility rules. [Q §§7,16]
