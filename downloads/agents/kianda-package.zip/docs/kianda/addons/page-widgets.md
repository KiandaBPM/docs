# Custom page widget lifecycle and navigation

Source-based topic reference from [custom-addon-knowledge.md](../custom-addon-knowledge.md). Original section numbers are retained for source citations; evidence status and unresolved qualifications are unchanged. Source labels and verification limits are in [addon evidence](./evidence.md#15-source-register).

## 8. Custom page widgets

### 8.1 Understand the host and views

Use exactly `displayMode === "settings"` for the configuration branch; otherwise render page content. `isDesign` is separate design-presentation metadata. It is not another field-style mode. The `widget-base` host supplies the frame, title, header controls and bridge to the child component.

The custom component receives `widget`, host `data`, `id`, `isDesign` and action bridges. `widget.page` is the containing-page relationship; a standalone `page` argument is not established by the shown host invocation. Host `data` has no universal result shape. `process-picker` can supply process **definition** metadata for settings controls, not an editable current process instance.

Use ordinary lifecycle hooks. Guard data loading and chart/calendar mounting against settings mode. A field-style `edit()` or rule-style `execute()` does not define a page widget's runtime lifecycle. Do not fetch unconditionally from `didRender`, because the resulting state update can render again. [W §§2,4,8]

### 8.2 Filtering and refresh

A filter-aware custom reporting widget implements `actions.refresh`. Kianda fires this action with **no arguments** and **does not await it**. The widget must own loading state, errors, request ordering and completion.

The host resolves filter connections and merges temporary groups into the target's live `widget.settings.conditions`. Those groups carry `filterId`. Build a request from a fresh clone of the entire effective array, retaining those temporary groups. Kianda removes the originating groups when a filter is cleared and strips temporary groups before saving the page. Do not cache a stale base array or independently remove runtime groups before querying.

```javascript
// Fragment inside the widget's error-handled loading method.
const conditions = JSON.parse(JSON.stringify(
  this.get("widget.settings.conditions") || []
));
this.get("ruleEngine").parseDateConditions(conditions);
```

JSON cloning here is for serialized condition data, not Ember models or arbitrary objects. The date helper mutates the copy; use that array afterward rather than expecting a returned array or Promise.

Connections target the **placed widget ID**, not `client-widget/<component-id>`. The filter's authoritative design configuration is `settings.connections`; a filter appearing beside a custom widget does not prove that the connection exists or the component supports it. [W §6; Q §10]

### 8.3 Coordinate asynchronous refreshes

Use a deliberate request policy. The supplied metric example coalesces refreshes, serializes requests for one stable aggregate identity and checks a revision/model before publishing. Capture conditions once for a logical refresh, then clone independently for separate datasets.

A stale-result guard prevents obsolete UI publication; it does not cancel HTTP work or isolate collisions in the shared Ember store. Give separate logical datasets distinct `info.id` values and coordinate overlapping requests using the same identity. Separate runtime component lifetimes may also need distinct identities when an earlier component's request is unfinished.

Mount external resources after insertion and destroy the component's instance on teardown. Keep temporary chart data, request counters and timers off `widget.settings`. Define whether loading clears a previous result or displays it as stale. A failed request is different from an empty result. [W §§3,7–9]

## 10. Navigation and other template contexts

The supplied page developer guide documents these global functions:

```javascript
window.showModalForm(nameOrUrl, isNew, params, isUrlPredefined, callBack, isStatic);
window.gotoForm(name, isNew, partnerId, queryParams, reload);
window.gotoDashboard(name, queryParams);
```

These lines are signatures, not calls with defined arguments. Use an instance `name` for an existing record and a process alias for a new process. Encode query parameter values. Do not assume a modal callback proves a save succeeded or returns an awaitable Promise. Verify optional partner, predefined-URL, reload and modal semantics before depending on them. [W §12]

Custom HBS **list columns** have another host context: `row`, projected properties and documented actions. They are not automatically standalone custom page widgets. An action available there, such as `showModal`, does not establish that every custom component inherits it. The custom-column action `showModal` and global `window.showModalForm` have different signatures; preserve their contexts. Similarly, the host invocation's action names do not define global-function argument signatures.

Keep hidden list projections that supply HBS values. Use the verified helpers/actions in [custom-column contracts](../page/templates-navigation.md), declare actions referenced by a standalone component's own template, and avoid assuming an addon-specific token such as `[description]` is a global interpolation mechanism. The recorded `mmoment-diff` spelling is unresolved; do not introduce a dependency on it or silently rename it. [Q §11; W §§2,11–12]
