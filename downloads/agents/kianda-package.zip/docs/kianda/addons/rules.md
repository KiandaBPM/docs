# Custom rule execution

Source-based topic reference from [custom-addon-knowledge.md](../custom-addon-knowledge.md). Original section numbers are retained for source citations; evidence status and unresolved qualifications are unchanged. Source labels and verification limits are in [addon evidence](./evidence.md#15-source-register).

## 6. Custom rule widgets

### 6.1 Execute from the supplied context

`execute()` is the only runtime entry point. The runtime instantiates the component without rendering its settings template. Runtime logic must therefore work without `this.element`, `didInsertElement`, settings-editor actions or a prior call to `settings()`.

| Supplied property | Meaning |
| --- | --- |
| `process` | Current process instance |
| `rule` | Current rule and its saved settings |
| `field` | Attached/triggering field where applicable; can be null |
| `form` | Associated form where applicable; can be null |
| `node` | Attachment point: process, form or field |
| `ruleEngine` | Current orchestrator; supplied rather than inferred from a rendered view |

The attached field can be a button while the destination is another field selected in `rule.settings`. Read the configured destination instead of assuming `this.field` is the target. The engine owns conditions, enabled state and alternate-setting orchestration; a custom executor should not reimplement those mechanisms. [R §§1,3]

### 6.2 Return completion and handle failure correctly

The engine awaits the Promise returned by `execute()`. Use `async execute()` and await all work that defines completion, including field updates. For a callback API, adapt its documented completion to a Promise. Use sequential `for` loops for ordered mutations; `forEach(async ...)` does not make the outer operation await each callback.

**Return values are ignored. Errors do not stop the subsequent rule sequence.** `return false` is not a cancellation mechanism. When a rule throws or rejects, Kianda records/reports the failure and continues. Dependent actions require explicit conditions on a verified result or outcome field. Reset a reused outcome before attempting work; set success only after the required operations finish.

The engine writes `rule.settings.lastExecuted` after success and `rule.settings.lastError` on failure. Preserve those keys and do not use them as custom options or set them yourself. A previous diagnostic alone is not proof of the current attempt's result. Throwing does not roll back earlier field writes, an external request or a counter allocation. [R §§3,6]

### 6.3 A small rule implementation pattern

This example copies displayed field-or-literal text into an independently selected text destination. The saved `source` and `destination` descriptors are this example's settings contract. It requires compatible text fields and the matching settings template; it is not a complete process definition.

```handlebars
<div class="form-group">
  <label>Source text</label>
  {{field-picker process=process required=true allowText=true
    selectForms=false selectFields=true value=rule.settings.source}}
</div>
<div class="form-group">
  <label>Destination text field</label>
  {{field-picker process=process required=true allowText=false
    includes='["fields/field-textbox"]'
    selectForms=false selectFields=true value=rule.settings.destination}}
</div>
```

```javascript
import Ember from "ember";

export default Ember.Component.extend({
  async execute() {
    const process = this.get("process");
    const rule = this.get("rule");
    const source = rule.get("settings.source");
    const target = rule.get("settings.destination");

    if (!process || !source ||
        (source.type !== "field" && source.type !== "text")) {
      throw new Error("Copy text: select a source field or enter text.");
    }
    if (!target || target.type !== "field") {
      throw new Error("Copy text: select a destination text field.");
    }
    const destination = process.findFieldByRef(target);
    if (!destination) {
      throw new Error("Copy text: the destination field no longer exists.");
    }
    if (destination.get("type") !== "fields/field-textbox") {
      throw new Error("Copy text: the destination must be a text box field.");
    }
    if (source.type === "field") {
      const sourceField = process.findFieldByRef(source);
      if (!sourceField) {
        throw new Error("Copy text: the source field no longer exists.");
      }
      if (sourceField === destination) {
        throw new Error("Copy text: source and destination must differ.");
      }
    }
    const text = process.getFieldRefText(source);
    if (text === undefined || text === null) {
      throw new Error("Copy text: the source text could not be read.");
    }
    await process.setField(destination, String(text));
  }
});
```

This example limits the destination to `fields/field-textbox` in both the picker and executor. It compares resolved field models, because names alone do not distinguish fields in different table rows. Before reuse, verify the chosen textbox configuration and row context, and test the rule chain for indirect cycles. This example preserves an empty string as meaningful input; requiredness and business validation belong to the intended workflow. Add the normal Save rule if that workflow should persist the resulting instance. The documented Format text implementation provides a fuller configurable transformation. [R §§2,4–6; F §8]

### 6.4 Tables and background execution

For table-processing rules, validate source/destination tables, mappings and key columns before mutations. A table model exposes `rows`, `createRow()` and row `subFields` in the documented pattern. Table-row field names can repeat between rows, so field resolution and equality must respect row context and value type.

Process row-dependent operations sequentially. Capture and restore `rowContext`, `isInRowContext` and `secondaryRowContext` in `finally`, including after failure. Do not replace a previously existing secondary context with a guessed null default. Ensure callback-based condition evaluation is included in completion. Require valid keys for merge/unique modes and specify how complex values are compared; object identity is not semantic equality.

Custom rules can also run in scheduled tasks. Obtain business input from the supplied models and saved configuration. Avoid dialogs or waiting for user interaction, and verify that required services and remote access work in the scheduled environment. Headless suitability is a runtime check, not a consequence of omitting a template. [R §§8,10; P §4]
