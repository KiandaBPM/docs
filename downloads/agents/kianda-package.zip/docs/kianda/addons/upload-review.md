# Public upload field source review

Source-based topic reference from [custom-addon-knowledge.md](../custom-addon-knowledge.md). Original section numbers are retained for source citations; evidence status and unresolved qualifications are unchanged. Source labels and verification limits are in [addon evidence](./evidence.md#15-source-register).

## 11. Review of the supplied public upload field

The supplied `upload-public-file(1).js` and `.hbs` implement a **custom field widget**, not a rule. They demonstrate adapter/session use, a browser upload and field-picker mappings. They are an integration example with local assumptions; the corrected field-widget developer guide provides stronger recommended patterns. [U; F §9]

| Observed source behaviour | Required treatment when adapting it |
| --- | --- |
| Upload UI appears in both `edit` and `design` | Use a passive Designer preview; permit upload through an editable user action |
| Uses `window.event.target` | Pass the native event explicitly to the action |
| Resolves `field.process` with legacy `.content` unwrapping | Use the documented process relationship and handle asynchronous resolution/context changes |
| Hard-codes folder `induction-training` | Treat it as this application's choice; make a general destination explicit |
| Computes `isPublic` but sends `isPublic=true` unconditionally | The shown upload is public; do not claim it supports private uploads |
| Calls `ensureFolder` before checking that a file exists and ignores its success result | Validate prerequisites first and check folder-operation outcomes |
| Inserts folder parameters into URLs without consistent encoding | Encode configured path/name parameters using the actual endpoint contract |
| Assumes synchronous `session.authorize` callback | Verify that contract; await authorization if the target integration is asynchronous |
| Validates HTTP success but then accesses `result.files[0]` without full shape checks | Validate application success and the returned file reference |
| Writes utility fields without awaiting `process.setField` | Validate targets and await dependent writes |
| Leaves the uploader's own `field.text` and `field.value` unset | Deliberately define whether the control owns a value or is an action-only uploader; the display/required contract must agree |
| Has no component busy/error/lifetime strategy | Handle retries, pending state and late responses explicitly |

The template's `process=this.process` also requires verification because the documented field context is `field.process`, and the provided JavaScript does not establish a separate `process` property. Its target-filename setting is labelled “Target field Id”; clarify the label without renaming the stored setting during an unrelated edit.

The observed endpoints `/kianda-files/folder` and `/kianda-files/file`, their authentication pattern, and their response shape are integration dependencies. They are not a complete public files SDK contract for every deployment. The actual file upload can persist remotely even when the enclosing process is never saved. Do not retrofit rollback, private-file semantics or automatic orphan cleanup without the corresponding service contract.
