# Addon installation, checks and evidence

Source-based topic reference from [custom-addon-knowledge.md](../custom-addon-knowledge.md). Original section numbers are retained for source citations; evidence status and unresolved qualifications are unchanged. Source labels and verification limits are in [addon evidence](./evidence.md#15-source-register).

## 12. Installation, updates and compatibility

Updating reusable widget code in Developer compiles it with Babel and produces source maps in the documented workflow. That differs from saving the configured use, publishing a process/page definition and saving an instance. Follow the workspace extension's actual publishing contract; local file save behaviour, asset propagation and cache invalidation are not established by these guides.

Changing shared component code can affect many existing uses. Retain saved settings and value shapes, initialize only missing defaults, and identify affected templates, processes and pages. If a migration is necessary, document its scope and verify representative retained configurations. Validate the enclosing process/page against its schema as well as reviewing the addon contract.

Do not infer automatic component installation, version pinning or settings migration from the existence of a source file. Resolve the installed registration and required assets. Preserve unknown outer metadata, while recognizing that permissive schema acceptance does not guarantee serializer retention. [F §12; R §11; W §§1,14; P §12]

## 13. Verification and completion

Select checks that address the changed behaviour:

| Area | Verification |
| --- | --- |
| Configuration | Required input, saved defaults, reopened settings, invalid/removed references, no duplicate listeners |
| Field | All four views; text/value agreement; clearing; required validation; rule notification; disable/hide/navigation during pending work |
| Rule | Correct attachment context; fully awaited work; failure followed by dependent rules; partial updates; scheduled operation where required |
| Page | Settings/runtime separation; initial load; zero/empty/error; change and clear filters; rapid refreshes; leave during a pending query |
| Shared component | Two simultaneous instances; independent DOM IDs, state and aggregate identities |
| Reporting | Exact field types/projections, paging, permissions, relative dates and indexing delay |
| Persistence | Save through the intended workflow, reopen, and verify retained values/configuration |
| Presentation | Responsive layout, keyboard operation, labels and useful loading/error/read-only states |

Use generated source maps and browser/Ember tooling for runtime diagnosis. Breakpoint a rule in `execute`, not an insertion hook. Investigate summary failures through the documented `support/logs` category `Instance | Summary find(Query)`. Do not convert failures into a successful empty list or zero tile.

For a substantive change, update [CHANGELOG.md](../../../CHANGELOG.md) and current addon documentation with behaviour, affected identifiers/files, settings/value compatibility, checks performed, limitations and any publishing or migration steps. Keep “syntax checked”, “compiled”, “runtime tested” and “published” distinct. This guide itself was assembled from supplied material and static source review; runtime integration checks remain deployment-specific.

## 14. Future addon contracts and remaining limits

The process/page packages propose trusted, version-matched addon settings schemas as a future capability. They do not implement an addon registry or side-loading protocol. A future contract could identify an exact runtime type and its settings schema, stored value shape, supported references, filter participation, dependencies and migration rules. Validate the common envelope first and then a trusted matching addon contract.

An unknown addon must remain distinguishable from a known addon with invalid settings. Preserve opaque settings and report incomplete coverage; use the confirmed page-widget warning policy and the explicit host policy for fields/rules. Do not bypass known checks via an opaque fallback or add proposed registry metadata to saved process/page JSON. [P §12; Q §17]

Remaining boundaries include the exact installed service/helper/library inventory, full custom connector contracts, authentication timing for the uploader, private-upload semantics, widget update propagation, extension v2 publish behaviour, and current runtime verification of each example. Resolve those from the target implementation when a task depends on them. Do not invent new hooks, commands, registry endpoints or automatic rollback behaviour.

## 15. Source register

| Code | Supplied source | Main evidence |
| --- | --- | --- |
| F | `field-widget.md`, “Field widget development” | Four modes, hooks, values, notifications, settings validation, child fields, async integrations and corrected upload patterns |
| R | `rule-widget.md`, “Rule widget development” | Runtime context, execute completion/error semantics, field APIs, settings validation, table processing and scheduling |
| W | `page-widget.md`, “Page (Dashboard) Widget Development” | Host/model, settings branch, refresh/filter behaviour, query identities, lifecycle, navigation and dependencies |
| S | `summaries(1).md`, “Summaries API” | Server/client query distinction, projections, indexing, permissions, conditions, pagination and aggregates |
| U | `upload-public-file(1).js` and `upload-public-file(1).hbs` | Existing application-specific field implementation; limitations reviewed in section 11 |
| P | `kianda-process-schema-v1.1.0(1).zip`: `process-knowledge.md`, `kianda-process-schema.json` | Process envelopes, type prefixes, references, table scope, current styling keys and extensibility limits |
| Q | `kianda-page-authoring-v1.0.0(1).zip`: `page-knowledge.md`, `kianda-page-schema.json` | Page envelopes, conditions, field types, filter contracts, custom-column contexts and V1 authoring policy |

The `(1)` suffixes identify the uploaded source filenames and have no runtime meaning. The intended installed schema names are `process-schema.json` and `page-schema.json`. Sibling links assume the complete knowledge set exists under `docs/kianda/`; the source developer guides and reference implementations need not be duplicated into that directory for these links to work.
