# Kianda custom addons — entry guide

Source guide **1.0.0**, prepared **27 October 2026**; navigation reorganized **4 November 2026**. Baseline: supplied **Ember 2.18** developer guides, accepted process **1.1.0**, page **draft 1.0.0**. Examples are source-based and were not certified in a live workspace.

A custom addon is an installed classic Ember JavaScript/Handlebars component with per-use `settings`. It is distinct from a reusable **Component process** loaded by `fields/field-component`. Resolve the exact registered identifier, source/templates, saved settings and consumers before changing it; a source file or an open schema does not prove installation.

## Host contracts

| Concern | Custom field | Custom rule | Custom page widget |
| --- | --- | --- | --- |
| Runtime identifier | `client-field/<component-id>` | `client-rule/<component-id>` | `client-widget/<component-id>` |
| Enclosing definition | Process field `type` | Process rule `action` | Placed page widget `type` |
| Primary responsibility | Render and edit field data | Perform a business action | Present information, query data or provide navigation |
| Configuration owner | `field.settings` | `rule.settings` | `widget.settings` |
| Model data | `field.text`, `field.value`, or deliberate child fields | Supplied process/form/field models | Query results normally remain component-local |
| Template | `design`, `edit`, `display`, `settings` views | Designer settings UI; not rendered for runtime execution | `settings` branch; otherwise page content |
| Runtime entry | Rendering, actions and lifecycle | `execute()` | Lifecycle and actions such as `refresh` |
| Host awaits asynchronous completion? | Field mode hooks are not awaited | Returned Promise from `execute()` is awaited | `actions.refresh` is not awaited |
| Persistence owner | Process save/commit workflow | Normally a process Save rule | Page designer saves configuration; instance mutations require their own workflow |

For a custom placed page widget, use `isCustom: true` as required by the supplied page schema. Do not copy that property onto other entity kinds without their own schema contract.

These prefixes identify the implementation to resolve; they do not prove that it is installed. An open settings schema does not create a component or establish its capabilities. The reusable component ID is also different from the GUID of an individual field, rule or placed widget. Multiple placed widgets can use the same component with independent settings and identities. [F; R; W; P §§6,12; Q §§7,17]

**Critical execution boundary:** rule `execute()` is awaited, its return value is ignored, and thrown/rejected errors **do not stop subsequent rules**. Use explicit verified outcome conditions for dependent actions; earlier field writes and external effects are not rolled back. Field mode hooks and page `actions.refresh` are not awaited. [Rule execution](./addons/rules.md)

## Read by changed behaviour

| Task | Direct reference |
| --- | --- |
| Ember lifecycle, per-instance state, defaults, async cleanup or Designer controls/validation | [Shared implementation](./addons/shared.md) |
| Field modes, text/value notifications, required input, child fields or field-picker APIs | [Fields](./addons/fields.md) |
| Runtime rule context, failure/Promise handling, table rows or scheduled execution | [Rules](./addons/rules.md) |
| Custom page host, settings/runtime views, refresh/filter state, request concurrency or global navigation | [Page widgets](./addons/page-widgets.md) |
| Query `POST /api/summaries` / `store.query`, projections, IDs, paging, dates, permissions or indexing | [Summaries](./addons/summaries.md) |
| Adapt the supplied public uploader | [Upload source review](./addons/upload-review.md) |
| Compile/publish/update compatibility, targeted checks, future schemas or source evidence | [Installation and evidence](./addons/evidence.md) |
| Place field/rule config into a process | [Process entry](./process-knowledge.md) and [process schema](./process-schema.json) |
| Place/configure a page widget | [Page entry](./page-knowledge.md) and [page schema](./page-schema.json) |
| HBS **list-column** helpers/actions | [Column context](./page/templates-navigation.md), which is separate from a standalone addon |
| Change presentation | [CSS entry](./css-style-guide.md) |

Keep classic `Ember.Component.extend`, Handlebars and the installed Bootstrap 3 environment. Do not introduce Octane or newer-library APIs by assumption. Preserve intentional `false`, `0`, empty strings, exact stored values and unknown settings; initialize only missing options, and specify migrations before changing stored value shape/meaning. Use the correct settings owner, not the triggering field as rule configuration.

Keep each configured instance's DOM resources and asynchronous state separate.

A local source edit, Developer compilation, saved configured use, published definition and saved runtime instance are different operations. Follow the actual extension workflow and root change-record policy. Select runtime checks by changed behaviour; report unavailable target-runtime evidence explicitly.
