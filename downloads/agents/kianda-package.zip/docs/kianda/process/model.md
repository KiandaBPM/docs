# Process model and identity contracts

Read for structure, cloning/renaming, form configuration, table names or reusable Components. Baseline: accepted schema `1.1.0`; source labels are defined in the [evidence register](./evidence.md).

## Containment and the accepted profile

The root owns `forms[]` and optional `rules[]`; forms own `fields[]` and optional `rules[]`; fields recursively own `fields[]` and attached `rules[]`. Inputs, buttons, panels, dialogs, tables, rows, static content, groups and reusable wrappers all use the field model. Recurse only through these actual entity collections. For example, `fields/field-group.settings.fields[]` contains descriptors of existing fields, not children; an arbitrary settings key named `field` or `fields` proves no ownership.

**Confirmed (C2026):** at least one form is required; the server rejects none. A definition with exact root `type: "Component"` has exactly one form. The accepted whole-document schema requires root `name`/`forms`, form `id`/`name`/`fields`, field `id`/`name`/`type`, and rule `id`/`action`. These are profile presence decisions, not a claim that every historical/partial serializer requires them.

Entity collections must be arrays and entity/settings nodes must be non-null objects when present. Empty hashes occur. Historical P0 null construction states are outside this profile; principal collections have their own compatibility rules. Missing, null, empty string, array and object are distinct; validation fills none of them. Field-specific options belong in field `settings`; rule settings belong to their rule. [H §§3, 5, 8.1, 8.5, 10; C2026; A–O; SC]

## Process aliases and entity IDs

Root `id` and `name` alias the process identifier, normally a readable dasherized name, not an entity GUID. The user can override a title-derived proposal. Allowed characters, case, reserved words and normalization are not fully specified. All five current exports have equal aliases; older H examples omit `id`. Preserve accepted historical representation during edits. When both aliases exist, check equality; availability requires workspace context.

**Confirmed:** form, field and rule GUIDs are unique within the process app. The corpus's 1,888 entities have GUID-shaped IDs with no duplicate entity ID in an app. Repeating an ID in a descriptor is a reference. Preserve existing identities; a clone needs new entity GUIDs and rewritten references to those clones. Do not rewrite principals, external-process/data source IDs or template IDs merely because they resemble GUIDs. Rule `originalId` has separate, incompletely specified lifecycle semantics.

**Groups:** direct-rule condition groups need GUIDs because Ember Data loads them as separate models (C2026). Settings query-filter groups managed by `rules/rule-conditions` also need GUIDs for UI deserialization/editing (C2026-23); those IDs are not an intrinsic server requirement for the filters. Preserve group IDs and allocate fresh ones for known new groups. `1.1.0` enforces them in direct groups and applicable typed query filters; inactive alternate settings bypass subtype checks. Individual condition-ID requiredness, exact group uniqueness boundaries and cross-model collisions remain unresolved. Avoid new in-document group reuse as a conservative policy, not a claimed workspace-wide contract. Do not apply it to arbitrary tenant settings.

## Logical names and contextual resolution

Preserve existing names, including uppercase prefixes, underscores, hyphens and `?` suffixes. A title change does not authorize renaming: expressions, mappings, tokens and name-only references may depend on names.

**Owner-confirmed field-name scope (C2026):**

| Field location | Required comparison scope |
| --- | --- |
| Inside a table row | Every field of that row, including descendants of panels/containers. Corresponding fields in different repeated rows can share names. |
| Outside every table row | Every field in the process, including fields inside rows. |
| Inside a Component | The same rules; a Component supplies no independent name namespace. |

This is not sibling-only uniqueness. An ordinary duplicate outside its permitted scope is an integrity error, not an invitation to auto-rename. The confirmation concerns field names: a form and field sharing a string is not itself a proven violation. Resolve descriptor kind, ID, name, process and row/parent context together. Do not silently take a first match. Deeper nested-name resolution still needs the correct containment context. [H §§4, 15, 16.2, superseded by C2026; C2026-23]

## Process and form configuration

Keep labels, aliases, design versions, metadata, workflow state and security separate.

| Property/context | Contract or evidence limit |
| --- | --- |
| Root `version` | Process/design version, not schema dialect or Component version. |
| Completion | Root `completed` is boolean; form `completed` is a date-time string with separate boolean `isComplete`. |
| Root flags | Current `deleted`, `rejected`, `publish`, `isDraft`, `allowNew`, `isPartner`, integer `MajorVersion`/`MinorVersion` do not establish defaults. |
| Root `type` | Four exports and SC use `"Process"`; I omits it. For a new Component use exact `"Component"`. Missing/unfamiliar type is not evidence of a Component. |
| Process settings | Execution order, navigation, comments, notifications, anonymous access and more. Example `keepRuleExecutionOrder` is a string; `buttonDisplayFlag` is boolean. Choose consequential access/deletion/notification options deliberately. |
| Form ownership | Current `/forms/N/process` matches the root alias. Forms have workflow/presentation and ownership/security properties, plus fields, rules and settings. |
| Historical form fields | Current forms omit `status`, `completedBy`, `partnerHide`; older H exports retained them. Neither presence nor omission is universal requiredness. |
| `activateWith` | Form **name**, not automatically a GUID; empty/absent is accepted and older examples also show null. |
| `submitMode` | Observed `single` and `all`; exhaustive values and complete semantics are unavailable. |
| `currentForm` | Populated contract unresolved. Hidden utility forms remain in reference indexes. |
| Form settings | Examples: `allowEdit`, `allowReassign`, `enableActions`, `hideFooterButtons`, `allowOwnerEdit`, `enableRulesOnSave`, custom-action configuration. Empty settings occur. |
| Principals/references | Settings user lists can contain rich principal objects; simpler ID arrays occur elsewhere. Resolve `customActionField` and other references semantically. Preserve security; schema validity does not establish permission. |
| Instance IDs | `customInstanceIDFormat` may reference field names and is separate from the process alias. EHSwise support fields are application conventions, not mandatory core properties. |

[H §§6–7; C2026; A–O roots/forms/settings; SC]

## Tables and generated row names

Tables contain `fields/table-row` entities with columns/nested containers beneath them. Multiple rows are supported; A `/forms/3/fields/7/fields/12` has two. Do not flatten them or require exactly one. Table `pagesize` is lowercase; the corpus has 13 integer and five string instances. Preserve each wire representation.

**Confirmed creation formula (C2026-23):**

```javascript
var name = table.get('name') + '-row' + rowIndex;
```

Use the containing table's name, literal `-row` and correct allocated index for a newly generated row. This creates a logical name, not a GUID. The example does not establish zero/one origin, contiguity, array-position equality, bounds or a universal numeric grammar; obtain the appropriate allocation contract.

Different table instances under different outer rows can have the same table name and generated row name. Keep instance context. All 19 observed rows are direct children of 18 tables and have unique names within their table instance. Eighteen row names do not match their current parent's prefix; the cause is unproven. The formula is a creation rule, not a proven invariant after table renames. Retain existing names. Prefix comparison is an informational diagnostic requiring edit history, not a newly proven error. This resolves I's earlier repeated-internal-row-name warning; it does not resolve the four ordinary-field duplicate groups in E/I/O. [C2026-23; A–O]

## Reusable Components

**Confirmed (C2026):** a Component is a process-shaped definition with `type: "Component"` and exactly one form. The platform loads the first form's field contents into a parent `fields/field-component` during design or runtime. It introduces no page/widget model.

`field.settings.componentId` is the referenced **Component process ID**, not the wrapper GUID or `fields/field-component`. The platform records that Component's `MajorVersion` in loaded `settings.version`; never substitute parent `MajorVersion` or root `version`. The server automatically upgrades updated Components based on their loaded version.

Create/resolve the dependency and its one-form shape; use the supported load/update mechanism. Do not require hand-authored expanded children because exports have them, or simulate upgrades by replacing trees. Preserve loaded subtrees during unrelated edits. Observed `componentName`, `componentLoaded` and `hideShowComponent` can appear on wrappers and some panels; none is made universally mandatory by observation. Cloned descendant identities, local-customization preservation and rule `originalId` through upgrades remain unverified. [H §§9.5–10; C2026]
