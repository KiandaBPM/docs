# Annotated Incident design reference

## Evidence boundary

Selected export: `incident(1).json`, alias `incident`, design version `136.0`, serialized modified `2026-01-13T14:35:23.117Z`; inspected 29 October 2026. SHA-256: `c4b25bf10d728028729f9077758ac42d40e08a739cda4a8ae9c2ef1e6f60ae41`.

This is a historical snapshot, not the latest live app. Observations cover form inventory and selected classification/visibility rules, not a complete audit/runtime test. JSON Pointers identify these exact bytes; lessons are recommendations, not proof of the original designer's reasoning or a universal template.

## Form architecture

| Title | Logical name | Serialized visibility |
| --- | --- | --- |
| Classification | `form1` | Visible |
| Circumstances | `form4` | Visible |
| People | `people` | Hidden |
| Authorities | `authorities` | Hidden |
| Assets | `assets` | Hidden |
| Cost | `cost` | Hidden |
| Quality | `quality` | Hidden |
| Environment | `environment` | Hidden |
| Security | `security` | Hidden |
| Investigation | `investigation` | Hidden |
| Summary | `FORM_OBS_Summary` | Visible |
| _Utility | `FORM_OBS_Utility` | Hidden |

Source `/forms/0`–`/forms/11`. Saved flags do not establish runtime editability, ownership or ordering. The reusable pattern is a reporting backbone, conditional information areas and a utility surface; it does not prescribe twelve forms.

## Selected decisions

| Observed configuration | Exact pointer | Reusable lesson |
| --- | --- | --- |
| Incident Type radio: Near-miss, Incident, Accident | `/forms/0/fields/2` | Early exclusive classification can shape later work; categories still need a domain requirement. |
| Show Damage Type reveals a detail container/title for Incident or Accident | `/forms/0/fields/2/rules/1` | Branches can affect sections within a form. |
| Damage-type checkbox: Assets, Quality, Environment, Reputation, Security | `/forms/0/fields/4/fields/0` | Overlapping categories need multiple concurrent branches. |
| Category rules target Assets, Quality, Environment, Security | `/forms/0/fields/4/fields/0/rules/1` through `/rules/4` | Whole information areas can be conditional. |
| Show Cost tests Assets OR Security with explicit show/hide | `/forms/0/fields/4/fields/0/rules/5` | Shared downstream targets need combined predicates/combination tests. |
| Reportable to the authorities controls Authorities | `/forms/0/fields/9/fields/1/fields/0/rules/0` | Separate policy decisions can add work; a toggle does not establish legal reporting duties. |
| Investigation controls Investigation | `/forms/0/fields/9/fields/3/fields/0/rules/0` | Resolve applicability, lifecycle and ownership separately. |
| Project-related selection shows on true, `hideAndClear` on alternate | `/forms/0/fields/5/fields/0/fields/1/fields/0/rules/0` | Hiding and clearing have different consequences; do not copy clearing policy indiscriminately. |

## Review cautions

Several rules write the same state: Incident Type initially hides several forms; Assets also writes Cost; a later Show Cost combines Assets/Security. Trace ordering, initialization and every writer; this is a review prompt, not proof of a runtime defect.

Damage choices omit People, yet an attached rule checks People. Incident Type also affects People for Accident. Check runtime choices, mapped/historical values and policy before retaining/removing/consolidating; do not silently repair the source while borrowing its pattern.

Initial Next uses `client-rule/go-to-next` at `/forms/0/fields/0/rules/0`. It is a tenant dependency, not proof of a native action or automatic skipping of all hidden forms. Retained `hasElse: false` alternatives are inactive; apply the [confirmed false-default/same-action contract](./rules.md#alternate-settings).

Extract and validate an explicit design contract from this case. Keep app-specific decisions in its blueprint and reusable lessons in the design references. [Acceptance scenarios](./design-review.md)
