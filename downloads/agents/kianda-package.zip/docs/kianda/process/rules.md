# Rules, expressions and references

Read for logic, action configuration, conditions, scheduling or dependency edits. Baseline `1.1.0`; [source labels](./evidence.md).

## Choose the implementation mechanism

For calculations/derived values, prefer native Set form field (`rules/rule-setfield`) with an expression. A short inline JavaScript expression suits clear local work. Reusable or independently testable logic can use an appropriate global helper in `js/app.js` called from the expression; that helper may return a value or a Promise. Keep value assignment in the native rule where practical; prefer explicit inputs/returned outputs over hidden state mutation.

JavaScript, multiple steps, reuse or asynchronous work alone do not justify a new custom rule, component, API endpoint or service. Identify the actual unsupported requirement, considering security, execution context, lifecycle, scale and maintenance. Verify expression settings, field references, helper availability, result types, recalculation triggers and failure/Promise behaviour in the target implementation. Do not invent async evaluation semantics. Preserve existing working implementations during unrelated work; this native-first policy does not authorize migration. (Retained builder-skill authoring policy.)

## Identity, attachment and execution

`action` selects implementation; a rule GUID is identity and `title` is descriptive. Do not invent a rule `name`. Preserve `originalId` separately; its complete lifecycle is unresolved. `datasource` can be a GUID-shaped identifier or a named token.

Root `rules[]` attaches process rules; field `rules[]` attaches field rules; form rules remain structurally supported. Current process rules put the process alias in `process`; field rules put owner GUID in `field`; current `form` ownership keys are absent. Historical relationships sometimes retain nulls. Do not require/fill all three references; check actual containment and attachment. [H §11; A–O]

Preserve array order, particularly with `keepRuleExecutionOrder`. Save, Submit, Close, Assign, Validate and Navigate are separate operations. The custom-rule contract documented in [the application model guide](../general.md) waits for a returned Promise, ignores its return value and continues after a thrown error/rejected Promise. Gate dependent saving, submission, notification or navigation explicitly. This does not establish every native validation action's stop behaviour, complete asynchronous runner semantics or transactional rollback. Verify those separately.

Implement initial load, changes/reversal, draft reopening and direct navigation through verified lifecycle hooks. Presentation recalculation should be safe to repeat; do not make each recalculation create records, send notifications or repeat external requests. Effective applicability must govern validation, completion, calculations and reporting. Preserve the agreed data-reversal policy, including derived values and related actions. [Designer contract](./design-journeys.md)

## Alternate settings

**Confirmed (C2026-23):** server `hasElse` is boolean and defaults to false when omitted. `elseSettings` is alternate configuration for the **same action**, not a separate action. Omitted/false leaves it operationally inactive; C2026 confirms ignored operational validity in that state. Preserve retained inactive targets/options without “repairing” them. Do not coerce string flags or insert an absent flag during validation.

Schema `1.1.0` applies action-specific alternate-settings constraints only for explicit `hasElse: true`; a present `elseSettings` still must be an object. A schema pass therefore does not certify editor readiness of every inactive retained query filter. SC's omitted flags demonstrate compatible serialization, not a runtime test.

## Scheduling

Outer `schedule` differs from `settings.task.schedule`. H observes outer `default`; tasks use `now`. Neither is an exhaustive enum. **C2026 confirms an executing schedule needs a field or rule target** in the observed `settings.target`; field targets are not button-only (H includes a date target; schema commentary also records list/number targets).

**C2026-23 exact supplied rule-target descriptor (ST):**

```json
{
  "text": "Save form",
  "name": "a0bbe568-c130-4fae-a886-7e7e176bb790",
  "type": "rule",
  "parentName": "btnSave",
  "parentType": "field"
}
```

`name` is the target **rule GUID**, matching SC `/forms/0/fields/0/rules/0/id`; `text` is a label. `parentName` is the target owner's logical name; `parentType` its kind. Do not invent target `id` or replace `name` with a title. The example establishes `parentType: "field"`, not an exhaustive kind enum or universal parent-key requiredness.

The owner excerpt's scheduling rule attaches to SC's textbox (`/forms/0/fields/1`); its target save rule belongs to `btnSave`. Source attachment and target parent are separate references. The excerpt uses `rules/rule-schedule`, `enabled: true`, outer `schedule: "default"`, a task with `settings: {}`/`schedule: "now"`, empty `conditions`/`elseSettings` and `hasElse: false`. It lacks an outer rule ID and has a trailing comma, so only ST's descriptor is a fixture, not a complete rule/app.

Schema checks a present rule-target `name` as a GUID when `type: "rule"`; it deliberately does not require all active target keys in every disabled/incomplete serialization. Existence, completeness and parent agreement remain operational/integrity checks. Do not add an unobserved `settings.rule` property. [H §11.6; C2026; C2026-23]

## Conditions and descriptors

`rule.conditions[]` contains groups, each with `conditions[]` and operands `arg1`/serialized `arg2`. The accepted direct condition shape requires `operator` and `arg1`; direct groups require GUID `id` and a `conditions` array (empty is not rejected). Individual condition-ID requiredness and recursively nested groups are not established. Preserve `group` connectors; complete evaluation, arity and group-token semantics need the engine contract.

Observed direct operators: `contains`, `eq`, `neq`, `gt`, `gte`, `lt`, `lte`, `isblank`, `notblank`; connectors: `and`, `or`. These are not exhaustive enums. Do not import page/query operators as proof of direct-rule support.

Operands can be sparse field, literal or system descriptors. Unary examples include 59 empty `arg2` objects and 164 containing only `{"name":""}`; A `/forms/0/fields/1/rules/0/conditions/0/conditions/0/arg2` is empty. Do not require `type`, `text`, `fieldType`, `id` or dummy date/value keys on every operand.

| Descriptor context | Meaning/limit |
| --- | --- |
| `type: "field"` | Reference kind; target component type can appear as `fieldType`. |
| `type: "form"` | May use logical name without ID. |
| Scheduled `type: "rule"` | `name` holds rule GUID, with target-parent context above. |
| System | Can use `__Field`. |
| Literal | Can carry `type: "text"` and text. |
| `settings.list` source selection | Integer `type`, e.g. `100`/`101`, is connector/source metadata, not a reason to widen every descriptor kind. A `/forms/2/fields/8/fields/1/fields/1/settings/list/type` is `101`. |

A closed universal descriptor union is premature. Resolve by action, kind, process and row/parent context.

Settings-level filters contain a separate observed 94 groups/138 conditions. Groups edited by `rules/rule-conditions` need GUIDs for UI deserialization/editing (C2026-23), even though the server does not intrinsically need them. Schema applies that contract only in known typed settings; `FilterGroup` requires `id`, not universally `conditions`. Inactive else branches bypass subtype checks. Keep query contexts/operators/counts distinct from direct conditions and arbitrary settings objects; individual query-condition ID requiredness is also unconfirmed. [H §§12–13; C2026; C2026-23]

## Mapping and dependency semantics

Mapping families (`inputMapping`, `outputMapping`, `errorMapping`, `tableMapping`, nested `columnMapping`, action-specific `mappings`) are not interchangeable. Set-field normally uses `left` for destination and `right` for source; cross-process mappings need separate source/target context.

**Confirmed left-only clear (C2026):** a `rules/rule-setfield` output entry with only `left` and no expression clears its destination. It is complete for that purpose; do not add a dummy right operand/expression. A `/forms/1/fields/2/fields/1/rules/0/elseSettings/outputMapping/0` is an example. Other entries omit `right` in favour of `expression`/`hasExpression`, e.g. A `/forms/0/fields/1/rules/2/settings/outputMapping/0`.

Find-items `inputMapping` can contain empty placeholders; an empty placeholder is not thereby a clear operation. Required-field and person-attribute mappings have other shapes. Preserve optional editor metadata such as `lefterror`/`righterror` without requiring it everywhere.

Review name dependencies in expressions, `[fieldName]` tokens, custom code and affected page bindings/CSS selectors during renames. H examples include `GetFieldValue(...)`, `ProcessID()`, `User()`, `QueryString(...)`, `IsOnline()`, `createGuid()` and `process.findFieldByName(...)`; their names do not establish standard JavaScript behaviour.

Resolve external processes, data sources, Components, files and principals through authorized workspace information. A queried-process descriptor must not be rewritten to a similarly named local field. Email recipients can encode selection modes/field references; attachment/document-template values may be descriptors rather than URLs. Recipients can retain `field: null` in other modes. Four inactive alternate visibility actions retain null targets with `hasElse: false`; preserve them. Active unresolved targets need completeness checks. [H §§11.4, 13; C2026; A–O]

## Observed action families

The corpus has 38 distinct actions. This table describes observed coverage, not exhaustive component settings or availability.

| Action(s) | Configuration concerns |
| --- | --- |
| `rules/rule-setfield` | `outputMapping`; source/destination descriptors, expression or left-only clearing |
| `rules/rule-hideordisable`, `rules/rule-makerequired` | Target/action entries; form or field targets |
| `rules/rule-validation` | Message and conditions; native stop behaviour needs evidence |
| `rules/rule-save`, `rules/rule-submit`, `rules/rule-close`, `rules/rule-delete` | Distinct operations; empty settings can occur |
| `rules/rule-assignform`, `rules/rule-gotoform` | Form descriptors, singular/plural collections, mode-specific pickers |
| `rules/rule-schedule` | Nested task, field/rule target, optional order/uniqueness settings |
| `rules/rule-finditems`, `rules/rule-startprocess` | Query, mappings, external process; start-process can perform lookup |
| `rules/rule-addrow`, `rules/rule-removerow`, `rules/rule-looptable`, `rules/rule-tablesum` | Table/column/result references; data-row actions differ from definition edits |
| `rules/rule-addtime`, `rules/rule-calculatetime`, `rules/rule-dateformat` | Date references, units/format |
| `rules/rule-finduser`, `rules/rule-personattribute` | Principal/profile mappings |
| `rules/rule-copyfile`, `rules/rule-generatedoc` | File descriptors/output destinations |
| `rules/rule-sendemail`, `rules/rule-alert` | Recipients/targets, content and delivery |
| `rules/rule-anonymouslink` | Lifetime/use settings and descriptors; permission is external |

Observed tenant actions under `client-rule/`: `client-rule/custom-id`, `go-to-next`, `go-to-previous`, `open-form-dialog`, `set-process-status`, `question-custom-answers`, `question-custom-score`, `show-hide-related-questions`, `set-field-title`, `append-user`, `clear-user-picker`. They are dependencies, not portable native capabilities or permission to guess settings. [H §11; A–O; SC; ST]
