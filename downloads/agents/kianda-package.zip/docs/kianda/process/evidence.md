# Process evidence register

Read for provenance or historical discrepancies; ordinary edits can use the relevant technical reference directly. This preserves the source boundaries of accepted process schema/knowledge `1.1.0` (23 October 2026), branding revision 1, and the draft design guide `0.1.0` (29 October 2026). The compact documentation revision does not promote the design draft or change the schema. No Kianda application/skill was executed in a target workspace when those guides were prepared.

## Authority and sources

Latest **Confirmed** owner statements supersede earlier conflicts. **Documented** internal guidance applies within its stated scope and workspace overrides. **Observed** exports/fixtures show serialization; screenshots establish appearance only. **Historical** declarations are not current defaults. **Proposed** authoring/validation choices are policy, not deployed behaviour. **Unresolved** points need evidence, with data preserved meanwhile.

Source names below identify the preparation corpus, not guaranteed files installed in this bootstrap. Pointers refer to those exact snapshots; do not read a different revision at the same pointer as equivalent evidence.

| Label | Source and limits |
| --- | --- |
| H | `kianda-process-schema.md`, numbered sections, owner U1–U5 statements and historical P0/P1–P3 material. The older Json.NET schema and inventory were described, not directly compared against actual files. |
| C2026 | Owner follow-up, 22 October 2026: accepts `kianda-process-schema.json` as the first version; confirms field-name scope, number bug, string/default settings, group GUIDs, `class`, runnable rules and Component loading/versioning. |
| C2026-23 | Owner follow-up, 23 October: confirms boolean `hasElse` default false, query-filter UI GUIDs, a rule-target descriptor and row-name generation. Supersedes corresponding v1.0.0 gaps. |
| CB | Owner branding request, 23 October: professional, authoritative, clean apps using Material principles, hierarchy, whitespace, responsive layouts and consistent typography. |
| B | `Kianda Process Apps Styling Guide.docx`; field class table rendered pages 1–2, global `app.css` and workspace overrides page 3. |
| BV | `branding example.png`; no app JSON, stylesheet, computed styles or interaction states supplied. |
| A / E / I / IN / O | `action.json`, `event.json`, `incident.json`, `inspection.json`, `observation.json`. Current I/O differ from H's older examples. |
| S | Raw `simple-app.json`; invalid JSON because a comma is missing after the second button rule's `elseSettings: {}`. Source unchanged. |
| SC | Explicit derivative `fixtures/simple-app.syntax-corrected.fixture.json`, adding only that comma. All bare-app pointers refer here; syntax repair is not runtime/design validation. |
| ST | `fixtures/schedule-rule-target.owner-example.json`, exact C2026-23 target descriptor. Surrounding scheduling excerpt is partial, lacks outer rule ID and has a trailing comma. |

## Corpus counts and observations

| Source | Forms | Recursive fields | Rules | Direct rule groups | Direct conditions |
| --- | ---: | ---: | ---: | ---: | ---: |
| A | 4 | 122 | 110 | 53 | 58 |
| E | 4 | 169 | 117 | 62 | 77 |
| I | 12 | 385 | 264 | 144 | 174 |
| IN | 6 | 209 | 181 | 92 | 115 |
| O | 4 | 167 | 134 | 78 | 93 |
| Total | 30 | 1,052 | 806 | 429 | 517 |

Counts follow actual containment: descriptors are excluded from fields; query filters are excluded from direct conditions. There are 1,034 direct operands, 35 process-attached and 771 field-attached rules, with no form-attached rule observed. Absence does not remove supported form rules. Query filters separately have 94 groups/138 conditions. All 1,888 form/field/rule IDs are GUID-shaped and unique within each app.

Ordinary-field duplicate groups (four in E/I/O) remain distinct from repeated generated row names in separate table instances. Example A `/forms/3/fields/7/fields/12/fields/0/fields/0` and its second-row counterpart illustrate permitted repeated row-field names. The 19 rows under 18 tables are unique within each table; 18 current prefixes differ from parents without proven cause. [Model limits](./model.md)

Eleven `showArrows: "c"` occurrences are confirmed bugs; exact casing/types and empty values remain meaningful. Counts for values, textbox modes and relevant field examples live with [field contracts](./fields.md), avoiding another normative catalogue here.

## Bare-app omission fixture

C2026 describes S as one form, one textbox and one button. Corrected SC has one form/two fields, with button rules ordered `rules/rule-save` then `rules/rule-close`. Textbox settings are empty and its child `fields` is omitted; close omits `conditions`; both rules omit `schedule` and `hasElse`.

These are omission/default fixtures, not a reason to fill every historical model property. Empty settings do not establish that every native field/action runs without configuration. Fixed identities, timestamps and values are evidence, not new-app defaults. Raw S must fail parsing; only SC can proceed to schema validation. Neither was executed. [SC `/forms/0`, `/forms/0/fields/0/rules`, `/forms/0/fields/1`; H §§1–4, 16–18]

## Design-source register

The owner discussion of 29 October establishes complementary designer/builder roles, visual process design, forms versus dynamic sections and Incident as a reference pattern; it does not settle every runtime setting. `general.md` 1.0.0 and `css-style-guide.md` 1.0.0 (27 October) supply application/extension/reporting and presentation boundaries; their target runtime was not independently executed. Process knowledge is accepted `1.1.0`, branding revision 1. The selected `incident(1).json` version 136.0 is a separately fingerprinted historical example; see [its case reference](./incident-reference.md), not the unqualified I alias above.
