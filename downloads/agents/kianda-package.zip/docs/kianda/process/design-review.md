# Design acceptance scenarios and readiness

Choose checks relevant to the change. Make important branches executable where existing tooling permits; invent no uninstalled test framework. Small critical decision sets can use exhaustive combinations; larger sets should prioritize overlaps, dependency boundaries and consequential paths, with coverage limits recorded.

| ID | Scenario | Expected observation |
| --- | --- | --- |
| D01 | New record, no classification | Clear initial task; unknown is not silently negative/completed. |
| D02 | Each primary classification | Intended forms, sections and actions apply and are reachable. |
| D03 | Overlapping categories | Relevant branches coexist; unrelated ones stay inactive. |
| D04 | Every OR combination, both and neither | Shared targets follow the truth table. |
| D05 | Select/deselect in different orders | Same final inputs/context yield the same intended state. |
| D06 | Change parent with populated children | Agreed data treatment; stale values cannot drive inactive work. |
| D07 | Reactivate populated branch | Values and completion behave as designed. |
| D08 | Save/reopen important branch states | UI reconstructs without depending only on fresh change events. |
| D09 | Backward/direct navigation or current-branch removal | Valid, understandable destination/path remains. |
| D10 | Submit missing applicable data; leave inactive data empty | Correct action blocked/allowed; errors reachable. |
| D11 | Validation/save/upload/required external action fails | Explicit success gates and clear data/retry behavior. |
| D12 | Reopen/retry/double-activate consequential action | No unintended duplicate records or repeated effects. |
| D13 | Relevant participants/permissions | Actual access and UI match; hiding is not the security test. |
| D14 | Existing record with old answers/lifecycle | Compatibility or explicit migration/review path. |
| D15 | Narrow screen, keyboard, long/populated content | Reading/focus order, labels, wrapping and actions usable. |
| D16 | Disconnect/reconnect when offline use required | Supported work/recovery and unavailable operations clear. |

Report static review, simulated logic, schema/integrity, rendered review and runtime interactions separately. A truth-table simulation does not prove Kianda rule execution; a screenshot does not prove saving or permissions; a schema pass does not prove a successful application.

A substantial design is implementable when the builder can explain forms/sections, predicates, answer changes, navigation/completion, mechanisms and meaningful acceptance scenarios. High-consequence unresolved decisions block their affected scope; make other assumptions visible. Do not call unreviewed design approved or static work runtime-verified. Review the draft against the real designer/player and representative journeys before promoting it to an accepted standard; do not alter the technical schema to accommodate conceptual design labels.

## Recurring review failures

Check for an experience reduced to fields plus later styling; arbitrary one-form-per-noun boundaries; hidden treated as complete/secure; conflicting show/hide writers; selection-only tests without reversal/reopen; preserved inactive data still driving totals; indiscriminate evidence clearing; assumed error-stop behavior; table storage incompatible with reporting; or out-of-scope historical cleanup. The corresponding design decisions belong in the [journey contract](./design-journeys.md) or [blueprint](./design-blueprint.md).
