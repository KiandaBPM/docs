# Fields and exact settings

Use for field types, values or native settings. This catalogue is incomplete; availability and complete runtime options require the target registry. [Evidence labels](./evidence.md)

## Field catalogue

| Identifier | Purpose/limit | Evidence |
| --- | --- | --- |
| `fields/field-textbox` | Single-line, multiline or rich text | Confirmed; observed |
| `fields/field-number` | Numeric input/display | Confirmed; observed |
| `fields/field-list` | Selection modes and data-bound choices | Confirmed; observed |
| `fields/field-date` | Date/date-time input/defaults | Confirmed; observed |
| `fields/field-toggle` | Toggle/checkbox control | Confirmed; observed |
| `fields/field-userpicker` | User/group/principal selection | Confirmed; observed |
| `fields/field-file` | File upload/access | Confirmed; observed |
| `fields/field-image` | Image display; sources may be descriptors | Confirmed; observed |
| `fields/field-signature` | Signature capture | Confirmed; observed |
| `fields/field-text` | Static, non-user-editable content, often HTML | Confirmed; observed |
| `fields/field-button` | Settings and/or ordered rules drive actions | Confirmed; observed |
| `fields/field-panel` | Layout container with descendants | Confirmed; observed |
| `fields/field-dialog` | Modal container with descendants | Confirmed; observed |
| `fields/field-table` | Repeating row structure | Confirmed; observed |
| `fields/table-row` | Internal row containing columns/containers | Observed |
| `fields/field-group` | Mirrors existing fields through descriptors | Confirmed; observed |
| `fields/field-component` | Loads first-form content from a Component process | C2026 confirmed; wrappers observed |
| `fields/field-subform` | Related-record management | Owner-described; absent in corpus |
| `fields/field-link` | Link field | Owner-described; absent in corpus |
| `client-field/<component-id>` | Tenant implementation | Confirmed; absent in five exports |

## Values, flags and styling locations

`field.value` is polymorphic and often omitted. The 158 observed values (75 strings, 73 arrays, ten integers) do not establish an exhaustive union. Do not force strings or add `value: null`. Outer `showTitle`, `visible`, `enabled`, `required` are booleans in the examples; many settings use `"yes"`/`"no"`. Application input requiredness differs from JSON Schema property requiredness. Do not globally coerce these representations.

**Current owner correction:** `field.class` is the persisted layout property. A proposed rename to `cssClass` was not implemented. Generate/preserve `class`, keep `customCssClass` separate, and do not delete existing `cssClass` data automatically. Combine verified Bootstrap 3 classes as needed; sibling widths need not total twelve. Keep observed mobile layout at `settings.mobileClass`, not an invented outer property. Use the [CSS guide](../css-style-guide.md) for visual utilities and the [visual evidence note](./presentation-evidence.md) for source-specific examples. [H §§8–9, corrected by C2026]

## Textbox: exact present-property contracts

Discriminator: `field.type = "fields/field-textbox"`. Enforce known values when present; UI availability does not imply serialized requiredness or forbid retained inactive settings.

| Setting | Confirmed values/meaning | Limit |
| --- | --- | --- |
| `textMode` | `single`, `multiple`, `richtext` | May be omitted; empty settings occur. |
| `textStyle` | `""`, `field-text-capitalize`, `field-text-uppercase`, `field-text-lowercase` | Empty string is intentional. |
| `controlType` | `text`, `password` | UI available in single mode; no proven presence/absence dependency. |
| `autofill` | `On`, `off`, `new-password`, `street-address`, `email`, `tel` | Preserve uppercase `On`; lowercase `on` is not confirmed. |
| `rows` | String captured by settings textbox and forwarded to textarea helper | `""` means defaults; bounds/numeric syntax unproven. |
| `placeholder` | String | No requiredness/maximum length supplied. |
| `maxlength` | String captured by settings textbox and forwarded to input helper | `"100"` and `""` supported; empty means defaults. |

Only 235 of 287 textboxes serialize `textMode`. Empty `rows` occur at A `/forms/3/fields/5/fields/9/settings/rows` and IN `/forms/4/fields/4/fields/1/fields/0/fields/0/fields/0/fields/2/settings/rows`; do not convert “row count” into an integer-only contract. [H §9; C2026]

## Number: exact present-property contracts

Discriminator: `field.type = "fields/field-number"`.

| Setting | Confirmed values/meaning | Limit |
| --- | --- | --- |
| `displayFormat` | `n` default, `#` integer, `c` currency, `p` percentage | Preserve compact tokens. |
| `currencyFormat` | `en-IE`, `en-US`, `en-AUS`, `ja-JP`, `en-GB`, `en-CA` | Currency UI branch; preserve literal `en-AUS` pending implementation confirmation. |
| `euroFormat` | `en-IE`, `pt-PT`, `fr-FR` | Currency branch when currency format is `en-IE`. |
| `showArrows` | `yes`, `no` | Existing `c` conflicts are not additional values. |
| `nativeMobile` | `yes`, `no` | Strings. |
| `decimalPlaces` | String; explicit example `"0"` | Zero is supported; `""` means defaults. Do not coerce. |
| `placeholder` | String | Requiredness not supplied. |

**C2026:** `decimalPlaces`, `rows`, `maxlength` are strings because textbox-based settings editors forward their values to the helpers. Preserve numeric-looking strings and empty strings. Exact numeric grammar, bounds and concrete defaults are unavailable; do not impose digit-only/positive-only constraints.

**Confirmed bug:** 11 `showArrows: "c"` occurrences (I: three; IN: eight) miss the exact `"no"` branch that sets `spinners=false`. That excerpt does not establish final spinner defaults. Generate `yes`/`no`; report existing conflicts without rewriting or expanding the enum. Examples: I `/forms/9/fields/4/fields/6/settings/showArrows`; IN `/forms/1/fields/3/fields/6/settings/showArrows`.

Earlier assistant schemas requiring `rows`, `controlType`, `currencyFormat` or `euroFormat` were proposals. Controls can be defaulted, omitted or retained after mode changes; runtime requiredness needs code evidence.

## Other settings

- **Manual lists:** exact keys include `listsource`, `displayformat`, `radiodisplayposition`, `choices`, `choicesValue`. Confirmed choices are newline-delimited strings, not an invented object array. `choicesValue` may remain when `enableSeparateValues` is false. Data-bound lists add process/data source descriptors, filters, mappings, sorting and limits; references may belong to another process.
- **Groups:** `settings.fields[]` mirrors existing fields through descriptors. It neither clones entities nor behaves like a panel. Resolve local targets.
- **Tables/Components:** preserve real rows, mixed `pagesize` types, contextual names and the confirmed loading/version relationship. See [model contracts](./model.md#tables-and-generated-row-names) when changing them.
- **Other values:** date defaults such as relative `now` are configuration, not timestamps to replace. Image/file sources may be descriptors; user-picker values may be principal collections. Buttons can derive behaviour from both settings and ordered rules. Obtain component-specific evidence before tightening these shapes.

[H §§9.5–10; A–O; C2026; C2026-23]
