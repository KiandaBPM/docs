# State, branching and journey design

Design recommendations for adaptive processes; these labels/pseudocode are blueprint vocabulary, not Kianda settings or runnable expressions. Read only when the task changes state, decisions, re-entry, validation or navigation.

## Independent state dimensions

| Dimension | Specify |
| --- | --- |
| Applicability | Does this information/activity belong to this case? |
| Visibility | Should this participant see it now? |
| Editability/availability | Can the participant interact now? |
| Requiredness | Which information is required for which action/transition? |
| Completion | Has applicable work met its criteria? |
| Authorization | Does the actual security mechanism permit access? |
| Data treatment | What happens to existing values when applicability changes? |

Map each dimension to verified configuration or record a gap. Hidden does not mean inapplicable, complete, deleted or secure. Read-only is not complete; completion does not prove permanent immutability. Required future work may be temporarily unavailable without becoming optional. Inactive branches should not produce unreachable validation errors, while applicable later stages retain their own completion requirements. Serialized `visible`/`enabled` flags do not prove post-initialization runtime state.

Define orientation and the first meaningful decision. Hide irrelevant details where helpful; show explanatory upcoming-stage states where useful. Do not hide everything as a universal default.

## Classification and effective predicates

Place important classification early enough to shape the journey, without asking what users cannot know. For each decision specify source, allowed answers, blank/unknown handling, exclusive/multiple selection, downstream effects, validation timing and change policy. Do not treat blank as No. Handle retired/unsupported stored answers explicitly.

Use exclusive choices only when they cannot coexist; overlapping categories need multi-select or independent decisions. Applicability includes relevant upstream decisions: a retained child answer must not activate work after its parent makes that answer irrelevant.

**Conceptual example (not Kianda syntax):** `costIsApplicable = damageDetailsAreApplicable AND (Assets selected OR Security selected)`.

| Damage details apply | Assets | Security | Cost applies |
| --- | --- | --- | --- |
| No | Any retained value | Any retained value | No |
| Yes | No | No | No |
| Yes | Yes | No | Yes |
| Yes | No | Yes | Yes |
| Yes | Yes | Yes | Yes |
| Unknown | Any | Any | Unresolved; do not mark complete |

Give each target state one logical definition, even when several physical rules implement it. Independent “Assets: show, else hide” and “Security: show, else hide” writers can conflict with the intended OR. Inspect initialization, resets, mapped values and custom writers too. Map dependencies through forms, sections, validation and actions; prefer acyclic flow. For deliberate feedback loops, specify convergence/safeguards instead of assuming the engine prevents them.

## Transitions, re-entry and asynchronous work

Cover first open, controlling-answer edits, backward navigation, draft reopen, existing-record resume and programmatic/mapped changes. For a meaningful transition, state prior state, initiating event, resulting state, newly applicable/inapplicable work, data treatment and next reachable action.

The same relevant inputs, participant/permission context and lifecycle state should produce the same intended UI regardless of selection/deselection order. Re-evaluation must not duplicate records/notifications or reset completed work without explicit policy. A field-change rule is not proof of an initial-load mechanism; establish the actual hook.

Keep presentation recomputation separate from consequential actions. Reopening alone does not authorize reassignment, email or another external request. For data loading/uploads/required services, define loading, success, failure, retry and dependent work; visual order does not imply rollback or stop-on-failure.

## Earlier-answer changes

| Policy | Use and required detail |
| --- | --- |
| Preserve while inactive | For allowed reversible choices; exclude stale values from active calculations, validation, reporting and effects; define reactivation. |
| Clear invalid dependents | When a changed parent invalidates values/references; identify direct/derived values, reason and warning needs. |
| Clear after confirmation | When discarding substantial entered content is intended; explain consequences and supported recovery/cancellation. |
| Restrict/review change | After consequential progress; identify authorized changer, reopened/invalidated work and required history. |

Preservation is only a starting preference where business/privacy/retention policy permits, not indefinite retention. Invent no inactive-data store or audit system. Hiding, clearing a value, removing a row, deleting a related record and deleting a file differ; a clear operation does not prove linked-resource deletion. Preserve the existing reversal policy unless its change is in scope; report risky patterns separately.

## Validation, navigation and actions

Specify checks separately for input, moving forward, draft save, stage submit and process completion. Requiredness follows effective applicability and the relevant completion boundary. Make errors reachable/correctable, including in another form; do not require inaccessible or uneditable inputs. Specify whether an action is blocked or a draft remains saveable, whether data is preserved and how users remain oriented. Flags alone do not prove those behaviors.

The custom-rule contract in [general.md](../general.md) continues after a thrown error/rejected Promise. Explicitly gate later save/submit/notification/navigation when dependent on success; do not generalize that evidence to every native validation action.

Define meaningful next/previous destinations, hidden/unavailable form treatment, direct access, return-to-edit and a destination when the current form becomes irrelevant. Keep utility forms out of progress UI. “Next” is not necessarily the next array element; establish native/tenant navigation contracts. Avoid fixed step totals when undecided branches make them misleading.

Labels should express actual effects (Save draft, Continue, Submit, Assign, Complete, Close). Give the current task one clear primary action, with understandable secondary/destructive actions. Describe validation, model update, persistence, side effects and navigation order with success gates. If an effect succeeds before a failed save, specify recovery and duplicate prevention without claiming transactions. [Acceptance scenarios](./design-review.md)

## Ownership, data and existing records

Define who may see, edit, submit, reassign and reopen each activity, then resolve conceptual roles to authorized target-workspace principals. Forms, hidden/disabled controls and navigation are not access boundaries. Preserve security during unrelated edits; copy no tenant identities and invent no principals. Unavailable permission/authoring mechanisms need explicit administrator steps and affected release readiness. A page-only principal policy is not a confirmed universal process rule.

Record triggers/failure handling for notifications, external requests, anonymous access, assignment, deletion and publication. Tests must not accidentally send production notifications or alter live records. Regulatory/safety processes need approved business policy; this guide establishes no reporting duties, deadlines or legal compliance.

Design storage/reporting together: identify dimensions, source-of-truth and derived values, and relationships. [general.md](../general.md) documents that Summaries cannot independently query table contents or arbitrary nested custom-field properties. Specify supported summary/projection maintenance and branch-change effects; invent no automatic synchronization or contribution from preserved inactive data.

Record Components, installed custom fields/rules, data sources, helpers, global CSS/JavaScript and related processes as dependencies, not portable built-ins. For existing records, identify compatibility, older answers/lifecycle and migration/revalidation needs. New required branches must not silently strand valid drafts; design authoring does not perform migration. Include offline/reconnection only when required/already relevant; visible controls do not prove data/service availability, so record scenarios and gaps.
