# Process presentation: evidence and implementation limits

Use the [CSS guide](../css-style-guide.md) for the canonical utility catalogue, property placement and composition guidance. Read this note when source-specific process examples, serialization evidence or unresolved visual mappings matter. [Source labels](./evidence.md)

## Contract and source boundaries

CB makes branding a core requirement: clean, professional, authoritative interfaces with hierarchy, whitespace, consistent type, responsive layout and recognizable actions/states. Material Design contributes principles, not an installed component/font/icon/token package. Implement through native fields/Components and verified Bootstrap 3/workspace styles. Preserve existing `fa fa-*` and `icon-*` icons unless deliberately choosing a supported replacement.

B documents seven process utilities normally placed in `field.customCssClass`: `panel-card`, `radio-list-card`, `checkbox-list-card`, `radio-list-button`, `section-title`, `table-no-style`, `image-thumbnails`. They ship in default global `app.css` but can be overridden. Page/widget utilities do not add process models. Class tokens omit selector dots and use spaces between tokens, e.g. `section-title expandable-section`. B's invisible U+200B after `radio-list-card` and `table-no-style` was intentionally omitted in documentation transcription; no source/app string was rewritten.

`field.class` is the confirmed layout key (observed `col-sm-*` and `pull-left`); `customCssClass` is additional styling. `field.settings.mobileClass` remains nested. Component options stay in actual settings, e.g. static `controlBgScheme`, button `colorScheme`/`buttonSize`/`alignButton`/`icon`. For static `fields/field-text`, `field.text` is displayed content, distinct from design title and logical name; preserve HTML on styling-only edits. `settings.cardPanel` and class `panel-card` are distinct; all 46 observed `cardPanel` values are empty strings.

Corpus styling observations: 305 `class`, zero `cssClass`, 135 `customCssClass` (ten empty), 50 `settings.mobileClass`; 22 `panel-card`, 25 containing `section-title`, ten `radio-list-button`, two `table-no-style`. The other three documented utilities are absent from these class values, not unsupported. `radio-button-list`, `toggle-block`, `expandable-section` and animation classes are observations, not a portable catalogue. Do not conflate `radio-button-list` with `radio-list-button`; a class alone does not prove expand/collapse behaviour.

## Serialized visual settings

| Choice | Evidence and limit |
| --- | --- |
| Section background | A `/forms/2/fields/9/fields/0`: `settings.controlBgScheme: "bg-primary"` with `section-title`. B also documents `bg-warning`, `bg-info`, `bg-success`; not every combination was rendered. |
| Radio list | `settings.displayformat: "radiolist"`; direction `settings.radiodisplayposition`. Ten button-style lists split five vertical/five horizontal. B's vertical recipe does not invalidate horizontal exports. |
| Checkbox list | `settings.displayformat: "checkboxlist"`, observed `settings.radiodisplayposition: "vertical"` at I `/forms/0/fields/4/fields/0` and `/forms/4/fields/3/fields/0`. This does not prove the card class was attached there. |
| File-source image | All 11 use `settings.imagesource: "file"`, `settings.inlineImages: "yes"`, descriptor `settings.fileSource`. I `/forms/1/fields/5/fields/0/fields/1` references sibling upload `/forms/1/fields/5/fields/0/fields/2`; resolve actual targets. |
| Process panel `panel-default` | B gives a UI colour choice but no confirmed JSON mapping. Do not invent `settings.colorScheme`, assume `controlBgScheme`, or add it as a class just because schema is open. All 132 panels have empty/absent `controlBgScheme`; do not rewrite them. |

Retain selection modes, labels, newline-delimited manual choices and stored business values. B alone does not establish Yes/No matching/selectors; do not change values to obtain colour or convey meaning only through colour. Later supplied stylesheet findings in the CSS guide are bounded to that snapshot.

## Source-grounded compositions

- **Heading + card:** A `/forms/2/fields/9` begins with static text (`section-title`, `showTitle: false`, `controlBgScheme: "bg-primary"`, text `\nAction Closure<!---->\n\n<!---->`) then a `fields/field-panel` (`class: "col-sm-12"`, `panel-card`, `showTitle: false`) containing comments/actions. This is a selected-property projection, not a complete field array. Retain identities/descendants/rules. HTML comments and `showTitle: false` are not universal requirements.
- **Choice:** I `/forms/2/fields/7/fields/0/fields/0/fields/0` shows `radio-list-button` with `displayformat: "radiolist"` and vertical direction. Card treatments suit spacious labels; compact buttons suit short readable alternatives. Preview focus/wrapping/selection/disabled states; a screenshot does not reveal serialized direction.
- **Repeating card:** I `/forms/2/fields/7` and `/forms/3/fields/3` use `table-no-style`; a row's first child panel uses `panel-card` and contains business fields. Preserve table-row entities, row operations and settings. This does not require one panel or one stored row.
- **Upload preview:** keep a file field and an image bound by `fileSource`, with file/inline settings above; `image-thumbnails` adds documented `object-fit: cover` presentation but was absent on corpus images. BV shows an upload list/two thumbnails, not enlargement behaviour, permission or exact dimensions. Keep a supported way to inspect full evidence.

BV also shows a blue section band, neutral surroundings, a white panel holding three choices and separate full-width option cards. Treat exact class attribution as inference. Its surrounding header, navigation and messaging overlay are product UI, not process-field models.

## Review limits

Use the CSS guide's composition/review policy: target styles, responsive behavior, semantic labels/headings, keyboard/focus, state feedback and full-evidence access require rendered checks. `col-sm-12`/`col-sm-6` are observed; sibling widths need not total twelve. No numeric brand spacing/radius scale was prescribed. WCAG 2.2 SC 1.4.3 review targets are 4.5:1 ordinary text/3:1 qualifying large text, with criterion exceptions; class presence is not conformance.

Styling one process does not authorize global `app.css` rewrites, invented app-level CSS keys or framework embedding. Additional CSS needs supported scope/shared-app impact review. Target CSS/overrides, brand palette/type/spacing/radius/breakpoints, panel colour serialization and value-specific Yes/No behavior need appropriate evidence; documented utilities with verified settings remain usable. Branding changes no schema `1.1.0` requirements or identities.

General-design sources (accessed 23 October 2026; not Kianda contracts): [Material principles](https://m2.material.io/collections/introduction-to-material-design/), [Material grouping](https://m2.material.io/design/layout/understanding-layout/), [Bootstrap 3.4 grid](https://getbootstrap.com/docs/3.4/css/#grid), WCAG [contrast](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html), [use of colour](https://www.w3.org/WAI/WCAG22/Understanding/use-of-color.html), [visible focus](https://www.w3.org/WAI/WCAG22/Understanding/focus-visible.html).
