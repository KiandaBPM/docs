# Page queries, filters and date state

Source-based topic reference from [page-knowledge.md](../page-knowledge.md). Original section numbers are retained for source citations; evidence status and unresolved qualifications are unchanged. The page authoring baseline remains **draft v1.0.0**. Source labels are in [validation and evidence](./validation-evidence.md#201-sources-used).

## 9. Query groups, conditions and operands

### 9.1 Shared shape and identity

The shared query model is a two-level structure, not an arbitrary recursive Boolean AST:

```text
conditions[]
  id: GUID
  group: "and" | "or"
  filterId: optional runtime provenance in retained snapshots
  conditions[]
    id: GUID
    operator: exact query operator
    arg1: contextual field selector
    arg2: operand where applicable
    group: "and" | "or"
```

The owner confirms individual condition GUIDs are needed for correct administrator/designer parsing. The shared-group GUID requirement was already confirmed. Generate fresh GUIDs for genuinely new logical groups and conditions; preserve identities on edits.

**Generation policy:** avoid identity collisions across newly authored logical groups and conditions in the page. The exact global runtime uniqueness domain is not supplied; fresh GUIDs avoid relying on a narrow scope. Repeated serialized copies in a runtime mirror are not new entities and should retain their logical identity. Do not run a blanket deduplication over every object containing `id`.

The original models default `group` to `"and"`. The schema permits omission for compatibility but does not insert a value. Emit connectors deliberately for new queries. [DRAFT ConditionGroup/Condition models; OWNER section 4]

### 9.2 Combining groups

The owner confirms that each subsequent group's connector joins it to the preceding group. For example, `[G1(group="and"), G2(group="or")]` means `(G1) OR (G2)`, not `(G1) AND (G2)`.

A useful unambiguous pattern for `(A AND B) OR (C AND D)` is two groups whose inner conditions are all `and`, with the second outer group set to `or`. Preserve array order. The first outer group has no preceding group to join.

Conditions also have their own `group` connector, and mixed inner values are observed. The exact evaluation precedence of a mixed inner AND/OR chain and longer mixed outer chains is not supplied. Do not assume SQL precedence, arbitrary nesting, or a generic AST evaluator. Prefer clearly grouped homogeneous inner expressions where they express the requested logic; verify more complex expressions against the runtime.

### 9.3 Operand precedence: `value` and `text`

The owner supplies this server behaviour:

```text
start with no operand value
if arg2.value is not null: use arg2.value
if arg2.type == "text" and arg2.text is not empty: use arg2.text instead
```

Consequences:

| Intended operand | Authoring guidance |
| --- | --- |
| Simple literal text | Use `{"type":"text","text":"Open"}` with a verified actual stored value. |
| Typed value carried in `value` | Do not also put an unrelated non-empty label into `text` with `type: "text"`; it would override the value. |
| Both `text` and `value` | Include both when appropriate, keeping the precedence consistent with the intended comparison. Do not assume `text` is always merely a label. |
| Numeric literal | A value-only shape such as `{"type":"text","value":7}` avoids a text override; the referenced field type still matters. This is an authoring use of the supplied precedence, not a new numeric operand-type enum. |
| Another process field | Resolve `name`, `type: "field"` and `fieldType` from that field; preserve additional descriptor context. |
| A filter selection | Use a dynamic operand with `type: "filter"` and `name: "filterValue1"` or `"filterValue2"` as appropriate. |

`type` is mandatory for a literal. Relative-date snapshots may contain an operand with only `name` and runtime boundaries, so the schema does not impose a literal type on every unary/relative operator. For ordinary binary comparisons, this profile requires `arg2` and its `type`; operand-free operators may omit it. Where a verified component supplies an empty operand object, preserve that representation.

Do not invent additional literal-type enums from JavaScript types. A valid operand shape does not by itself prove compatible field comparison, date semantics or pattern syntax. [OWNER section 4 and supplied server snippet; HANDOVER section 9.2]

### 9.4 Dynamic filter operands

Canonical new filter connections use unresolved selection slots, not a captured tenant selection:

```json
{
  "text": "Filter value",
  "name": "filterValue1",
  "type": "filter"
}
```

For an observed two-ended date range, use `filterValue1` for the start and `filterValue2` for the end. Exported materialized operands sometimes retain these names but have `type: "text"`, `value` and selected text. Preserve them on unrelated edits; do not copy those captured selections into a new page.

### 9.5 Exact page-query operators

| Category | Supported supplied values |
| --- | --- |
| Relative day | `isToday`, `isBeforeToday`, `isAfterToday` |
| Relative week | `isThisWeek`, `isPrevWeek`, `isNextWeek` |
| Relative month | `isThisMonth`, `isPrevMonth`, `isNextMonth` |
| Relative year | `isThisYear`, `isPrevYear`, `isNextYear` |
| Date range | `isBetweenDates` |
| Equality and text | `eq`, `neq`, `contains`, `startsWith` |
| Ordered comparison | `gt`, `gte`, `lt`, `lte` |
| Empty and pattern | `isblank`, `notblank`, `match`, `nomatch` |
| User membership | `IsUserOrMember` |

Do not use UI-state operators `isvisible`, `isenable` or `isenabled` in page queries. The original shared list spells the enabled entry `isenable`; the latest answer refers to `isenabled`. Both spellings are excluded here rather than silently reconciled into a page operator.

`IsUserOrMember` is available only for `fields/field-userpicker`. It compares the current user's identity and group identities to the user-picker field, covering direct or indirect assignment. The serialized operator is the capitalized `IsUserOrMember` from the actual catalogue and the owner's example, not the differently cased prose spelling. Do not replace it with a guessed list of principals. It is a query predicate, not a replacement for record authorization. [DRAFT operators; OWNER section 4]

Pattern operators' regex dialect and other type-specific comparison details are not established. Do not invent them.

## 10. Filter ownership, connections, URL state and dates

### 10.1 Configuration versus runtime state

| Location / value | Ownership and handling |
| --- | --- |
| Filter `settings.connections[]` | Authoritative authored relationships and target predicates. |
| Connection `widgetId` | Target identity; resolve it within the page. Titles are not keys. |
| Configured `defaultValue` | Intentional authoring configuration, not the last selected value. |
| Selected values materialized into operands | Transient runtime state; not portable default business data. |
| `filterId` | Runtime provenance. Do not calculate or seed it for a new filter. |
| Incoming copies in target `settings.conditions` / `settings.datasourceFilter` | May be runtime mirrors in exports; do not hand-generate them for new connections. |
| Independent source/target base predicates | Real query intent. Do not erase them while removing or avoiding transient state. |

The owner confirmation resolves connection authority; it does not imply every group in `conditions` or `datasourceFilter` is disposable. For example, `type = Project` and `active = Yes` select Location options, whereas a selected project's code filters target records. The exact ownership of every untagged static source-predicate duplicate between those two arrays is not fully specified.

For new pages, author filter relationships in `settings.connections`, leave selection values unresolved and retain deliberate fixed source/target queries in their supported locations. Do not synthesize incoming mirror groups in target widgets. For existing pages, preserve unrelated runtime snapshots and fixed predicates; a normalization or reset is a separate, reviewed change. [OWNER section 3; HANDOVER sections 7.6, 10]

### 10.2 Lifecycle

On render, the configured default is applied first and the query-string value then takes precedence. On clear, the runtime finds matching `filterId` groups in connected widget conditions and removes them.

Do not infer that clearing deletes unrelated base predicates, persists a cleared default or immediately restores the configured default. An empty URL value, rerender/reset behaviour, cached selection restoration, invalid cascade selection and history updates still need runtime verification when relevant.

Observed tags have the form `<filter-widget-id>_<connection-index>`. That is not an instruction for the agent to compute them. Edit the authoritative connection configuration and let the runtime manage current selection provenance. Reordering or removal should be checked after reload/clear; do not invent a global tag-rewriting algorithm.

### 10.3 Filter coverage and the two connection mechanisms

Filter fan-out uses `settings.connections[]`. Tile/chart drill-down uses `isConnected` and `connectTo`. They are separate mechanisms.

A filter may target lists, tiles, charts, another filter or a verified filter-aware custom component. A known aggregate drill-down targets a list. Do not make every filter target a list only, and do not assume every custom widget supports filtering.

Plan a coverage matrix before configuring a dashboard:

| Input | Results list | KPI tiles | Charts | Selector source / banner |
| --- | --- | --- | --- | --- |
| Context, such as project | Deliberate yes/no | Deliberate yes/no for each metric | Deliberate yes/no | Only intended dependent selectors/components |
| Date range | Deliberate yes/no | Decide whether period KPIs stay independent | Deliberate yes/no | Usually only if the component contract calls for it |
| Search/status | Deliberate yes/no | Do not imply inheritance | Do not imply inheritance | Only verified targets |

The original analytics page has non-uniform coverage and a repeated Project-to-list connection. These are observations, not permission to silently repair an existing page. New dashboards should follow their requested semantics, not copy these patterns mechanically. Preserve duplicate links/connections when they are deliberate; review intent before deduplicating.

### 10.4 Cascading selectors

The project example demonstrates:

```text
Country (asset title -> code; URL country)
  -> Items list: country-related fields
  -> Location selector: countryCode source restriction
Location (asset displayName -> code; URL project)
  -> Items list: processProjectCode
  -> installed carousel: code, with parameter project
Tabs (manual radiolist; URL tab)
  -> cross-process Items list: __PROCESS_TITLE
ID / Creator / Status
  -> their selected Items-list fields
```

Preserve display/value mappings, source predicates and URL keys. A connection's `processName` can describe the predicate's field context without redefining the target list's overall `processName: null`. Verify what happens when a parent selection makes a child selection invalid; do not claim a cascade-clearing policy the sources do not state. [G-PROJECT filters and list]

### 10.5 Relative dates and explicit ranges

For a new relative-period condition, author the relative operator and a verified date field, without manually supplied `date1` or `date2`. The runtime supplies calculated dates, including runtime value data where applicable. Do not copy the gold export's concrete September/October boundaries or use the author's timezone as a substitute.

The observed date-range connection has two conditions: `gte` with `filterValue1` and `lte` with `filterValue2`. This is a supported demonstrated pattern distinct from a single `isBetweenDates` predicate.

The owner confirms that a date-range filter uses the end user's timezone and computes corresponding UTC dates. The exact inclusive end-of-day policy, week-start convention, DST edge behaviour and when every relative query is refreshed are not fully established. Preserve the operator representation and let the runtime calculate boundaries; test relevant boundary cases in Kianda. Do not replace them with a guessed UTC-midnight or 23:59:59.999 policy. [OWNER section 6; G-OBS /widgets/10 through /widgets/13]
