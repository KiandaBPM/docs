# Creating, editing and cloning page documents

Source-based topic reference from [page-knowledge.md](../page-knowledge.md). Original section numbers are retained for source citations; evidence status and unresolved qualifications are unchanged. The page authoring baseline remains **draft v1.0.0**. Source labels are in [validation and evidence](./validation-evidence.md#201-sources-used).

## 14. Creating, editing, cloning and preserving dependencies

### 14.1 New document

Allocate a unique readable page alias and new widget/group/condition identities. Bind references to actual process definitions. Omit server-owned metadata and runtime selection state. Use verified settings and styling. Leave V1 permissions unconfigured, with the required security handoff when applicable.

The page schema is not a publish/save API. Do not insert `status`, `changes`, `removePaths`, `widgetOrder`, `baseRevision` or temporary `new:*` identifiers from the historical Page Copilot transport proposal. Diagnostics and delivery notes belong outside the saved document.

### 14.2 Existing document

Retain IDs, aliases, array order, field descriptors, content strings, URL keys, unknown properties and unrelated security/metadata. Change only the requested behaviour and dependencies necessarily affected by it. Titles and class names can be selectors; inspect their consumers before renaming them.

Preserving an observed setting is not certifying its correctness. Report suspicious patterns, such as duplicate target connections, without silently repairing them. Do not normalize string flags, erase runtime mirrors, sanitize legacy content or regenerate IDs during an unrelated visual change.

### 14.3 Cloning

Separate true entities from references. Allocate new IDs for the cloned page-local widgets and newly independent query groups/conditions. Update internal references such as `connectTo`, connection `widgetId`, the outer widget `page`, and applicable self/source `filterWidgetId` references. Rebuild new canonical filter connections rather than copying selection tags or captured business values.

Do not regenerate process field IDs, datasource IDs, principal IDs, external page/process targets or asset references. Resolve or deliberately replace non-portable assets; do not globally replace UUID-looking strings in HTML.

Preserve the identity of repeated runtime copies when maintaining an existing relationship. A clone intended as a new logical relationship gets new canonical identities; incidental serialized mirrors do not become separate entities.

### 14.4 Dependency checklist

Relevant dependencies include aliases and routes; widget IDs; `settings.container`; field selectors; hidden list projections; HBS row paths and helpers; custom-column component names; filter source/display/value mappings; connection targets; walkthrough DOM selectors; CSS selectors; carousel tokens; native Link targets; query parameter names; and assets.

An individual page export cannot prove the absence of references elsewhere. Use all available workspace pages, processes, component code and styles, and state the boundary of any incomplete audit. No filename-only or GUID-only scan is a complete dependency check.
