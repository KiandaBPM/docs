# Page security and administrator handoff

Source-based topic reference from [page-knowledge.md](../page-knowledge.md). Original section numbers are retained for source citations; evidence status and unresolved qualifications are unchanged. The page authoring baseline remains **draft v1.0.0**. Source labels are in [validation and evidence](./validation-evidence.md#201-sources-used).

## 13. V1 security policy and administrator handoff

### 13.1 Confirmed semantics

| Surface | Owner-confirmed behaviour |
| --- | --- |
| Page `visibleTo` | Controls page security. A user outside the configured group restriction is denied access to load the page. |
| Widget `visibleTo` | Controls client-side widget visibility. The page model is downloaded to the browser; hidden widgets are not a server-side secrecy boundary. |
| Link `users` | Similar visibility restriction for individual Link items. |
| Empty `visibleTo` / `users` arrays | That additional security restriction is not enabled. This does not establish anonymous access or disable underlying record authorization. |

The full interaction with `isPublic`, partner settings and other authorization layers is not supplied. `settings.hide`, `visible: false`, CSS hiding, list query scopes and `is-member` are not substitutes for appropriate security. [OWNER section 5]

### 13.2 New pages versus existing pages

**Confirmed V1 scope:** permissions must remain unconfigured because principal discovery/selection is deferred to V2. Do not populate real or invented user/group assignments for newly authored pages/widgets/links. Omitted arrays or explicit empty arrays express an unconfigured restriction where supported; do not treat them as a secure role configuration.

For existing pages, preserve unrelated `visibleTo`, Link `users`, `adminOnly`, `isPublic` and process security. Do not clear existing restrictions to make an example reusable or to comply with the new-page policy. Changing security is a separate authorized task, not a formatting operation.

Do not set `isPublic: true` by inference. Do not invent an administrator's identity, auto-select a similarly named group, or copy expanded user profiles from gold examples.

### 13.3 Required handoff when roles are part of the requested app

Deliver a short, app-specific administrator checklist outside the persisted page JSON:

1. Identify or create the actual workspace users/groups corresponding to the requested roles. Name the intended roles without inventing principal IDs.
2. Apply the intended page-load restrictions through each relevant page's `visibleTo` configuration. List the exact page aliases to configure.
3. Apply any additional widget/Link visibility rules, clearly stating that these are presentation restrictions and cannot protect the downloaded model or data on their own.
4. Configure and verify the underlying process/record permissions under the process security contract. Do not rely on page filtering to prevent unauthorized record access.
5. Test allowed and denied roles using direct page URLs, record access and navigation as well as menu visibility. Review public/partner settings where relevant before release.

For a role-sensitive app, explicitly report that security configuration is pending and the app is not ready for role-restricted release until those steps are completed. A structurally valid, unconfigured page is not a secured application. [OWNER section 5]
