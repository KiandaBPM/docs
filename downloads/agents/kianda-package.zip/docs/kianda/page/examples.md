# Page composition patterns and examples

Source-based topic reference from [page-knowledge.md](../page-knowledge.md). Original section numbers are retained for source citations; evidence status and unresolved qualifications are unchanged. The page authoring baseline remains **draft v1.0.0**. Source labels are in [validation and evidence](./validation-evidence.md#201-sources-used).

The historical `fixtures/...` files named below belonged to the source page-authoring package and are **not included in this workspace bootstrap**. Inline examples remain available here. Earlier schema/integrity checks are source-package reports, not checks repeated by this documentation reorganization; no example was runtime-certified.

## 15. Reusable page patterns and worked examples

### 15.1 Four composition patterns

| Pattern | Useful composition | Dependencies and cautions |
| --- | --- | --- |
| Landing/home | Purpose, primary tasks, optional installed banner, concise supporting content, verified onboarding guide. | Static historical figures are not live KPIs. Native launchers often avoid unnecessary custom action HTML. |
| Analytics | Context filters, aggregate tiles, Chart v1, a results list and deliberate drill-down. | Explicit filter coverage; verified measure/status domains; no automatic inheritance from the list. |
| Create-new launcher | Section headings and native process Link items, with intentional modal/context options. | Resolve every process target. Preserve distinct variants to the same process. Leave new principal restrictions to the administrator. |
| Contextual workspace | Cascading selectors, cross-process results/tabs, optional installed banner, card list and secondary filters. | Verify common field meanings, source value/display mapping, URL state, hidden projections and component availability. |

These are adaptations of the four gold pages, not instructions to copy their principals, public-file paths, selected project/country codes, historical figures or tenant-specific process conventions. [HANDOVER section 12; G-HOME/G-OBS/G-CREATE/G-PROJECT]

### 15.2 Minimal page

The owner confirms an empty page is valid. This new-authoring example omits permitted server metadata and the future `urlPath` parameter:

```json
{
  "id": "simple-page",
  "title": "simple-page",
  "name": "simple-page",
  "group": "Documents",
  "sortOrder": 0,
  "settings": {},
  "widgets": []
}
```

Choose a unique alias and a useful display title in a real app; `simple-page` is an example, not a reserved/default alias. `fixtures/owner-minimal-empty.syntax-corrected.json` retains the owner's metadata values for compatibility testing; `fixtures/minimal-new-page.json` is the explicit metadata-omitting derivative.

### 15.3 One HTML widget

The following follows the owner-provided envelope and content placement. The GUID is illustrative and must not be reused for independent new widgets:

```json
{
  "id": "welcome-page",
  "name": "welcome-page",
  "title": "Welcome",
  "group": "Documents",
  "sortOrder": 0,
  "settings": {},
  "widgets": [
    {
      "id": "e1af57fd-f773-49f7-aafd-8c3a73ad07bd",
      "title": "Welcome",
      "type": "widgets/widget-html",
      "class": "col-md-12 col-sm-12",
      "visible": true,
      "showHeader": false,
      "isCustom": false,
      "colorScheme": "panel-default",
      "customCssClass": "widget-section-title",
      "settings": {
        "container": "",
        "content": "<h2>Welcome</h2><p>Choose a task to get started.</p>"
      },
      "page": "welcome-page"
    }
  ]
}
```

This is a new illustrative design using the verified page heading class, not a claim that the owner supplied these exact content/style values.

### 15.4 Connected status filter and list

The packaged `fixtures/connected-status-list.json` is a complete structural example with two declared containers, a free-text status filter and a cross-process native list. The filter connects only to the list. It does not assume that all processes share a particular fixed set of status values.

The important connection shape is:

```json
{
  "widgetId": "15c2ea48-7941-4692-8096-0d2fcc24ba49",
  "title": "Records",
  "conditions": [
    {
      "id": "5adfb02e-19be-49a9-abfb-54c4872815c8",
      "group": "and",
      "conditions": [
        {
          "id": "7375df90-4167-41d1-8d97-194c01aceedc",
          "operator": "eq",
          "arg1": {"text": "Status", "name": "__STATUS", "type": "__Field"},
          "arg2": {"text": "Filter value", "name": "filterValue1", "type": "filter"},
          "group": "and"
        }
      ]
    }
  ]
}
```

The `widgetId` above is illustrative: it must resolve to the actual list in the page. The complete packaged fixture uses internally consistent IDs. There is no `filterId`, captured selection, or manually created incoming target mirror. List settings retain an empty base `conditions` array and explicit `processName: null`.

This is schema/integrity-tested example configuration, not a browser-tested application or a claim about a specific workspace's returned records.

### 15.5 Content card list

`fixtures/content-card-list.json` demonstrates the same verified system-field pattern with the results container named `Content`. Its first field is a custom HBS column. Hidden ID/status/creation-date fields remain after it to support `row.name`, `row.status` and `row.created`. `name2` is omitted, and the column uses the demonstrated `___CUSTOM_FIELD` / `list-field` naming conventions.

The card template shows the status rather than inventing a Closed fallback. Its `showModal` button uses the supplied action name and `row.name`, not the concatenated `row.id`. The example's component name and all entity IDs are illustrative and must be allocated appropriately for a real new page.

### 15.6 Relative-period structural example

The fixture `fixtures/relative-period.structural.json` demonstrates a count tile with `isThisMonth` over a process-date selector and an operand containing only `name: ""`, preserving the observed relative-operand shape while omitting runtime dates as the owner instructs.

Its `example-process` / `reportedOn` binding is deliberately synthetic. It must be replaced with a verified process/date field; it is not a promised built-in process or deployable EHSwise page. A schema pass establishes structure only, not the existence of those bindings.
