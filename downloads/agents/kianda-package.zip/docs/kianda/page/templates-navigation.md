# Custom list columns and navigation

Source-based topic reference from [page-knowledge.md](../page-knowledge.md). Original section numbers are retained for source citations; evidence status and unresolved qualifications are unchanged. The page authoring baseline remains **draft v1.0.0**. Source labels are in [validation and evidence](./validation-evidence.md#201-sources-used).

## 11. Custom HBS list columns, helpers and actions

### 11.1 Identity allocation

The owner supplies the designer creation code:

```javascript
var customField = {
  text: "",
  type: "___CUSTOM_FIELD",
  name: "___CUSTOM_FIELD" + this.get("fields.length"),
  componentName: "list-field" + moment().unix(),
  html: "",
  sortable: false,
  filterable: false
};
```

`name2` is automatically calculated by the list widget. Omit it for a newly authored column unless an actual integration contract requires a serialized value; preserve it during edits. Keep `name`, `componentName` and `type` unchanged for an ordinary template edit.

**Allocation safeguard, proposed:** check generated names against existing and newly generated columns. A length-derived name can collide after deletions, and a seconds-based component name can collide during batch generation. Reserve distinct names within the demonstrated prefix/numeric-suffix convention instead of assuming simultaneous calls are collision-free. This is a generation safeguard, not a claim about undocumented registry collision handling or workspace-wide uniqueness rules.

### 11.2 Row context

Custom `html` is compiled as an HBS template into a component receiving a `row` context. Prefer `row.name` for the process instance ID: the owner states that `row.id` includes a widget-ID concatenation and is not the preferred instance identifier.

Confirmed/observed row access includes:

```text
row.name
row.created
row.createdBy.displayName
row.status
row.properties.__STATUS
row.properties.<exactProjectedProcessFieldName>
```

The owner confirms `row.status` and `row.properties.__STATUS` are interchangeable. Do not generalize that equivalence to other system fields without evidence. Preserve hidden projections supplying the template's values. Never remove them just because a card or the Content CSS hides their cells.

### 11.3 Helpers and spelling discipline

The owner's stated `ember-truth-helpers` list is:

```text
and, equal, gt, gte, is-array, is-equal, lt, lte,
not-equal, not, or, xor
```

The gold templates additionally demonstrate `if`/`else` and `eq`. Preserve supported existing `eq` usages. The package list and observed aliases are source evidence, not a newly tested runtime registry.

The owner's stated `ember-moment` list is:

```text
is-after, is-before, is-between, is-same-or-after,
is-same-or-before, is-same, moment-add, moment-calendar,
mmoment-diff, moment-format, moment-duration,
moment-from-now, moment-from, moment-to-now, moment-to,
now, unix, utc
```

The source spells one entry **`mmoment-diff`**. Its exact installed registration has not been verified. Do not silently replace it with `moment-diff` or generate a dependency on the questionable spelling without checking the workspace. `moment-format` with `allow-empty=true` is demonstrated in the gold templates and is used in the illustrative card fixture.

The platform helper `is-member` accepts an array of identities and returns whether they match the current user's identities. It can support presentation logic, but cannot replace server-side page/record authorization. Do not invent the array's principal-object shape or expose unauthorized data merely because a helper hides its display. [OWNER section 7; G-OBS/G-PROJECT custom fields]

### 11.4 Exposed custom-column actions

These are **actions available inside custom list-column components**, not permission to call the same names on every content surface:

| Action | Supplied signature | Confirmed behaviour / boundary |
| --- | --- | --- |
| `refresh` | `refresh()` | Sends a list refresh. |
| `execute` | `execute(options)` | Triggers actions/rules in a process instance. Supplied option keys are `fieldname`, `refresh`, `ruleId`. |
| `gotoForm` | `gotoForm(name, isNew, partnerId, queryParams)` | Forwards to the supplied form-navigation path/global; the snippet also handles a non-string first argument specially. |
| `showModal` | `showModal(name, isNew, queryParams, dismissible)` | Calls `window.showModalForm(name, isNew, queryParams, null, null, dismissible)`. |
| `gotoDashboard` | `gotoDashboard(name, queryParams)` | Calls `window.gotoDashboard(name, queryParams)`. |
| `applyFilter` | `applyFilter(widgetId, value1, value2)` | Sends `sendFilterValue` with those arguments. Resolve the expected widget identity from the actual handler before constructing a new pattern. |

Important distinctions: the exposed action is named **`showModal`**, not `showModalForm`; the execute option is **`fieldname`**, not a guessed `fieldName`; `execute`'s supplied snippet does not document the full instance-binding/dispatch implementation. Do not invent additional keys or a complete rule-execution protocol. Use execution actions only when the business operation and current instance context are verified, and retain actual rule/field references.

An illustrative existing-record control using the supplied action signature is:

```handlebars
<button type="button" class="btn btn-link"
        {{action "showModal" row.name false}}>
  View record
</button>
```

This is a new authoring example, not a claim that its HBS was compiled in Kianda during this work. It avoids injecting record values into inline JavaScript. Underlying action authorization and error handling still belong to the platform/runtime. [OWNER additional actions code]

### 11.5 Safe template practices

Use escaped double-curly output for record values. Quote HTML attributes, avoid nested anchors and duplicate attributes, and do not interpolate untrusted record values into JavaScript strings or load external scripts. Keep navigation semantics and accessible labels clear.

Preserve unrelated legacy templates during a cosmetic edit. Fixing existing malformed HTML or script-bearing content is a deliberate change with behavioural review, not an automatic part of JSON validation. Plain string validation cannot prove sanitization, helper existence or successful compilation.

## 12. Navigation and native Link items

The native Link widget stores items in `settings.links[]`. The owner confirms exactly these destination types:

| `type` | `target` |
| --- | --- |
| `process` | Process alias. |
| `dashboard` | Page/dashboard alias. |
| `external` | External destination. Verify URL safety and intended destination. |

All three use `target`, not a guessed `url`, `pageId` or `processId` property. Do not invent `type: "url"` or `type: "page"`.

Items may also have `text`, `description`, `icon`, `textColour`, `cssClass`, `blank`, string `adminOnly`, `users`, `queryString`, `autoAppendQuery` and boolean `showModal` for process links. The owner confirms `showModal` opens a new process form in a modal. Do not automatically apply that meaning to dashboard/external links.

Both process and dashboard links support a predefined `queryString`. `autoAppendQuery` passes the current page's query parameters to the next destination. Duplicate-key precedence, encoding details and external-link propagation are not fully specified. Avoid overlapping keys in newly authored combinations unless the actual implementation is verified; do not claim that one set always wins.

Resolve process/page targets from the current workspace, including new definitions created in the same task. Different links to the same process can intentionally have distinct labels, parameters or restrictions. Do not deduplicate by target. Keep actual URL keys aligned with filter `queryParameter`, carousel parameters and favourites.

Prefer native Link items for launchers when they meet the design. Do not copy source-workspace domains, public-file IDs, QR endpoints or principal profiles into new pages. [OWNER Link answers; G-CREATE /widgets/1/settings/links and /widgets/3/settings/links]
