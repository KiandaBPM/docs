# Native and installed page widgets

Source-based topic reference from [page-knowledge.md](../page-knowledge.md). Original section numbers are retained for source citations; evidence status and unresolved qualifications are unchanged. The page authoring baseline remains **draft v1.0.0**. Source labels are in [validation and evidence](./validation-evidence.md#201-sources-used).

## 7. Native and custom widget contracts

### 7.1 Catalogue and coverage

There are eight registered native identifiers in the original draft, despite its prose referring to seven. Chart v2 is one of those eight but is excluded from V1 new authoring by the owner's latest decision.

| Runtime type | V1 use | Coverage |
| --- | --- | --- |
| `widgets/widget-html` | Static content and headings | Documented settings and source examples. |
| `widgets/widget-tile` | Numeric aggregates and optional list drill-down | Documented count/sum/avg; nine count examples. |
| `widgets/widget-list` | Tables and HBS-rendered records | Documented settings and two examples. |
| `widgets/widget-chart` | Chart v1: pie, bar, line | Documented settings; three Count examples. |
| `widgets/widget-chart2` | Preserve existing only | Opaque settings; do not author new in V1. |
| `widgets/widget-filter` | Context, text, selection and date-range inputs | Four observed input modes; connected examples. |
| `widgets/widget-link` | Native process/dashboard/external navigation | All three types now owner-confirmed. |
| `widgets/widget-walkme` | Guides with verified selectors/actions | Export structure available; runtime safety/selector details still require review. |
| `client-widget/carousel-widget` | Only with the installed, verified component | Partial observed tenant settings; not a built-in. |
| `client-widget/<component-id>` | Only with a resolved installed implementation | Settings remain open without a trusted add-on schema. |

An uncatalogued native type is not automatically a tenant widget. Preserve an existing definition while reporting coverage; for new use, resolve the real component and contract. The base schema's permissive envelope is not an installation registry. [DRAFT registration list; HANDOVER section 7; OWNER Chart v2 answer]

For page utility classes and the intended-versus-observed `widget-section-title` separator, use [styling utilities](../styling/utilities.md). For a list assigned to `Content`, use [first-column behaviour](../styling/page-lists.md).

### 7.2 HTML widget

Put content in `settings.content`, not in an outer `content` property. The original owner draft allows Bootstrap-styled HTML, style elements, video/embed content, iframes and event attributes, but excludes script tags specifically for the HTML widget.

Use concise content, meaningful headings and verified navigation patterns. Allowed inline-event syntax does not prove that an arbitrary function exists. Do not use HTML to fabricate dynamic totals or to work around a missing native configuration. The schema only checks that content is a string; surface-aware safety review remains necessary.

### 7.3 Tile widget

A tile can configure `icon`, `conditions`, `queryType`, `showDecimals`, `isConnected`, `tile`, `connectTo`, `processName` and an optional measure `field`. `processSource: "own"` is observed; its full meaning and enum are unresolved.

`tile` values are exactly `count`, `sum` and `avg`. A count does not require a measure field. Sum and average require a verified numeric process field with `fieldType: "fields/field-number"`. Do not generate SQL or an arbitrary formula in place of that field descriptor.

Documented tile query scopes are `all`, `assignedTo` and `createdBy`. Do not copy List's `modifiedBy` scope into a tile. The original draft says an empty `processName` permits querying across processes; ensure measures retain a coherent meaning across that scope.

`isConnected: "yes"` with `connectTo` associates the tile with a list for inspecting the records behind its query. A tile does not automatically inherit all of the list's current filters merely because they are connected. Plan direct filter coverage separately. [DRAFT Tile settings; G-OBS tile widgets]

### 7.4 List widget

Key settings include:

| Setting | Contract / guidance |
| --- | --- |
| `fields` | Ordered projections and columns, including hidden dependencies and custom HBS columns. |
| `conditions` | Fixed list predicates and possibly captured incoming/runtime state in exports. Preserve the distinction. |
| `processName` | String or null; empty/null can intentionally span processes. |
| `queryType` | `all`, `createdBy`, `assignedTo`, `modifiedBy`. |
| `pageSize` | String, such as `"20"`. |
| `sorting`, `search`, `filtering` | `"yes"`/`"no"` settings. |
| `pagingMode` | `"no"` for traditional paging or `"loadMore"`. |
| `showAdd`, `defaultAdd` | Separate settings; do not collapse them. |
| `showDelete`, `enableBulkDelete` | Distinct deletion-related options. |
| `showHistory`, `enableExport` | Separate history/export controls. |
| `exportdataFormat` | Exact spelling; `csv`, `odata`, `excel`. |
| `sortBy` | A field selector; preserve its scope/type/identity. |
| `sortByDir` | `desc` is observed; the supplied sources do not establish a full enum. |
| `enableEmptyListTemplate`, `emptyListTemplate` | String flag plus HTML empty-state content. Arbitrary HBS capability is not established here. |
| `processSource` | `own` observed; full semantics unresolved. |

The registration defaults in the old draft include `sorting: "yes"`, `search: "yes"`, `pageSize: "20"`, `showAdd: "yes"` and `showDelete: "yes"`. These are not a requirement to enable every action in AI-authored pages.

**Recommended new-page policy:** expose only the actions the user needs; use `showDelete: "no"` and `enableBulkDelete: "no"` unless deletion is explicitly part of the design. That is an authoring decision, not a claim that the platform defaults changed. For cross-process lists, do not assume that an Add control has an unambiguous destination. [DRAFT List registration/settings; G-OBS /widgets/7/settings; G-PROJECT /widgets/4/settings]

### 7.5 Chart v1

Documented chart types are `pie`, `bar` and `line`. Relevant settings include `conditions`, `queryType`, `isConnected`, `chartType`, `value1Exp`, `isLimited`, `showValue`, `hideLegend`, `processName`, `connectTo`, `labelsField`, `valueField1` and `container`.

The gold charts use `value1Exp: "Count"` and also contain `value2Exp: "Count"`. The exact spelling and full configuration for other chart aggregations or a second series are not established. Do not derive them from tile values or infer an underlying chart library's API.

Observed optional settings include integer `pageSize`, `widthType: "customWidth"`, `heightMode: "fixed"`, `sortLegend: ""` and `labelFormat: "text"`. These observations do not establish complete enums or dimension-setting names.

Resolve grouping/measure fields with the correct system/process descriptor shape. Connect to a list when drill-down is requested; explicitly include the chart in any applicable filter connections. [DRAFT Chart settings; G-OBS /widgets/1 through /widgets/3]

### 7.6 Filter widget

Verified authoring input modes are `dropdownlist`, `radiolist`, `freetext` and `daterange`; sources include `manual` and `datasource`. The schema keeps these strings open because the observed modes are not confirmed exhaustive. For new generation, use the verified modes unless component evidence supports another.

Manual selection options are a newline-separated string, not an array of `{label,value}` objects. Do not rename stored values merely to improve labels.

A Kianda datasource filter can use an outer `datasource: "kianda-data"`, `settings.list`, `displayField`/`processDisplayField` and `valueField`/`processValueField`. The display value and returned value may differ. In the project example, Country displays `title` and returns `code`; Location displays `displayName` and returns `code`.

`settings.list` may contain `text`, `name`, `type: "process"`, `processName`, `process`, numeric `page`, `isFilterWidget` and `filterWidgetId`. That nested numeric `page` is not the widget's owning-page alias. Do not claim a complete paging meaning from its observed zero value.

Use [queries and filters](./queries-filters.md) when configuring query connections or runtime state. A filter's source-options query is not the same as its predicates over target records. [G-OBS filters; G-PROJECT /widgets/1 through /widgets/3 and /widgets/5 through /widgets/7]

### 7.7 Walkthrough widget

The source examples use `steps`, `autoStart`, `returnOnEnd`, `autoStartAdmin`, `container` and `conditions`. Auto/return settings use `"yes"`/`"no"` strings. Steps contain GUID `id`, `title`, `type`, `content`, `element`, `placement` and sometimes `position` or the capitalized property `Url`. Observed types are `popup` and `click`; neither their completeness nor `Url`'s full semantics are established.

Keep step order, identities and selectors during edits. Selectors can depend on titles, CSS classes, navigation items or process fields, not only widget GUIDs. For a new guide, use actual verified DOM targets and supported interactions. Do not invent selectors or automatically submit business records as part of onboarding.

Eight legacy step-content strings contain script tags. Their presence does not prove execution, approval or portability. Do not impose the HTML-widget serialization restriction on every unrelated string surface, and do not copy old scripts into a new guide merely because an export contains them. [G-HOME walkthrough widgets; HANDOVER sections 7.8, 11.2]

### 7.8 Known carousel and other tenant widgets

The known carousel uses `isCustom: true`. Observed settings include `slides`, `showBtn`, `fullBanner`, `bannerHeight`, `container` and `conditions`; the data-bound example adds `list` and `parameter`. Slides contain `url`, `title`, `btn` and `_title`. Only empty `btn` arrays are available; do not fabricate a populated button structure.

The project carousel uses `parameter: "project"` and component-specific tokens such as `[description]`, `[location]`, `[code]`, `[locationURL]` and `[__NAME]`. These are not Handlebars and do not establish a global page interpolation syntax. The component must be present in the destination workspace, with compatible source/field/token contracts.

Unknown tenant settings are preserved with a coverage warning. Do not interpret every tenant property named `conditions`, `fields` or `id` as a native Kianda model. Side-loaded schemas remain a [future direction](./validation-evidence.md#17-tenant-add-on-schemas-future-direction). [G-HOME /widgets/0; G-PROJECT /widgets/0; HANDOVER sections 3.1, 7.9]
