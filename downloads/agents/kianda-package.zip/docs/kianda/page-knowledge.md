# Kianda page authoring — entry guide

**Contract baseline:** draft **v1.0.0**, updated **23 October 2026**. **Companion:** unchanged [page-schema.json](./page-schema.json), Draft 2020-12, local identifier `urn:kianda:page-schema:1.0.0`. The package is a proposed first version, not an owner-accepted release or runtime certification. Documentation navigation was reorganized **4 November 2026**.

## Read by task

Read the relevant topic and actual affected definitions. No full-guide chain is required.

| Task | Direct reference |
| --- | --- |
| Root properties, widget envelope, exact wire types, containers | [Model](./page/model.md) |
| Bind process fields, system descriptors, hidden projections, component availability | [Bindings](./page/bindings.md) |
| Configure HTML/tile/list/Chart v1/filter/walkthrough or installed carousel | [Widget contracts](./page/widgets.md) |
| Conditions/operators, filter connections, defaults/URL/clear, cascades, dates | [Queries and filters](./page/queries-filters.md) |
| HBS columns, helpers/actions, native Link items | [Templates and navigation](./page/templates-navigation.md) |
| Access or role-sensitive app | [Security policy and administrator handoff](./page/security.md) |
| New document, targeted edit, clone or dependency rename | [Editing](./page/editing.md) |
| Layout/utilities or a list in `Content` | [CSS entry](./css-style-guide.md); [Content first-column contract](./styling/page-lists.md) |
| Need a starting composition or inline JSON example | [Examples](./page/examples.md) |
| Validator setup, diagnostics, unresolved claims or provenance | [Validation and evidence](./page/validation-evidence.md) |
| Implement a custom page component or Summaries client | [Addon entry](./custom-addon-knowledge.md) |

## Required authoring boundaries

- Author complete page JSON; zero widgets is valid. Do not persist the historical patch-transport keys (`status`, `changes`, `removePaths`, `widgetOrder`, `baseRevision`, temporary `new:*` IDs).
- New pages use equal, readable, non-GUID `id` / `name` and a workspace-unique alias. `title`, `settings`, `widgets` are required by this complete-document profile. Server audit fields may be omitted; do not invent audit events.
- New placed widgets, shared query groups and individual page conditions need GUIDs. References retain actual scoped process identities; copy exact field `name` and outer `type` to selector `fieldType`. Process objects follow the separate process contract.
- For edits, preserve identities, aliases, order, exact wire types/casing, content, unknown settings, unrelated metadata/security, base predicates and runtime snapshots. Compatibility acceptance does not justify broad normalization or invent new capabilities.
- Author filter relationships in `settings.connections`. Do not seed captured selections, `filterId` or incoming target mirrors. Defaults apply first; query strings override on render. Filters and tile/chart drill-down are separate mechanisms.
- Keep relative operators in saved configuration; let runtime compute boundaries. Date-range conversion uses the end user's timezone. Mixed Boolean precedence and boundary edge cases remain qualified in the query reference.
- New native Chart v2 authoring is excluded in V1; preserve existing Chart v2 definitions. Unknown tenant settings get a coverage warning; missing installed code is a separate availability problem.
- **New principal permissions stay unconfigured in V1.** Preserve existing restrictions. A role-sensitive app needs the linked administrator handoff and remains pending for role-restricted release. Page `visibleTo` restricts loading; widget/Link visibility, filters and hidden navigation cannot protect downloaded data by themselves.
- A native list with custom HBS remains a native widget. Use `row.name` for instance identity. `Content` hides list headers and every cell after the first; retain projected data required by the template.

Use Material Design principles through verified Kianda components and Bootstrap 3 styling. The owner’s design objective does not imply another framework, font/icon package or new settings. Apply the shared [design/review guidance](./styling/design-review.md) only when presentation changes.

Strict JSON/schema checks, semantic dependency checks and target-runtime acceptance are separate. Configure validation without coercion/default insertion/property removal; enable `uuid`/`date-time` checks. Report actual checks and publication status under root policy. Historical source-package exports, fixtures and validation reports named in references are not present in this bootstrap and were not re-tested by this reorganization.
