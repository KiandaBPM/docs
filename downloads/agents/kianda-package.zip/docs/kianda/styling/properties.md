# Persisted styling properties

Source-based topic reference from [css-style-guide.md](../css-style-guide.md). Original section numbers are retained for source citations; evidence status and unresolved qualifications are unchanged. Source labels and snapshot limits are in [styling evidence](./source-evidence.md#10-known-limits-and-source-register).

## 3. Put styling in the correct property

| Object or location | Property or mechanism | Instruction |
| --- | --- | --- |
| Process field | `field.class` | Current persisted layout class string. Use for grid classes such as `col-sm-12`. Preserve the exact key. |
| Process field | `field.customCssClass` | Additional visual or behaviour-associated class tokens, such as `panel-card`. |
| Process field | `field.settings.mobileClass` | Existing nested mobile layout setting. Keep it nested and preserve its value unless deliberately changing the layout. Its precedence against other layout settings requires runtime inspection. |
| Process static text | `field.text` and `field.settings.controlBgScheme` | Content and documented background treatment for `fields/field-text`. These are distinct from its logical `name` and design `title`. |
| Page widget | `widget.class` | Responsive widget layout string. Use the existing Bootstrap 3 vocabulary. |
| Page widget | `widget.customCssClass` | Additional utility classes, such as `widget-section-title` or `widget-filter-compact`. |
| Page widget | Outer `widget.colorScheme` | Widget frame treatment; `panel-default` is documented. This does not establish the same property on a process panel. |
| Page container | `page.settings.containers[]` entries with `name`, `desktopClass`, `mobileClass` | Container layout declarations. A widget selects one through `widget.settings.container`. |
| Native page Link item | Item-level `cssClass` | A separate, real property in that item's contract. Do not globally replace every `cssClass` in a page. |
| Custom component template | Classes on HTML elements the component owns | Use stable, scoped classes and follow the component's actual rendering contract. Inspect the outer field/widget wrapper separately. |
| Workspace global stylesheet | `styles/app.css` in the proposed workspace layout | Shared styling with potential impact across applications. The extension's server filename mapping is a separate concern. |

Both field and widget layout use `class`, not `cssClass`. The process schema accepts an existing field `cssClass` for compatibility, but its documentation explicitly says that the proposed rename was not implemented. Schema acceptance does not establish how an extension or server will retain that property. Preserve unfamiliar existing data; generate the current `class` property. [PROC §6, §14.1; PS `$defs/Field`; PAGE §4–6; PG `$defs/Widget`, `$defs/LinkItem`]

Class values are tokens without a leading dot. Multiple tokens are separated by spaces. For example, `customCssClass: "section-title expandable-section"` contains two classes. Retain unrelated tokens when adding or removing a treatment. A token such as `expandable-section` does not by itself establish that an expand/collapse interaction exists. [PROC §14.1, §14.5]

Do not turn native settings into CSS merely to simplify serialization. Buttons have their own documented presentation settings, and list settings control whether an input is a radio list or a checkbox list. Styling does not change selection semantics or save behaviour.
