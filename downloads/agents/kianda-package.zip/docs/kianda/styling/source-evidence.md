# Styling source observations and limits

Source-based topic reference from [css-style-guide.md](../css-style-guide.md). Original section numbers are retained for source citations; evidence status and unresolved qualifications are unchanged. Source labels and snapshot limits are in [styling evidence](./source-evidence.md#10-known-limits-and-source-register).

## 2. Styling sources and availability

### 2.1 Documented defaults and workspace overrides

The internal styling guide describes ten utilities shipped with the default global CSS. It explicitly allows workspace changes and overrides. Seven utilities target process fields and three target page widgets. Treat them as documented defaults with a known intended use, while checking the actual target workspace before relying on their appearance. [STYLE pp. 1–3]

The supplied `app.css` starts with an external `@import` of an EHSwise public `app-style.css`, followed by a comment identifying workspace-specific CSS. Its local declarations implement several application-specific treatments. The imported stylesheet was retrieved on 27 October 2026 and inspected completely: it contains selectors for all ten documented utilities. The source-observation table below records implementation details and differences from the prose guide. This is evidence for that inherited EHSwise snapshot, not proof that every customer loads the same source. [CSS; SHARED]

The import is a dependency of that particular workspace. Preserve its intended role when editing that workspace; do not copy its tenant-specific URL into a generic Kianda application or replace a target's import as part of an unrelated styling task. The inherited source itself imports Animate.css 4.1.1. That is an observed dependency of this snapshot, not a required Kianda dependency or evidence that the animation stylesheet has loaded in every runtime. [SHARED]

An effective style can depend on the inherited stylesheet, local overrides, selector specificity, loaded framework styles and the rendered DOM. A utility's documented name is not proof that its source has loaded or that an overriding declaration has not changed it.

### 2.2 Source authority

Use the following distinctions throughout this guide:

| Evidence | What it establishes | What remains to be checked |
| --- | --- | --- |
| Internal styling guide | Intended utilities, component context and UI configuration labels | Current declarations, active overrides and computed appearance |
| Process/page knowledge and schemas | Persisted property names, supported shapes and documented behaviour | Rendered usability and component-specific behaviour outside those contracts |
| Inspected stylesheet | Exact declarations and selectors in that source snapshot | Whether the target loads it, whether selectors match and how the cascade resolves |
| Existing application JSON | How a particular saved application is configured | Whether its configuration is current, supported for a new application or appropriate for another tenant |
| Runtime inspection | Appearance and behaviour observed in the tested environment | Untested devices, data sets, permissions and other environments |

The source register at the end identifies the evidence used. Do not promote a tenant class or a visually plausible result into a universal platform feature.

### 4.4 Details verified in the inherited stylesheet

These are exact source observations from the retrieved snapshot, not mandatory branding tokens or computed runtime results. Other declarations can change the outcome. [SHARED]

| Utility | Verified selector or treatment | Practical implication |
| --- | --- | --- |
| `panel-card` | `.panel-card.form-group`: white background, 12px radius and `#e7eaee` border | Requires the expected wrapper classes. The separate `.card-panel` selector has a 10px radius; these names are not interchangeable. |
| `radio-list-card` | `.radio-list-card.form-group>div>span>label`: white cards, shadow, 4px radius, padding and negative left margin | Depends on native list markup. Inspect narrow layouts and overflow. |
| `checkbox-list-card` | `.checkbox-list-card.form-group>div>div`: white cards, shadow, 4px radius and padded content | Uses a different descendant structure from radio cards. |
| `radio-list-button` | Flex wrapping and label/overlay styling; exact value selectors for `OK`, `NOK` and `N/A` | Those selectors provide green, red and grey treatments respectively. The local Yes/No rules apply only to `?inlineButtons`, not this class. |
| `section-title` | `.section-title.form-group` removes shadow, uses 4px corners and bottom margin; nested `.field-richtext-content` is `1.4em` | The rule does not supply a background colour. Preserve the native background setting. |
| `table-no-style` | Removes panel/table treatments, hides `thead`, allows visible horizontal overflow and changes footer/link spacing | More than a cosmetic border change. Review headings, row controls and wide content. |
| `image-thumbnails` | Flex layout; nested `img` uses 110px width/height, 5px corners and `object-fit: cover` | These dimensions belong to this snapshot. Thumbnail cropping is confirmed in source. |
| `widget-filter-tabs` | Horizontally scrollable inline-flex form; selected `.radio-filter.is-checked` gets transparent background; `.radio-filter span.fa` is hidden | Check selection and focus remain perceivable without the hidden icon. |
| `widget-section-title` | `.page-widget.widget-section-title>.panel` removes background, border, shadow, margin, radius and padding | No lower separator is declared here. Verify any expected separator through the remaining styles or deliberately add a scoped treatment. |
| `widget-filter-compact` | Heading padding is 5px with 15px on the left; body padding is 5px | Compactness is a source-specific frame treatment. Check labels, focus and controls remain usable. |

For `radio-list-button`, a later generic checked-state rule has `background: none !important`. The value-specific rules also use `!important` and have higher specificity, so source order alone is not enough to explain a colour difference. Inspect the actual stored value, matching selectors and complete cascade. Preserve values used by rules and integrations; change presentation deliberately instead of renaming values to obtain a colour.

## 6. What the supplied workspace stylesheet actually contains

The following observations describe the local declarations in the supplied `app.css`, applied in addition to the inherited source. They are useful examples of dependency and regression concerns, not a portable Kianda utility catalogue. [CSS]

| Selector or family | Source behaviour | Consequence for an agent |
| --- | --- | --- |
| `div[data-name$="?inlineButtons"] .c-radio input[type=radio][value="Yes"]:checked+span` and the `No` variant | Sets a green/red border and translucent background on an adjacent `span`; the background uses `!important` | Requires that exact runtime markup, value spelling and `data-name` suffix. This source does not establish an association with `radio-list-button`. |
| `.expiry-badge-green`, `.expiry-badge-expiring`, `.expiry-badge-expired` | Shared pill-like layout with separate green, orange and red backgrounds, white text and a hover opacity change | Application-specific expiry presentation. Pair with readable status text and inspect actual contrast and states. |
| `#checklist-cards` | Column flex layout, fixed maximum height, shadow and both axes set to hidden overflow | The comment claims vertical scrolling, but `overflow-y: hidden` clips overflow. Assess long-content access before copying or changing the pattern. |
| `div[title="Checklist"] ...` | Styles nested panels, tables and links, removes some decoration and hides `.panel-footer` | Tied to an exact title attribute and broad descendants. Check title changes, localization, footer controls and all matching widgets. |
| `.checklist-item` with `.priority-box` and `.description-box` | Flex links with a 30%/70% split and fixed padding | A tenant card pattern. Check wrapping, long text and narrow-screen reading order. |
| `.checklist-link` | Link spacing, size and pointer cursor | Visual declarations alone do not establish a keyboard-operable action. Inspect the actual element and action wiring. |
| `.clearFiltersButton` | Button-like presentation with padding, background, text colour, border removal and `float: right` | Preserve the actual filter-clear action. Inspect focus, disabled state and layout in the rendered context. |
| `.slide-title-wrapper` and descendants | Flex layout and positioning for a title and image, with the image prevented from shrinking | Application-specific title/image placement. Inspect long titles, image size and constrained widths. |

Do not copy these exact names into unrelated applications simply because they are available in this example. Inspect whether a new component already has an established local pattern. Existing broad or title-dependent selectors should be reviewed when the affected application is changed; their presence is not a request to refactor all shared styling.

The inherited source also contains application-shell changes, named-field selectors, repeated `.dashlist-*` declarations and broad rules. For example, `.common-table td, th` includes an unscoped `th` selector. Review the complete cascade rather than assuming every rule is restricted to its nearby comment or prefix. [SHARED]

## 10. Known limits and source register

The following items require target-specific evidence before making a new claim:

- The process panel setting corresponding to the UI's `panel-default` colour choice.
- Which inherited and local styles are loaded in a particular customer workspace, and whether they are overridden.
- An approved cross-workspace palette, font/type scale, numeric spacing/radius system or customised breakpoint policy.
- The actual accessibility and interaction behaviour of a styled native control or custom component.
- Whether a tenant class or helper should be promoted to a shared platform contract.

| Key | Source | Use in this guide |
| --- | --- | --- |
| STYLE | `Kianda Process Apps Styling Guide(1).docx`, supplied 27 October 2026; all three rendered pages inspected | Ten utility names, intended components, UI configuration labels, default-global-CSS statement and override guidance |
| CSS | `app.css`, supplied 27 October 2026; complete file inspected | External inherited stylesheet dependency and exact local workspace selectors/declarations |
| SHARED | Public `app-style.css` referenced by the supplied `app.css`; retrieved 27 October 2026; 73,508 bytes; SHA-256 `da1c59a5e27837e23abf74eac5346c5ff8cd130552f292d38f7c10f5cff1969e` | Complete inherited source inspection: ten utility selectors, value-specific styling, Content behaviour, dependencies and cascade caveats |
| PROC | `process-knowledge.md` from `kianda-process-schema-v1.1.0(1).zip`; particularly §§2, 6 and 14 | Current field layout property, branding objective, utility recipes, observed settings and limitations |
| PS | `kianda-process-schema.json` from that process package | Shapes and comments for field presentation properties and native settings; installed companion filename is `process-schema.json` |
| PAGE | `page-knowledge.md` from `kianda-page-authoring-v1.0.0(1).zip`; particularly §§4–6, 12–13 and 15.3 | Widget/container properties, page utilities, Content container behaviour, visibility boundaries and heading example |
| PG | `kianda-page-schema.json` from that page package | Widget, container and Link-item property contracts; installed companion filename is `page-schema.json` |

Package statements about earlier example exports and owner confirmations are cited as package evidence. Their historical runtime environments were not independently reproduced for this guide. The DOCX was rendered to verify its content and table coverage; that is not a runtime preview of a Kianda application. This reference does not alter the supplied schemas or their validation scope.

The [inherited stylesheet source URL](https://app.ehswise.com/public-file/d7bcf632-40ec-4f5e-bc24-62848bd9f90d/app-style.css) is provenance for the inspected snapshot, not a recommendation to adopt that tenant URL as a universal runtime dependency. The URL can change content; the retrieval date and hash identify the inspected bytes. Transitive imports were not independently reviewed.
