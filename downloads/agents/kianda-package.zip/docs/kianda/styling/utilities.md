# Process and page styling utilities

Source-based topic reference from [css-style-guide.md](../css-style-guide.md). Original section numbers are retained for source citations; evidence status and unresolved qualifications are unchanged. Source labels and snapshot limits are in [styling evidence](./source-evidence.md#10-known-limits-and-source-register).

## 4. Documented utility catalogue

The following class names are clean tokens transcribed from the internal guide. Invisible U+200B characters found after some class names in the DOCX have been removed in this reference. Do not copy those invisible characters into application JSON or selectors. [STYLE]

### 4.1 Process field utilities

| Class | Intended field and configuration | Documented effect | Important limit |
| --- | --- | --- | --- |
| `panel-card` | `fields/field-panel`; guide UI choice: Colour scheme = `panel-default` | White rounded panel grouping related content | The process panel's serialized key for that UI colour choice is unresolved; preserve saved settings or obtain a confirmed example. |
| `radio-list-card` | `fields/field-list`; Radio list; Vertical position | Full-width white choice cards with rounded corners | Retain single-selection behaviour and the actual option values. The guide recommends using its own surface outside another card where suitable. |
| `checkbox-list-card` | `fields/field-list`; Checkbox list; Vertical position | Corresponding card presentation for multiple selections | A checkbox list remains multi-select. Do not swap its mode for a different appearance. |
| `radio-list-button` | `fields/field-list`; Radio list; Vertical position in the guide's recipe | Rounded button treatment for choices; the guide describes possible Yes/No colours | The inspected implementation targets different exact values; see [source observations](./source-evidence.md#44-details-verified-in-the-inherited-stylesheet). Existing horizontal configurations are observed and should not be automatically rewritten. |
| `section-title` | `fields/field-text`; background choice `bg-primary`, `bg-warning`, `bg-info` or `bg-success` | Larger static section text with a background treatment and soft corners | Styling `field.text` does not prove semantic heading markup or an accessible name. |
| `table-no-style` | `fields/field-table` | Removes usual table borders/shading for compositions such as repeating cards | Preserve repeating row structure, operations and data. This is a field-table utility, separate from the page `Content` treatment. |
| `image-thumbnails` | `fields/field-image`; File field source; inline images enabled | Consistent thumbnail presentation; the guide describes `object-fit: cover` | Cropping can hide evidence details. Preserve a supported way to inspect the original image. |

Sources: [STYLE pp. 1–2; PROC §14.2–14.4]. These recipes are not mandatory schema properties. Do not apply every class to every type of field.

### 4.2 Exact process settings and unresolved mapping

| Desired configuration | Source-supported representation |
| --- | --- |
| Radio list | `settings.displayformat: "radiolist"` |
| Checkbox list | `settings.displayformat: "checkboxlist"` |
| Vertical list | `settings.radiodisplayposition: "vertical"` |
| Static section background | `settings.controlBgScheme: "bg-primary"` is observed with `section-title`; the styling guide also documents the other background choices above |
| Images from a file field | `settings.imagesource: "file"`, `settings.inlineImages: "yes"`, and an actual field descriptor in `settings.fileSource` |
| Process panel UI colour choice `panel-default` | Serialized key/value mapping remains unresolved in the supplied process contract |

For a process panel, neither the open `settings` object nor a similarly named widget property justifies inventing `settings.colorScheme`. `settings.cardPanel` is also distinct from `customCssClass: "panel-card"`; the package records empty-string `cardPanel` values and does not define a conversion between the two. [PROC §14.1–14.3; PS `$defs/PanelSettings`]

The following is a property excerpt for an existing field, not a complete field definition or a destructive replacement of its `settings`:

```json
{
  "type": "fields/field-list",
  "class": "col-sm-12",
  "customCssClass": "radio-list-button",
  "settings": {
    "displayformat": "radiolist",
    "radiodisplayposition": "vertical"
  }
}
```

Retain identities, choices, source bindings, rules and any other settings. Obtain actual stored values from the target application. The process guide distinguishes `radio-button-list`, observed in some existing data, from the documented `radio-list-button`; they must not be silently treated as interchangeable. [PROC §14.2–14.4]

### 4.3 Page widget utilities

| Class | Intended widget and configuration | Documented effect |
| --- | --- | --- |
| `widget-filter-tabs` | `widgets/widget-filter` with `settings.filterType: "radiolist"` | Presents radio options as a tab-like strip above the connected results region |
| `widget-section-title` | `widgets/widget-html` using `colorScheme: "panel-default"` | Guide describes a cleared frame background and faint lower separator; the inspected rule clears the frame but does not add that separator |
| `widget-filter-compact` | `widgets/widget-filter` | Reduces padding around the frame |

Apply these through `widget.customCssClass`. Process-field utilities do not automatically apply to page widgets with different markup. [STYLE pp. 2–3; PAGE §6.2]

A tab-like appearance does not create filter connections, routes or page security. Configure the real filter and its target connections using the page contract. Preserve default values, runtime state handling and query semantics. Do not add tab roles or keyboard assumptions unless the rendered widget implements the corresponding interaction.

An HTML heading widget should avoid repeating the same title in both its frame and inner content. The following is a partial presentation excerpt; retain the widget's identity, owning page and other settings:

```json
{
  "type": "widgets/widget-html",
  "class": "col-md-12 col-sm-12",
  "showHeader": false,
  "colorScheme": "panel-default",
  "customCssClass": "widget-section-title",
  "settings": {
    "container": "",
    "content": "<h2>Project overview</h2>"
  }
}
```

Choose the heading level for the surrounding document structure. The example's text is illustrative, and `showHeader: false` is a deliberate choice for this composition, not a required value for every widget. [PAGE §15.3]

## 5. Composition rules that preserve application behaviour

### 5.1 Sections and cards

Use a static text field with `section-title` to establish a meaningful process section, followed by a `panel-card` containing related inputs where grouping helps the task. Keep the section's content separate from field naming and identity. Choose an existing palette treatment instead of assigning different colours to every section. Maintain consistent spacing between headings, cards and primary actions. [PROC §14.4–14.5]

Avoid unnecessary layers of nested cards. The card-style radio and checkbox lists already have their own surface treatment. Select the treatment that communicates the grouping without making every input appear equally prominent.

### 5.2 Repeating cards inside a process table

The process package documents `table-no-style` on a table with a `fields/table-row` child. Inside that row, the first child is a `fields/field-panel` using `panel-card`; the panel contains the repeated business fields. [PROC §14.4]

Preserve the full table/row/descendant structure, field scope, row operations and bindings. Repeated content still has a table lifecycle. Do not flatten it into unrelated panels or duplicate fixed panels to imitate repetition. The observed recipe does not require every table to contain exactly one panel or a particular number of stored rows.

### 5.4 Uploads and thumbnails

Use the existing file field for upload and bind a separate image field through a verified descriptor when that composition is appropriate. `image-thumbnails` changes presentation; it does not establish upload, image deletion, annotation, public access or click-to-enlarge behaviour. Check those capabilities in the actual controls. Give users a supported way to inspect evidence at sufficient detail, since a cropped preview can hide relevant content. [PROC §14.3–14.4]
