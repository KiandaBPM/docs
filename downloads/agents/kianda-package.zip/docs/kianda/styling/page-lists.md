# Page lists in the Content container

The exact container name `Content` selects owner-confirmed styling that hides list headers and every body cell except the first. For a card list, place the rendered card column first and retain hidden projections required by its HBS. Review every list in that container; ordinary multi-column tables need a different container such as `Results` or a verified scoped override.

The owner-supplied CSS below is provenance, not an instruction to inject duplicate styles. Workspace overrides are possible. The later inherited EHSwise snapshot independently contains the header and first-column hiding selectors, but its nearby `table-layout: fixed` selector is preceded by a stray `*/`. Do not assume that malformed rule applies or copy it. See [snapshot evidence](./source-evidence.md).

```css
div[data-container="Content"]>div.widget-list .table-responsive {
  overflow: visible;
}
div[data-container="Content"]>div.widget-list .table {
  table-layout: fixed;
}
div[data-container="Content"]>div.widget-list div.panel {
  -webkit-box-shadow: none;
  box-shadow: none;
  background: none;
}
div[data-container="Content"]>div.widget-list a:hover,
div[data-container="Content"]>div.widget-list a:focus {
  text-decoration: none;
}
div[data-container="Content"]>div.widget-list .table-bordered>thead {
  display: none;
}
div[data-container="Content"]>div.widget-list .table-bordered>tbody>tr {
  background: none;
}
div[data-container="Content"]>div.widget-list .table-bordered>tbody>tr>td {
  border: none;
  white-space: normal;
  padding: 5px 2px;
}
div[data-container="Content"]>div.widget-list .table-bordered>tbody>tr>td:not(:first-child) {
  display: none;
}
div[data-container="Content"]>div.widget-list .panel-footer {
  background: none;
  border: none;
}
```

Preserve container names unless intentionally changing their references and CSS consumers. Container declarations and the widget array are both ordered; exact cross-container rendering remains unresolved. [Original PAGE §§6.1, 6.3; CSS §5.3]
