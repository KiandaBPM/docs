# Interface design and review

These are **authoring recommendations**, derived from original CSS §§1, 5.5, 7–9 and PAGE §§2, 6.4. They do not add JSON properties or certify rendering. Evidence labels are in [styling evidence](./source-evidence.md).

## Design within the installed interface

Apply the owner's clean, professional enterprise/Material Design objectives through Kianda controls, the existing Bootstrap 3 grid and verified workspace styles. A Material library, font, icon set or token system is not implied. Use purpose and context before detail, clear grouping, one distinguishable primary action, intentional whitespace, consistent typography and meaningful feedback. Adapt density to the task: a mobile inspection and a reporting table need different spacing.

Use live bound widgets for live metrics; historical home-page figures from 2025 are not current data. Prefer native filters, charts, lists and launchers where configuration suffices. Do not invent `loadingTemplate`, `errorState` or equivalent settings. Avoid repeated widget-frame/inner headings and unnecessary nested cards; radio/checkbox card lists already have their own surface.

Keep the existing font, hierarchy, long labels and instructions readable through wrapping and layout. The source establishes no mandatory numeric spacing/radius scale, font family/type scale or customised breakpoint policy. Use approved workspace design choices. Bootstrap 3 examples include process `col-sm-12` / `col-sm-6` and widget `col-md-12 col-sm-12`; do not require all siblings to total twelve, assume standard breakpoints override Kianda/tenant rendering, or introduce Bootstrap 5 utilities. Grid wrappers belong only in markup the template owns, not an invented JSON wrapper.

Pair colour with text/icons or another usable cue. Review foreground/background combinations in hover, focus, selected/unselected, validation/error, disabled and read-only states. Yes/No desirability depends on the question; preserve labels and stored values. Original process guidance uses WCAG 2.2 text-contrast review targets of 4.5:1 for ordinary text and 3:1 for qualifying large text, subject to criterion definitions/exceptions. These are review criteria, not a compliance claim.

Preserve visible focus, readable labels, useful errors, semantic headings and keyboard actions. A coloured section band, styled `div` or pointer cursor does not create those semantics. Check focus/reading order, zoom, small viewports, long translated labels and repeated rows. Preserve access to full evidence behind cropped thumbnails and clipped/scrollable content. Avoid distracting animation and respect the workspace's established reduced-motion treatment. CSS hiding does not provide authorization or remove projected data.

## Add CSS only for a concrete gap

Inspect the owning field/widget/component, existing utilities, inherited styles, local overrides and rendered wrapper before adding a rule. Scope new CSS to markup you own, with a unique prefix. For example, this **illustrative, uninstalled** pattern demonstrates scoping only:

```html
<div class="inspection-summary">
  <h3 class="inspection-summary__title">Inspection summary</h3>
  <p class="inspection-summary__details">Details rendered by the component.</p>
</div>
```

```css
.inspection-summary .inspection-summary__title {
  margin-top: 0;
  overflow-wrap: break-word;
}
.inspection-summary .inspection-summary__details {
  margin-bottom: 0;
  overflow-wrap: break-word;
}
```

Use the target's colours, typography, borders and spacing; those example values are not platform defaults. Keep escaped binding and semantic content consistent with the template contract. Prefer owned classes to translated titles, generated Ember IDs, temporary DOM order or broad descendants. `customCssClass` may be on an outer wrapper. Explain any necessary specificity or `!important` override and keep it narrow. Preserve unrelated imports/rules; a new remote font/framework/stylesheet requires an intentional dependency change.

## Verify the affected behaviour

| Check | Scope |
| --- | --- |
| Static | Parse/schema-check changed definitions; verify property placement, exact class tokens/casing/invisible characters, native settings and container references; inspect declarations/imports/overrides and selector consumers. |
| Data and structure | Preserve process rows, field descriptors, projections, queries, connections, rules, values and permissions. Review hiding, footer controls, height limits, removed focus and table-display changes. |
| Runtime when available | Verify styles load/match; test wide/narrow views, zoom, long labels, empty/populated content and repeated rows; inspect all relevant interaction states, accessibility, row operations, filter clear, navigation and uploaded evidence. |
| Shared changes | Review other consumers of shared styles or reusable components; check actual contrast, visible focus, accessible names, headings and feedback. |

Follow the root change-record policy. Report schema/source inspection separately from computed-style, interaction and accessibility checks. If the target cannot be opened, state the remaining runtime review; a schema pass cannot establish appearance, wrapping, visibility or interaction correctness.
