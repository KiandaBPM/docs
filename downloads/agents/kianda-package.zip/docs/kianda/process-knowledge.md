# Kianda process-app authoring knowledge

**Baseline:** accepted `1.1.0`, owner confirmations through 23 October 2026. **Documentation:** compact routing revision, 4 November 2026; no schema change.  
**Schema:** [process-schema.json](./process-schema.json), local identifier `urn:kianda:process-schema:1.1.0`. **Scope:** complete process definitions, forms, recursive fields, rules, conditions, mappings and settings. A definition is distinct from a submitted business-record instance.

## Read by task

Open the relevant reference; a focused edit does not require every guide or full schema text. Validate JSON programmatically and inspect specific schema definitions when needed.

| Work | Reference |
| --- | --- |
| Structure, aliases/IDs/names, forms, tables or Components | [Model and identity](./process/model.md) |
| Field types, values or textbox/number/list settings | [Fields and exact settings](./process/fields.md) |
| Rules, Set field expressions/helpers, lifecycle, scheduling, conditions or mappings | [Rules and references](./process/rules.md) |
| Validation, extension coverage or unresolved contracts | [Validation and limits](./process/validation.md) |
| Stages, forms/sections, branching, validation/navigation or visual composition | [Process design guide](./process-design-knowledge.md) |
| Styling utilities/settings | [CSS guide](./css-style-guide.md); [process visual evidence](./process/presentation-evidence.md) only for its historical examples/limits |
| Provenance, corpus counts or historical discrepancies | [Evidence register](./process/evidence.md) |

## Working contract

- Preserve requested scope, existing identities/names/order/security, arbitrary settings and unrelated metadata. Display edits do not imply renaming. Report unrelated defects; do not silently clean up or migrate.
- Index actual entity collections and affected dependencies. Settings descriptors are not children. New local entities need fresh GUIDs and correct rewritten references; external identities are not clone targets. Table-row name scopes and Component loading/versioning require their specific model contracts.
- Preserve wire types, casing, empty values and omissions. Use verified settings; an open schema does not authorize invented properties. No copied principals, tenant URLs, timestamps, audit users, business-record values or dependency IDs as new-app defaults.
- Preserve rule attachment/order. Omitted `hasElse` defaults false; alternate settings belong to the same action. Left-only Set field clears its destination. Executing schedule targets and active settings require semantic resolution beyond schema acceptance.
- Treat stages, adaptive journeys and branding as design work. Apply professional, authoritative, clean interfaces with hierarchy, whitespace, consistent type and responsive native controls. Layout uses `field.class`; additional styling uses `field.customCssClass`. Do not rename layout to `cssClass`.

Establish the design/dependencies, make the scoped change, then check structure, integrity and relevant rendered/runtime behavior. Keep blueprint labels, test results and orchestration metadata outside process JSON. Validation must not insert defaults, coerce/remove data, regenerate IDs, rename fields or execute production side effects. Return complete requested JSON with material diagnostics, distinguishing errors, unavailable dependencies, unknown coverage and untested behavior.

Latest **Confirmed** owner statements supersede conflicts; **Documented** guidance is scoped; **Observed** snapshots establish only what they show; **Historical** evidence is not a current default; **Proposed** policy is not runtime behavior; **Unresolved** points need evidence. Schema acceptance certifies neither execution, permission nor appearance. No application was executed when the baseline was prepared. [Source details](./process/evidence.md)
